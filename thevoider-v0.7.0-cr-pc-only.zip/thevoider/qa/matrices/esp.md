# Behavioral Acceptance Matrix — Void ESP

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 พร้อมคำตัดสิน Q1=(ข) Ken เฉพาะการแสดงผลใน ESP / Q2=(ก) / Q3=(ข) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **อ้างอิง:** แผน freeze v2.1 §2.4 (ตัวอย่างที่ 2), §4.3, §6.3, §9.1 + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `VoidESP` / L5 Feature Modules |
| Depends on | `TargetService`, `WorldAdapter`, `CameraAdapter` *(เพิ่ม v1.4 — `WorldToScreen` ระบุไว้ใน camera.lua ว่า "ใช้โดย ESP เฟส 2")* |
| Internal services (ไม่ขึ้น graph) | EspRenderer, ObjectPool, EspFilter |
| Capability gates (CG-07) | `DRAWING` — **ระดับโมดูลทั้งตัว**: ESP ทุกชนิดวาดด้วย Drawing → หาย = ปิดทั้งโมดูล + แจ้ง + โมดูลอื่นเดินต่อ (ตัวอย่างตรงตัวของ §6.3 ข้อ 2) |
| สาย adapter ที่กระทบ (CG-08) | `CameraAdapter` ตาย = หยุดวาด (ไม่มีพิกัดจอ) + แจ้ง / `WorldAdapter` ตาย = ไม่รู้ระยะ/ผู้เล่น → ปิด + แจ้ง / `PlayerAdapter` เสื่อม = ชนิดข้อมูล level/bounty หายเป็นรายชนิด (degradation รายฟีเจอร์ + แจ้ง) |
| Config root | `settings.esp.*` (โครง: `enabled`, `types.{name,level,race,ken,hp,distance,combat,bounty,indicator}`, `maxDistance`, `bountyColors[]`, `textSize`, `mode` (compact\|verbose)) |
| Keybind actions (CG-12) | ไม่มี keybind ระดับ P0 (เปิด-ปิดผ่าน UI เฟส 1) — ถ้าเพิ่มภายหลังต้องผ่าน KeybindService เท่านั้น |
| Bus events | ฟัง `config:changed`, `adapter:health` (สายกลับมา = re-activate ตามค่าตั้ง) / เผยแพร่ `module:state` |
| L4 services ที่เรียกตรง | `TargetService:GetCandidates(...)` (รายการเป้าสำหรับวาด) |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md` — พารามิเตอร์เฉพาะโมดูลของ CG-07/CG-08 ตามตารางข้อ 1 (จุดสำคัญ: ESP คือกรณี benchmark ของ "ปิด capability จำลอง → graceful disable" ชุดทดสอบถาวร §6.3)

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 2 ไม่จบ §5.5)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| ES-001 | P0 | ข้อมูลครบ 9 ชนิดพร้อมกัน (§2.4) | เปิด ESP ทุกชนิด + ฉาก 50 ผู้เล่นจำลอง | แสดงครบ 9 ชนิด (name/level/race/ken/hp/distance/combat/bounty/indicator) **ถูกต้องทุกชนิดพร้อมกัน** — assert รายผู้เล่นรายชนิดใน L2 | ผู้เล่นเข้า/ออกกลางเกม (ES-007) / ตาย (ES-008) / ไกลเกิน max distance (ES-003) | L2 (จำลอง 50 ผู้เล่น) |
| ES-002 | P0 | ค่าทุกชนิดมาจากแหล่งจริง (ผ่าน adapter ทางเดียว §3.3) | ป้อนค่าที่รู้ล่วงหน้าใน stub game | mapping ตรง: level/bounty → `PlayerAdapter:GetStats/GetBounty`, hp → `CharacterAdapter:GetState`, distance → `WorldAdapter:GetDistance`, ตำแหน่งจอ → `CameraAdapter:WorldToScreen`, combat → `CombatStateService` — ค่าที่แสดง = ค่าที่ป้อน 100% (lint ห้ามอ่านเกมนอก adapter) | ค่าเปลี่ยนกลางแสดงผล → ค่าใหม่ภายใน frame เดียวกัน/ถัดไป | L2 |
| ES-003 | P0 | Max Distance filter (§2.4) | ผู้เล่นเกินระยะ `maxDistance` | หายจาก ESP ทันที (frame เดียวกัน/ถัดไป) | ผู้เล่นวิ่งข้ามเส้นระยะไปมาถี่ ๆ — ต้องไม่กระพริบค้าง/แคชผู้เล่นเก่า / เปลี่ยน maxDistance กลางรันมีผลทันที | L2 |
| ES-004 | P0 | Bounty Colors (§2.4) | ผู้เล่น bounty ต่างช่วงกัน | สีตามช่วง bounty ที่กำหนดใน `bountyColors` — assert สีรายผู้เล่น | bounty เปลี่ยนขณะแสดงผลอยู่ → สีใหม่ทันที / ผู้เล่น bounty 0 / ช่วงสีซ้อนกัน = ยกให้ช่วงแรก + validate ตอนตั้งค่า | L2 |
| ES-005 | P0 | Text Size ปรับได้ | เปลี่ยน `textSize` | ทุกชนิดขยาย-ย่อตาม มีผลทันที + อ่านอ่านได้ที่ค่าในช่วงที่อนุญาต (validate ช่วง + clamp + แจ้งเมื่อเกิน) | ค่าน้อยที่สุด/มากที่สุดของช่วง / ใช้ร่วมกับ verbose mode | L2 |
| ES-006 | P0 | โหมด Compact/Verbose | สลับ `mode` | compact = ชนิดหลักย่อ / verbose = ครบ 9 ชนิด — สลับมีผลทันทีทุก object ที่กำลังแสดง | สลับกลางมี 50 ผู้เล่น / สลับกลาง hot update (โหมดคงอยู่ตาม CG-04) | L2 |
| ES-007 | P0 | ผู้เล่นเข้า/ออกกลางเกม + ObjectPool | เพิ่ม/ลบผู้เล่นจาก stub ระหว่างแสดงผล | object ถูกสร้าง/คืนเข้า pool ทันที — จำนวน object ที่ active = จำนวนผู้เล่นที่ผ่านเงื่อนไขเสมอ + pool ไม่โตไม่จำกัด (มี cap + reuse) | เข้า-ออกถี่ 100 ครั้งต่อเนื่อง → render orphan = 0 และ pool size คงที่หลัง warm-up | L2 |
| ES-008 | P0 | ผู้เล่นตาย | เป้าเลือด 0 ระหว่างถูกแสดง | ตามค่าตั้ง (default: จางหาย) — ไม่ error ไม่ค้าง object ผี | ตายแล้ว respawn (object กลับมาถูกต้องตาม ES-001) | L2 |
| ES-009 | P0 | จุดหลังกล้อง/นอกจอ (ปิด contract `WorldToScreen`) | เป้าอยู่หลังกล้อง/นอก viewport | ตามสัญญาข้อ 6.1: `WorldToScreen` คืน visible=false → **ไม่วาด ไม่ error** + indicator แสดงทิศตามค่าตั้ง (ถ้าเปิด) | กล้องหมุนเร็ว ๆ รอบเป้า / เป้าอยู่ขอบจอพอดี | L1 + L2 |
| ES-010 | P0 | ESP render cost ≤ 0.5 ms/frame @ 50 วัตถุ (§9.1) | ฉาก 50 ผู้เล่น + ทุกชนิดเปิด | per-module timer: ≤ 0.5 ms/frame ใน L2 test env — เกิน = บั๊ก performance (§11 กฎ 5) มี BUG ID | ระดับเตือน > 0.8 ms ต้องเห็นใน Diagnostics | L2 (metric) |
| ES-011 | P0 | DRAWING หาย = ปิดทั้งโมดูล + แจ้ง (ชุดทดสอบถาวร §6.3) | stub ปิด DRAWING กลางรัน | VoidESP graceful disable + `notify:user` ภาษาไทย + **โมดูลอื่นเดินต่อ** + พอ DRAWING กลับมา = เปิดใช้ได้ใหม่ตามค่าตั้ง | หายตอนกำลังวาด 50 วัตถุ / หาย-กลับถี่ ๆ | L2 (ชุดทดสอบถาวร) |
| ES-012 | P0 | ทุก render object ผ่าน Registry | ตรวจโค้ด + รันฉาก | ทุก Drawing/Instance ผ่าน `Runtime.NewRender` owner=`VoidESP` — lint ห้ามสร้าง render นอกระบบ (§3.9-4) | — | L2 + lint |
| ES-013 | P0 | เปิด-ปิด-เปิด 20 รอบ | toggle 20 ครั้งต่อเนื่อง | render orphan = 0 ทุกรอบ (assert อัตโนมัติ) + object pool reuse ถูกต้อง | ปิดกลางมี 50 วัตถุ / ปิดกลางเฟรมวาด | L2 |
| ES-014 | P0 | เข้า-ออกผู้เล่นกลาง hot update (CG-15 รายโมดูล) | ทำ hot update จำลอง + เข้า/ออกผู้เล่นระหว่าง FREEZE | รายชื่อผู้เล่นเป็น**สถานะโลกจริง** → ตาม policy CG-15 (ฉบับอนุมัติ CR-REPLAY-001): event ช่วง freeze ถูก **DROP + re-derive จาก WorldAdapter/PlayerAdapter** หลัง RESUME — ไม่ใช่ replay event เก่า (ส่วน State/Config/Idempotent อื่นในหน้าต่างเดียวกันถูก replay ตาม policy ของมัน) | ผู้เล่นออกตอนยัง freeze → หลัง update ต้องหายจากจอ | L2 |
| ES-015 | P0 | เป้าปัจจุบัน (จาก VoidAim) ไฮไลต์ตามค่าตั้ง | เปิด aim ล็อกเป้า แล้วดู ESP | เป้าที่ `TargetService:GetCurrentTarget()` ชี้ ถูกไฮไลต์/เน้นตามค่าตั้ง — สลับเป้า = ไฮไลต์ตาม frame เดียวกัน/ถัดไป | ล็อกแล้วเป้าตาย / ปิด VoidAim กลางล็อก = ไฮไลต์ปลด | L2 |

## 4. แถว Matrix ระดับ P1 (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสผ่านได้ §5.1)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| ES-016 | P1 | Chams Outline | เปิด chams รายเป้า | วาดขอบตัวละครตามสีที่ตั้ง (ผ่าน render registry ทางเดียว) — ซ่อนเมื่อเกิน maxDistance เช่นเดียวกับ ES-003 | ซ้อนกับชื่อ/ข้อความ / 50 วัตถุ | L2 + L3 |
| ES-017 | P1 | Rare Fruit Alert | มีผลหายากในโลก | แจ้งเตือน `notify:user` ภาษาไทย + วาด indicator ตำแหน่งผล ตามรายการที่ตั้ง | ผลโดนเก็บก่อนแจ้ง / ผลซ้ำตำแหน่งเดิม (ไม่สแปมแจ้งซ้ำ) | L2 + L3 |
| ES-018 | P1 | กรอง Bounty ขั้นต่ำ | ตั้งค่า min bounty | ผู้เล่น bounty ต่ำกว่าค่า = ไม่แสดง (ร่วมกับเงื่อนไขอื่นแบบ AND) | เปลี่ยนค่ากลางรัน / bounty ขยับข้ามเส้นพอดี | L2 |
| ES-019 | P1 | ธีมสี 5 ชุด | เลือกธีม | ชุดสีเปลี่ยนครบทุกชนิดที่วาด + ค่าผู้ใช้ (ธีมที่เลือก) อยู่รอด migration | สลับธีมกลาง 50 วัตถุ / ธีม default เมื่อ config เสีย | L2 |

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0)

— *(ไม่มีรายการ P2 สำหรับ VoidESP ตาม §4.3)*

## 6. ความต้องการต่อ Adapter/L4 ที่ยัง PENDING

### 6.1 `CameraAdapter:WorldToScreen(point)` — สัญญาเต็มที่ VoidESP ต้องการ (ปิด PENDING เฟส 2)

| เงื่อนไข | สัญญา |
|---|---|
| จุดบนจอ | คืน `{x = พิกเซล, y = พิกเซล, visible = true}` — พิกัด viewport ปัจจุบัน |
| จุดหลังกล้อง / นอก viewport | คืน `{x, y, visible = false}` — **ไม่คืน nil ไม่โยน error** (consumer ตรวจ visible อย่างเดียว — กัน nil-check หลุด) |
| กล้อง GONE | คืน `(nil, {code="GONE", ...})` ตามสัญญากลางของ adapter |
| สมบัติ | query บริสุทธิ์ (ไม่มี state / side effect) + เรียกได้ทุก frame ไม่จำกัด |

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| ESP render cost (50 วัตถุ, ทุกชนิดเปิด) | ≤ 0.5 ms/frame | > 0.8 ms |
| Render orphan หลังปิด/Destroy | 0 ทุกครั้ง (assert) | > 0 = fail ทันที |
| ObjectPool size หลัง warm-up | คงที่ (ไม่โต monotonic ตามจำนวนเข้า-ออก) | โต monotonic = บั๊ก |

## 8. L3 Checklist ฉบับร่าง (เฟส 2)

1. ☐ เปิด ESP ในเซิร์ฟเวอร์คนเต็ม — ข้อมูล 9 ชนิดถูกทุกชนิดเทียบสายตากับข้อมูลจริง (ES-001/002)
2. ☐ เดินเข้า-ออกระยะ maxDistance — หาย/โผล่ทันที ไม่กระพริบค้าง (ES-003)
3. ☐ Bounty เปลี่ยนระหว่างแสดง — สีเปลี่ยนทันที (ES-004)
4. ☐ ปิด-เปิด 20 รอบ — จอสะอาด ไม่มีของค้าง (ES-013)
5. ☐ เพื่อนทดสอบเข้า-ออกเกมกลางรัน (ES-007)
6. ☐ ปิด Drawing จำลอง (ถ้าทำได้บน Volt) — ดูการแจ้งภาษาไทย (ES-011)
7. ☐ รัน 30 นาที + Export Diagnostics แนบ (ES-010)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 2) | — |
| ES-001 … ES-015 (P0) | ยังไม่พิสูจน์ | — |
| ES-016 … ES-019 (P1) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Void ESP)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Parity ครบ 9 ชนิด | P0 | ES-001, ES-002, ES-015 |
| Text Size ปรับได้ | P0 | ES-005 |
| Bounty Colors | P0 | ES-004 |
| โหมด Compact/Verbose | P0 | ES-006 |
| Max Distance filter *(จากแถวตัวอย่าง §2.4)* | P0 | ES-003 |
| Chams Outline | P1 | ES-016 |
| Rare Fruit Alert | P1 | ES-017 |
| กรอง Bounty ขั้นต่ำ | P1 | ES-018 |
| ธีมสี 5 ชุด | P1 | ES-019 |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.1 | 1 ตุลาคม 2026 | ตามคำตัดสินเจ้าของ (sign-off รอบ 6): ES-014 อัปเดตถ้อยความให้อ้าง Replay Policy ของ CG-15 ฉบับอนุมัติ CR-REPLAY-001 (world state = DROP + re-derive ยังคงเดิม — ส่วนแถวอื่นของระบบ replay ตาม policy ของตัวเอง) + บันทึกคำตัดสิน Q1=(ข): Ken status display อยู่ใน ES-001/ES-002 (P0) / **Auto Ken out of scope v1.0** |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (15 แถว P0 + 4 แถว P1) + ปิด contract `WorldToScreen` เป็นข้อเสนอรอเจ้าของรีวิว |
