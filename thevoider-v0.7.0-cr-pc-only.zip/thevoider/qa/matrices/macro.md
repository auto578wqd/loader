# Behavioral Acceptance Matrix — Void Macro

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 (ไม่มีแถวที่ขอแก้) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **[CR-PC-ONLY 1 ต.ค. 2026]** เป้าหมายรับรอง = **PC/Desktop only บน Volt** — **MC-012 (Mobile Macro Slots) = OUT OF SCOPE — PC ONLY** (เก็บ ID ไว้เพื่อ traceability ไม่นับเป็นแถว P0 active) — แถว P0 active เหลือ **14 แถว**
> **อ้างอิง:** แผน freeze v2.1 §2.4 (ตัวอย่างที่ 3), §4.3, §5.1 (เกณฑ์ timing ฉบับแก้), §5.6 + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `VoidMacro` / L5 Feature Modules |
| Depends on | `InputAdapter`, `ConfigService`, `CombatAdapter` *(เพิ่ม v1.4 — Soru Skill Macro เป็น P0 ของ §4.3 และการยิงสกิลต้องผ่าน `CombatAdapter:FireSkill` ประตูเดียว)*, `KeybindService` *(เพิ่ม v1.4 — ปุ่มเริ่มอัด/เล่นซ้ำเป็น P0)* |
| Internal services (ไม่ขึ้น graph) | MacroRecorder, MacroPlayer, EditorModel, MacroSerializer |
| Capability gates (CG-07) | `INPUT` — หาย = อัด/เล่นคีย์ไม่ได้ → ปิดโมดูล + แจ้ง / `CLIPBOARD`+`FILEIO` — เฉพาะฟีเจอร์ P1 Import/Export (MC-017) |
| สาย adapter ที่กระทบ (CG-08) | `InputAdapter` ตาย = อัดไม่ได้ + เล่นคีย์ไม่ได้ (เล่นสกิลยังได้ถ้า CombatAdapter ยังมีชีวิต — แจ้งระดับฟีเจอร์) / `CombatAdapter` ตาย = Soru/skill macro ปิด (คีย์ธรรมดายังเล่นได้ — แจ้ง) |
| Config root | `settings.macro.*` (โครง: `enabled`, `slots{}`, `activeSlot`, `timing.{resolution, tolerance}`, `onDeath` (stop\|continue), `recordKey`, `playKey`) — ตัว macro เองเก็บใน `slots` ผ่าน MacroSerializer |
| Keybind actions (CG-12) | `macro.record`, `macro.play`, `macro.stop` — ผ่าน KeybindService ทางเดียว *(เดิมมีหมายเหตุมือถือ `Keybind:Trigger` — ถูกตัดออกตาม CR-PC-ONLY)* |
| Bus events | ฟัง `config:changed` / เผยแพร่ `module:state` + `notify:user` (สถานะอัด/เล่น/หยุด) |
| L4 services ที่เรียกตรง | — (ไม่พึ่ง L4 — ใช้ adapter โดยตรงตาม graph) |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md` — หมายเหตุ CG-05 รายโมดูล: หลัง rollback จาก hot update ที่กำลังเล่น macro อยู่ = **หยุดสะอาด + แจ้งผู้ใช้** (ไม่เล่นต่ออัตโนมัติ — ปลอดภัยกว่าเพราะ timing context ข้ามรุ่นไม่รับประกัน)

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 3 ไม่จบ §5.6)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| MC-001 | P0 | บันทึกคอมโบ (§2.4) | กด `macro.record` แล้วเล่นลำดับ input | เก็บ **action + timing ทุกขั้นถูกลำดับ** (คีย์/สกิล + relative delay) — เทียบลำดับที่อัดกับที่เล่นให้ดู 100% | อัดชุดว่าง (ไม่มี action) = ปฏิเสธบันทึก + แจ้ง / กด record ซ้ำระหว่างอัด = จบรอบเดิมก่อน | L1 + L2 |
| MC-002 | P0 | อัดยาว 50+ ขั้น | อัดคอมโบ 50 ขั้นต่อเนื่อง | ครบทุกขั้นไม่หล่น (assert จำนวน + ลำดับ) — พร้อมใช้เล่นซ้ำได้ทันที | อัด 100 ขั้น (เกินเคสมาตรฐาน) / อัดยาวข้ามช่วงเกมเปลี่ยน map (ยังบันทึกต่อได้) | L2 |
| MC-003 | P0 | กดซ้อนหลายคีย์ในเฟรมเดียว (§2.4) | กด 2-3 คีย์พร้อมกันใน frame เดียว | เก็บครบทุกคีย์ + ลำดับ relative ชัด (พร้อมกัน = ระบุ same-frame ไม่สับสนลำดับเก็บ) — เล่นซ้ำได้ถูกต้อง | ปล่อยต่างเฟรมกัน / กด-ปล่อยเร็วมาก (2 frame) | L1 + L2 |
| MC-004 | P0 | เล่นซ้ำ: action sequence match = 100% (§5.1) | เล่น macro ที่อัดไว้ | **ทุก action ถูกเรียกตามลำดับครบถ้วน** (นับที่ dispatch จริง) — เกณฑ์นี้แยกจาก timing (MC-005) ห้ามรวม | ชุด 50+ ขั้น / เล่นซ้ำ 10 รอบต่อเนื่อง (ทุกรอบ 100%) / เล่นระหว่างมี macro อื่นกำลังเล่น (MC-010) | L2 |
| MC-005 | P0 | Timing: tolerance ±1 frame @ 60fps (§5.1) | เล่น macro + วัด actual execution เทียบ virtual-time | actual delay แต่ละขั้นอยู่ใน **±16.7 ms (±1 frame @60fps)** ของค่าที่อัด + **jitter จริงบันทึกเป็น metric ต่อ release** | ขั้น delay สั้นสุด (0.01s) / ขั้น delay ยาว (5s) / โหลดสูง (ฉาก 50 ผู้เล่นเปิด ESP พร้อมกัน) | L2 (virtual time) |
| MC-006 | P0 | Requested delay resolution 0.01s | ตั้ง delay รายขั้น 0.01–5.00s | รับค่าละเอียด 0.01s ได้เต็มช่วง + quantize ชัดเจน (ค่าที่รับ = ค่าที่ใช้ ไม่ปัดเงียบ) | ค่านอกช่วง = validate + แจ้ง / ค่า 0 (ทันที) | L1 + L2 |
| MC-007 | P0 | ยกเลิกกลางคัน (§2.4) | กด `macro.stop` (หรือปิดโมดูล) กลางเล่น | หยุดสะอาดทันที: คิวว่าง + คีย์ที่กดค้างถูกปล่อย (dispatch keyup ให้ครบ) + resource orphan = 0 | ยกเลิกตอนขั้นที่ 49/50 / ยกเลิกกลาง same-frame หลายคีย์ / ยกเลิกผ่าน hot update TEARDOWN | L2 |
| MC-008 | P0 | ตายกลางเล่น (§2.4) | local player ตายระหว่างเล่น macro | ตามค่าตั้ง `onDeath`: **default = หยุด** + แจ้งผู้ใช้ (ไม่เล่นต่อบนศพ) — ตั้งให้เล่นต่อได้แต่ต้องรอดจากทุก edge | ตายแล้ว respawn กลางคอมโบ / ตายซ้ำระหว่างเล่นต่อ | L2 |
| MC-009 | P0 | Macro Slots หลายชุด + สลับด่วน (§2.4) | บันทึกหลายสล็อต + สลับไปมา | สลับได้ทันที + **ชุดเดิมไม่พัง** (เนื้อหาทุกสล็อตคงเดิมเทียบ snapshot) + `activeSlot` persist ใน config | สลับ 20 รอบ / สล็อตเต็ม (cap ตามค่าตั้ง — validate + แจ้ง) / สล็อตว่าง = เล่นไม่ได้ + แจ้ง | L1 + L2 |
| MC-010 | P0 | สลับชุดกลางเล่นซ้ำ (§2.4) | สั่งเล่นชุดใหม่ขณะชุดเก่ากำลังเล่น | ยกเลิกชุดเก่าสะอาด (ตาม MC-007) แล้วเล่นชุดใหม่ — **ไม่ซ้อนคิวสองชุดพร้อมกัน** | สั่งถี่ ๆ 5 ชุดใน 1 วินาที (ยกเลิก-เริ่ม ถูกต้องทุกครั้ง ไม่ตกคีย์ค้าง) | L2 |
| MC-011 | P0 | Soru Skill Macro | อัด/เล่นคอมโบที่มีสกิล Soru | สกิล Soru ถูกยิงผ่าน `CombatAdapter:FireSkill` ทางเดียว (lint) + ตำแหน่งในลำดับถูกต้อง | Soru cooldown อยู่ (fallback ตามสัญญา PENDING ของ GetSkillCooldown — ไฟล์ voidaim.md ข้อ 6.2) / อัดสกิลผสมคีย์ธรรมดา | L2 + L3 |
| MC-012 | ~~P0~~ **OUT OF SCOPE — PC ONLY** | Mobile Macro Slots | มือถือ: เล่นผ่านปุ่มลัด UI | **ถูกตัดออกจาก v1.0 scope ตาม CR-PC-ONLY (1 ต.ค. 2026) — ไม่ implement ไม่ย้ายเป็น P1/P2** · keybind/keyboard path บน PC ยังเป็น P0 ตามแถว MC-001–MC-015 ที่เหลือ | — | — | — |
| MC-013 | P0 | Timing Tuner | ปรับ `timing.resolution`/`timing.tolerance` รายชุด (หรือรวมตาม UI เฟส 3) | ค่าที่ปรับมีผลกับการเล่นครั้งถัดไปทันที + ผลต่อ replay วัดได้ (เช่น tolerance หด = jitter metric หดตาม) | ตั้ง tolerance แคบกว่า resolution = validate + เตือน | L1 + L2 |
| MC-014 | P0 | เล่นผ่าน adapter ทางเดียว (§3.3) | ตรวจโค้ด + รันฉากเล่น | ทุก action ตอนเล่นกระจายผ่าน: คีย์ → `InputAdapter:DispatchKey` (contract ข้อ 6.1) / สกิล → `CombatAdapter:FireSkill` — lint ห้ามส่ง input/remote นอก adapter | executor ไม่มี input dispatch จริง = macro เล่นสกิลได้แต่คีย์ไม่ได้ → **แจ้งผู้ใช้ตอนกดเล่น ไม่พังเงียบ** (No Silent Degradation) | L2 + lint |
| MC-015 | P0 | Persist + อยู่รอด migration/hot update | บันทึก macro → ปิดเปิดเกม / รัน config migration / hot update | macro ทุกสล็อตอยู่ครบ (เทียบ checksum เนื้อหา) + อยู่รอด migration chain (§3.7 ห้ามทิ้ง) + หลัง hot update/rollback สถานะ "กำลังเล่น" ถูกจัดการตาม CG-05 (หยุดสะอาด + แจ้ง) | config เสีย → fallback `.bak` ตามระบบ + macro ยังต้องอยู่ / migration หลายขั้น (v1→v2→v3 จำลอง) | L1 + L2 |

## 4. แถว Matrix ระดับ P1 (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสผ่านได้ §5.6)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| MC-016 | P1 | Visual Macro Editor | แก้/ลบ/แทรกขั้นใน UI แล้วเล่นซ้ำ | ผล replay ตรง matrix: ลำดับใหม่ถูกต้อง 100% + timing ขั้นที่แก้ตามค่าใหม่ | แก้ระหว่างเล่น (ล็อก editor ตอนเล่น + แจ้ง) / ลบทั้งชุด = ยืนยันก่อน | L2 + L3 |
| MC-017 | P1 | Macro Import/Export | ส่งไฟล์คอมโบให้เพื่อนเปิด | ผูก `CLIPBOARD`/`FILEIO` capability — **ถ้า capability ไม่มี = แจ้ง + เลื่อน v1.1 ไม่ใช่ความล้มเหลว** (§5.6 บอกตรง ๆ) | format เวอร์ชันต่างรุ่น (มี schemaVersion + ปฏิเสธเป็นละเอียด) / ไฟล์เสีย | L2 |
| MC-018 | P1 | Interactive Guide | เปิดคู่มือในแอป | ขั้นตอนแนะนำถูกต้อง 2 ภาษา (CG-11) และปุ่มในคู่มือทำงานจริง | สลับภาษากลางคู่มือ | L3 |

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0 §5.1)

- **Combo Learning** — เรียนรู้คอมโบจากการเล่นจริง
- **แนะนำคอมโบอัตโนมัติ** — สร้างคำแนะนำจาก pattern

## 6. ความต้องการต่อ Adapter ที่ยัง PENDING (ข้อเสนอรอเจ้าของรีวิว)

### 6.1 `InputAdapter:DispatchKey(key, down)` — contract ใหม่ที่ Macro ต้องการ (ยังไม่มีใน InputAdapter ปัจจุบัน)

| เงื่อนไข | สัญญา (ข้อเสนอ) |
|---|---|
| สำเร็จ | คืน `(true)` — ส่ง key down/up เข้าระบบ input ของเกม (ผ่าน mechanism ที่ Volt รองรับ — สำรวจจริงตอน implement เฟส 3 แล้วบันทึกผล survey เป็น contract note เหมือน GetSkillCooldown) |
| ใช้ไม่ได้ | คืน `(false, {code="UNSUPPORTED"})` — consumer ต้องแจ้งผู้ใช้ตาม MC-014 edge สุดท้าย (ไม่พังเงียบ) |
| คู่กัน | ทุก `down=true` ต้องมี `down=false` ให้ครบเมื่อหยุด/ยกเลิก (MC-007) — สถานะคีย์ค้างต้องเป็น 0 เสมอ |
| เจ้าของ | InputAdapter เป็นประตูเดียวของ input จำลอง (lint บังคับ) — ใช้ capability `INPUT` เป็นเงื่อนไข gate |

### 6.2 `CombatAdapter:GetSkillCooldown(skill)` — ใช้สัญญาเดียวกับ voidaim.md ข้อ 6.2 (single source — อ่านจากไฟล์นั้น)

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3 — ตัวชี้วัดใหม่จะเพิ่มตอน implement ตาม §9.3 กฎ 2)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| Action sequence match | 100% ทุกชุดทดสอบ (รวม 50+ ขั้น) | < 100% = fail ทันที |
| Timing jitter (เทียบ virtual-time) | อยู่ใน ±1 frame @60fps (±16.7 ms) | เกิน tolerance = บั๊ก + บันทึก jitter เป็น metric ทุก release |
| คีย์ค้างหลังหยุด/ยกเลิก/ตาย/rollback | 0 ทุกครั้ง (assert) | > 0 = fail ทันที |
| Macro dispatch cost (ตัวใหม่ — เพิ่มตอน implement) | บันทึกเป็น baseline แล้วเทียบข้ามรอบ (§9.3 กฎ 1) | แย่ลง > 10% โดยไม่มีเหตุผล = บั๊ก |

## 8. L3 Checklist ฉบับร่าง (เฟส 3)

1. ☐ อัดคอมโบจริง 20+ ขั้น → เล่นซ้ำในแมตช์จริง — ลำดับถูกทุกขั้น (MC-004)
2. ☐ อัด 50+ ขั้น (Soru ผสมคีย์) → เล่นซ้ำได้ (MC-002/MC-011)
3. ☐ ยกเลิกกลางคัน → ตัวละครไม่ค้างคีย์ (MC-007)
4. ☐ ตายกลางเล่น → หยุด + แจ้ง (MC-008)
5. ☐ สลับสล็อตกลางเล่น 10 รอบ → ไม่มีคีย์ค้าง/ชุดพัง (MC-009/MC-010)
6. ~~มือถือ: เล่นผ่านปุ่มลัดได้ (MC-012)~~ **OUT OF SCOPE — PC ONLY ตาม CR-PC-ONLY — ไม่ต้องทดสอบ**
7. ☐ ปิดเปิดเกม → ทุกสล็อตยังอยู่ (MC-015)
8. ☐ เล่น macro 30 นาทีต่อเนื่อง + Export Diagnostics (jitter metric แนบ §9.2)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 3) | — |
| MC-001 … MC-011, MC-013 … MC-015 (P0) | ยังไม่พิสูจน์ | — |
| MC-012 | **OUT OF SCOPE — PC ONLY** (CR-PC-ONLY) | ไม่พิสูจน์ — ห้ามนับ N/A เป็น "ผ่าน" |
| MC-016 … MC-018 (P1) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Void Macro)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Macro Slots หลายชุด + สลับด่วน | P0 | MC-009, MC-010 |
| บันทึก/เล่นซ้ำ | P0 | MC-001, MC-002, MC-003, MC-004, MC-005, MC-006, MC-014, MC-015 |
| Soru Skill Macro | P0 | MC-011 |
| Mobile Slots | ~~P0~~ **OUT OF SCOPE — PC ONLY** (CR-PC-ONLY) | MC-012 (เก็บ ID เพื่อ traceability ไม่นับแถว active) |
| Timing Tuner (resolution 0.01s + tolerance §5) | P0 | MC-005, MC-006, MC-013 |
| ยกเลิก/ตายกลางเล่น *(แถวตัวอย่าง §2.4)* | P0 | MC-007, MC-008 |
| Visual Macro Editor | P1 | MC-016 |
| Macro Import/Export | P1 | MC-017 |
| Interactive Guide | P1 | MC-018 |
| Combo Learning / แนะนำคอมโบอัตโนมัติ | P2 | §5 (ไม่ตรวจรับ v1.0) |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.2 | 1 ตุลาคม 2026 | **CR-PC-ONLY:** MC-012 Mobile Macro Slots = **OUT OF SCOPE — PC ONLY** (ตัดจาก v1.0 scope ไม่ย้าย P1/P2 — เก็บ ID เพื่อ traceability) + ถอดหมายเหตุมือถือออกจากแถว CG-12 + แถว P0 active เหลือ 14 — ตามคำตัดสินเจ้าของโปรเจกต์ "PC/Desktop only บน Volt" |
| 1.1 | 1 ตุลาคม 2026 | บันทึก sign-off เจ้าของโปรเจกต์ (APPROVED BASELINE v1.0 ไม่มีแถวที่ขอแก้) พร้อมคำตัดสิน Q1=(ข) / Q2=(ก) / Q3=(ข) — ชุดนี้เป็น acceptance source of truth ของ implementation ตั้งแต่รอบ 6 |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (15 แถว P0 + 3 แถว P1) — แยกเกณฑ์ sequence/timing ตาม §5.1 เคร่งครัด + เสนอ contract ใหม่ `InputAdapter:DispatchKey` รอเจ้าของรีวิว |
