# Behavioral Acceptance Matrix — Movement

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 (ไม่มีแถวที่ขอแก้) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **อ้างอิง:** แผน freeze v2.1 §4.3, §3.3 + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `Movement` / L5 Feature Modules |
| Depends on | `CharacterAdapter`, `InputAdapter` |
| Internal services (ไม่ขึ้น graph) | MovementProfiler, BoostApplier |
| Capability gates (CG-07) | ไม่มี capability เฉพาะ (input ที่ใช้ = input ของเกมเดิม ตรวจผ่าน InputAdapter — ไม่ต้อง bind คีย์ใหม่ระดับ P0) |
| สาย adapter ที่กระทบ (CG-08) | `CharacterAdapter` ตาย = ปรับ movement ไม่ได้ → ปิด + แจ้ง / `InputAdapter` เสื่อม = โหมด hold ใช้ไม่ได้ (fallback ตามแถว) + แจ้ง |
| Config root | `settings.movement.*` (โครง: `enabled`, `airJump.{enabled, holdMode}`, `superJump.{enabled, power 80–200}`, `sangZ`, `yamaZ`, `soulGuitarMomentum`, `diamondM1`, `dashJumpBoost`) |
| Keybind actions (CG-12) | ไม่มี binding ใหม่ระดับ P0 — ใช้ input ที่เกมมีอยู่ (เช่น ปุ่มกระโดด) ตรวจผ่าน `InputAdapter:IsKeyDown` (อ่านสถานะ ไม่ใช่การยึดคีย์) — ถ้าอนาคตเพิ่มคีย์เฉพาะต้องผ่าน KeybindService เท่านั้น |
| Bus events | ฟัง `config:changed` / เผยแพร่ `module:state` |
| L4 services ที่เรียกตรง | — |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md`

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 4 ไม่จบ §5.7)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| MV-001 | P0 | Infinite Air Jump | เปิด + กดกระโดดกลางอากาศ | กระโดดได้ไม่จำกัดครั้ง (นับจำนวนครั้งใน L2 stub ได้ไม่จำกัด) — ผ่าน BoostApplier → CharacterAdapter (contract ข้อ 6.1) | ตายกลางอากาศ (reset สถานะ) / ลงพื้นแล้วกระโดดปกติไม่เพี้ยน / ปิดกลางอากาศ (ไม่ค้างสถานะลอย) | L2 |
| MV-002 | P0 | Air Jump +Hold | เปิด holdMode + กดค้าง | กระโดดต่อเนื่องตามจังหวะของเกม (`IsKeyDown` = true ตลอด) — ปล่อย = หยุดทันที | กดค้างข้ามการตาย/respawn / สลับหน้าต่าง (input หลุด = หยุด ไม่ค้างกระโดด) | L2 |
| MV-003 | P0 | Super Jump (80–200) | ตั้ง `power` แล้วกระโดด | ความสูงกระโดดสอดคล้องค่า power ในช่วง **80–200 เท่านั้น** — ค่านอกช่วง = validate + clamp + แจ้ง (ไม่ใช้ค่าเงียบ ๆ) | ตั้ง 79.9 / ตั้ง 201 / ตั้งค่าไม่ใช่ตัวเลข | L1 + L2 |
| MV-004 | P0 | Sang Z momentum | ใช้ท่า Sang Z | momentum ถูก apply ตามค่าที่ตั้ง (ทิศ/แรง) ผ่าน adapter ทางเดียว | ใช้กลางอากาศ / ชนกำแพงระหว่าง momentum (ไม่ค้าง) / ท่า cooldown | L2 |
| MV-005 | P0 | Yama Z momentum | ใช้ท่า Yama Z | เช่นเดียวกับ MV-004 สำหรับ Yama | สลับอาวุธกลางท่า | L2 |
| MV-006 | P0 | Soul Guitar Momentum | ใช้ Soul Guitar พร้อมเงื่อนไขที่ตั้ง | momentum ถูก apply ตามที่ตั้ง | เงื่อนไขเกมไม่ให้ (สถานะผิด) = ไม่ apply + ไม่ error | L2 |
| MV-007 | P0 | Diamond M1 | ถือ Diamond + M1 | พฤติกรรม M1 ตามค่าที่ตั้ง (ผ่าน CombatAdapter เส้นเดียวกับ CombatCore — ไม่ทำ remote ซ้ำระบบ) | สลับอาวุธกลาง M1 | L2 |
| MV-008 | P0 | Dash/Jump Boost | เปิด + ทำ dash/กระโดด | บูสต์ตามค่าที่ตั้ง (ทิศจาก `GetMoveDirection`) | dash กลางอากาศ / ทิศเฉียง / ปิดกลาง dash (ไม่ค้าง) | L2 |
| MV-009 | P0 | ประตูเดียว: ทุกบูสต์ผ่าน adapter | ตรวจโค้ด + ทุกฉาก | ทุกการแต่ physics/velocity ผ่าน contract ข้อ 6.1 ของ CharacterAdapter เท่านั้น — lint ห้ามแตะ HumanoidRootPart/physics ตรง | — | L2 + lint |
| MV-010 | P0 | Disable = บูสต์หยุดจริง | ปิดโมดูล (toggle/TEARDOWN) หลังเปิดทุกชนิด | ไม่มีบูสต์ที่ยังทำงาน + สถานะตัวละครปกติ + orphan 0 — ทดสอบ 20 รอบเปิด-ปิด | ปิดกลาง momentum / ปิดกลาง hold | L2 |
| MV-011 | P0 | ตาย/respawn รีเซ็ตสะอาด | ตายขณะบูสต์ทุกชนิดเปิดอยู่ | หลัง respawn ไม่มีสถานะผี (ลอยค้าง/momentum ค้าง) — บูสต์กลับมาทำงานตามค่าตั้งเมื่อเงื่อนไขกลับมา | ตายกลาง air jump ถี่ ๆ / respawn ตำแหน่งใหม่ | L2 |
| MV-012 | P0 | MovementProfiler (internal) | สลับสถานการณ์ (บนพื้น/ลอย/น้ำ — จาก `GetState`) | โปรไฟล์ movement ที่ใช้ถูกสถานการณ์ (บูสต์บางชนิดใช้ได้เฉพาะสถานะ) — assert การเลือกโปรไฟล์รายสถานะ | สถานะเปลี่ยนถี่ (ไม่กระพริบ apply-undo เกิน 1 ครั้ง/เงื่อนไข) | L2 |
| MV-013 | P0 | อยู่รอด hot update/rollback | hot update กลางใช้บูสต์ | หลัง update/rollback: บูสต์เปิดอยู่ตามค่า config + ไม่มีสถานะผีข้ามรุ่น + หยุดสะอาดตามค่าตั้ง (CG-04/CG-05) | rollback กลาง hold | L2 |

## 4. แถว Matrix ระดับ P1 (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสผ่านได้ §5.1)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| MV-014 | P1 | Movement Profile (preset 1 คลิก) | เลือก preset ที่มัดรวมบูสต์ | ใช้ชุดค่า preset ครบทุกชนิด + ค่าที่ตั้งเองก่อนหน้าคงอยู่เมื่อออก + persist ข้าม session | สลับ preset กลาง momentum / preset เสีย (แจ้ง ไม่ใช้ครึ่งชุด) | L2 |

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0 §5.1)

- **Advanced movement tuning** — จูนบูสต์เชิงลึกรายพารามิเตอร์ (§4.3)

## 6. ความต้องการต่อ Adapter ที่ยัง PENDING (ข้อเสนอรอเจ้าของรีวิว)

### 6.1 Movement API ของ CharacterAdapter — contract ใหม่ (ยังไม่มีเมธอด apply ใด ๆ ในปัจจุบัน)

`CharacterAdapter` ปัจจุบันเป็น **read-only** (GetCharacter/GetRoot/IsAlive/GetState/GetMoveDirection) — Movement ทุกแถว P0 ต้อง "เขียน" ลง physics ของตัวละคร จึงต้องเพิ่ม contract:

| เมธอด (ข้อเสนอ) | สัญญา |
|---|---|
| `CharacterAdapter:ApplyVelocity(velocity)` | คืน `(true)` เมื่อ apply สำเร็จ / `(false, {code})` เมื่อ root GONE หรือ executor ไม่รองรับกลไก — **ไม่โยน error** |
| `CharacterAdapter:SetStateFlag(flag, value)` | สำหรับ air jump (ปรับจำนวนครั้ง/สถานะ) — คืนผลจริง แจ้งเมื่อทำไม่ได้ |
| กติกา | ทุก write ผ่านเมธอดเหล่านี้ทางเดียว (lint) + mechanism จริง (AssemblyLinearVelocity / Humanoid ฯลฯ) ต้อง survey บน Volt ตอน implement เฟส 4 แล้ว freeze เป็น contract note — แบบเดียวกับ GetSkillCooldown (ไม่เดาก่อนพิสูจน์) |

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| สถานะผีหลังปิด/ตาย/rollback (ลอยค้าง/momentum ค้าง) | 0 ครั้ง (assert) | > 0 = fail ทันที |
| ส่วนแบ่ง frame cost ของ Movement | รวม ≤ 2.0 ms/frame — baseline รายโมดูลเก็บตอน implement | แย่ลง > 10% ไม่มีเหตุผล = บั๊ก |

## 8. L3 Checklist ฉบับร่าง (เฟส 4)

1. ☐ Air Jump กลางอากาศ + โหมด hold (MV-001/MV-002)
2. ☐ Super Jump ตั้ง 80 / 150 / 200 — ความสูงสอดคล้อง + ค่านอกช่วงถูกปฏิเสธ (MV-003)
3. ☐ Sang Z / Yama Z / Soul Guitar momentum ในเกมจริง (MV-004–MV-006)
4. ☐ Diamond M1 (MV-007)
5. ☐ Dash/Jump Boost ทิศตรง/เฉียง (MV-008)
6. ☐ ปิดโมดูลกลาง momentum → ตัวละครกลับปกติ (MV-010)
7. ☐ ตาย-เกิด 10 รอบต่อเนื่อง → ไม่มีสถานะผี (MV-011)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 4) | — |
| MV-001 … MV-013 (P0) | ยังไม่พิสูจน์ | — |
| MV-014 (P1) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Movement)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Infinite Air Jump (+Hold) | P0 | MV-001, MV-002 |
| Super Jump (80–200) | P0 | MV-003 |
| Sang Z | P0 | MV-004 |
| Yama Z | P0 | MV-005 |
| Soul Guitar Momentum | P0 | MV-006 |
| Diamond M1 | P0 | MV-007 |
| Dash/Jump Boost | P0 | MV-008 |
| Movement Profile (preset) | P1 | MV-014 |
| Advanced movement tuning | P2 | §5 (ไม่ตรวจรับ v1.0) |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.1 | 1 ตุลาคม 2026 | บันทึก sign-off เจ้าของโปรเจกต์ (APPROVED BASELINE v1.0 ไม่มีแถวที่ขอแก้) พร้อมคำตัดสิน Q1=(ข) / Q2=(ก) / Q3=(ข) — ชุดนี้เป็น acceptance source of truth ของ implementation ตั้งแต่รอบ 6 |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (13 แถว P0 + 1 แถว P1) + เสนอ contract write-side ของ CharacterAdapter (ApplyVelocity/SetStateFlag — survey ตอน implement) |
