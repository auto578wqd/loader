# Behavioral Acceptance Matrix — ทั้ง 8 Product Modules (Index)

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off ครบทั้ง 10 ไฟล์ **1 ตุลาคม 2026** (150 แถว: 118 P0 + 17 P1 + 15 CG ไม่มีแถวที่ขอแก้) + คำตัดสิน **Q1=(ข) / Q2=(ก) / Q3=(ข)** — ชุดนี้คือ acceptance source of truth ของ implementation ตั้งแต่รอบ 6 เป็นต้นไป แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **[CR-PC-ONLY 1 ต.ค. 2026]** แพลตฟอร์มรับรอง = **PC/Desktop only บน Volt** — แถว **MC-012** (macro) และ **VA-033** (voidaim) = `OUT OF SCOPE — PC ONLY` (เก็บ ID เพื่อ traceability) — แถว active เหลือ **148** (117 P0 + 16 P1 + 15 CG) · ห้ามนับแถว out-of-scope เป็น "ผ่าน" · กฎเต็ม: `_common-gates.md` §3.1
> **อ้างอิง:** แผน freeze v2.1 §2.3/§2.4/§2.5, §4.1–§4.5, §5.1, §6.4 + dependencies.md v1.4
> **นิยาม Feature Parity 100% (§2.3):** = 100% ของ behavior ที่อยู่ใน matrix ของโมดูลนั้นผ่านการทดสอบ — ไม่ใช่จำนวนจุดในไฟล์ต้นทาง

## 1. ไฟล์ในชุดนี้

| ไฟล์ | โมดูล (node) | แถว P0 | แถว P1 | หมายเหตุ |
|---|---|---|---|---|
| `_common-gates.md` | (ทุกโมดูล) | 15 | — | ประตูบังคับร่วม CG-01–CG-15 |
| `voidaim.md` | `VoidAim` ⭐ | 28 | 5 *(เดิม 6 — VA-033 OUT OF SCOPE ตาม CR-PC-ONLY)* | ธงเรือ + ปิด contract `SetLock`/`GetSkillCooldown` |
| `esp.md` | `VoidESP` | 15 | 4 | ปิด contract `WorldToScreen` |
| `macro.md` | `VoidMacro` | 14 *(เดิม 15 — MC-012 OUT OF SCOPE ตาม CR-PC-ONLY)* | 3 | เสนอ contract `InputAdapter:DispatchKey` |
| `combat-core.md` | `CombatCore` | 15 | — | ⚠ มีคำถามเปิดเรื่อง "Ken" |
| `race.md` | `Race` | 10 | — | เสนอ contract VFX ของ CharacterAdapter |
| `fruit.md` | `Fruit` | 12 | 3 | ข้อเสนอ remote gate ผ่าน CombatAdapter |
| `movement.md` | `Movement` | 13 | 1 | เสนอ contract write-side ของ CharacterAdapter |
| `serverhop-teleport.md` | `ServerHop` | 10 | — | กลไกย้ายตัว = survey ตอน implement |
| **รวม** | **8 โมดูล** | **117** *(เดิม 118)* | **16** *(เดิม 17)* | +15 CG = **148 แถว active** (+2 แถว out-of-scope ตาม CR-PC-ONLY เก็บไว้เพื่อ traceability) |

## 2. วิธีอ่านหนึ่งแถว (โครงมาตรฐาน §2.4 + ส่วนขยาย 2 ช่อง)

โครงมาตรฐานตาม freeze: **Behavior | Input/Trigger | Expected Behavior | Edge Cases | วัดที่ชั้น** — ชุดนี้ขยายเพิ่ม 2 ช่องหน้าเพื่อให้ตรวจรับได้จริง:

| ช่อง | ที่มา / เหตุผลที่ขยาย |
|---|---|
| `ID` (เช่น VA-013) | ตัวถือหลักฐานถาวร — §6.4 บังคับว่า "ทุกแถว matrix มีสถานะ + หลักฐานกำกับ" ซึ่งต้องอ้างถึงแถวได้ไม่คลาดเคลื่อนข้ามรอบส่งมอบ (ตัวเลขแถวในตารางเลื่อนได้ถ้าแทรกแถว) |
| `P` (P0/P1) | §5.1 แยก DoD: P0 = MUST PASS (ไม่ผ่านเฟสไม่จบ) / P1 = SHOULD PASS (ไม่ผ่าน = ย้าย backlog v1.1 อย่างเปิดเผย) — การผสมสองระดับในตารางเดียวโดยไม่ติดป้าย = ตัดสินผิดเกณฑ์ |

ชั้นทดสอบ (§6.1): **L1** = fengari + stub + virtual time (เครื่องเรา) / **L2** = integration บน stub game เต็มรูปแบบ / **L3** = Volt จริง + เกมจริง (checklist + วิดีโอ + Diagnostics export)

**กติกาการพิสูจน์แถว:** ทุกแถวเริ่มสถานะ "ยังไม่พิสูจน์" — ปิดได้เฉพาะด้วยหลักฐานตามชั้นที่แถวกำหนด (ผลรัน/วิดีโอ/export) พร้อมแหล่งที่มา (ไฟล์เทส/ฉาก/วันที่) ตามกฎ "ตัวเลขทุกตัวมีที่มา" (§9.2) — ห้ามปิดแบบ "น่าจะได้"

## 3. ขั้นตอนตรวจรับ (§4.5 — ลำดับเดียวกันทุกโมดูล)

```text
(1) เขียน Behavioral Matrix ก่อน   ← เฟส 0 รอบ 5
(2) เจ้าของโปรเจกต์รีวิว matrix     ← ✅ APPROVED 1 ต.ค. 2026 (รอบ 6)
(3) เขียนโค้ด + L1/L2 ตามแถว        ← ขั้นถัดไป (เริ่มหลัง CR-REPLAY-001 ปิด)
(4) ทดสอบ L3 ในเกมจริง
(5) ปิด acceptance ทีละแถว (พร้อมหลักฐาน)
```

## 4. L4 Shared Services — สัญญา preconditions (สร้างพร้อมเฟส 2–3)

L4 ไม่มี matrix แยก (ตาม §4.1 หน่วยส่งมอบคือ Product Module) — สัญญาของ L4 ถูกกำหนดและพิสูจน์**ผ่านแถวของโมดูลผู้ใช้**:

| L4 Service | สัญญาหลัก (§3.5) | พิสูจน์ผ่านแถว |
|---|---|---|
| `TargetService` | `GetCurrentTarget()` / `GetCandidates(fov, filters)` + **generation token** (กัน duplicate lock) | VA-005, VA-012, VA-024, ES-015 |
| `PredictionService` | `GetPredictedPosition(target, leadTime)` (v1 ping / v2 +velocity+ทิศ) | VA-013, VA-029 |
| `CameraService` | ตำแหน่ง/ทิศ/FOV + ล็อกกล้อง (ห่อ CameraAdapter:SetLock) | VA-023, VA-026 |
| `CombatStateService` | `IsStunned(player)` + สถานะ ragdoll/cooldown รายผู้เล่น | CC-001, CC-004, VA-011 |

## 5. PENDING contracts ทั้งหมดในชุดนี้ (สรุปรวม — รายละเอียดในไฟล์โมดูล)

> ✅ เจ้าของอนุมัติทั้งหมดเป็น **implementation prerequisites** (1 ต.ค. 2026) — ไม่ใช่ scope ใหม่เพราะเป็น contract ที่ matrix ต้องใช้ตาม architecture เดิม ทุกตัวต้องมี test + regression ตามปกติ

| Contract | ไฟล์เจ้าของ | สถานะ | วิธีปิด |
|---|---|---|---|
| `CameraAdapter:SetLock` | voidaim.md §6.1 | ✅ อนุมัติเป็น prerequisite | implement เฟส 2 พร้อม L1/L2 |
| `CameraAdapter:WorldToScreen` | esp.md §6.1 | ✅ อนุมัติเป็น prerequisite | เช่นกัน — visible→{x,y,visible} / camera gone→nil+structured error |
| `CombatAdapter:GetSkillCooldown` | voidaim.md §6.2 (ใช้ร่วม MC/CC) | ✅ อนุมัติเป็น prerequisite — **สัญญาเดียวกันทั้งระบบ ห้ามสร้างสองชุด** | survey จริงต้นเฟส 2 → contract note → ถอด PENDING |
| `InputAdapter:DispatchKey` (ใหม่) | macro.md §6.1 | ✅ อนุมัติเป็น prerequisite | สำเร็จ→true / ไม่รองรับ→false+{code="UNSUPPORTED"} / key-down ทุกครั้งต้องมี key-up เมื่อ stop/disable/destroy/rollback — survey กลไก Volt เฟส 3 |
| `CharacterAdapter` VFX (SetVfxHidden) | race.md §6.1 | ✅ อนุมัติเป็น prerequisite | survey เฟส 4 |
| `CharacterAdapter` write-side (ApplyVelocity/SetStateFlag) | movement.md §6.1 | ✅ อนุมัติเป็น prerequisite | survey เฟส 4 |
| อ่านสต๊อก dealer ผ่าน WorldAdapter | fruit.md §6.1 | ✅ อนุมัติเป็น prerequisite — ห้ามอ่าน instance เกมตรงจาก Fruit | survey เฟส 4 |
| กลไกย้ายตัวละคร (teleport) | serverhop-teleport.md §6.1 | ✅ อนุมัติเป็น prerequisite | survey จริงเฟส 4 แล้ว freeze |

## 6. สถานะ CR-REPLAY-001 — ✅ อนุมัติ (ตัวเลือก ข) +  implement และพิสูจน์แล้วรอบ 6 (1 ต.ค. 2026)

- **คำตัดสินเจ้าของ:** อนุมัติ Change Request ให้แก้ `eventbus.lua` เพื่อให้ behavior ตรง §3.6 ดั้งเดิมโดยไม่ redesign EventBus
- **ขอบเขตที่อนุมัติ (ครบถ้วน):** queued event เก็บ generation/timestamp/type/replayable/payload + Replay Policy คงเดิม (Transient→DROP / State-Config→REPLAY LWW / Idempotent→REPLAY / world state→DROP + re-derive จาก Adapter ห้ามย้อน world state) + ต้องมี regression + L1/L2 ก่อนปิด + อัปเดต CG-15 กลับเป็น Replay Policy
- **สิ่งที่ทำรอบ 6:** `eventbus.lua` v0.2.0→0.3.0 (Queue คืน payload ครบ 5 ช่อง + `ExportQueue` deep-clone พร้อม payload + `ImportQueue` policy ตัดสินใหม่ตาม Declare ของรุ่นปลายทาง ใช้ได้เฉพาะขณะ frozen + Shutdown ไม่ล้างคิวให้ข้าม generation ได้รวม event ที่ hook ปล่อยตอน teardown) + `update.lua` export หลัง TEARDOWN → import ก่อน Resume **ทั้ง path สำเร็จและ path rollback** + counter `imported/importDropped` ใน Stats (§8.4)
- **หลักฐานการปิด (ตามกฎ "ยังไม่ถือว่า CR ปิดเพียงเพราะโค้ดถูกแก้ — ต้องพิสูจน์ behavior จริง"):** L1 190/190 ALL_GREEN (ใหม่ 12 เคส: test_eventbus CR-REPLAY-001 + regression ถาวร `qa/regression/CR-REPLAY-001_cross-generation-replay.lua` path สำเร็จ+rollback) + L2 22/22 ALL_GREEN (ฉากใหม่: system_hotupdate "คิวข้าม generation บนรุ่นใหม่" + update_failures "rollback F3 ก็ replay บนรุ่นเดิม" + ฉาก F4 เดิมยืนยัน world state = DROP + re-derive) — ทุกแถวพิสูจน์ครบทั้ง 4 policy ตามที่อนุมัติ
- **CG-15 อัปเดตแล้ว** (v1.1) จาก "DROP ทั้ง freeze window" กลับเป็น Replay Policy §3.6 ดั้งเดิมตามคำสั่ง

## 7. การเปลี่ยน SSOT `dependencies.md` ที่มาพร้อมชุดนี้ (v1.3 → v1.4)

ทุก edge เพิ่มเพราะ **ฟีเจอร์ P0 ใน §4.3 บังคับ** (ไม่ใช่ขอใหม่นอกแผน) — รายละเอียด + เหตุผลเต็มอยู่ใน changelog ของ dependencies.md v1.4:

| Edge ใหม่ | เหตุผล (อ้างแถว matrix) |
|---|---|
| `VoidAim` → `KeybindService`, `InputAdapter` | Aim Key/Mode = P0 §4.3 (VA-007) + hold ตรวจ IsKeyDown |
| `VoidESP` → `CameraAdapter` | WorldToScreen — camera.lua ระบุ "ใช้โดย ESP เฟส 2" (ES-009) |
| `VoidMacro` → `CombatAdapter`, `KeybindService` | Soru Skill Macro = P0 §4.3 (MC-011) + ปุ่มอัด/เล่น (MC-001) |
| `Race` → `KeybindService` | ActivateRaceV4 = P0 §4.3 (RA-007) |
| `Fruit` → `CombatAdapter` | remote gate เจ้าของเดียวของระบบ (FR-010) — **ทางเลือกแยก RemoteAdapter = CR แยก ดู fruit.md §6.2** |

ผลกระทบ: 39 node (ไม่เปลี่ยน) / 48 → 55 edge — ผ่าน build validation 3 ชั้น + `npm run verify` เขียวทั้ง chain (รายงานรอบนี้)

## 8. คำถามเปิด — ✅ ตอบครบทั้ง 3 ข้อโดยเจ้าของโปรเจกต์ (1 ต.ค. 2026)

| # | เรื่อง | คำตัดสิน | บันทึกไว้ที่ |
|---|---|---|---|
| Q1 | **"Ken" (Observation Haki)** — §4.1 จัดเข้า Combat Core แต่ §4.3 ไม่มี Auto Ken | **(ข)** Ken status display อยู่ใน VoidESP P0 (ES-001/ES-002) / **Auto Ken / Auto Observation out of scope v1.0** — ไม่ต้องเปิด CR (ไม่ได้เปลี่ยน requirement ที่ freeze) | combat-core.md §6.2 (v1.1) |
| Q2 | **Remote gate ของ Fruit** — CombatAdapter หรือแยก RemoteAdapter | **(ก)** Fruit → **CombatAdapter เป็น remote gate เดียว** ไม่สร้าง RemoteAdapter — เมธอดที่ต้องเพิ่ม = adapter contract pending ของ implementation phase (มี test + regression แต่ไม่ใช่ architecture layer ใหม่) + stock/dealer read ผ่าน WorldAdapter ห้ามอ่าน instance เกมตรง | fruit.md §6.2 (v1.1) |
| Q3 | **CR-REPLAY-001** (ค้างจากรอบ 4) | **(ข)** อนุมัติแก้ `eventbus.lua` ตามขอบเขต CR — implement + พิสูจน์ครบรอบ 6: ดู §6 ของไฟล์นี้ | §6 ของไฟล์นี้ + _common-gates.md CG-15 (v1.1) |

## 9. ตาราง Sign-off รีวิวรายไฟล์ — ✅ อนุมัติครบทั้ง 10 ไฟล์ (1 ต.ค. 2026)

| ไฟล์ | อนุมัติเนื้อหา | ขอแก้ (ระบุแถว) | หมายเหตุ |
|---|---|---|---|
| `_common-gates.md` | ✅ APPROVED | — ไม่มี | CG-15 อัปเดต v1.1 ตาม Q3 + CG-05 clarification |
| `voidaim.md` | ✅ APPROVED | — ไม่มี | ธงเรือ — รีวิวละเอียดสุด |
| `esp.md` | ✅ APPROVED | — ไม่มี | ES-014 อัปเดต v1.1 ตาม Q3 |
| `macro.md` | ✅ APPROVED | — ไม่มี | contract ใหม่ DispatchKey อนุมัติเป็น implementation prerequisite |
| `combat-core.md` | ✅ APPROVED | — ไม่มี | + ตอบ Q1 = (ข) บันทึกใน §6.2 |
| `race.md` | ✅ APPROVED | — ไม่มี | |
| `fruit.md` | ✅ APPROVED | — ไม่มี | + ตอบ Q2 = (ก) บันทึกใน §6.2 |
| `movement.md` | ✅ APPROVED | — ไม่มี | |
| `serverhop-teleport.md` | ✅ APPROVED | — ไม่มี | |

**Contract ที่อนุมัติให้เป็น implementation prerequisites (ไม่ใช่ scope ใหม่ — ต้องมี test + regression ตามปกติ):** `InputAdapter:DispatchKey(key, down)` (สำเร็จ→true / ไม่รองรับ→false+UNSUPPORTED / ทุก key-down ต้องมี key-up เมื่อ stop/disable/destroy/rollback / ผ่าน InputAdapter ทางเดียว) · `CameraAdapter:WorldToScreen(point)` ({x,y,visible} / camera gone = nil+structured error) · Fruit stock/dealer read ผ่าน WorldAdapter + remote ทั้งหมดผ่าน CombatAdapter · `CombatAdapter:GetSkillCooldown(skill)` ใช้สัญญาเดียวกับ voidaim ไม่สร้างสองชุด

## 10. กฎของชุดเอกสารนี้ (เอกสารมีชีวิต §2.5)

1. เจอ behavior ใหม่ที่สำคัญ = **เพิ่มแถวใหม่เสมอ ไม่มีข้อยกเว้น** — พร้อมบันทึกใน changelog ของไฟล์นั้น + แจ้งในรายงานของรอบนั้น (ไม่แอบเพิ่มเงียบ ๆ ตามกฎ No Silent Hotfix §11)
2. แถวที่เพิ่มระหว่าง implementation ต้องระบุระดับ P0/P1 ชัดเจน — เพิ่ม P0 ระหว่างเฟส = ต้องแจ้งเจ้าของทันที (กระทบ DoD รับงานของเฟสนั้น)
3. ทุกไฟล์มีตารางติดตามสถานะรายแถวเป็นหลักฐานการตัดสิน (§6.4) — สถานะอนุญาต: `ยังไม่พิสูจน์` / `ผ่าน (+หลักฐาน)` / `ไม่ผ่าน (+BUG ID)` / `ระงับชั่วคราว — รอ <ระบบ>` / `เลื่อน v1.1 (เฉพาะ P1)` / **`OUT OF SCOPE — PC ONLY (CR-PC-ONLY)` — ไม่ใช่ "ผ่าน" และห้ามใช้ปิดเฟส (ดู `_common-gates.md` §3.1)**
4. แก้สัญญา interface ที่ประกาศใน matrix = ต้องผ่านการรีวิวของเจ้าของก่อน (เพราะแถวอื่นผูกกับสัญญานั้น)

## 11. Changelog ของไฟล์นี้

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.2 | 1 ตุลาคม 2026 | **CR-PC-ONLY:** MC-012 (macro P0) + VA-033 (voidaim P1) = **OUT OF SCOPE — PC ONLY** (เก็บ ID เพื่อ traceability) — แถว active 150→148 (117 P0 + 16 P1 + 15 CG) + เพิ่มสถานะ `OUT OF SCOPE — PC ONLY` เข้ากฎ §10.3 (ห้ามนับเป็น "ผ่าน") + กฎเต็มที่ `_common-gates.md` §3.1 — ตามคำตัดสินเจ้าของโปรเจกต์ "PC/Desktop only บน Volt" |
| 1.1 | 1 ตุลาคม 2026 | บันทึกคำตัดสินเจ้าของ (รอบ 6): sign-off ครบ 10 ไฟล์ = **APPROVED BASELINE v1.0** + Q1=(ข) / Q2=(ก) / Q3=(ข) + สถานะ CR-REPLAY-001 (implement + พิสูจน์แล้ว ดู §6) + ตาราง §9 กรอกเสร็จ + contract prerequisites ที่อนุมัติ |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรกพร้อมทั้งชุด (8 โมดูล + common gates = 150 แถว) — deliverable บังคับของเฟส 0 (§5.3) ส่งรีวิวตาม §4.5 |
