# Behavioral Acceptance Matrix — Race

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 (ไม่มีแถวที่ขอแก้) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **อ้างอิง:** แผน freeze v2.1 §4.3, §3.4 + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `Race` / L5 Feature Modules |
| Depends on | `PlayerAdapter`, `CharacterAdapter`, `KeybindService` *(เพิ่ม v1.4 — ActivateRaceV4 ใช้คีย์ตาม §4.3)* |
| Internal services (ไม่ขึ้น graph) | RaceDetector, V4Sequencer |
| Capability gates (CG-07) | ไม่มี capability เฉพาะ |
| สาย adapter ที่กระทบ (CG-08) | `PlayerAdapter` ตาย = ไม่รู้เผ่า/สถานะ → ปิด + แจ้ง / `CharacterAdapter` ตาย = V4Sequencer ทำไม่ได้ → ปิด + แจ้ง |
| Config root | `settings.race.*` (โครง: `enabled`, `autoV3`, `autoV4`, `smartV3`, `smartV4`, `hideV4Effects`, `hideControlEffects`, `activateV4Key`) |
| Keybind actions (CG-12) | `race.activateV4` |
| Bus events | ฟัง `config:changed` / เผยแพร่ `module:state` + `notify:user` (ผล V3/V4) |
| L4 services ที่เรียกตรง | — |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md`

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 4 ไม่จบ §5.7)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| RA-001 | P0 | Auto V3 | เปิด `autoV3` + มีเผ่าที่ทำ V3 ได้ | ทำ V3 ครบทุกขั้นตามลำดับ (V4Sequencer ขับเคลื่อนผ่าน adapter) — จบขั้นสุดท้าย + แจ้งผล | ขั้นกลางทางล้ม (NPC ไม่ตอบ) = retry ตามค่าตั้ง แล้วแจ้งเมื่อเกิน / ตายกลาง sequence = หยุด-เริ่มใหม่ตามค่าตั้ง (idempotent) | L2 (stub quest flow) + L3 |
| RA-002 | P0 | Auto V4 | เปิด `autoV4` + เงื่อนไข V4 พร้อม | ทำ V4 ครบทุกขั้น + แจ้งผล | ขั้น trial ล้ม / ออกจากเกมกลาง sequence = หยุดสะอาด orphan 0 | L2 + L3 |
| RA-003 | P0 | Smart V3 | เปิด `smartV3` + เงื่อนไขยังไม่พร้อม | **ไม่ทำอะไรเลย**จนกว่าเงื่อนไขพร้อม (ระดับ/ไอเทมครบ) — ตรวจสอบต่อเนื่องแบบไม่สแปม (อัปเดตตามที่ตั้ง) | เงื่อนไขพร้อมตอนกลาง sequence อื่น (รอจบก่อน — ไม่ซ้อน sequence) | L2 |
| RA-004 | P0 | Smart V4 | เปิด `smartV4` + เงื่อนไขยังไม่พร้อม | เช่นเดียวกับ RA-003 สำหรับ V4 + จับจังหวะตามเงื่อนไขที่ตั้ง | V4 พร้อมตอนกำลังไฟต์ (ตามค่าตั้ง: รอ/ทำทันที) | L2 |
| RA-005 | P0 | HideV4Effects | เปิด `hideV4Effects` + เข้าสถานะ V4 | ซ่อน VFX ของ V4 (จัดการผ่าน CharacterAdapter — contract ข้อ 6.1) โดย gameplay อื่นไม่กระทบ | เข้า-ออก V4 ถี่ / ซ่อนแล้วคนอื่นยังเห็นบางส่วน (แจ้งข้อจำกัดตามที่พบจริง — ไม่อ้างว่าซ่อนได้หมดถ้าไม่จริง) | L2 + L3 |
| RA-006 | P0 | HideControlEffects | เปิด `hideControlEffects` | ซ่อนเอฟเฟกต์ UI/control ที่เกี่ยวกับ race ตามที่ตั้ง | เอฟเฟกต์เกิดตอน sequence กำลังทำงาน | L2 + L3 |
| RA-007 | P0 | ActivateRaceV4 (คีย์) | กด `race.activateV4` | เปิดใช้ V4 ทันทีเมื่อเงื่อนไขเกมอนุญาต + แจ้งเมื่อเงื่อนไขไม่พร้อม (ไม่เงียบ) | กดตอน cooldown / กดค้าง (ทำครั้งเดียว ไม่รัว) | L1 + L2 |
| RA-008 | P0 | RaceDetector | เข้าเกม/เปลี่ยนเผ่า | ตรวจเผ่าปัจจุบันถูกต้อง (จาก `PlayerAdapter`) และใช้ตัดสิน sequence ที่ใช้ได้ — ผิดเผ่า = ไม่มี sequence รัน + แจ้ง | เปลี่ยนเผ่ากลางเซสชัน (re-detect + ปรับ) / เผ่ายังไม่รองรับ (แจ้งรายการที่รองรับ) | L1 + L2 |
| RA-009 | P0 | Sequence ทั้งหมด idempotent + ไม่ลาม | หยุด/ปิดโมดูล/ตาย/hot update กลาง sequence | หยุดสะอาดทุกกรณี: task หยุด + orphan 0 + สถานะเกมไม่ถูกทิ้งกลางค้าง (re-entrant ได้) | ปิดตอนขั้นที่ยิง remote แล้ว (รอผลก่อนหยุดหรือยกเลิกชัดเจน — ตาม contract ขั้น) | L2 |
| RA-010 | P0 | ประตูเดียว: ทุกการกระทำผ่าน adapter | ตรวจโค้ด + ทุกฉาก | ทุก interaction (NPC/VFX/สถานะ) ผ่าน `CharacterAdapter`/`PlayerAdapter` เท่านั้น — lint บังคับ | — | L2 + lint |

## 4. แถว Matrix ระดับ P1

— *(ไม่มีรายการ P1 สำหรับ Race ตาม §4.3)*

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0 §5.1)

- **Race Timing Profiles** — จูนจังหวะ sequence รายเผ่า (§4.3)

## 6. ความต้องการต่อ Adapter ที่ยัง PENDING (ข้อเสนอรอเจ้าของรีวิว)

### 6.1 VFX ของ CharacterAdapter — ความต้องการของ RA-005/RA-006

`CharacterAdapter` ปัจจุบันมี `GetCharacter/GetRoot/IsAlive/GetState/GetMoveDirection` — **ยังไม่มีวิธีจัดการ VFX/เอฟเฟกต์** (สัญญา "VFX" ใน Provides ของ dependencies.md §3 ยังไม่มีเมธอดจริง)

ข้อเสนอ contract ใหม่ (survey จริงตอน implement เฟส 4 แล้ว freeze ก่อนใช้ — แบบเดียวกับ GetSkillCooldown):
- `CharacterAdapter:SetVfxHidden(kind, hidden)` — kind = ชุด VFX ที่จัดการได้ (เช่น v4, control) + คืนผลจริง (ซ่อนได้/ไม่ได้บางส่วน — แจ้งตามจริง ตาม RA-005 edge)
- ทุกการเปลี่ยน VFX ต้องผ่านเมธอดนี้ทางเดียว (lint) — ห้ามแตะ instance เกมตรง

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| ส่วนแบ่ง frame cost ของ Race | รวม ≤ 2.0 ms/frame — baseline รายโมดูลเก็บตอน implement | แย่ลง > 10% ไม่มีเหตุผล = บั๊ก |
| Sequence ค้าง (ไม่จบ-ไม่แจ้ง) | 0 ครั้ง | > 0 = บั๊ก |

## 8. L3 Checklist ฉบับร่าง (เฟส 4)

1. ☐ Auto V3 ครบทุกขั้นในเกมจริง — แจ้งผลตอนจบ (RA-001)
2. ☐ Auto V4 ครบทุกขั้น (RA-002)
3. ☐ Smart V3/V4 ไม่ทำงานเมื่อเงื่อนไขไม่พร้อม (RA-003/RA-004)
4. ☐ HideV4Effects — เทียบสายตาก่อน/หลัง + ถามเพื่อนว่าเห็น VFX ไหม (RA-005)
5. ☐ กดคีย์ ActivateRaceV4 (RA-007)
6. ☐ เปลี่ยนเผ่ากลางเซสชัน → ตรวจถูก (RA-008)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 4) | — |
| RA-001 … RA-010 (P0) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Race)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Auto V3 | P0 | RA-001 |
| Auto V4 | P0 | RA-002 |
| Smart V3 | P0 | RA-003 |
| Smart V4 | P0 | RA-004 |
| HideV4Effects | P0 | RA-005 |
| HideControlEffects | P0 | RA-006 |
| ActivateRaceV4 | P0 | RA-007 |
| Race Timing Profiles | P2 | §5 (ไม่ตรวจรับ v1.0) |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.1 | 1 ตุลาคม 2026 | บันทึก sign-off เจ้าของโปรเจกต์ (APPROVED BASELINE v1.0 ไม่มีแถวที่ขอแก้) พร้อมคำตัดสิน Q1=(ข) / Q2=(ก) / Q3=(ข) — ชุดนี้เป็น acceptance source of truth ของ implementation ตั้งแต่รอบ 6 |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (10 แถว P0) + เสนอ contract VFX ของ CharacterAdapter (ยังไม่มีเมธอดจริง — survey ตอน implement) |
