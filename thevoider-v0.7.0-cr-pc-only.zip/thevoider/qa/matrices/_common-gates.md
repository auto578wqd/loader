# Behavioral Acceptance Matrix — Common Gates (ประตูบังคับร่วมทุก 8 Product Modules)

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off ทุกไฟล์ 1 ตุลาคม 2026 (150 แถว: 118 P0 + 17 P1 + 15 CG) พร้อมคำตัดสิน Q1=(ข) / Q2=(ก) / Q3=(ข) — แก้ไขหลังนี้ต้องผ่าน Change Request ตามกฎเอกสารมีชีวิต §2.5
> **[CR-PC-ONLY 1 ต.ค. 2026]** แพลตฟอร์มรับรอง = **PC/Desktop only บน Volt** — gate ที่พูดถึง mobile/touch path = **OUT OF SCOPE — PC ONLY** · **desktop/keyboard path ของ gate เดียวกันยังบังคับผ่านตามเดิม** · **ห้ามนับแถว/เงื่อนไข mobile ที่ถูกตัด (N/A) เป็น "ผ่าน"** — ดูกฎเต็มใน §3.1
> **อ้างอิง:** แผน freeze v2.1 §2.4/§2.5/§3.4/§3.5/§3.6/§3.9/§5.1/§6.3/§6.4/§11 + dependencies.md v1.4
>
> ไฟล์นี้คือชุด gate ที่ **ทุก** Product Module (L5: VoidAim, VoidESP, VoidMacro, CombatCore, Race, Fruit, Movement, ServerHop) ต้องผ่าน **ทั้งหมด** — โมดูลใดไม่ผ่าน gate ใด = โมดูลนั้น "ยังไม่เสร็จ" ไม่ใช่ "เกือบเสร็จ" (§3.4 กฎเหล็กของ Destroy)
> แถวเฉพาะพฤติกรรมฟีเจอร์ของแต่ละโมดูลอยู่ใน `qa/matrices/<module>.md` ของโมดูลนั้น — การติดตามสถานะ CG รายโมดูลอยู่ในตารางติดตามของไฟล์โมดูลนั้น ๆ

## 1. หลักการของ Common Gates

- ทุก gate มาจาก **requirement ที่ freeze ไว้แล้ว** ในแผน v2.1 หรือสัญญา interface ที่ผ่าน gate รอบก่อน — ไม่มี gate ที่คิดขึ้นใหม่นอกแผน
- ทุก gate **วัดได้ด้วยเครื่องมือที่มีอยู่จริง** (L1 fengari + stub / L2 integration + stub game + virtual time / L3 checklist บน Volt) ตาม §6.1
- gate ที่ต้อง parameter เฉพาะโมดูล (เช่น capability ที่ต้องใช้, สาย adapter ที่กระทบ) ระบุค่าไว้ใน **ส่วนหัวของไฟล์โมดูล** — ไฟล์นี้เก็บตัว gate กลาง ๆ

## 2. ตาราง Common Gates (CG-01 – CG-15)

| ID | Gate | Behavior ที่ต้องเกิด (วัดได้) | วิธีวัด / ชั้นทดสอบ | อ้างอิง |
|---|---|---|---|---|
| CG-01 | Init ไม่แตะเกม | `Module:Init(context)` รับ dependencies ผ่าน context เท่านั้น — ตลอด Init ห้ามมีการเรียก Game Adapter หรือ instance ของเกมแม้แต่ครั้งเดียว (อ่านค่า config/สร้าง table ได้) | L2: stub game ติด counter — assert จำนวน call ระหว่าง Init = 0 + lint ห้ามแตะเกมนอก adapter | §3.4 |
| CG-02 | Disable แล้ว Enable คง state | หลัง `Disable()` → `Enable()` กลับมา: ค่าที่ผู้ใช้ตั้งไว้ + state ทำงานไม่หาย (ไม่ reset เป็น default) — state ถูกเก็บในหน่วยความจำตาม lifecycle | L2: สั่ง Enable→ตั้งค่า→Disable→Enable → อ่านค่าเทียบ 100% + พฤติกรรมทำงานต่อ | §3.4 |
| CG-03 | Destroy → resource orphan = 0 | หลัง `Destroy()` จบ: Resource Registry รวม **4 ชนิด** (task/connection/render/temp) ของ owner = ชื่อ node ต้องเท่ากับ **0 ทุกชนิด** — assert อัตโนมัติ ไม่ใช่ตาดู | L2: Registry assert ใน debug build + ผล assert ใน test log (fail ทันที ไม่ใช่เตือน §9.1) | §3.4/§9.1 |
| CG-04 | เข้าร่วม Hot Update ได้ | โมดูลลงทะเบียน state provider ตามสัญญา `{name, Serialize, Apply}` ของ bundle + state รอดข้ามรุ่น: hot update v→v+1 แล้ว state โมดูลยังอยู่ (ผ่าน `MIGRATE` ด้วย `MigrateState` + `schemaVersion` ของ state) | L2 ฉาก hotupdate ที่มีโมดูลจริงลงทะเบียน (ต่อยอดฉาก system_hotupdate เดิม) | §3.6/§3.4 |
| CG-05 | Rollback = ใช้ต่อได้จริง | หลัง rollback ตาม path F1–F4: โมดูล Enable ใช้งานต่อได้ + state กลับสถานะก่อนอัปเดต (ผ่าน `Apply`) + config ผู้ใช้ไม่เปลี่ยน — **ไม่ใช่แค่ "โหลดโค้ดเก่า"** (คำตัดสิน Loader gate รอบ 4) **[คำชี้แจงจากเจ้าของ 1 ต.ค. 2026 — ล็อกไว้ใน test wording ไม่ใช่การขยาย scope]** = state/config **recovery + ใช้งานต่อได้จริง** ไม่ใช่บังคับให้ transient execution state กลับมา "กำลังทำต่อกลาง operation": rollback ระหว่างเล่น macro = หยุดสะอาด ไม่เล่นต่ออัตโนมัติ ไม่มี key ค้าง orphan=0 แจ้งผู้ใช้ — snapshot กู้ config/profile/macro data แต่ไม่ต้อง restore สถานะ "กำลังเล่นอยู่" | L2 failure injection ราย path + ตรวจ lifecycle ใช้งานต่อ + state/config เทียบ snapshot | §3.6 + คำตัดสินรอบ 4 + คำชี้แจงรอบ 6 |
| CG-06 | Config integration | อ่านค่าจาก `settings.<module>.*` ผ่าน ConfigService เท่านั้น + ตอบสนอง event `config:changed` ของ key ที่เกี่ยวกับตัวเองภายใน frame เดียวกัน/ถัดไป (ไม่ต้องรีสตาร์ทโมดูล) + ค่าผู้ใช้อยู่รอด migration chain (ห้ามทิ้ง §3.7) | L1: mapping key→behavior / L2: เปลี่ยนค่ากลางรัน + ฉาก config migration เดิม | §3.7/§3.5 |
| CG-07 | Capability gate | capability ที่โมดูลต้องใช้ (ระบุรายโมดูลในไฟล์โมดูล) หาย/ถูกปิดจำลอง = graceful disable **ระดับที่ถูกต้อง** (ทั้งโมดูล หรือ เฉพาะฟีเจอร์ ตามที่ระบุ) + `notify:user` ภาษาไทย + โมดูลอื่นเดินต่อ ไม่มี error ลาม | L2: ชุดทดสอบถาวร "ปิด capability จำลอง" (§6.3 ข้อ 2) — stub ให้ capability หายกลางรัน | §6.3/§3.9-5 |
| CG-08 | Adapter dead ไม่ลาม | สาย API ที่โมดูลใช้ตาย (ตาม mapping สายตายของ Self-Probe + graph) → โมดูลหยุดใช้ API นั้น + แจ้งผู้ใช้ + ไม่ throw ไม่ลามไปโมดูลอื่น — กลับมาใช้ได้เมื่อ API กลับมา (re-probe) ตามค่าตั้ง | L2: ฉาก adapter dead 3 ระดับ (เดิม — ขยายให้ครอบคลุมโมดูลจริง) | §3.3 |
| CG-09 | Error boundary + Bug ID | error ภายในโมดูลถูก Boundary จับ ระบบไม่ดับ + error counter ต่อโมดูลตรงกับ session log 100% (ไม่มี error ไร้เจ้าของ) + ทุก error ที่เกิดมี Bug ID ก่อนปิด (กฎ §11) | L2: pcall spy ปล่อย error จำลองรายโมดูล + เทียบ counter/log / L3: จาก session จริง | §5.1/§11 |
| CG-10 | Watchdog | โมดูลหยุดหายใจ (task ค้าง) = watchdog restart 1 ครั้ง + backoff + แจ้งผู้ใช้ — พังซ้ำใน window เดียวกัน = ปิดตัวถาวรพร้อมแจ้ง (ไม่พังเงียบ) | L2: virtual-time watchdog ฉากเดิม + โมดูลจริงที่ล็อก loop จำลอง | §3.2 |
| CG-11 | i18n ครบ 2 ภาษา | ข้อความที่ผู้ใช้เห็นทุกชิ้นของโมดูลผ่าน `I18nService:T()` — key coverage 100% ทั้งไทย/อังกฤษ ห้ามมี key ตกหล่น/ข้อความค้างภาษาเดิม (เกณฑ์เดียวกับ DoD เฟส 1) | L1: ไล่ทุก key ที่โมดูลใช้ทั้ง 2 ภาษา | §5.4/§3.9 |
| CG-12 | Input ผ่าน KeybindService ทางเดียว | ทุกคีย์/ปุ่มลัดของโมดูลลงทะเบียนผ่าน `Keybind:Bind` + `OnAction` เท่านั้น — ห้ามฟัง input เองนอก InputAdapter (lint บังคับ) + คีย์ชน = ปฏิเสธพร้อมแจ้ง ไม่เขียนทับเงียบ (สัญญา Keybind เดิม) | L2: สั่ง Bind คีย์เดียวกัน 2 action + lint / L1: สัญญา Keybind เดิม | §3.5/สัญญา Keybind |
| CG-13 | No Silent Degradation ใน UI | ฟีเจอร์ที่ปิดเพราะ capability/probe แสดงเป็นปุ่มสีเทา + 🔒 + เหตุผลสั้น (แตะดูรายละเอียดได้) — ไม่ซ่อนไปเงียบ ๆ (เฟส 1 จึงจะวัดส่วน UI จริงได้ — กำหนด behavior ไว้ตอนนี้เพื่อให้โมดูลเผยแพร่สถานะถูกต้องตั้งแต่ต้น) | L2 ตอนเฟส 1: ตรวจ state ที่โมดูลเผยแพร่ (disabled + เหตุผล) ตรงเงื่อนไข CG-07/CG-08 | §8.2/§3.9-5 |
| CG-14 | State schema serialize ได้จริง | `SerializeState` คืน plain table (string/number/boolean/table เท่านั้น — ไม่มี function/instance Vector3 ดิบ) + มี `schemaVersion` ของ state + ผ่าน walkPlain (สัญญา Rollback Snapshot 7 ช่อง) | L1: walkPlain บน state จริง + KAT กับ deepClone | §3.4/§3.6 + สัญญา update.lua |
| CG-15 | Freeze window: Replay ตาม policy (§3.6 ดั้งเดิม — กลับมาตาม CR-REPLAY-001 ที่อนุมัติ) | event ที่เกิดระหว่างหน้าต่าง freeze (FREEZE จนจบ TEARDOWN) ถูกส่งข้าม generation ไป replay บนระบบปลายทาง (ทั้ง path อัปเดตสำเร็จและ path rollback) ตาม policy: **Transient → DROP** / **State-Config → REPLAY เรียง timestamp (last-write-wins)** / **Idempotent → REPLAY** / **สถานะโลกจริง (target/position/alive) → DROP + re-derive จาก Adapter** (ห้ามย้อน world state ด้วย event เก่า) — policy ตัดสินโดย Declare ของรุ่นปลายทาง ชนิดที่รุ่นใหม่ไม่รู้จัก = drop + นับ undeclared | L1: test_eventbus (CR-REPLAY-001 9 เคส) + regression ถาวร / L2: ฉาก system_hotupdate (path สำเร็จ) + ฉาก update_failures (path rollback F3) + ฉาก F4 (Transient โลกจริง) — หลักฐานรอบ 6: L1 190/190 + L2 22/22 | §3.6 + CR-REPLAY-001 (อนุมัติ ตัวเลือก ข — 1 ต.ค. 2026) |

## 3. วิธีนับ "ผ่าน" ของ Common Gates

- โมดูลหนึ่งตัวผ่าน CG เมื่อ **ทุกแถว CG-01 ถึง CG-15 มีหลักฐานกำกับ** (ผลรัน L1/L2 หรือ L3 checklist ตามชั้นที่แถวระบุ) — สถานะถูกบันทึกในตารางติดตามของไฟล์โมดูลนั้น (ส่วนท้ายไฟล์)
- หลักฐานต้องระบุแหล่งที่มาได้ (ชื่อไฟล์เทส/ฉาก L2/รอบที่รัน + วันที่) ตามกฎ "ตัวเลขทุกตัวมีที่มา" (§9.2)
- แถว CG ที่ยังไม่พิสูจน์ได้เพราะระบบที่ต้องพึ่งยังไม่มี (เช่น CG-13 ต้องรอ UI เฟส 1) = สถานะ "ระงับชั่วคราว — รอ <ระบบ>" ไม่ใช่ "ผ่าน" — ห้ามปิดล่วงหน้า

### 3.1 กฎการนับสถานะ mobile หลัง CR-PC-ONLY (1 ต.ค. 2026)

- แพลตฟอร์มที่รับรอง = **PC/Desktop only บน Volt** — Mobile = ไม่รองรับ / ไม่ทดสอบ / ไม่รับประกัน
- ส่วนของ gate ใดที่เกี่ยวกับ **mobile/touch path เฉพาะ** (เช่น ปุ่มลัดมือถือ, Mobile Aim Button, Mobile Macro Slots, L3 checklist มือถือ) = สถานะ **`OUT OF SCOPE — PC ONLY (CR-PC-ONLY)`**
- **ห้ามนับ "N/A เพราะ mobile ถูกตัด" เป็น "ผ่าน"** — แถวนั้นไม่ถูกปิดด้วยหลักฐานใด ๆ และไม่ถูกนับเป็นแถว active ของเฟส
- **ส่วน desktop/keyboard path ของ gate เดียวกันยังบังคับผ่านตามเดิม** (เช่น CG-12 — คีย์ลัดคีย์บอร์ดบน PC ยัต้องผ่าน KeybindService ทางเดียว + คีย์ชน = ปฏิเสธ) — การตัด mobile ไม่ได้ตัดข้อกำหนดของ PC ตามไปด้วย
- อุปกรณ์ PC จอสัมผัส (touch-screen บนเดสก์ท็อป) ไม่อยู่ในขอบเขตรับประกัน — UI ออกแบบและรับรองด้วย mouse+keyboard เท่านั้น

## 4. Changelog ของไฟล์นี้ (เอกสารมีชีวิต §2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.2 | 1 ตุลาคม 2026 | **CR-PC-ONLY:** เพิ่ม §3.1 กฎการนับสถานะ mobile — mobile/touch path = `OUT OF SCOPE — PC ONLY` · ห้ามนับ N/A เป็น "ผ่าน" · desktop/keyboard path ยังบังคับผ่านตามเดิม — ทุก gate ในตาราง §2 ที่มีส่วนของ input ใช้กฎนี้ (โดยเฉพาะ CG-12) |
| 1.1 | 1 ตุลาคม 2026 | ตามคำตัดสินเจ้าของ (sign-off รอบ 6): (1) **CG-15 กลับเป็น Replay Policy §3.6 ดั้งเดิม** ตาม CR-REPLAY-001 ที่อนุมัติ (ตัวเลือก ข) — แทนข้อความ "DROP ทั้งหน้าต่าง" ของ v1.0 + ผูกหลักฐาน L1/L2/regression รอบ 6 (2) **CG-05 เพิ่มคำชี้แจงจากเจ้าของ** — ตีความเป็น state/config recovery + ใช้งานต่อได้จริง ไม่ใช่ resume transient execution state กลาง operation (ล็อกใน test wording ไม่ใช่การขยาย scope) |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรกพร้อมชุด matrix ทั้ง 8 โมดูล (deliverable เฟส 0 รอบ 5) — CG-15 ระบุสถานะ CR-REPLAY-001 (OPEN) ตรง ๆ ตามคำตัดสิน Loader gate รอบ 4 |
