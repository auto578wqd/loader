# Behavioral Acceptance Matrix — Fruit

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 + คำตัดสิน Q2=(ก) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **อ้างอิง:** แผน freeze v2.1 §4.3, §3.3 (ประตูเดียวสู่เกม) + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `Fruit` / L5 Feature Modules |
| Depends on | `WorldAdapter`, `PlayerAdapter`, `CombatAdapter` *(เพิ่ม v1.4 — การ roll/store/buy/transform ทำผ่าน remote ของเกม และ CombatAdapter คือเจ้าของ remote gate เพียงตัวเดียวในระบบปัจจุบัน `GetRemotes/FireSkill` — ดูข้อ 6.2)* |
| Internal services (ไม่ขึ้น graph) | FruitDB, StockWatcher, RollController |
| Capability gates (CG-07) | ไม่มี capability เฉพาะ (ไม่ใช้ HTTP ภายนอก — StockWatcher อ่านจากโลกเกมผ่าน adapter) |
| สาย adapter ที่กระทบ (CG-08) | `WorldAdapter` ตาย = ไม่เห็นผล/สต๊อกในโลก → หยุด watcher + แจ้ง / `PlayerAdapter` ตาย = ไม่รู้กระเป๋า/สถานะตัวเอง → ปิด + แจ้ง / `CombatAdapter` ตาย = remote ใช้ไม่ได้ → หยุดทุก action + แจ้ง |
| Config root | `settings.fruit.*` (โครง: `enabled`, `autoRoll.{enabled, wanted[]}`, `autoStore.{enabled, sources}` (rolled\|purchased\|both), `transform`, `stockChecker.{enabled, interval}`, `gacha.{enabled, budget}`, `awakeningMoves`) |
| Keybind actions (CG-12) | ไม่มี keybind P0 (ทำงานอัตโนมัติ/ผ่าน UI) |
| Bus events | ฟัง `config:changed`, `adapter:health` / เผยแพร่ `module:state` + `notify:user` (ผลสำคัญ: ได้ผลที่ต้องการ/สต๊อกเข้า) |
| L4 services ที่เรียกตรง | — |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md`

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 4 ไม่จบ §5.7)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| FR-001 | P0 | Auto Roll | เปิด + ระบุ `wanted[]` | หมุนผลต่อเนื่องผ่าน remote (adapter ทางเดียว) จนกว่าจะได้ผลใน `wanted[]` — นับจำนวนครั้งหมุนได้ + หยุดทันทีเมื่อได้ (FR-009) | `wanted[]` ว่าง = ไม่หมุน + แจ้ง (validate) / เงิน/ค่าใช้จ่ายในเกมหมด = หยุด + แจ้ง ไม่ลองไร้จำกัด | L2 (stub dealer) |
| FR-002 | P0 | Auto-Store (ผลที่หมุนได้) | ได้ผลจากการหมุน | เก็บผลเข้าที่เก็บอัตโนมัติ (ตาม `sources` รวม rolled) — ตรวจสถานะกระเป๋าหลังเก็บ | ที่เก็บเต็ม = แจ้ง + หยุดเก็บ (ไม่วนสแปม) / ผลซ้ำกับที่มีอยู่ | L2 |
| FR-003 | P0 | Auto-Store (ผลที่ซื้อมา) | ซื้อผลสำเร็จ | เก็บอัตโนมัติเช่นเดียวกับ FR-002 (ตาม sources รวม purchased) | ซื้อแล้วเกมยังไม่เคลียร์รายการ (รอ confirm จากสถานะจริง ไม่เดา) | L2 |
| FR-004 | P0 | Transform | ตั้งเงื่อนไข transform | แปลงผลตามเงื่อนไข (ผลต้นทาง + เป้าหมาย) ผ่าน remote — ตรวจผลหลังแปลงจากสถานะจริง | ผลต้นทางหายกลางทาง / เงื่อนไขเป้าหมายใช้ไม่ได้ในตอนนั้น = แจ้ง ไม่พยายามวน | L2 |
| FR-005 | P0 | Stock Checker | เปิด + dealer มีสต๊อก | อ่านสต๊อกจากโลกเกมผ่าน `WorldAdapter` ตาม `interval` + แสดงรายการล่าสุด + ไม่สแปมอ่าน (respect interval) | dealer หาย/โหลดช้า (รอ + แจ้งตามค่าตั้ง) / สต๊อกเปลี่ยนถี่ (ค่าล่าสุดถูกเสมอ) | L2 |
| FR-006 | P0 | Gacha | เปิด + ตั้ง `budget` | สุ่มตามงบที่ตั้ง — **ห้ามวนเกินงบ** (นับครั้ง + ค่าใช้จ่ายรวม ≤ budget) + แจ้งเมื่องบหมด | budget ตั้ง 0 = ไม่ทำงาน + validate / ได้ผลหยุด (ตามค่าตั้ง) | L2 |
| FR-007 | P0 | Awakening Moves | เปิด + มีผล/สถานะที่เปิด awakening ได้ | เปิดใช้ awakening moves ตามเงื่อนไข (ผ่าน remote/adapter) + ตรวจสถานะหลังเปิด | awakening ถูกปิดกลางทางโดยเกม / สลับผลกลางเปิด | L2 |
| FR-008 | P0 | FruitDB | โมดูลทำงาน | ฐานข้อมูลผล (ชื่อ/หมวด/มูลค่าอ้างอิง) ครบทุกผลที่ระบบอ้างถึง — ชื่อที่ระบบใช้ตรงกับที่เกมใช้ (ตรวจ mapping ใน L2 stub) | เกมเพิ่มผลใหม่ที่ DB ไม่รู้จัก = แจ้ง "ไม่รู้จัก" ไม่พัง (และเป็นแถวใหม่ใน DB ตามเอกสารมีชีวิต §2.5) | L1 + L2 |
| FR-009 | P0 | หยุดทันทีเมื่อได้ผลที่ต้องการ | หมุนจนได้ผลใน `wanted[]` | หยุดหมุนทันที (ไม่หมุนเกิน 1 ครั้งหลังได้) + แจ้งผู้ใช้ | ได้ 2 ผลต้องการพร้อมกัน (ครั้งเดียวจบ) | L2 |
| FR-010 | P0 | ประตูเดียว: ทุก action ผ่าน adapter | ตรวจโค้ด + ทุกฉาก | ทุก roll/store/buy/transform/gacha/awakening ผ่าน remote ที่ adapter เป็นเจ้าของ — lint ห้าม remote ตรง (§3.3) | — | L2 + lint |
| FR-011 | P0 | แจ้งเตือนผลสำคัญ | เหตุการณ์สำคัญเกิด (ได้ผล wanted / สต๊อกเข้า) | `notify:user` ภาษาไทยครั้งเดียวต่อเหตุการณ์ (ไม่สแปมซ้ำ) | เหตุการณ์เกิดถี่ใน 1 วินาที (รวมแจ้ง + นับถูก) | L2 |
| FR-012 | P0 | state อยู่รอด migration + hot update | บันทึกค่าตั้ง → migration / hot update / rollback | ค่าตั้ง (`wanted[]` ฯลฯ) อยู่ครบ + หลัง rollback ไม่ "หมุนต่อ" โดยไม่รับรู้ (หยุดสะอาด + แจ้ง ตาม CG-05) | migration หลายขั้น / config เสีย → `.bak` | L1 + L2 |

## 4. แถว Matrix ระดับ P1 (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสผ่านได้ §5.1)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| FR-013 | P1 | Fruit Value Table | เปิดใช้ | แสดงมูลค่าอ้างอิงรายผลจาก FruitDB (แก้ไขค่าได้ + persist) | ค่าที่ผู้ใช้แก้ทับ DB default + อยู่รอด migration | L2 |
| FR-014 | P1 | Stock Notification | สต๊อกที่สนใจเข้า | แจ้ง `notify:user` รายรายการที่ตั้ง (แยกจาก FR-011 ที่เป็นเหตุการณ์ action) | สต๊อกเข้า-ออกถี่ (rate limit) | L2 |
| FR-015 | P1 | Auto-Store Safety whitelist | ตั้งรายการ "ห้ามเก็บอัตโนมัติ" | ผลใน whitelist ไม่ถูกเก็บอัตโนมัติ + แจ้งว่าถูกข้าม | ผลอยู่ทั้ง whitelist และ `wanted[]` (whitelist ชนะ — ปลอดภัยก่อน + แจ้งให้ผู้ใช้ตัดสิน) | L2 |

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0)

— *(ไม่มีรายการ P2 สำหรับ Fruit ตาม §4.3)*

## 6. ความต้องการต่อ Adapter ที่ยัง PENDING / ข้อเสนอ

### 6.1 StockWatcher ใช้ WorldAdapter อย่างไร

`WorldAdapter` ปัจจุบันมี `GetPlayers/GetOthers/GetServerInfo/RaycastClear/GetDistance` — การอ่านสต๊อก dealer ต้องอ่าน "entities ในโลก" ซึ่งเป็นขอบเขต Provides ของ WorldAdapter อยู่แล้ว แต่**ยังไม่มีเมธอดระดับ "อ่านสต๊อก"** — ข้อเสนอ: เพิ่มเมธอดอ่านข้อมูล entity ทั่วไป (survey โครงสร้างจริงของ dealer ตอน implement เฟส 4 แล้ว freeze contract ก่อนใช้ — แบบเดียวกับ GetSkillCooldown) ไม่มีการอ่าน instance เกมตรง

### 6.2 ✅ คำตัดสินแล้ว — Remote gate ของ Fruit ใช้ CombatAdapter (เลือก (ก) โดยเจ้าของโปรเจกต์ 1 ตุลาคม 2026)

**คำตัดสิน:** Fruit ใช้ **CombatAdapter เป็น remote gate เดียว** ตามสถาปัตยกรรมปัจจุบัน — ไม่สร้าง `RemoteAdapter` ใหม่ ไม่แตก architecture เพิ่ม

```text
Fruit
 └─ CombatAdapter   (source of truth เดียวของ action ที่ต้องผ่าน remote)
```

- เมธอดที่ Fruit ต้องการเพิ่มเติม (stock/dealer data, remote contract ที่ยังไม่มี implementation) = **adapter contract pending สำหรับ implementation phase** — ต้องมี test + regression ตามปกติ แต่**ไม่ถือเป็นการสร้าง architecture layer ใหม่**
- Stock/dealer read contract เพิ่มเข้า **WorldAdapter** ตาม §6.1 — ห้ามอ่าน instance เกมตรงจาก Fruit module
- ทางเลือกแยก RemoteAdapter ที่เคยเสนอไว้ = **ไม่นำไปใช้** ถ้าจะกลับมาแยกภายหลังต้องเปิด change request สถาปัตยกรรมใหม่ตามกฎ

*(ที่มา: การทำ P0 ทุกแถวต้องยิง remote ของเกม (roll/store/buy/transform/gacha/awakening) — CombatAdapter เป็นเจ้าของ remote gate เพียงตัวเดียว (`GetRemotes`/`FireSkill`) จึงเสนอ dependency `Fruit → CombatAdapter` ใน SSOT v1.4 ซึ่งได้รับอนุมัติยืนยันแล้ว)*

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| จำนวน remote call ที่ไม่จำเป็น | 0 (ทุก call ต้องมีเหตุผลตามแถว) | > 0 = บั๊ก |
| ส่วนแบ่ง frame cost ของ Fruit | รวม ≤ 2.0 ms/frame — baseline รายโมดูลเก็บตอน implement | แย่ลง > 10% ไม่มีเหตุผล = บั๊ก |

## 8. L3 Checklist ฉบับร่าง (เฟส 4)

1. ☐ Auto Roll หมุนจนได้ผลที่ตั้ง — หยุดเอง + แจ้ง (FR-001/FR-009)
2. ☐ Auto-Store ทั้งผลหมุนได้และซื้อมา (FR-002/FR-003)
3. ☐ Transform ผลจริง 1 รอบ (FR-004)
4. ☐ Stock Checker อัปเดตสต๊อกถูกตามจริง (FR-005)
5. ☐ Gacha ไม่เกินงบ (FR-006)
6. ☐ Awakening Moves กับผลจริง (FR-007)
7. ☐ ปิดโมดูลกลาง action → ไม่มี remote ค้าง/loop ค้าง (FR-012 + CG-03)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 4) | — |
| FR-001 … FR-012 (P0) | ยังไม่พิสูจน์ | — |
| FR-013 … FR-015 (P1) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Fruit)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Auto Roll | P0 | FR-001, FR-009 |
| Auto-Store (หมุนได้+ซื้อมา) | P0 | FR-002, FR-003 |
| Transform | P0 | FR-004 |
| Stock Checker | P0 | FR-005 |
| Gacha | P0 | FR-006 |
| Awakening Moves | P0 | FR-007 |
| Fruit Value Table | P1 | FR-013 |
| Stock Notification | P1 | FR-014 |
| Auto-Store Safety whitelist | P1 | FR-015 |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.1 | 1 ตุลาคม 2026 | บันทึกคำตัดสินเจ้าของ Q2=(ก): Fruit → CombatAdapter เป็น remote gate เดียว ไม่แยก RemoteAdapter — เมธอดที่ต้องเพิ่ม = adapter contract pending ของ implementation phase (ต้องมี test + regression) ไม่ใช่ architecture layer ใหม่ + ยืนยัน stock/dealer read ผ่าน WorldAdapter ห้ามอ่าน instance เกมตรง |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (12 แถว P0 + 3 แถว P1) + เสนอ remote gate ผ่าน CombatAdapter (ทางเลือกแยก RemoteAdapter = CR แยกตามกฎ) |
