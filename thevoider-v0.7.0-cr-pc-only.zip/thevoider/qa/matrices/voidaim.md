# Behavioral Acceptance Matrix — ⭐ VoidAim (ระบบเรือธง)

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 (ไม่มีแถวที่ขอแก้) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **[CR-PC-ONLY 1 ต.ค. 2026]** เป้าหมายรับรอง = **PC/Desktop only บน Volt** — **VA-033 (Mobile Aim Button, P1) = OUT OF SCOPE — PC ONLY** (เก็บ ID ไว้เพื่อ traceability ไม่นับเป็นแถว P1 active — ไม่ implement ไม่ย้าย P2) — แถว P1 active เหลือ **5 แถว** (VA-029–VA-032, VA-034)
> **อ้างอิง:** แผน freeze v2.1 §2.4 (แถวตัวอย่างครบชุด), §4.3, §4.4, §5.1, §9.1 + dependencies.md v1.4
> **ปรัชญา (§4.4):** "เปิดเดียวก็เทพ ปรับลึกก็โหด" — EZ Mode ใช้ได้ด้วยสวิตช์เดียว / Legend Mode ปรับได้ทุกอย่าง

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `VoidAim` / L5 Feature Modules |
| Depends on | `TargetService`, `PredictionService`, `CameraService`, `CombatStateService`, `KeybindService` *(เพิ่ม v1.4 — Aim Key/Mode เป็น P0 ของ §4.3)*, `InputAdapter` *(เพิ่ม v1.4 — โหมด hold ตรวจ `IsKeyDown` ตามแบบ Keybind เดิม)* |
| Internal services (ไม่ขึ้น graph) | AimEngine, SkillAimProfiles |
| Capability gates (CG-07) | `DRAWING` — **เฉพาะฟีเจอร์ FOV Circle Visual**: หาย = aim ยังใช้ได้ แต่วง FOV ปิด + แจ้งผู้ใช้ (degradation ระดับฟีเจอร์ ไม่ใช่ระดับโมดูล) |
| สาย adapter ที่กระทบ (CG-08) | `CameraAdapter` ตาย = หยุดล็อกกล้อง + แจ้ง / `PlayerAdapter`+`WorldAdapter` ตาย = TargetService เสีย → ปิดโมดูล + แจ้ง / `CombatAdapter` เสื่อม = สกิล/Soru aimbot ปิดตามฟีเจอร์ |
| Config root | `settings.voidaim.*` (ราย key กำหนดตอน implement — โครง: `enabled`, `mode`, `fov`, `lockRange`, `priority`, `aimKey`, `aimMode`, `prediction.*`, `exclude[]`, `skillAim.{Z,X,C,V,F,M1}`, `soru.*`, `fovCircle.*`) |
| Keybind actions (CG-12) | `aim.lock`, `aim.toggleMode`, `soru.normal` — ทั้งหมดผ่าน KeybindService ทางเดียว |
| Bus events | ฟัง `config:changed` / เผยแพร่ `module:state` (สถานะเปิด-ปิด-เหตุผล ให้ UI แสดงตาม CG-13) |
| L4 services ที่เรียกตรง (hot path §3.5) | `TargetService:GetCurrentTarget()` / `TargetService:GetCandidates(fov, filters)` / `PredictionService:GetPredictedPosition(target, leadTime)` / `CameraService:GetState()` / `CombatStateService:IsStunned(player)` |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md` — พารามิเตอร์เฉพาะโมดูลของ CG-07/CG-08 ตามตารางข้อ 1 ข้างบน

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 2 ไม่จบ §5.5)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| VA-001 | P0 | EZ Mode เปิดเดียวใช้ได้ (§4.4) | ผู้ใช้กด toggle "VoidAim: EZ Mode" โดยไม่ตั้งค่าอื่นเลย | ระบบทำงานครบวงจรด้วยค่า default: เลือกเป้าเอง (ใกล้สุดใน FOV) + ทำนาย v1 + ล็อกเมื่อกด aim key — assert ค่า default ครบทุกช่องที่ EZ ต้องใช้ | เปิดครั้งแรกทั้งที่ยังไม่เคยมี config ไฟล์ / เปิดทันทีหลัง hot update | L2 + L3 |
| VA-002 | P0 | สลับโหมด EZ→Pro→Legend ค่าไม่หาย (§2.4) | กดสลับโหมดแล้วสลับกลับ | ค่าตั้งของโหมดเดิมคงเดิม**ทุกตัว** (เก็บแยก namespace ต่อโหมด) — เทียบ snapshot ค่าก่อนสลับ = ตรง 100% | สลับกลางล็อกเป้า / สลับกลางเล่น macro / สลับ 20 รอบต่อเนื่อง | L2 |
| VA-003 | P0 | Pro Mode ~8 ค่าหลักมีผลทันที | แก้ค่า FOV / ระยะล็อก / priority / คีย์ / prediction | ค่าใหม่มีผล **frame เดียวกันหรือ frame ถัดไป** (virtual-time assert) — ไม่ต้อง Disable/Enable หรือรีสตาร์ทโมดูล | แก้ระหว่างล็อกเป้า / แก้เป็นค่าผิดช่วง = ถูก validate + clamp + แจ้ง (ไม่พังเงียบ) | L2 |
| VA-004 | P0 | Legend Mode เข้าถึงทุกอย่าง | เปิด Legend Mode | ปรับ per-skill aimbot (Z/X/C/V/F/M1) + ผสาน macro + soru aimbot + โหมดเป้าหมายพิเศษได้ครบตาม §4.4 | ใช้ค่า Pro ที่ตั้งไว้แล้วขยายเป็น Legend โดยค่าเดิมไม่หาย | L2 |
| VA-005 | P0 | Main Aim: ล็อกเป้า (§2.4) | เปิด Aim + กดคีย์ล็อก (`aim.lock`) | ล็อกเป้าตามเงื่อนไข (ใกล้สุดใน FOV ตามค่า `fov`+`lockRange`) **ภายใน frame เดียวกันหรือ frame ถัดไป** — วัดใน virtual-time L2 | เป้าตายกลางล็อก / หลุดระยะ / เข้า safe zone / respawn ใน FOV เดิม (ครบใน VA-017 ถึง VA-020) | L2 + L3 |
| VA-006 | P0 | ปลดล็อกเมื่อปล่อยคีย์ (§2.4) | ปล่อยคีย์ล็อก (โหมด hold) | ปลดทันที (frame เดียวกัน/ถัดไป) + `CameraAdapter:SetLock(nil)` คืนกล้องให้ผู้ใช้คุมเอง | ปล่อยพร้อมกับที่เป้าตาย / ปล่อยระหว่างเฟรม render / ปล่อยหลังเป้าออกจากเกม | L1 + L2 |
| VA-007 | P0 | Aim Key/Mode: hold vs toggle | ตั้ง `aimMode` = hold หรือ toggle | hold = ล็อกขณะกดค้าง (`InputAdapter:IsKeyDown`) / toggle = กดครั้งเดียวล็อกจนกดอีกครั้งหรือเงื่อนไขปลดตาม VA-017–VA-020 | สลับโหมดกลางล็อก = พฤติกรรมโหมดใหม่ทำงานทันทีไม่ติดค้างของเดิม | L1 + L2 |
| VA-008 | P0 | FOV กำหนดกรวยเลือกเป้า | ตั้งค่า FOV + มีเป้าใน/นอกกรวย | เป้านอก FOV **ไม่ถูกเลือกเด็ดขาด** (assert รายเป้าใน L2) — หน่วยแสดงใน UI ชัดเจน (พิกเซลบนจอ ไม่ใช่ค่าลอย) | เป้าอยู่ขอบ FOV พอดี / เปลี่ยน FOV กลางล็อก = ประเมินใหม่ frame ถัดไป | L2 |
| VA-009 | P0 | FOV Circle Visual | เปิดใช้ + ปรับค่า FOV | วงกลมรัศมีตรงค่า FOV ปัจจุบัน วาดผ่าน `Runtime.NewRender` (Drawing, owner=`VoidAim`) + เปิด/ปิดได้ + ปรับตามค่าแบบสด | DRAWING capability หายกลางรัน = **วงหาย + แจ้งผู้ใช้ แต่ aim ยังทำงาน** (degradation ระดับฟีเจอร์) / ปิด-เปิด 20 รอบ render orphan = 0 | L2 (mock render นับ object) + L3 |
| VA-010 | P0 | Exclude list (§2.4) | เพิ่มชื่อลงบัญชีดำ | ไม่เลือกชื่อนั้นเป็นเป้า**เด็ดขาด** — ทั้งจาก GetCandidates และการสลับเป้าอัตโนมัติ | ชื่อต่างตัวพิมพ์ใหญ่-เล็ก / ตัวอักษรพิเศษ / รายชื่อว่าง / ผู้เล่นออกจากเกมกลางล็อก / เพิ่มชื่อกลางล็อก (ปลดทันทีถ้าเป้าปัจจุบันโดน exclude) | L1 + L2 |
| VA-011 | P0 | Target Priority ตามเกณฑ์ (§2.4) | ตั้งเกณฑ์: ใกล้สุด / เลือดน้อย / bounty สูง | เลือกเป้าอันดับ 1 ตามเกณฑ์เสมอ (คะแนนจาก `TargetService:GetCandidates` เรียงถูก) | สองเป้าคะแนนเท่ากัน (tie-break = ระยะ) / เป้าใหม่เข้ากลางล็อกไม่สะเทือนถ้ายังไม่เปลี่ยนเกณฑ์ / เป้า stunned ได้ weight ตามข้อเสนอ §6-L4 (เห็นชัดในไฟล์นี้ รอเจ้าของยืนยัน) | L2 |
| VA-012 | P0 | Target switch ตามเกณฑ์ §5.1 | เงื่อนไขเป้าเปลี่ยน (เป้าเดิมตาย/ออก FOV/เกณฑ์ใหม่ให้ผลต่าง) | สลับเป้า **frame เดียวกันหรือ frame ถัดไป** + ออก generation token ใหม่ + **ห้าม duplicate lock** + upper-bound จาก test env บันทึกเป็น metric ทุกรอบส่งมอบ | สลับพร้อมกัน 2 เงื่อนไขใน frame เดียว / สลับ 100 ครั้งต่อเนื่อง (ฉากเดิมของ L2) | L2 (virtual time) |
| VA-013 | P0 | Prediction v1 (ping-based) (§2.4) | ping สูงขณะล็อก | ชดเชยตำแหน่งเล็งตาม ping ที่วัดได้ (`PredictionService:GetPredictedPosition(target, leadTime)`) — ใน L2 ป้อน ping ที่กำหนด + เทียบตำแหน่งที่ทำนายกับค่าคาดหมายเชิงคณิต | ping เปลี่ยนกลางไฟต์ / เป้าวาร์ปด้วย Soru (ทำนายไม่ตาม — ต้อง re-lock ไม่ยึดตำแหน่งเก่า) / เป้าหยุดกะทันหัน | L2 (virtual time) |
| VA-014 | P0 | Skill Aimbot รายสกิล (§2.4) | ใช้สกิล Z/X/C/V/F/M1 ขณะล็อก | เล็งตามพารามิเตอร์เฉพาะของสกิลนั้น (SkillAimProfiles — ค่าต่อสกิลแยกกัน) + ยิงผ่าน `CombatAdapter:FireSkill` ทางเดียว | สกิล cooldown อยู่ (ใช้ `GetSkillCooldown` — fallback ตามสัญญา PENDING ข้อ 6) / เปลี่ยนอาวุธกลางล็อก (VA-021) / ปิด per-skill ตัวเดียวไม่กระทบตัวอื่น | L2 + L3 |
| VA-015 | P0 | Soru Aimbot (§2.4) | เป้าออกนอกระยะ M1 ขณะล็อก | เด้ง Soru เข้าหาเป้า (ผ่าน `CombatAdapter:FireSkill`) แล้ว**ล็อกต่อ** อัตโนมัติ | Soru cooldown อยู่ = รอไม่สแปม / เป้าบินข้ามกำแพง (raycast ผ่าน `WorldAdapter:RaycastClear` กันวาร์ปทะลุ) / ระยะเกินซ้ำ ๆ ต่อเนื่อง = มีจำกัดจำนวนครั้งต่อ window + แจ้ง | L2 + L3 |
| VA-016 | P0 | Normal Soru (ไม่ใช่ aimbot) | กด `soru.normal` โดยไม่ได้ล็อก | ใช้ Soru ปกติตามทิศที่ผู้ใช้คุม — ไม่ขัดพฤติกรรม aimbot ที่เปิดอยู่ | กดค้างระหว่างล็อก / Soru cooldown | L2 |
| VA-017 | P0 | เป้าตายกลางล็อก | เป้าปัจจุบันเลือด 0 (`CharacterAdapter:IsAlive` = false) | ปลดหรือสลับเป้าตาม priority **frame เดียวกัน/ถัดไป** — ไม่ค้างล็อก "ผี" (ตำแหน่งเก่าของศพ) | ตายพร้อมกับเป้าอื่นเข้า FOV พร้อมกัน / ตายแล้ว respawn ทันที (VA-020) | L2 |
| VA-018 | P0 | เป้าหลุดระยะ/ออก FOV | เป้าวิ่งออกนอก `lockRange` หรือ FOV | ปลดล็อก + แจ้ง (ตามค่าตั้ง: ปลด หรือ สลับเป้าถัดไป) ภายใน frame เดียวกัน/ถัดไป | เป้าวิ่งข้ามเส้นระยะไปมาถี่ ๆ (ไม่กระพริบล็อก-ปลดเกิน 1 ครั้ง/เงื่อนไข) | L2 |
| VA-019 | P0 | Safe zone | เป้าเข้าพื้นที่ safe zone | ไม่ยิง/ปลดล็อกตามค่าตั้ง — ตรวจจากข้อมูลโลกผ่าน adapter เท่านั้น | เข้า-ออก safe zone ถี่ / ยืนบนขอบเขต | L2 (stub กำหนดโซน) + L3 |
| VA-020 | P0 | Respawn เป้าเดิมใน FOV | เป้าตายแล้ว respawn กลับมาใน FOV เดิม | ระบบประเมินเป็นเป้าใหม่ (ไม่ถือ generation เก่า) — ล็อกใหม่ได้ตามเกณฑ์ปกติ | respawn ตำแหน่งเดิม vs ตำแหน่งใหม่ | L2 |
| VA-021 | P0 | เปลี่ยนอาวุธกลางล็อก | สลับอาวุธขณะล็อก (`CombatAdapter:GetEquippedWeapon` เปลี่ยน) | โปรไฟล์สกิลสลับตามอาวุธใหม่ทันที + ล็อกคงอยู่ (ไม่ต้องปลด) | อาวุธเปลี่ยนระหว่างสกิลกำลังยิง / ถอดอาวุธ (มือเปล่า) | L2 |
| VA-022 | P0 | ผู้เล่นออกจากเกมกลางล็อก | เป้า `Players:Remove` ระหว่างล็อก | ปลดล็อกสะอาด/สลับเป้า + ไม่ error ไม่ค้าง | ออกพร้อมกันหลายเป้า / ออกขณะ Soru กำลังเด้งเข้าหา | L2 |
| VA-023 | P0 | สัญญาล็อกกล้องเต็ม (ปิด PENDING ของ `CameraAdapter:SetLock`) | เรียก SetLock ตามสัญญาข้อ 6 | ทำงานครบสัญญา: re-assert ทุก frame / `SetLock(nil)` คืนกล้องทันที / กล้อง GONE คืน `(false, {code="GONE"})` แล้ว consumer หยุด + แจ้ง / idempotent / Disable-Destroy เรียก SetLock(nil) เสมอ | กล้องตายกลางล็อก / SetLock ซ้ำ 100 ครั้ง / โมดูลปิดกลางล็อก (ต่อ VA-026) | L1 + L2 |
| VA-024 | P0 | Duplicate lock = 0 ทั้ง suite (§4.4) | ทุกฉาก L2 ของ VoidAim + ฉาก stress สลับเป้า 100 ครั้ง | generation token assert: ไม่มีช่วงเวลาใดที่ lock 2 อัน active พร้อมกัน + token ใหม่ทุกการ lock/switch | สลับเป้ารัว / hot update กลางล็อก (lock ต้องตายกับ generation เก่า — ไม่ฟื้นข้ามรุ่น) | L2 (assert อัตโนมัติ) |
| VA-025 | P0 | Aim update cost ≤ 0.8 ms/frame (§9.1) | ฉาก 50 ผู้เล่นจำลอง + ล็อกต่อเนื่อง | per-module timer (DiagnosticsService): aim update ≤ 0.8 ms/frame ใน L2 test env — เกิน = บั๊กประเภท performance (§11 กฎ 5) ต้องมี BUG ID | ระดับเตือน > 1.2 ms ต้องโผล่ใน Diagnostics | L2 (metric) |
| VA-026 | P0 | ปิดโมดูลกลางล็อก | `Disable()`/ปิด toggle ขณะล็อกอยู่ | `SetLock(nil)` + หยุด task ทั้งหมด + render orphan (FOV circle) = 0 — กล้องคืนผู้ใช้ทันที | ปิดระหว่าง Soru เด้ง / ปิดผ่าน hot update TEARDOWN (กลไกเดียวกัน CG-03/CG-05) | L2 |
| VA-027 | P0 | ผู้ใช้ตายกลางล็อก | local player `IsAlive` = false ขณะล็อก | ปลดล็อก + หยุดพฤติกรรม aim ทั้งหมด — ไม่ล็อก/ยิงต่อจากสถานะศพ | ตายแล้ว respawn กลางล็อกเดิม = เริ่มใหม่ตามเงื่อนไขปกติ ไม่ฟื้น lock เก่า | L2 |
| VA-028 | P0 | EZ Mode: ผู้ใช้ใหม่สำเร็จใน 10 วินาที (§4.4) | ผู้ใช้ทดสอบที่ไม่เคยใช้งาน เปิด EZ Mode ครั้งแรก | จับเวลาจริงจากกด toggle ถึง "ล็อกเป้าแรกสำเร็จ" ≤ 10 วินาที — L3 checklist + วิดีโออ้างอิง | ผู้ทดสอบ ≥ 3 คน (เกณฑ์ §6.4 — ไม่ใช่คนเดียว) | L3 |

## 4. แถว Matrix ระดับ P1 (SHOULD PASS §5.1 — ไม่ผ่าน = ย้าย backlog v1.1 อย่างเปิดเผย เฟสผ่านได้ปกติ)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| VA-029 | P1 | Void Prediction v2 (ping+velocity+ทิศ) | เป้าเคลื่อนที่ด้วยความเร็ว/ทิศต่าง ๆ | ทำนายจาก ping + velocity + ทิศทาง (`CharacterAdapter:GetMoveDirection`) — hit-rate จำลองใน L2 สูงกว่า v1 อย่างน้อยตามเกณฑ์ที่ตั้งไว้ตอน implement (ระบุตัวเลขในรายงานรอบนั้น) | เป้าเปลี่ยนทิศกะทันหัน / เป้าลอย (Freefall) / ping แกว่ง | L2 (virtual time) |
| VA-030 | P1 | Smart Target Priority | หลายเป้าที่สถานะต่างกัน (เลือด/ระยะ/bounty/stun) | ถ่วงน้ำหนักหลายเกณฑ์เป็นคะแนนเดียวแล้วเลือกอันดับ 1 — เกณฑ์การถ่วงถูกพิสูจน์ด้วยชุดเป้าที่กำหนดผลล่วงหน้า | คะแนนใกล้เคียงกันมาก / เป้า stun หมดเวลากลางคำนวณ | L2 |
| VA-031 | P1 | Auto Switch | เป้าที่ "ดีกว่า" เข้ามาตามเกณฑ์ผู้ใช้ตั้ง | สลับอัตโนมัติ **frame เดียวกัน/ถัดไป + ห้าม duplicate lock** + upper-bound จาก test env เป็น metric (เกณฑ์ §5.1 ที่แทน "0.1 วิ" เดิม) | สลับไป-กลับถี่ (มี hysteresis ตามค่าตั้ง) / เป้าดีกว่าเป็นชื่อใน exclude | L2 (virtual time) |
| VA-032 | P1 | Aim Stats | เล่นไประยะหนึ่งแล้วเปิดแผงสถิติ | ความแม่นเซสชันนี้ + จำนวนล็อก/สลับ มาจาก event จริงของระบบ (นับได้ตรวจได้ ไม่ใช่ตัวเลขปลอม) | รีเซ็ตสถิติ / hot update กลางเซสชัน (สถิติรอดตาม CG-04/CG-05) | L2 + L3 |
| VA-033 | ~~P1~~ **OUT OF SCOPE — PC ONLY** | Mobile Aim Button | มือถือ: ปุ่มลอย aim | **ถูกตัดออกจาก v1.0 scope ตาม CR-PC-ONLY (1 ต.ค. 2026) — ไม่ implement ไม่ย้าย P2** · บน PC ใช้ Aim Key/Mode ผ่านคีย์บอร์ดตาม VA-007 | — | — | — |
| VA-034 | P1 | Preset สถานการณ์ 1 คลิก | เลือก preset (เช่น " Bounty Hunt" / "Raid") | ใช้ชุดค่าของ preset ครบทุกช่อง + ค่าที่ผู้ใช้ตั้งเองก่อนหน้ายังอยู่เมื่อออกจาก preset | สลับ preset กลางล็อก / preset เสีย (config ไม่ครบ) = แจ้ง ไม่ใช้ค่าครึ่ง ๆ กลาง ๆ | L2 |

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0 §5.1 — ทำ matrix เต็มเมื่อถึงเวลา + flag `experimental` ใน UI)

- **Prediction Learning** (§4.3/§4.4) — เรียนรู้ pattern การเคลื่อนที่รายบุคคล — เริ่มหลัง v1.0 stable เท่านั้น

## 6. ความต้องการต่อ Adapter/L4 ที่ยัง PENDING (ไฟล์นี้คือผู้ปิด contract ตามที่ `camera.lua`/`combat.lua` รอไว้)

### 6.1 `CameraAdapter:SetLock(targetOrNil)` — สัญญาเต็มที่ VoidAim ต้องการ (ปิด PENDING เฟส 2)

| เงื่อนไข | สัญญา |
|---|---|
| สำเร็จ | คืน `(true)` — ตั้งแต่ frame ถัดไป กล้องถูกชี้ตามเป้า **โดย consumer re-assert ทุก frame** (adapter เก็บเป้า ไม่ loop เอง) |
| ปลด | `SetLock(nil)` → `(true)` — คืนการควบคุมแก่ผู้ใช้ทันที (frame เดียวกัน/ถัดไป) |
| กล้อง GONE | คืน `(false, {code="GONE", ...})` — consumer ต้องหยุดพฤติกรรมล็อก + แจ้งผู้ใช้ ไม่ retry ไม่จำกัด |
| เป้าหายกลางล็อก | adapter **ไม่โยน error** — คืน `(false, {code="GONE"})` ที่ re-assert ครั้งถัดไป แล้ว consumer จัดการต่อเอง (สลับ/ปลด ตาม VA-017/VA-022) |
| Idempotent | `SetLock(x)` ซ้ำไม่สร้างสถานะซ้อน / Disable-Destroy ของ consumer ต้องเรียก `SetLock(nil)` เสมอ (ตรวจใน teardown ของโมดูล) |

### 6.2 `CombatAdapter:GetSkillCooldown(skill)` — สัญญา + แผนปิด PENDING

- สัญญาเมื่อพร้อม: คืน `(remaining >= 0)` (0 = พร้อมใช้) หรือ `(nil, {code=...})` เมื่ออ่านไม่ได้
- **ระหว่าง PENDING**: consumer ต้อง fallback อย่างปลอดภัย = ใช้ Attack Delay ตามค่าตั้งผู้ใช้ และ**ห้ามสแปมยิงแทน** (พิสูจน์ใน VA-014 edge "cooldown อยู่")
- **แผนปิด**: แหล่งค่าจริง (tool attribute / remote response / จับเวลาเอง) ต้องถูก survey ใน L3 ช่วงต้นเฟส 2 → บันทึกผลเป็น contract note ในไฟล์นี้ (changelog) + เพิ่มแถวพิสูจน์ใน L3 checklist → จึงถอด PENDING — **ห้ามปิดพิสูจน์แบบเดา**

### 6.3 L4 preconditions ที่ VoidAim พึ่ง (สร้างพร้อมเฟส 2 — สรุปสัญญาอยู่ `qa/matrices/README.md` §L4)

- `TargetService` — เป้าปัจจุบัน/รายการเป้า + **generation token** (พิสูจน์ผ่าน VA-012/VA-024)
- `PredictionService` — `GetPredictedPosition(target, leadTime)` (พิสูจน์ผ่าน VA-013/VA-029)
- `CameraService` — ตำแหน่ง/ทิศ/FOV + ล็อกกล้อง (พิสูจน์ผ่าน VA-023)
- `CombatStateService` — `IsStunned(player)` (พิสูจน์ผ่าน VA-011 edge + CombatCore)

## 7. ตัวชี้วัดประจำโมดูล (บันทึกเป็น metric ทุกรอบส่งมอบ — §9.1/§9.3)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| Aim update cost | ≤ 0.8 ms/frame | > 1.2 ms |
| Target switch upper-bound (frame ที่ใช้จริง) | frame เดียวกัน/ถัดไป — ค่าที่วัดได้บันทึกทุกรอบ | เกิน 2 frame = บั๊ก |
| Duplicate lock ทั้ง suite | 0 | > 0 = fail ทันที |
| จำนวนเป้าทดสอบพร้อมกัน | 50 (ฉากมาตรฐาน) | — |

## 8. L3 Checklist ฉบับร่าง (ใช้จริงเมื่อถึงเฟส 2 — จับเวลา + วิดีโออ้างอิงตาม §6.1)

1. ☐ เปิด EZ Mode ครั้งแรก → ล็อกเป้าแรกสำเร็จ ≤ 10 วินาที (VA-028)
2. ☐ ล็อกเป้า → ปล่อยคีย์ → กล้องคืนทันที สัมผัสได้ (VA-006)
3. ☐ เป้าตายกลางล็อก → สละ/สลับเป้า ไม่ค้าง (VA-017)
4. ☐ สลับโหมดกลางล็อก 20 รอบ → ค่าไม่หาย (VA-002)
5. ☐ ใช้สกิล Z/X/C/V/F/M1 ขณะล็อก — เล็งตามโปรไฟล์สกิล (VA-014)
6. ☐ Soru Aimbot: เป้าหนีออกนอกระยะ → เด้งตาม + ล็อกต่อ (VA-015)
7. ☐ FOV Circle แสดง/ปิดได้ + รัศมีตรงค่า (VA-009)
8. ☐ ปิดโมดูลกลางล็อก → กล้องคืน + ไม่มีของค้างบนจอ (VA-026)
9. ☐ เปิดทิ้งไว้ 30 นาทีในเซิร์ฟเวอร์คนเต็ม → Export Diagnostics แนบผล (VA-025 + §8.4)
10. ~~มือถือ: ปุ่มลอย aim ใช้ได้ (VA-033)~~ **OUT OF SCOPE — PC ONLY ตาม CR-PC-ONLY — ไม่ต้องทดสอบ**

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ — ทุกแถวต้องมีหลักฐาน §6.4)

| ID | สถานะ | หลักฐาน (ไฟล์เทส/ฉาก/รอบ+วันที่) |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 2) | — |
| VA-001 … VA-028 (P0) | ยังไม่พิสูจน์ | — |
| VA-029 … VA-032, VA-034 (P1) | ยังไม่พิสูจน์ | — |
| VA-033 | **OUT OF SCOPE — PC ONLY** (CR-PC-ONLY) | ไม่พิสูจน์ — ห้ามนับ N/A เป็น "ผ่าน" |

## 10. Traceability กับ §4.3/§4.4 (พิสูจน์ว่าไม่มี requirement หาย / ไม่มีแถวหลุดโลก)

| ฟีเจอร์ §4.3 (VoidAim) | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| 3 โหมด EZ/Pro/Legend | P0 | VA-001, VA-002, VA-003, VA-004 |
| Main Aimbot | P0 | VA-005, VA-006, VA-007, VA-017–VA-022, VA-027 |
| Skill Aimbot (Z/X/C/V/F/M1) | P0 | VA-014, VA-021 |
| Soru Aimbot + Normal Soru | P0 | VA-015, VA-016 |
| Aim Key/Mode | P0 | VA-007 |
| Prediction v1 (ping-based) | P0 | VA-013 |
| Exclude list | P0 | VA-010 |
| FOV + FOV Circle Visual | P0 | VA-008, VA-009 |
| Void Prediction v2 | P1 | VA-029 |
| Smart Target Priority | P1 | VA-030 |
| Auto Switch | P1 | VA-031 |
| Aim Stats | P1 | VA-032 |
| Mobile Aim Button | ~~P1~~ **OUT OF SCOPE — PC ONLY** (CR-PC-ONLY) | VA-033 (เก็บ ID เพื่อ traceability ไม่นับแถว active) |
| Preset สถานการณ์ 1 คลิก | P1 | VA-034 |
| Prediction Learning | P2 | §5 (ไม่ตรวจรับ v1.0) |

## 11. Changelog ของไฟล์นี้ (เอกสารมีชีวิต §2.5 — เจอ behavior ใหม่สำคัญ = เพิ่มแถวเสมอ + แจ้งในรายงานรอบนั้น)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.2 | 1 ตุลาคม 2026 | **CR-PC-ONLY:** VA-033 Mobile Aim Button (P1) = **OUT OF SCOPE — PC ONLY** (ไม่ implement ไม่ย้าย P2 — เก็บ ID เพื่อ traceability) — แถว P1 active เหลือ 5 — ตามคำตัดสินเจ้าของโปรเจกต์ "PC/Desktop only บน Volt" · บน PC ใช้ Aim Key/Mode ตาม VA-007 |
| 1.1 | 1 ตุลาคม 2026 | บันทึก sign-off เจ้าของโปรเจกต์ (APPROVED BASELINE v1.0 ไม่มีแถวที่ขอแก้) พร้อมคำตัดสิน Q1=(ข) / Q2=(ก) / Q3=(ข) — ชุดนี้เป็น acceptance source of truth ของ implementation ตั้งแต่รอบ 6 |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (28 แถว P0 + 6 แถว P1) — ครบแถวตัวอย่าง §2.4 ทั้ง 8 + ปิด contract PENDING ของ SetLock/GetSkillCooldown เป็นข้อเสนอรอเจ้าของรีวิว |
