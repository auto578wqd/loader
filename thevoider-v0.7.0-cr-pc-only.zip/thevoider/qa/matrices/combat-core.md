# Behavioral Acceptance Matrix — Combat Core

> **สถานะ:** ✅ **APPROVED BASELINE v1.0** — เจ้าของโปรเจกต์ sign-off 1 ตุลาคม 2026 + คำตัดสิน Q1=(ข) — แก้ไขหลังนี้ต้องผ่าน Change Request (§2.5)
> **อ้างอิง:** แผน freeze v2.1 §4.1, §4.3, §3.5 (กฎคู่ของ Services), §5.6 + dependencies.md v1.4

## 1. ข้อมูลสถาปัตยกรรม (อ้าง SSOT `dependencies.md` v1.4)

| รายการ | ค่า |
|---|---|
| Node / ชั้น | `CombatCore` / L5 Feature Modules |
| Depends on | `CombatStateService`, `CombatAdapter` |
| Internal services (ไม่ขึ้น graph) | BountyTracker, AbilitySequencer, BlockEditor |
| Capability gates (CG-07) | ไม่มี capability เฉพาะ (ไม่วาดภาพ/ไม่ใช้เน็ต) — พึ่ง TASK แบบ ambient ผ่าน Registry |
| สาย adapter ที่กระทบ (CG-08) | `CombatAdapter` ตาย = ยิงสกิล/M1 ไม่ได้ → ปิดโมดูล + แจ้ง / `CharacterAdapter` เสื่อม = CombatStateService เสื่อม → ปิดการตรวจ stun/anti-combo + แจ้ง / `PlayerAdapter` เสื่อม = BountyTracker หยุด + แจ้งรายฟีเจอร์ |
| Config root | `settings.combat.*` (โครง: `enabled`, `antiCombo.{mode, counterSkill, skull, soru}`, `antiStun.{enabled, counterSkill}`, `abilityTrigger.{enabled, abilities[], range}`, `attackDelay`, `blockEditor.{before, after}`, `comboPlans{}`, `acidumM1`, `autoSkullGuitar`) |
| Keybind actions (CG-12) | ไม่มี keybind P0 (ทำงานอัตโนมัติตามเงื่อนไข — สอดคล้อง §4.3 ที่ไม่ระบุคีย์) |
| Bus events | ฟัง `config:changed`, `adapter:health` / เผยแพร่ `module:state` + **event แจ้งการเปลี่ยน bounty รายเป้า** (CC-014 — ตาม §3.5 กฎ 2: query ตรง + แจ้ง event เมื่อ state เปลี่ยน) |
| L4 services ที่เรียกตรง | `CombatStateService:IsStunned(player)` + สถานะ ragdoll/cooldown รายผู้เล่น |

## 2. Common Gates ที่บังคับ (CG-01 – CG-15 ทั้งหมด)

ดู `qa/matrices/_common-gates.md`

## 3. แถว Matrix ระดับ P0 (MUST PASS — ไม่ผ่านเฟส 3 ไม่จบ §5.6)

| ID | P | Behavior | Input / Trigger | Expected Behavior (วัดได้) | Edge Cases | ชั้นทดสอบ |
|---|---|---|---|---|---|---|
| CC-001 | P0 | Anti Combo | ถูกโจมตีต่อเนื่อง (คอมโบขาเข้า — ตรวจจากสถานะผ่าน adapter) | ตอบโต้ด้วยท่าที่ตั้งไว้ (`counterSkill`) ภายใน frame เดียวกัน/ถัดไปหลังเงื่อนไขครบ — นับจำนวนครั้งตอบโต้ได้ตรงจำนวนเงื่อนไข | โดนคอมโบจาก 2 คนพร้อมกัน / เงื่อนไขติด-ดับถี่ (มี cooldown ภายในตามค่าตั้ง ไม่สแปมท่า) | L2 |
| CC-002 | P0 | Anti Combo + Skull | ตั้งตอบโต้ด้วย Skull Guitar | ใช้ท่า Skull Guitar ตามลำดับที่ตั้ง (ผ่าน `CombatAdapter:FireSkill`) | Skull cooldown อยู่ (CC-013) / เปลี่ยนอาวุธกลางท่า | L2 |
| CC-003 | P0 | Anti Combo + Soru | ตั้งตอบโต้ด้วย Soru | หลบด้วย Soru ตามทิศที่ตั้ง (หนี/ทะลุ) แล้วกลับสถานะพร้อมสู้ | Soru cooldown / หลบไปชนกำแพง (ไม่ค้างสถานะ) | L2 |
| CC-004 | P0 | Anti Stun | local player ถูก stun (`CombatStateService:IsStunned(ตัวเอง)` = true) | ใช้ท่าต้าน/ล้าง stun ตามค่าตั้งภายใน frame เดียวกัน/ถัดไป + แจ้งเมื่อทำงาน (ตามค่าตั้ง) | ถูก stun ซ้ำต่อเนื่อง / stun ตอนท่ากำลังออก / เป้าไม่มีท่าต้าน (skill ไม่พร้อม) = รอ + ไม่สแปม | L2 |
| CC-005 | P0 | Ability Trigger | เงื่อนไขครบ (เป้าถูกเลือก + ตรงเงื่อนไขที่ตั้ง) | ยิงสกิลในลิสต์ `abilities[]` อัตโนมัติตามลำดับ — นับการยิงได้ตรง | สองสกิลเงื่อนไขตรงพร้อมกัน (ตามลำดับที่ตั้ง) / เงื่อนไขหายกลางลำดับ (หยุดชุด ไม่ยิงค้าง) | L2 |
| CC-006 | P0 | Range Check | เป้าอยู่นอกระยะที่ตั้ง | **ไม่ยิง + ไม่ส่ง remote เลย** (นับ remote call = 0) — รอจนกว่าเข้าระยะ | เป้าวิ่งข้ามเส้นระยะไปมาถี่ (ไม่ยิงกระพริบ — ประเมินต่อเนื่องแต่ยิงเมื่อเข้าเงื่อนไขจริง) | L2 (นับ remote) |
| CC-007 | P0 | Attack Delay | ตั้งค่าหน่วงระหว่างการโจมตี | ระยะห่างการโจมตีจริง ≥ ค่าที่ตั้ง (วัดจาก timestamp การยิงใน virtual-time) — กันสแปมที่เกมถีบ | ตั้ง 0 = ไม่หน่วง (ผู้ใช้รับผิดชอบเอง) / ตั้งสูงมาก = ยิงถี่ตามค่าจริง | L2 (virtual time) |
| CC-008 | P0 | Block Editor — Before | ตั้งลำดับบล็อกก่อนโจมตี | ก่อนเริ่มผังโจมตี ทำการบล็อกตามลำดับ+จังหวะที่ตั้ง ครบทุกขั้น | ถูกขัดกลางบล็อก (โดน stun) = ออกจากลำดับสะอาดตาม CC-004 | L2 |
| CC-009 | P0 | Block Editor — After | ตั้งลำดับบล็อกหลังโจมตี | หลังผังโจมตีจบ ทำบล็อกตามลำดับที่ตั้งครบทุกขั้น | ผังโจมตีถูกยกเลิกกลางคัน = ไม่ทำ after-block ของผังที่ไม่จบ | L2 |
| CC-010 | P0 | Combo System | ตั้งผังคอมโบ (ลำดับสกิล+เงื่อนไข) แล้วเข้าเงื่อนไข | ทำตามผังลำดับถูก 100% (นับที่ dispatch จริง) + จบผังครบหรือหยุดสะอาดเมื่อเงื่อนไขพัง | เป้าตายกลางผัง / เปลี่ยนเป้ากลางผัง (ตามค่าตั้ง: หยุดหรือต่อ) / ผังยาว 20+ ขั้น | L2 |
| CC-011 | P0 | Acidum Rifle M1 | ถือ Acidum Rifle + เปิดใช้ | โหมด M1 ของ Acidum ทำงานตามจังหวะที่ตั้ง (ผ่าน `CombatAdapter` ทางเดียว) | สลับอาวุธกลาง M1 / กระสุน/remote ไม่พร้อม | L2 + L3 |
| CC-012 | P0 | Auto Skull Guitar | เงื่อนไขที่ตั้งครบ (เช่น จำนวนเป้าในระยะ) | ใช้สกิล Skull Guitar อัตโนมัติ 1 ครั้งต่อเงื่อนไข + ไม่ซ้ำจนกว่าเงื่อนไขใหม่ | เป้าออกจากระยะกลาง cast / cooldown ยังไม่ครบ (CC-013) | L2 |
| CC-013 | P0 | เคารพ cooldown จริง | สกิลที่ใช้ยัง cooldown อยู่ | **ไม่ยิงซ้ำ** — อ่านจาก `CombatAdapter:GetSkillCooldown` เมื่อพร้อม; ระหว่าง PENDING ใช้ fallback delay ตามค่าตั้ง + ห้ามสแปมแทน (สัญญาเดียวกับ voidaim.md ข้อ 6.2) | cooldown หมดพอดีกับเงื่อนไข (ยิงได้ทันที) / อ่าน cooldown ไม่ได้ต่อเนื่อง | L2 |
| CC-014 | P0 | BountyTracker + แจ้งผ่าน bus | bounty รายผู้เล่นเปลี่ยน | ตรวจจับการเปลี่ยน + **เผยแพร่ event ผ่าน bus** (§3.5 กฎ 2 — ผู้สนใจเช่น ESP/UI ไม่พลาด) + ค่าที่แจ้ง = ค่าจาก `PlayerAdapter:GetBounty` จริง | เปลี่ยนถี่ 10 ครั้ง/วินาที (rate จำกัด + ค่าล่าสุดถูก) / ผู้เล่นออกจากเกม (เลิกติดตาม + orphan 0) | L2 |
| CC-015 | P0 | ประตูเดียว: ทุกการยิงผ่าน CombatAdapter | ตรวจโค้ด + รันทุกฉาก | ทุกการยิงสกิล/M1/บล็อก ผ่าน `CombatAdapter:FireSkill`/remote ของ adapter เท่านั้น — lint ห้าม remote ตรง (§3.3) | — | L2 + lint |

## 4. แถว Matrix ระดับ P1

— *(ไม่มีรายการ P1 สำหรับ CombatCore ตาม §4.3)*

## 5. ระดับ P2 (ไม่ตรวจรับใน v1.0 §5.1)

- **Combo Simulator** — จำลอง timeline + ดาเมจของผังคอมโบ (§4.3)
- **Auto Retaliate Profile** — โปรไฟล์ตอบโต้อัตโนมัติรายสถานการณ์ (§4.3)

## 6. ความต้องการต่อ Adapter/L4 + คำถามเปิดถึงเจ้าของโปรเจกต์

### 6.1 ใช้สัญญาที่มีอยู่แล้ว

- `CombatAdapter:FireSkill` / `GetEquippedWeapon` / `GetRemotes` / `GetSkillCooldown` (PENDING — สัญญาเดียวกับ voidaim.md ข้อ 6.2)
- `CombatStateService:IsStunned(player)` + สถานะ ragdoll/cooldown (L4 — สร้างพร้อมเฟส 3)
- `CharacterAdapter:GetState` (alive/health/state — มีอยู่แล้ว)

### 6.2 ✅ คำตัดสินแล้ว — "Ken" (Observation Haki): เลือก (ข) โดยเจ้าของโปรเจกต์ 1 ตุลาคม 2026

**คำตัดสิน (บันทึกตามคำสั่งเจ้าของ):**

```text
Ken status display → อยู่ใน VoidESP P0 (ES-001 / ES-002)
Auto Ken / Auto Observation → out of scope for v1.0
```

- v1.0 ให้ Ken อยู่ในขอบเขต **ข้อมูลสถานะที่ ESP แสดงได้** ตาม ES-001/ES-002 เท่านั้น — ไม่เพิ่ม `Auto Ken / Auto Observation` เป็น P0 หรือ P1 และไม่สร้างฟีเจอร์ใหม่จากจุดที่ §4.3 ไม่ได้ระบุไว้
- **ไม่ต้องเปิด Change Request** เพราะไม่ได้เปลี่ยน requirement ที่ freeze ไว้ (§4.3 ไม่เคยมี Auto Ken อยู่แล้ว)
- ที่มาของคำถาม (เก็บไว้เป็นประวัติ): แผน §4.1 จัด "Ken" เข้า Product Module **Combat Core** ("Player/Combat + Sword/Gun + Bounty + Ken") แต่ตารางฟีเจอร์ §4.3 ของ Combat Core (P0/P1/P2) **ไม่มีรายการ Auto Ken / Auto Observation** — ขอบเขต Ken ที่ปรากฏชัดมีเพียง "แสดงสถานะ ken ของเป้า" ใน VoidESP (ES-001/ES-002) เท่านั้น ตัวเลือกที่เสนอไว้: (ก) เพิ่ม Auto Ken ระบุระดับ / (ข) v1.0 มีเฉพาะแสดงสถานะใน ESP → **เจ้าของเลือก (ข)**

## 7. ตัวชี้วัดประจำโมดูล (§9.1/§9.3 — เพิ่มตัวชี้วัดรายโมดูลตอน implement ตาม §9.3 กฎ 2)

| ตัวชี้วัด | เป้า (L2 test env) | ระดับเตือน |
|---|---|---|
| ส่วนแบ่ง frame cost ของ CombatCore | รวมทั้งสคริปต์ ≤ 2.0 ms/frame (§9.1) — ส่วนของโมดูลบันทึกเป็น baseline ตอน implement | เกินส่วนแบ่งที่ตกลง > 10% โดยไม่มีเหตุผล = บั๊ก |
| Remote spam | 0 ครั้งเมื่อเงื่อนไขไม่ครบ (CC-006/CC-013 นับได้) | > 0 = fail |

## 8. L3 Checklist ฉบับร่าง (เฟส 3)

1. ☐ เข้าไฟต์จริง → Anti Combo ทำงานตามท่าที่ตั้ง (CC-001–CC-003)
2. ☐ ถูก stun จากผู้เล่นจริง → Anti Stun ตอบโต้ (CC-004)
3. ☐ Ability Trigger กับเป้าจริง — ไม่ยิงเปล่าเมื่อไกล (CC-005/CC-006)
4. ☐ ผังคอมโบที่ตั้งเอง 10+ ขั้น เล่นจบครบในแมตช์จริง (CC-010)
5. ☐ Acidum Rifle M1 จังหวะถูก (CC-011)
6. ☐ Auto Skull Guitar กับหมู่เป้าจริง (CC-012)
7. ☐ ค้างไว้ 30 นาที + Export Diagnostics (§7)

## 9. ตารางติดตามสถานะรายแถว (เติมเมื่อพิสูจน์ §6.4)

| ID | สถานะ | หลักฐาน |
|---|---|---|
| CG-01 … CG-15 | ยังไม่พิสูจน์ (รอ implementation เฟส 3) | — |
| CC-001 … CC-015 (P0) | ยังไม่พิสูจน์ | — |

## 10. Traceability กับ §4.3 (Combat Core)

| ฟีเจอร์ §4.3 | ระดับ | แถวที่พิสูจน์ |
|---|---|---|
| Anti Combo (+Skull/Soru) | P0 | CC-001, CC-002, CC-003 |
| Anti Stun | P0 | CC-004 |
| Ability Trigger + Range Check | P0 | CC-005, CC-006 |
| Attack Delay | P0 | CC-007 |
| Block Editor (Before/After) | P0 | CC-008, CC-009 |
| Combo System | P0 | CC-010 |
| Acidum Rifle M1 | P0 | CC-011 |
| Auto Skull Guitar | P0 | CC-012 |
| Combo Simulator | P2 | §5 (ไม่ตรวจรับ v1.0) |
| Auto Retaliate Profile | P2 | §5 (ไม่ตรวจรับ v1.0) |
| *(Ken — คำตัดสินแล้ว §6.2)* | **ไม่มีแถวของ Combat Core** — Ken status display อยู่ใน VoidESP (ES-001/ES-002) / Auto Ken out of scope v1.0 | — |

## 11. Changelog ของไฟล์นี้ (§2.5)

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| 1.1 | 1 ตุลาคม 2026 | บันทึกคำตัดสินเจ้าของ Q1=(ข): Ken status display อยู่ใน VoidESP P0 (ES-001/ES-002) / **Auto Ken / Auto Observation out of scope v1.0** — ไม่เพิ่มแถวใหม่ ไม่ต้องเปิด CR (ไม่ได้เปลี่ยน requirement ที่ freeze ไว้) — ปิดคำถามเปิดของ §6.2 ถาวร |
| 1.0 | 1 ตุลาคม 2026 | สร้างครั้งแรก (15 แถว P0) + ยกคำถามเปิดเรื่อง "Ken" (§4.1 vs §4.3 ไม่ตรงกัน) ขอคำตัดสินเจ้าของโปรเจกต์ |
