-- L2 ฉากที่ 2: Adapter สายตาย (dead API) — graceful degradation (§3.3 กฎ 3) +
-- Diagnostics เห็นหลักฐานจริง (gate เจ้าของโปรเจกต์: แกนพื้นฐานต้องพร้อมก่อนฟีเจอร์หลัก)
local H = PKG_harness
local RuntimeLib = PKG_init
local FoundationLib = PKG_foundation
local AdapterLib = PKG_adapter

local function bootStack()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  return R, F, A
end

H.test("L2/adapter-dead: leaderstats ตาย → เสื่อมบางส่วน + แจ้งโมดูล + แจ้งผู้ใช้ + ระบบเดินต่อ", function()
  local R, F, A = bootStack()
  local health, notify = {}, {}
  R.Scope("M1", function()
    F.Bus:On("adapter:health", function(p) health[#health + 1] = p end)
    F.Bus:On("notify:user", function(p) notify[#notify + 1] = p end)
  end)

  -- เกมอัปเดต: leaderstats หาย
  __GAME.kill("leaderstats")
  local report = A:Reprobe()
  H.eq(report.status, "degraded", "สถานะรวมเสื่อมบางส่วน (ไม่ใช่พังทั้งระบบ)")
  H.eq(report.adapters.PlayerAdapter.status, "degraded", "PlayerAdapter เสื่อม")
  H.eq(#health, 1, "โมดูลได้รับ adapter:health 1 ครั้ง")
  H.eq(health[1].status, "degraded", "event บอกสถานะตรง")
  H.ok(#notify >= 1, "ผู้ใช้ถูกแจ้ง (No Silent Degradation)")
  H.eq(notify[1].key, "notify.adapter.degraded", "แจ้งด้วย key ที่ i18n แปลได้")

  -- API อื่นยังใช้ได้ — ระบบเดินต่อ
  H.eq(A.Camera:GetFOV(), 70, "กล้องยังทำงาน")
  H.eq(#A.World:GetOthers(), 2, "world ยังทำงาน")

  -- Diagnostics เห็นหลักฐาน (เหตุผลที่ต้องมีก่อนฟีเจอร์หลัก)
  local export = F.Diag:Export()
  H.ok(export:find("PlayerAdapter") ~= nil, "Export ระบุ adapter ที่เสื่อม")
  H.ok(export:find("GetBounty") ~= nil, "Export ระบุ method ที่ตาย")

  -- เกมกลับมา (หรืออัปเดต adapter แล้ว) → re-probe กลับ ok
  __GAME.restore("leaderstats")
  H.eq(A:Reprobe().status, "ok", "re-probe กลับมา ok")

  R.ShutdownAll({ assertZero = true })
end)

H.test("L2/adapter-dead: Players service ตายทั้งตัว → dead + รายงาน consumer ที่กระทบ + ปิดสะอาด", function()
  local R, F, A = bootStack()
  __GAME.kill("service:Players")
  local report = A:Reprobe()
  H.eq(report.adapters.PlayerAdapter.status, "dead", "PlayerAdapter dead")
  -- WorldAdapter เสื่อม (degraded) ไม่ใช่ dead — เพราะ RaycastClear/GetDistance
  -- ไม่พึ่ง Players service จึงยังใช้ได้ (แยกฟีเจอร์ได้จริงตาม §3.3 กฎ 3)
  H.eq(report.adapters.WorldAdapter.status, "degraded", "WorldAdapter เสื่อมบางส่วน (raycast/distance ยังอยู่)")
  local wDead = report.adapters.WorldAdapter.deadMethods
  H.eq(#wDead, 3, "method ที่ตายของ World = 3 (GetPlayers/GetOthers/GetServerInfo)")
  local impacted = report.impacted["PlayerAdapter"]
  H.ok(impacted and #impacted.consumers >= 3, "รายงานสายตาย: consumer ที่กระทบ >= 3 (TargetService/Race/Fruit)")
  H.ok(F.Diag:Export():find("PlayerAdapter ตาย") ~= nil, "Export สรุปว่าตาย")

  -- แม้ adapter ตาย การปิดระบบยังต้องสะอาด (orphan=0 เสมอ)
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "ปิดสะอาดแม้ adapter เสื่อม")
end)

H.test("L2/adapter-dead: InputAdapter ตาย → keybind เงียบแต่ระบบไม่พัง + กลับมาได้", function()
  local R, F, A = bootStack()
  F.Keybind:Bind("toggle", "K")
  __GAME.kill("service:UserInputService")
  local report = A:Reprobe()
  H.eq(report.adapters.InputAdapter.status, "dead", "InputAdapter dead")
  -- Keybind ยัง Trigger ผ่าน path UI ได้ (ไม่พึ่งคีย์บอร์ด — CR-PC-ONLY: เดิมเรียก path มือถือ)
  local fired = 0
  R.Scope("M1", function()
    F.Keybind:OnAction("toggle", function() fired = fired + 1 end)
  end)
  F.Keybind:Trigger("toggle")
  H.eq(fired, 1, "Trigger ทาง UI ยังทำงาน")
  R.ShutdownAll({ assertZero = true })
end)
