// ============================================================================
// The Voider — L2 runner (fengari) — Integration: โมดูล + adapter + bus + config
// ใช้:  npm run l2     (หรือ node qa/l2_integration/run_l2.js)
// โหลด: stub (env + game) → ทุก package (runtime + foundation + adapter) →
//       scenarios 3 ฉาก → รัน harness → exit code != 0 เมื่อ fail
// ============================================================================
const fs = require('fs');
const path = require('path');

let fengari;
try {
  fengari = require('fengari');
} catch (e) {
  try {
    fengari = require(path.resolve(__dirname, '..', '..', '..', 'scripts', 'node_modules', 'fengari'));
  } catch (e2) {
    console.error('[run_l2] ไม่พบ fengari — รัน "npm install" ใน root ของ repo ก่อน');
    process.exit(1);
  }
}
const { lua, lauxlib, lualib, to_luastring } = fengari;

const REPO = path.resolve(__dirname, '..', '..');

const FILES = [
  ['stub_env', 'qa/l1_unit/stub_env.lua', false],
  ['stub_game', 'qa/l1_unit/stub_game.lua', false],
  ['harness', 'qa/l1_unit/harness.lua', true],
  // runtime
  ['graph', 'core/runtime/graph.lua', true],
  ['preflight', 'core/runtime/preflight.lua', true],
  ['capability', 'core/runtime/capability.lua', true],
  ['registry', 'core/runtime/registry.lua', true],
  ['boundary', 'core/runtime/boundary.lua', true],
  ['watchdog', 'core/runtime/watchdog.lua', true],
  ['shutdown', 'core/runtime/shutdown.lua', true],
  ['init', 'core/runtime/init.lua', true],
  // foundation
  ['json', 'core/foundation/json.lua', true],
  ['services', 'core/foundation/services.lua', true],
  ['eventbus', 'core/foundation/eventbus.lua', true],
  ['migration', 'core/foundation/migration.lua', true],
  ['config', 'core/foundation/config.lua', true],
  ['i18n', 'core/foundation/i18n.lua', true],
  ['keybind', 'core/foundation/keybind.lua', true],
  ['diagnostics', 'core/foundation/diagnostics.lua', true],
  ['foundation', 'core/foundation/init.lua', true],
  // adapter
  ['adapter_common', 'core/adapter/_common.lua', true],
  ['adapter_player', 'core/adapter/player.lua', true],
  ['adapter_character', 'core/adapter/character.lua', true],
  ['adapter_combat', 'core/adapter/combat.lua', true],
  ['adapter_camera', 'core/adapter/camera.lua', true],
  ['adapter_input', 'core/adapter/input.lua', true],
  ['adapter_world', 'core/adapter/world.lua', true],
  ['adapter_probe', 'core/adapter/probe.lua', true],
  ['adapter', 'core/adapter/init.lua', true],
  // ui (L6 — เฟส 1)
  ['ui_backend', 'core/ui/_backend.lua', true],
  ['ui_theme', 'core/ui/theme.lua', true],
  ['ui_hub', 'core/ui/hub.lua', true],
  ['ui_hud', 'core/ui/hud.lua', true],
  ['ui_notify', 'core/ui/notify.lua', true],
  ['ui', 'core/ui/init.lua', true],
  // loader-domain (รอบ 4: Loader v2 + Update/Rollback §3.6/§7)
  ['version', 'core/runtime/version.lua', true],
  ['sha256', 'core/runtime/sha256.lua', true],
  ['manifest', 'core/runtime/manifest.lua', true],
  ['update', 'core/runtime/update.lua', true],
  ['bundle', 'core/runtime/bundle.lua', true],
  ['loadermain', 'core/runtime/loader_main.lua', true],
  // L2 scenarios (ฉาก integration)
  ['scenario_fullstack', 'qa/l2_integration/scenario_fullstack.lua', false],
  ['scenario_adapter_dead', 'qa/l2_integration/scenario_adapter_dead.lua', false],
  ['scenario_config_hotupdate', 'qa/l2_integration/scenario_config_hotupdate.lua', false],
  ['scenario_system_hotupdate', 'qa/l2_integration/scenario_system_hotupdate.lua', false],
  ['scenario_update_failures', 'qa/l2_integration/scenario_update_failures.lua', false],
  ['scenario_loader_e2e', 'qa/l2_integration/scenario_loader_e2e.lua', false],
  ['scenario_ui', 'qa/l2_integration/scenario_ui.lua', false],
];

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

function runChunk(name, code, isPackage) {
  let wrapped;
  if (isPackage) {
    wrapped = `local __m = (function()\n${code}\nend)(); __TV_PACKAGES[${JSON.stringify(name)}] = __m; PKG_${name} = __m;`;
  } else {
    wrapped = `do\n${code}\nend`;
  }
  const st = lauxlib.luaL_loadbuffer(L, to_luastring(wrapped), null, to_luastring('@' + name));
  if (st !== lua.LUA_OK) {
    console.log(`[LOAD FAIL ${name}]`, lua.lua_tojsstring(L, -1));
    process.exit(1);
  }
  const st2 = lua.lua_pcall(L, 0, 0, 0);
  if (st2 !== lua.LUA_OK) {
    console.log(`[RUN FAIL ${name}]`, lua.lua_tojsstring(L, -1));
    process.exit(1);
  }
}

console.log('===== The Voider L2 — Integration (full stack: Runtime+Foundation+Adapter) =====');
for (const [name, rel, isPackage] of FILES) {
  runChunk(name, fs.readFileSync(path.join(REPO, rel), 'utf8'), isPackage);
}

// ฉีด source ของ loader.lua ที่ build ประกอบแล้ว (ต้อง npm run build ก่อน)
// ให้ scenario_loader_e2e ใช้ผ่าน global __LOADER_LUA_SOURCE — ฉีดหลังโหลดทุก package
(function injectLoaderSource() {
  const p = path.join(REPO, 'loader.lua');
  if (!fs.existsSync(p)) {
    console.error('[run_l2] ไม่พบ loader.lua — รัน "npm run build" ก่อน (verify chain ทำให้อยู่แล้ว)');
    process.exit(1);
  }
  const src = fs.readFileSync(p, 'utf8');
  runChunk('__inject_loader', `__LOADER_LUA_SOURCE = ${JSON.stringify(src)};`, false);
})();

runChunk('__run_l2', `
local s = PKG_harness.run()
__FLUSH_OUT()
assert(s.fail == 0, ("L2_FAILED pass=%d fail=%d"):format(s.pass, s.fail))
__OUT.prints = {}
print("L2_ALL_GREEN")
__FLUSH_OUT()
`, false);

console.log('===== L2 RUNNER DONE =====');
