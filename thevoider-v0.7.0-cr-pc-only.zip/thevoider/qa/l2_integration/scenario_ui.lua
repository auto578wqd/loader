-- L2 ฉากที่ 7: UI Framework (เฟส 1) — integration ข้ามชั้น
-- UI(L6) × Adapter(L5-พื้นฐาน) × Event Bus × Config × i18n × Teardown (§5.4 + §8.1–8.4)
--
-- ต่างจาก L1 (test_ui.lua — หน่วย/โหนดเดียว): ฉากนี้พิสูจน์การ "เชื่อมกันจริง"
--   1) เต็มสแตก + UI เรนเดอร์บน gethui → ปิดทั้งระบบตาม graph กลับด้าน
--      (UI ทั้ง 3 node อยู่ท้าย initOrder จึงถูกปิดก่อน Foundation เสมอ)
--   2) [CR-PC-ONLY] อุปกรณ์ทัชอย่างเดียว (stub) → ยังได้ UI desktop เต็มชุด
--      ไม่มี layer TVMobile/ปุ่มลัดมือถือ + ปิดสะอาด orphan 0 (PC-only guard)
--   3) Adapter เสื่อมกลางเซสชัน → probe ประกาศผ่าน bus → toast โผล่จริงบน
--      UI + จุดสถานะ HUD เปลี่ยนสี + กลับมา ok + ไม่มี resource สะสม
--   4) ผู้ใช้จริงใช้งาน (ลาก hub/เปลี่ยน accent/เปลี่ยนภาษา) → ปิดระบบ →
--      เปิดใหม่: ค่าทั้งหมดกลับมาผ่าน ConfigService (§3.7 ความต่อเนื่อง)
local H = PKG_harness
local RuntimeLib = PKG_init
local FoundationLib = PKG_foundation
local AdapterLib = PKG_adapter
local UiLib = PKG_ui

local CONFIG_FILE = "thevoider/config.json"

local function bootStack(opts)
  opts = opts or {}
  __GAME.reset()
  if opts.touch ~= nil then __GAME.uis.TouchEnabled = opts.touch end
  if opts.keyboard ~= nil then __GAME.uis.KeyboardEnabled = opts.keyboard end
  if not opts.keepConfig then delfile(CONFIG_FILE) end
  __HUI = nil -- root ใหม่ต่อเซสชัน (จำลองรันใหม่หลังปิดสคริปต์)

  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  local U = UiLib.new({ runtime = R, foundation = F, version = "0.7.0-l2", clock = VTNow })
  U:Bootstrap()
  return R, F, A, U
end

local function findUI(U, name)
  return __UI.find(U.Backend.root, name)
end

local function fireDrag(rootHandle, gripHandle, dx, dy)
  gripHandle.obj.InputBegan:Fire({
    UserInputType = "MouseButton1", Input = { Delta = { X = 0, Y = 0 } },
  })
  rootHandle.obj.InputChanged:Fire({
    UserInputType = "MouseButton1", Input = { Delta = { X = dx, Y = dy } },
  })
  gripHandle.obj.InputEnded:Fire({ UserInputType = "MouseButton1" })
end

H.test("L2/ui: เต็มสแตก + UI เรนเดอร์บน gethui → ปิดตาม graph กลับด้าน (UI ก่อน Foundation)", function()
  local R, F, A, U = bootStack()
  H.eq(A.SelfProbe:LastReport().status, "ok", "โลกปกติ: adapter ครบก่อนมี UI")
  H.ok(U.Backend.available, "backend ต่อ gethui ได้")
  H.eq(U.Hub:Stats().built and U.HUD:Stats().built
    and U.Notify:Stats().built, true, "UI ครบ 3 node (CR-PC-ONLY: ตัด MobileLayout)")
  H.ok(findUI(U, "Hub") ~= nil and findUI(U, "TVHud") ~= nil
    and findUI(U, "TVNotify") ~= nil, "โครงทั้งสาม layer อยู่บน root จริง")

  -- ต้นทุน UI render ข้ามชั้น: HUD → Diagnostics timer "ui" (DoD §5.4)
  __VT.advance(2)
  local t = F.Diag:Snapshot().timers["ui"]
  H.ok(t and t.count >= 4, "timer ui วัดจาก frame task จริง")
  H.ok(t.total / t.count <= 0.5, ("ต้นทุน render เฉลี่ย %.4f ms ≤ 0.5 ms (L2 full stack)")
    :format(t.total / t.count))

  -- ปิดทั้งระบบ: UI ต้องถูกปิดก่อนผู้ให้บริการของตัวเอง (graph กลับด้าน §3.10)
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "orphan 0 ทุก node")
  H.eq(rep.orphans, 0, "รวมทั้งระบบ = 0")
  local order, pos = {}, {}
  for i, n in ipairs(rep.order) do pos[n] = i end
  H.ok(pos["Notification"] and pos["HUD"] and pos["Hub"],
    "UI ทั้ง 3 node อยู่ในรายงานการปิด")
  H.ok(pos["Notification"] < pos["HUD"] and pos["HUD"] < pos["Hub"],
    "ปิด UI ตาม graph กลับด้าน: Notify → HUD → Hub (MobileLayout ตัดตาม CR-PC-ONLY)")
  H.ok(pos["Hub"] < pos["KeybindService"] and pos["KeybindService"] < pos["EventBus"],
    "ผู้ใช้ (UI/Keybind) ถูกปิดก่อนผู้ให้บริการ (EventBus)")
end)

H.test("L2/ui: PC-only guard — อุปกรณ์ทัชอย่างเดียว (stub) ก็ได้ UI desktop เต็มชุด (CR-PC-ONLY)", function()
  local R, F, A, U = bootStack({ touch = true, keyboard = false })
  H.eq(F.Keybind:InputInfo().touchEnabled, true, "stub: ทัชเปิดจริง")
  H.eq(F.Keybind:InputInfo().keyboardEnabled, false, "stub: ไม่มีคีย์บอร์ด")
  -- UI ครบ 3 node และเป็นเลย์เอาต์ desktop ทุกค่า — ไม่มี adaptation มือถืออีกต่อไป
  H.eq(U.Hub:Stats().built and U.HUD:Stats().built and U.Notify:Stats().built, true,
    "UI ครบ 3 node บนอุปกรณ์ทัชอย่างเดียวเช่นกัน")
  local L = U.Theme:Get().layout
  H.eq(findUI(U, "Hub").Size.X.Offset, L.HUB_W, "hub กว้าง HUB_W ตาม desktop")
  H.eq(findUI(U, "Hub").Size.Y.Offset, L.HUB_H, "hub สูง HUB_H ตาม desktop")
  H.eq(findUI(U, "TVMobile"), nil, "ไม่มี layer TVMobile")
  H.eq(findUI(U, "QuickHub"), nil, "ไม่มีปุ่มลัดลอยมือถือ")
  -- ใช้งานได้ปกติ: ย่อ hub แล้ว pill แสดง (ไม่มีโหมดมือถือมาซ่อนอีก)
  U.Hub:Toggle()
  H.eq(U.Hub:Stats().visible, false, "ย่อ hub ได้ปกติ")
  H.eq(findUI(U, "OpenPill").Visible, true, "pill แสดงเมื่อย่อ (CR-PC-ONLY: ไม่ซ่อนฝั่งทัช)")
  U.Hub:Toggle()
  -- ปิดสะอาดบนอุปกรณ์ทัชอย่างเดียวเช่นกัน
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "orphan 0 ทุก node บนอุปกรณ์ทัชอย่างเดียวเช่นกัน")
end)

H.test("L2/ui: Adapter เสื่อมกลางเซสชัน → toast จริงบน UI + จุด HUD เปลี่ยน + กลับมา + ไม่สะสม", function()
  local R, F, A, U = bootStack()
  local base = R.Snapshot("Notification")
  -- เปิดแผงย่อ HUD ก่อน เพื่อดูจุดสถานะ adapter จากมุมผู้ใช้
  findUI(U, "Bar").MouseButton1Click:Fire()
  local dot = findUI(U, "DotAdapter")
  H.eq(dot.BackgroundColor3, U.Theme:Get().on, "เริ่มต้น: จุด adapter เขียว (ok)")

  -- เกมอัปเดต: leaderstats หาย → PlayerAdapter เสื่อม
  __GAME.kill("leaderstats")
  local report = A:Reprobe()
  H.eq(report.status, "degraded", "probe รายงานเสื่อม")
  local st = U.Notify:Stats()
  H.eq(st.active, 1, "toast โผล่ 1 อัน (ผ่าน bus จาก probe → Notification)")
  local toast = __UI.findAll(U.Backend.root, "Toast")[1]
  local msg = toast:FindFirstChild("Text").Text
  H.ok(msg:find("PlayerAdapter") ~= nil and msg:find("เสื่อม") ~= nil,
    "ข้อความ toast แปลจาก i18n พร้อมชื่อ adapter")
  H.eq(dot.BackgroundColor3, U.Theme:Get().warn, "จุด adapter เหลือง (degraded)")

  -- เกมกลับมา → probe ok → จุดกลับเขียว (adapter:health replay §3.6)
  __GAME.restore("leaderstats")
  H.eq(A:Reprobe().status, "ok", "re-probe กลับมา ok")
  H.eq(dot.BackgroundColor3, U.Theme:Get().on, "จุด adapter เขียวอีกครั้ง")

  -- toast หมดอายุเอง (TTL 5 วิ VT) → resource กลับระดับตั้งต้น (ไม่สะสม)
  __VT.advance(6)
  H.eq(U.Notify:Stats().active, 0, "toast หายตาม TTL")
  local after = R.Snapshot("Notification")
  H.eq(after.total, base.total, "ไม่มี resource ของ toast ค้าง (orphan สะสม = 0)")
  R.ShutdownAll({ assertZero = true })
end)

H.test("L2/ui: ผู้ใช้ลาก/เปลี่ยน accent/เปลี่ยนภาษา → ปิดระบบ → เปิดใหม่ ค่ากลับมาครบ (§3.7)", function()
  -- เซสชัน 1: ใช้งานจริงผ่าน UI
  local R, F, A, U = bootStack()
  fireDrag(U.Hub.mainH, U.Hub.elems.header, 33, -11)
  H.eq(F.Config:Get("ui.hub.pos").x, 33, "ลาก hub → บันทึกตำแหน่งลง config ทันที")
  H.ok(U.Hub:TrySetAccent("cyan"), "เปลี่ยน accent ผ่าน Setup")
  U.Hub.langBtns.en.obj.MouseButton1Click:Fire()
  H.eq(F.I18n:Lang(), "en", "เปลี่ยนภาษาผ่านปุ่ม")
  R.ShutdownAll({ assertZero = true })

  -- เซสชัน 2: config ไฟล์จริงต้องพาทุกอย่างกลับมา
  local R2, F2, A2, U2 = bootStack({ keepConfig = true })
  H.eq(F2.Config.status, "file", "โหลดจากไฟล์ของเซสชันก่อน")
  H.eq(findUI(U2, "Hub").Position.X.Offset, 33, "ตำแหน่ง hub กลับมา")
  H.eq(findUI(U2, "Hub").Position.Y.Offset, -51, "ทั้งสองแกนตรงตามที่ลากไว้")
  H.eq(U2.Theme:Accent(), "cyan", "accent กลับมา")
  H.eq(F2.I18n:Lang(), "en", "ภาษากลับมา")
  H.ok(U2.Hub.elems.statusText.obj.Text:find("ready") ~= nil, "ป้ายสถานะเป็นภาษาที่ตั้งไว้")
  R2.ShutdownAll({ assertZero = true })
  delfile(CONFIG_FILE) -- เก็บกวาดให้ฉากอื่นเริ่มสะอาด
end)
