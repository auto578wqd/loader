-- L2 ฉากที่ 1: Full Stack — โหลดทั้งระบบตาม dependency graph → ใช้งานจริง
-- → ปิดทั้งระบบตาม graph กลับด้าน → Resource orphan = 0 (§3.4 + §3.10)
local H = PKG_harness
local RuntimeLib = PKG_init
local FoundationLib = PKG_foundation
local AdapterLib = PKG_adapter

H.test("L2/fullstack: Runtime → Foundation → Adapter โหลดครบ + Self-Probe ok + system:ready", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()

  -- Foundation ฟัง system:ready ตั้งแต่ก่อน Bootstrap (ยังไม่มีใคร publish)
  -- (subscription อยู่ใต้ Scope ตามกติกา §3.4 — ฉากนี้ใช้ชื่อเจ้าของ "L2Scenario")
  local F = FoundationLib.new({ runtime = R })
  local ready = {}
  R.Scope("L2Scenario", function()
    F.Bus:On("system:ready", function(p) ready[#ready + 1] = p end)
  end)
  F:Bootstrap()
  H.eq(#ready, 1, "system:ready ประกาศครั้งเดียวตอน Bootstrap")
  H.eq(F.Config.status, "default", "config เริ่มจาก default (โลกใหม่)")
  H.eq(F.I18n:Lang(), "th", "ภาษาไทยจาก config")
  H.eq(F.Services:MustGet("I18n").Lang(), "th", "Direct Service I18n ใช้ได้")

  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  H.eq(A.SelfProbe:LastReport().status, "ok", "Adapter Health ครบทั้ง 6 ตอนโลกปกติ")
  H.ok(F.Keybind:Stats().inputAttached, "Keybind ต่อ InputAdapter แล้ว")

  -- จำลองโมดูล M1 (feature module ตัวแรกของระบบ) — ทุกอย่างอยู่ใต้ Scope
  local seen = {}
  R.Scope("M1", function()
    F.Bus:On("config:changed", function(p) seen.config = p end)
    F.Keybind:OnAction("toggle", function() seen.action = (seen.action or 0) + 1 end)
    R.Spawn("m1-heartbeat", function(ctx)
      while ctx.ShouldRun() do
        task.wait(0.1)
      end
    end)
  end)
  F.Keybind:Bind("toggle", "K")

  -- กดคีย์จริงผ่าน InputAdapter → Keybind → action ของ M1
  __GAME.pressKey("K")
  __GAME.releaseKey("K")
  H.eq(seen.action, 1, "action ทำงาน end-to-end: คีย์ → adapter → keybind → โมดูล")

  -- config change → event ถึงโมดูลผ่าน bus
  F.Config:Set("VoidAim.fov", 111)
  H.eq(seen.config and seen.config.path, "VoidAim.fov", "config:changed ถึงโมดูล")

  -- Diagnostics ใช้งานได้บน full stack (gate เจ้าของโปรเจกต์)
  local export = F.Diag:Export()
  H.ok(export:find("Adapter ครบทั้ง 6 API") ~= nil, "Export มี Adapter Health ล่าสุด")
  H.ok(export:find("task=%d+") ~= nil, "Export นับ resource สด")
  F.Diag:Sample()
  H.ok(F.Diag:SampleCount() >= 2, "sampling เดินจริง (bootstrap + ตอนนี้)")

  -- ปิดทั้งระบบตาม graph (Init กลับด้าน) — assertZero ตรวจ orphan ราย node
  local report = R.ShutdownAll({ assertZero = true })
  H.ok(report.ok, "รายงานปิด ok (ทุก node ที่มี hook คืนครบ)")
  H.eq(report.orphans, 0, "orphan รวม = 0")
  local okAll, snapAll = R.VerifyZero(nil)
  H.ok(okAll, "registry ว่างสนิทรวมทุกเจ้าของ (รวม M1 ที่ไม่ใช่ node) total=" .. snapAll.total)

  -- ลำดับปิดต้องกลับด้านจาก graph: KeybindService ก่อน EventBus
  local shutdownOrder = {}
  for _, name in ipairs(report.order) do shutdownOrder[#shutdownOrder + 1] = name end
  local function pos(name)
    for i, n in ipairs(shutdownOrder) do if n == name then return i end end
  end
  H.ok(pos("KeybindService") < pos("EventBus"), "ปิดกลับลำดับ: KeybindService ก่อน EventBus (ผู้ใช้ก่อนผู้ให้บริการ)")

  -- config ที่แก้ระหว่างเซสชัน (Keybinds + fov) ต้องถูกบันทึกตอนปิด (ConfigService destroy hook)
  H.ok(not F.Config.dirty, "dirty ถูกเคลียร์ = Save ทำงานตอน Destroy")
end)

H.test("L2/fullstack: โหลดซ้ำหลังปิด — config ที่บันทึกไว้กลับมาครบ (ความต่อเนื่องข้ามเซสชัน)", function()
  -- (ต่อจากฉากก่อน: ไฟล์ config มีค่าจากเซสชันที่แล้วแล้ว)
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  H.eq(F.Config.status, "file", "โหลดจากไฟล์จริง")
  H.eq(F.Config:Get("VoidAim.fov"), 111, "ค่าที่ตั้งเซสชันก่อนกลับมาครบ")
  H.eq(F.Config:Get("Keybinds.toggle"), "K", "keybind กลับมาครบ")
  H.eq(F.Keybind:KeyOf("toggle"), "K", "LoadFromConfig ทำงานตอน Bootstrap")
  -- เก็บกวาด: ปิดระบบ + ลบไฟล์ให้ฉากถัดไปเริ่มสะอาด
  R.ShutdownAll({ assertZero = true })
  delfile("thevoider/config.json")
end)
