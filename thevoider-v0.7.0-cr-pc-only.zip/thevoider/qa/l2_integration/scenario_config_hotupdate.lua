-- L2 ฉากที่ 3: Config + hot update จำลองย่อส่วน (§3.6 ขั้น FREEZE/RESUME + §3.7)
-- — migration v1 บน full stack + freeze/replay + rollback config
local H = PKG_harness
local RuntimeLib = PKG_init
local FoundationLib = PKG_foundation
local AdapterLib = PKG_adapter
local Json = PKG_json

H.test("L2/config-hotupdate: config v1 (Aimbot.FOV) → full stack → migrate อัตโนมัติ + ค่าถึงโมดูล", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  -- ผู้ใช้เก่า: config รุ่น v1 ตามแผน §3.7 (Aimbot.FOV)
  writefile("thevoider/config.json", Json.encode({
    schemaVersion = 1,
    profile = { name = "หลัก", createdAt = 1, updatedAt = 1 },
    settings = {
      Aimbot = { FOV = 90 },
      i18n = { lang = "en" }, -- ผู้ใช้คนนี้ใช้อังกฤษ
      Keybinds = { toggle = "K" },
    },
  }))

  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()

  H.eq(F.Config.status, "migrated", "migrate v1→v2 อัตโนมัติตอนโหลด")
  H.eq(F.Config:Get("VoidAim.fov"), 90, "Aimbot.FOV 90 → VoidAim.fov 90 ครบ")
  H.eq(F.Config:Get("_legacy")["settings.Aimbot"].FOV, 90, "ของเก่าเก็บใน _legacy (ห้ามทิ้ง)")
  H.eq(F.I18n:Lang(), "en", "ภาษาอังกฤษตาม config ผู้ใช้ (ไม่ใช่ default ไทย)")
  H.eq(F.Keybind:KeyOf("toggle"), "K", "keybind กู้คืนจาก config เก่า")

  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  H.eq(A.SelfProbe:LastReport().status, "ok", "adapter ok")
  R.ShutdownAll({ assertZero = true })
  delfile("thevoider/config.json")
end)

H.test("L2/config-hotupdate: FREEZE → config เปลี่ยนระหว่าง freeze → RESUME replay ถึงโมดูล", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()

  local seen = {}
  R.Scope("M1", function()
    F.Bus:On("config:changed", function(p) seen[#seen + 1] = p end)
  end)

  -- จำลอง hot update ขั้น FREEZE (§3.6 ขั้น 4): event ใหม่เข้าคิว
  F.Bus:Freeze(2)
  F.Config:Set("VoidAim.fov", 555)
  H.eq(#seen, 0, "ระหว่าง freeze โมดูลยังไม่ได้รับ event")
  H.eq(F.Bus:Stats().queued, 1, "event ค้างในคิว 1 ตัว")
  H.eq(F.Config:Get("VoidAim.fov"), 555, "ค่าจริงถูกเขียนแล้ว (state ใหม่)")

  -- RESUME (§3.6 ขั้น 9): replay ตาม policy — config:changed = replay
  local result = F.Bus:Resume(2)
  H.eq(result.replayed, 1, "replay 1 ตัว")
  H.eq(#seen, 1, "โมดูลได้รับ event หลัง resume")
  H.eq(seen[1].value, 555, "ค่าตรงกับที่เปลี่ยนระหว่าง freeze")
  H.eq(F.Bus:Stats().generation, 2, "generation ใหม่ = 2")

  R.ShutdownAll({ assertZero = true })
  delfile("thevoider/config.json")
end)

H.test("L2/config-hotupdate: Rollback Snapshot — configState คืนได้จริง + คิวทิ้งได้ (ไม่ replay ย้อน state)", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()

  -- สร้าง Rollback Snapshot (schema 7 ช่อง §3.6 — รอบนี้พิสูจน์ 2 ช่องหลักที่ Foundation ดูแล)
  local snapshot = {
    version = R.version,
    configState = F.Config:Data(),
    timestamp = 1790000000,
  }
  F.Config:Set("VoidAim.fov", 999)
  H.eq(F.Config:Get("VoidAim.fov"), 999, "เปลี่ยนค่าระหว่างทาง")

  -- อัปเดตพัง → rollback: กลับรุ่นเก่า = Replace(configState) + ทิ้งคิว (Transient DROP)
  F.Bus:Freeze(3)
  F.Config:Set("VoidAim.fov", 1234)
  local dropped = F.Bus:DropQueue()
  H.eq(dropped, 1, "event ที่ค้างระหว่าง rollback ถูกทิ้ง (รุ่นเก่า re-derive เอง)")
  F.Config:Replace(snapshot.configState)
  H.eq(F.Config:Get("VoidAim.fov"), 120, "config กลับค่าตอน snapshot ครบ")

  -- ตรวจว่า snapshot อ่านกลับได้ (กฎ: สร้างเสร็จต้องตรวจ recover ได้ §3.6)
  local okDecode = pcall(Json.decode, Json.encode(snapshot.configState))
  H.ok(okDecode, "configState เข้ารหัส/อ่านกลับได้ (ทำ snapshot จริงตอน Loader รอบหน้า)")

  R.ShutdownAll({ assertZero = true })
  delfile("thevoider/config.json")
end)

H.test("L2/config-hotupdate: config เสียกลางทาง → .bak + default + แจ้ง + ระบบยังเดิน + ปิดสะอาด", function()
  __GAME.reset()
  writefile("thevoider/config.json", "{{{ ไฟล์เสียกลางคัน")
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  H.eq(F.Config.status, "corrupted", "ตรวจจับไฟล์เสีย")
  H.eq(F.Config:Get("VoidAim.fov"), 120, "fallback default ใช้งานได้ทันที")
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  H.eq(A.SelfProbe:LastReport().status, "ok", "ระบบเดินต่อแม้ config เสีย")
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "ปิดสะอาด")
  delfile("thevoider/config.json")
end)
