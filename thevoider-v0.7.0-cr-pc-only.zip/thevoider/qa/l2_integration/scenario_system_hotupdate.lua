-- L2 ฉากที่ 4: System Hot Update แบบเต็มระบบจริง (Bundle.Build ผ่าน load จริง)
-- พิสูจน์: v→v+1, v→v+2 ต่อเนื่อง, ข้ามรุ่น (0.2→0.4), migration รักษา state,
-- config ผู้ใช้ไม่หาย, atomic ทุกจุด, orphan 0, timing ในงบ
local H = PKG_harness

-- L2 ใช้ crypto stub ของ stub_env (ตอบ 64-zeros สำหรับ input อื่น) — ต่อเป็นของจริง
-- เพื่อไม่ให้ tier crypto-api พังลวง ๆ (เหมือน executor จริงที่มี crypto)
do
  local S = PKG_sha256
  local __orig = crypto and crypto.hash or nil
  crypto.hash = function(algo, s)
    if algo ~= "sha256" then return __orig and __orig(algo, s) or nil end
    return S.hex(s)
  end
end
local Bundle = PKG_bundle
local Mani = PKG_manifest
local Sha = PKG_sha256
local Update = PKG_update

-- ---- โรงงาน source ของแต่ละ release -------------------------------------------
-- "bundle" ของ L2 คือ source จริงที่ load()+exec ผ่าน fengari — ตัวต่อ
-- __TV_PACKAGES.bundle.Entry (จุดเดียวกับ the-voider.lua ที่ build ประกอบ)

local RT = '  runtime = { clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true },\n'
  .. '  env = { game = game, workspace = workspace },\n'

-- release 0.2.0 — state รูปร่างเดิม {n=...}
local SRC_02 = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.2.0", releaseId = "r-0.2.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter',\n",
  "      Serialize = function(sys) return { n = sys._counter.n } end,\n",
  "      Apply = function(sys, old)\n",
  "        if old == nil then sys._counter = { n = 5 } return end\n",
  "        sys._counter = { n = old.n } -- รูปร่างเดิม รับตรง ๆ\n",
  "      end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { n = 5 } end,\n",
  "})\n",
})

-- release 0.3.0 — state เปลี่ยนรูปร่างเป็น {count, label} + เก็บของเก่าไว้ (_legacy)
local SRC_03 = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.3.0", releaseId = "r-0.3.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter',\n",
  "      Serialize = function(sys) return { count = sys._counter.count, label = sys._counter.label } end,\n",
  "      Apply = function(sys, old)\n",
  "        if old == nil then sys._counter = { count = 5, label = '-' } return end -- รุ่นนี้เพิ่งมาใหม่\n",
  "        if old.n ~= nil then -- มาจากรุ่นเก่า → MigrateState ของโมดูลเอง (§3.4)\n",
  "          sys._counter = { count = old.n, label = '-' }\n",
  "          sys._counter._legacy = { ['Counter.n'] = old.n } -- ห้ามทิ้ง §3.7\n",
  "          return\n",
  "        end\n",
  "        sys._counter = { count = old.count, label = old.label } -- รูปร่างเดียวกัน\n",
  "      end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { count = 5, label = '-' } end,\n",
  "})\n",
})

-- release 0.4.0 — เปลี่ยนรูปร่างอีกครั้ง {total} — Apply รับได้ทุกรูปร่างเก่า (ข้ามรุ่น)
local SRC_04 = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.4.0", releaseId = "r-0.4.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter',\n",
  "      Serialize = function(sys) return { total = sys._counter.total } end,\n",
  "      Apply = function(sys, old)\n",
  "        local t = 5\n",
  "        if old ~= nil then\n",
  "          if old.total ~= nil then t = old.total\n",
  "          elseif old.count ~= nil then t = old.count\n",
  "          elseif old.n ~= nil then t = old.n end -- ข้ามจาก 0.2 ตรงถึง 0.4 ได้\n",
  "        end\n",
  "        sys._counter = { total = t }\n",
  "        if old ~= nil and old.n ~= nil then\n",
  "          sys._counter._legacy = { ['Counter@0.2'] = old }\n",
  "        end\n",
  "      end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { total = 5 } end,\n",
  "})\n",
})

local function maniFor(ver, sha)
  local m, err = Mani.Build({
    version = ver, releaseId = "r-" .. ver,
    files = { ["the-voider.lua"] = { sha256 = sha, size = 1000 } },
    minLoaderVersion = "0.2.0", channel = "stable",
  })
  assert(m, tostring(err))
  return m
end

local function newUpdater(onStep)
  local upd
  upd = Update.new({
    loadFn = function(src, cn)
      local f, e = load(src, cn and ("@" .. tostring(cn)) or "@bundle")
      if not f then return nil, tostring(e) end
      return f
    end,
    clock = (function() local t = 0; return function() t = t + 0.001; return t end end)(),
    time = function() return __VT.now end,
    logger = function() end,
    onStep = onStep and function(step, info) onStep(upd, step, info) end or nil,
  })
  return upd
end

-- ต่อระบบเข้า updater เหมือนที่ loader ทำ (host.register)
local function attachBuilt(upd, src)
  -- exec เหมือน loader: ตั้ง __TV_HOST/__TV_BUNDLE_RUN → load → Entry จดทะเบียน
  local ver = src:match('version%s*=%s*"([%d%.]+)"')
  rawset(_G, "__TV_BUNDLE_RUN", { source = src, manifest = maniFor(ver, Sha.hex(src)) })
  local prevHost = rawget(_G, "__TV_HOST")
  rawset(_G, "__TV_HOST", {
    register = function(rec) upd:Attach(rec) end,
    checkUpdate = function() end,
  })
  local f = load(src, "@boot")
  local sys = f()
  rawset(_G, "__TV_HOST", prevHost)
  rawset(_G, "__TV_BUNDLE_RUN", nil)
  return sys
end

H.test("L2/hotupdate: v0.2.0→0.3.0 — state migrate รูปร่างใหม่ + config ผู้ใช้ไม่หาย + atomic", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local stepLog = {}
  local upd -- ประกาศก่อน: onStep ต้องเห็นเป็น upvalue
  upd = newUpdater(function(u, step) stepLog[#stepLog + 1] = step end)
  local sys02 = attachBuilt(upd, SRC_02)
  H.eq(sys02.version, "0.2.0")
  H.eq(sys02._counter.n, 5, "state 0.2.0 ตั้งต้น")

  -- config ผู้ใช้ตั้งเอง (จะต้องข้าม update ไปได้)
  sys02.config:Set("VoidAim.fov", 95)
  sys02.config:Set("i18n.lang", "en")
  H.eq(sys02.config:Get("i18n.lang"), "en")

  local res = upd:Apply(SRC_03, maniFor("0.3.0", Sha.hex(SRC_03)))
  H.ok(res.ok, res.detail)
  H.eq(res.path, "OK")
  H.eq(upd:Active().version, "0.3.0", "NEW active หลัง commit เท่านั้น")
  H.eq(upd:RollbackTarget().version, "0.2.0", "OLD คงไว้เป็น rollback target")

  -- atomic ตามลำดับขั้น
  local seen = {}
  for _, s in ipairs(stepLog) do seen[s] = (seen[s] or 0) + 1 end
  H.ok(seen["freeze"] == 1 and seen["teardown"] == 1 and seen["load"] == 1 and seen["commit"] == 1,
    "ทุกขั้นเดินครบรอบเดียว")

  -- state migration: {n=5} → {count=5} + เก็บของเก่า
  local sys03 = upd:Active().system
  H.eq(sys03._counter.count, 5, "MigrateState: n=5 → count=5")
  H.eq(sys03._counter._legacy["Counter.n"], 5, "ค่าเก่าถูกเก็บใน _legacy (ห้ามทิ้ง §3.7)")

  -- config ผู้ใช้: ค่าเดิมอยู่ครบ
  H.eq(sys03.config:Get("VoidAim.fov"), 95, "fov=95 ข้าม update มาได้")
  H.eq(sys03.config:Get("i18n.lang"), "en", "ภาษาที่ตั้งไว้ยังอยู่")
  H.eq(sys03.config:StorageKind(), "file", "storage ยัง persist")

  -- ใช้งานต่อได้จริง: bus ไม่ frozen + publish ใหม่เดิน + adapter probe ok
  H.ok(not sys03.bus:Stats().frozen)
  local hit = {}
  sys03.runtime.Scope("L2Hot", function()
    sys03.bus:On("config:changed", function(p) hit[#hit + 1] = p end)
  end)
  sys03.config:Set("VoidAim.fov", 111)
  H.eq(#hit, 1, "ระบบใหม่ยังรับ event ได้ปกติหลังอัปเดต")
  H.eq(sys03.probe:LastReport().status, "ok", "adapter ยังเห็นเกมครบ")

  -- orphan 4 ชนิด = 0 จาก teardown จริง
  H.eq(res.orphans.total, 0)
  H.eq(res.orphans.tasks, 0); H.eq(res.orphans.connections, 0)
  H.eq(res.orphans.renders, 0); H.eq(res.orphans.temps, 0)

  -- timing ในงบ + มีทุกขั้น
  H.ok(res.timing.totalMs > 0 and not res.timing.overBudget,
    ("timing totalMs=%.1f ในงบ %d"):format(res.timing.totalMs, res.timing.budgetMs))
  H.ok(res.timing.steps["snapshot-validate"] ~= nil, "มีขั้นตรวจ snapshot ก่อน teardown (R4)")

  -- replay จากของจริง: RESUME มี event ที่เกิดระหว่าง freeze ของระบบใหม่
  H.ok(res.replay.total >= 1, "มี event ในคิวระบบใหม่ถูก replay ตาม policy")

  -- ผู้ใช้ได้แจ้งเตือนสำเร็จ (ภาษาไทยผ่าน notify:user)
  local notified = {}
  sys03.runtime.Scope("L2Hot2", function()
    sys03.bus:On("notify:user", function(p) notified[#notified + 1] = p end)
  end)
  H.eq(#notified, 0, "ยังไม่มีแจ้งเตือนใหม่ (update จบไปแล้ว)")
end)

H.test("L2/hotupdate: CR-REPLAY-001 — คิว freeze window ข้าม generation ไป replay บนรุ่นใหม่ตาม policy", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local seenCfg, seenTick, seenSync = {}, 0, 0
  local upd
  upd = newUpdater(function(u, step, info)
    if step == "load" and info and info.system then
      -- โมดูลรุ่นใหม่ Declare + สมัครรับบน bus รุ่นใหม่ก่อน RESUME ทำงาน
      local s = info.system
      s.bus:Declare("world:tick", "drop")
      s.bus:Declare("sync:refresh", "idempotent")
      s.runtime.Scope("L2Carry", function()
        s.bus:On("config:changed", function(p) seenCfg[#seenCfg + 1] = p end)
        s.bus:On("world:tick", function() seenTick = seenTick + 1 end)
        s.bus:On("sync:refresh", function() seenSync = seenSync + 1 end)
      end)
    end
  end)
  local sys02 = attachBuilt(upd, SRC_02)
  sys02.bus:Declare("world:tick", "drop")
  sys02.bus:Declare("sync:refresh", "idempotent")
  sys02.config:Set("VoidAim.fov", 80)

  local res = upd:Apply(SRC_03, maniFor("0.3.0", Sha.hex(SRC_03)), {
    drainFns = {
      function()
        -- เหตุการณ์บน bus รุ่นเก่าระหว่างหน้าต่าง freeze (เดิมถูกทิ้งทั้งคิว)
        local s = upd:Active().system
        s.bus:Publish("world:tick", { n = 1 })       -- Transient → DROP
        s.bus:Publish("sync:refresh", { id = "go" }) -- Idempotent → REPLAY
        s.config:Set("VoidAim.fov", 555)              -- State → REPLAY (ผ่านของจริง)
      end,
    },
  })
  H.ok(res.ok, res.detail)
  H.eq(res.path, "OK")

  -- คิวรุ่นเก่าอย่างน้อย 3 ตัว (tick + sync + config:changed) ข้าม generation
  H.ok(res.replay.carried >= 3,
    ("คิว freeze window ถูกส่งข้าม generation (ได้ %d ตัว)"):format(res.replay.carried))
  H.ok(res.replay.carriedAccepted >= 2, "State + Idempotent ถูกรับไป replay บนรุ่นใหม่")
  H.ok(res.replay.carriedDropped >= 1, "Transient ถูก DROP ตอน import ตาม policy")
  H.eq(seenTick, 0, "world:tick (Transient) ไม่ถึงมือรุ่นใหม่ — re-derive จาก Adapter")
  H.eq(seenSync, 1, "sync:refresh (Idempotent) replay ถึงมือรุ่นใหม่ครบ")
  H.ok(#seenCfg >= 1, "config:changed (State) replay ถึงมือรุ่นใหม่")
  H.eq(seenCfg[#seenCfg].value, 555, "ค่า state ล่าสุด (LWW) ถึงมือรุ่นใหม่")
  H.eq(upd:Active().system.config:Get("VoidAim.fov"), 555,
    "config จริงมี 555 (snapshot ถ่ายหลัง drain → MIGRATE สอดคล้อง replay)")
  H.ok(not upd:Active().system.bus:Stats().frozen, "ใช้งานต่อได้จริง")

  delfile("thevoider/config.json")
end)

H.test("L2/hotupdate: 0.3.0→0.4.0 ต่อเนื่อง + ข้ามรุ่น 0.2.0→0.4.0 ตรง (v→v+2)", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local upd = newUpdater()
  local sys02 = attachBuilt(upd, SRC_02)
  sys02.config:Set("VoidAim.fov", 77)

  -- ต่อเนื่อง: 0.2 → 0.3
  local r1 = upd:Apply(SRC_03, maniFor("0.3.0", Sha.hex(SRC_03)))
  H.ok(r1.ok, r1.detail)
  H.eq(upd:Active().system._counter.count, 5)

  -- ต่อเนื่อง: 0.3 → 0.4
  local r2 = upd:Apply(SRC_04, maniFor("0.4.0", Sha.hex(SRC_04)))
  H.ok(r2.ok, r2.detail)
  H.eq(upd:Active().version, "0.4.0")
  H.eq(upd:Active().system._counter.total, 5, "state ข้ามสองรุ่นยังได้ 5 ตลอด")
  H.eq(upd:Active().system.config:Get("VoidAim.fov"), 77, "config ผู้ใช้ผ่านสองรอบ update")
  H.eq(upd:RollbackTarget().version, "0.3.0", "rollback target เลื่อนเป็นรุ่นก่อนหน้าล่าสุด")

  -- ข้ามรุ่นตรง: 0.2 → 0.4 (ฉากใหม่ ระบบใหม่)
  local upd2 = newUpdater()
  local sys02b = attachBuilt(upd2, SRC_02)
  sys02b.config:Set("VoidAim.fov", 33)
  local r3 = upd2:Apply(SRC_04, maniFor("0.4.0", Sha.hex(SRC_04)))
  H.ok(r3.ok, r3.detail)
  H.eq(upd2:Active().version, "0.4.0")
  H.eq(upd2:Active().system._counter.total, 5, "ข้ามจาก {n} ตรงเป็น {total} — MigrateState ของ 0.4 รับได้")
  H.ok(upd2:Active().system._counter._legacy["Counter@0.2"] ~= nil, "รูปร่างเก่าสุดถูกเก็บไว้ให้ตรวจย้อนหลัง")
  H.eq(upd2:Active().system.config:Get("VoidAim.fov"), 33)

  -- NOOP: ขอ 0.4 อีกครั้ง
  local r4 = upd2:Apply(SRC_04, maniFor("0.4.0", Sha.hex(SRC_04)))
  H.ok(r4.ok and r4.path == "NOOP")
  H.eq(upd2:Active().system._counter.total, 5, "NOOP ไม่แตะ state")
end)
