-- L2 ฉากที่ 6: Loader ปลายทาง — ทดสอบ "loader.lua ที่ build ประกอบแล้ว" ทั้งไฟล์
-- (ไม่ใช่แค่ package แยก) ผ่าน __TV_LOADER_TEST_MODE + stub HTTP 4-URL
-- ต้องรัน "npm run build" ก่อน — run_l2.js ฉีด source ผ่าน __LOADER_LUA_SOURCE
local H = PKG_harness

-- L2 ใช้ crypto stub ของ stub_env (ตอบ 64-zeros สำหรับ input อื่น) — ต่อเป็นของจริง
-- เพื่อไม่ให้ tier crypto-api พังลวง ๆ (เหมือน executor จริงที่มี crypto)
do
  local S = PKG_sha256
  local __orig = crypto and crypto.hash or nil
  crypto.hash = function(algo, s)
    if algo ~= "sha256" then return __orig and __orig(algo, s) or nil end
    return S.hex(s)
  end
end
local Sha = PKG_sha256
local Mani = PKG_manifest

-- โหมดทดสอบของ loader ที่ประกอบแล้ว: ให้คืน API แทนการรัน boot จริง
rawset(_G, "__TV_LOADER_TEST_MODE", true)

local function LOADER_SRC() return __LOADER_LUA_SOURCE end -- lazy: ฉีดหลังโหลดไฟล์ (run_l2)

-- โรงงาน HTTP stub: เสิ่อ 4 URL ตาม state ที่เทสตั้ง
local function makeCloud(spec)
  -- spec = { manifest = string|nil (nil = 404), entry = string|nil, delayUrls = {} }
  return function(req)
    local url = req.Url
    if url:find("/manifest%.json$") then
      if spec.manifest == nil then
        return { StatusCode = 404, Body = "" }
      end
      return { StatusCode = 200, Body = spec.manifest }
    end
    if url:find("/the%-voider%.lua$") then
      if spec.entry == nil then
        return { StatusCode = 404, Body = "" }
      end
      return { StatusCode = 200, Body = spec.entry }
    end
    return { StatusCode = 404, Body = "" }
  end
end

local function fixtureBundleSrc(version, releaseId)
  return table.concat({
    "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
    ('  version = %q, releaseId = %q,\n'):format(version, releaseId),
    "  runtime = { clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true },\n",
    "  env = { game = game, workspace = workspace },\n",
    "  onAssembly = function(sys) sys._mark = 'from-loader' end,\n",
    "})\n",
  })
end

local function fixtureManifest(version, entrySrc, channel)
  local m, err = Mani.Build({
    version = version, releaseId = "r-" .. version,
    files = { ["the-voider.lua"] = { sha256 = Sha.hex(entrySrc), size = #entrySrc } },
    minLoaderVersion = "0.3.0", channel = channel or "stable",
  })
  assert(m, tostring(err))
  return m
end

-- แปลง manifest table → JSON string ผ่าน json ของระบบ (เหมือน CDN จริง)
local function manifestJson(m)
  local Json = __TV_PACKAGES.json
  return Json.encode(m)
end

H.test("L2/loader: boot ผ่าน 4-URL (URL1 ตาย → URL2) + version gate + integrity + host.register", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  H.ok(LOADER_SRC() and #LOADER_SRC() > 1000, "มี source ของ loader จริง (ต้อง npm run build ก่อน)")

  local entry = fixtureBundleSrc("0.3.0", "r-0.3.0")
  local manifestStr = manifestJson(fixtureManifest("0.3.0", entry))
  -- URL แรกตาย (404) — ต้องไปต่อ URL2 ได้; เริ่มจาก "ทั้งเมฆว่าง" ก่อน
  local cloudState = { manifest = nil, entry = nil }
  local deadUrls = {
    "https://dead.invalid/thevoider/main",
    "https://cdn.example/thevoider/main",
    "https://raw.example/thevoider/main",
    "https://gh.example/thevoider/main",
  }
  local function thisHttp(req)
    if req.Url:find("dead%.invalid") then
      return { StatusCode = 404, Body = "" }
    end
    return makeCloud(cloudState)(req)
  end

  -- โหลด loader ที่ประกอบแล้วในโหมดทดสอบ (คืน { new = ... })
  local f, err = load(LOADER_SRC(), "@loader.lua")
  H.ok(f ~= nil, tostring(err))
  local api = f()
  H.ok(type(api) == "table" and type(api.new) == "function", "โหมดทดสอบคืน API")

  local loader = api.new({
    urls = deadUrls,
    httpFn = thisHttp,
    logger = function() end,
    clock = VTNow,
  })
  -- URL1 ตาย + URL2-4 ยังว่าง → boot ต้อง fail ที่ preflight (แจ้งภาษาไทย)
  local b1 = loader:boot()
  H.ok(not b1.ok, "URL ทั้งหมดว่าง = boot fail พร้อมข้อความไทย")

  -- ปลุก URL2: manifest + entry พร้อม
  cloudState.manifest = manifestStr
  cloudState.entry = entry
  local loader2 = api.new({
    urls = deadUrls,
    httpFn = thisHttp,
    logger = function() end,
    clock = VTNow,
  })
  local b2 = loader2:boot()
  H.ok(b2.ok, b2.message or "boot ผ่านผ่าน URL2 (fallback 4-URL)")
  H.eq(b2.version, "0.3.0")
  H.eq(loader2.updater:Active().version, "0.3.0", "host.register ต่อ updater แล้ว")
  H.ok(b2.system._mark == "from-loader", "bundle จริงถูก execute (fixture ผ่าน Entry จริง)")
  H.ok(b2.verify.ok, b2.verify.detail)
end)

H.test("L2/loader: checkUpdate — เจอรุ่นใหม่ผ่าน manifest → Hot Update เต็ม protocol จาก loader จริง", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local api = (load(LOADER_SRC(), "@loader.lua"))()
  local entry03 = fixtureBundleSrc("0.3.0", "r-0.3.0")
  local entry04 = fixtureBundleSrc("0.4.0", "r-0.4.0")
  local cloudState = {
    manifest = manifestJson(fixtureManifest("0.3.0", entry03)),
    entry = entry03,
  }
  local loader = api.new({
    urls = { "https://cdn.example/thevoider/main" },
    httpFn = makeCloud(cloudState),
    logger = function() end,
    clock = VTNow,
  })
  local b = loader:boot()
  H.ok(b.ok, b.message)
  H.eq(loader.updater:Active().version, "0.3.0")

  -- ออกรุ่นใหม่บน CDN
  cloudState.manifest = manifestJson(fixtureManifest("0.4.0", entry04))
  cloudState.entry = entry04

  local res = loader:checkUpdate()
  H.ok(res.ok, res.detail)
  H.eq(res.path, "OK")
  H.eq(loader.updater:Active().version, "0.4.0", "อัปเดตผ่าน loader จริง")
  H.eq(loader.updater:Active().system._mark, "from-loader")

  -- NOOP เมื่อไม่มีรุ่นใหม่
  local res2 = loader:checkUpdate()
  H.ok(res2.ok and res2.path == "NOOP")
end)

H.test("L2/loader: minLoaderVersion ปฏิเสธ + entry hash ไม่ตรง = F0 (ไม่ boot ระบบเสีย)", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local api = (load(LOADER_SRC(), "@loader.lua"))()
  local entry = fixtureBundleSrc("9.9.9", "r-9.9.9")
  -- manifest บังคับ loader v9.9.9 — ตัวเราเป็น 0.3.0 → ปฏิเสธชัด ๆ
  local m, err = Mani.Build({
    version = "9.9.9", releaseId = "r-9.9.9",
    files = { ["the-voider.lua"] = { sha256 = Sha.hex(entry), size = #entry } },
    minLoaderVersion = "9.9.9", channel = "stable",
  })
  local cloudState = { manifest = manifestJson(m), entry = entry }
  local loader = api.new({
    urls = { "https://cdn.example/thevoider/main" },
    httpFn = makeCloud(cloudState),
    logger = function() end,
    clock = VTNow,
  })
  local b = loader:boot()
  H.ok(not b.ok)
  H.eq(b.stage, "min-loader")
  H.ok(b.message:find("loader v9%.9%.9") ~= nil, "บอกตรง ๆ ว่าต้องรัน loader ใหม่")

  -- hash ไม่ตรง: manifest ชี้ sha ผิด → entry ตรวจไม่ผ่าน (F0 ระดับ loader)
  local entry2 = fixtureBundleSrc("9.9.9", "r-9.9.9")
  local m2, _ = Mani.Build({
    version = "0.3.0", releaseId = "r-0.3.0",
    files = { ["the-voider.lua"] = { sha256 = string.rep("0", 64), size = #entry2 } },
    minLoaderVersion = "0.3.0", channel = "stable",
  })
  local cloudState2 = { manifest = manifestJson(m2), entry = entry2 }
  local loader2 = api.new({
    urls = { "https://cdn.example/thevoider/main" },
    httpFn = makeCloud(cloudState2),
    logger = function() end,
    clock = VTNow,
  })
  local b2 = loader2:boot()
  H.ok(not b2.ok)
  H.eq(b2.stage, "entry")
  H.ok(b2.message:find("ไม่ผ่าน") ~= nil, "รายงานว่าตรวจไม่ผ่าน (ไม่ใช่พังเงียบ ๆ)")
end)
