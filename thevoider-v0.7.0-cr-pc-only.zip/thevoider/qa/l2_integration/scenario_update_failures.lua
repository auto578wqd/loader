-- L2 ฉากที่ 5: Failure Injection ทุก rollback path (§3.6 F0–F4 + F-SNAP + ยกเลิกก่อน teardown)
-- ทุก path พิสูจน์ว่า "กลับรุ่นเดิม + ใช้งานต่อได้จริง" ไม่ใช่แค่ "โหลดโค้ดเก่า"
local H = PKG_harness

-- L2 ใช้ crypto stub ของ stub_env (ตอบ 64-zeros สำหรับ input อื่น) — ต่อเป็นของจริง
-- เพื่อไม่ให้ tier crypto-api พังลวง ๆ (เหมือน executor จริงที่มี crypto)
do
  local S = PKG_sha256
  local __orig = crypto and crypto.hash or nil
  crypto.hash = function(algo, s)
    if algo ~= "sha256" then return __orig and __orig(algo, s) or nil end
    return S.hex(s)
  end
end
local Bundle = PKG_bundle
local Mani = PKG_manifest
local Sha = PKG_sha256
local Update = PKG_update

local RT = '  runtime = { clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true },\n'
  .. '  env = { game = game, workspace = workspace },\n'

local SRC_OK_02 = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.2.0", releaseId = "r-0.2.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter', Serialize = function(sys) return { n = sys._counter.n } end,\n",
  "      Apply = function(sys, old) sys._counter = old and { n = old.n } or { n = 5 } end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { n = 5 } end,\n",
  "})\n",
})

-- รุ่นใหม่ที่ "จงใจพัง" ตามชนิด — สลับได้ด้วย breakKind
local function src03Broken(breakKind)
  local breakPart = ""
  if breakKind == "load" then
    return "this is not lua at all !!! ( ( ("
  elseif breakKind == "exec" then
    breakPart = "  bootBroken = true,\n" -- bundle Build ต้องเป็น合法 — ใช้ exec พังที่ระดับ loadFn แทน
  end
  return table.concat({
    "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
    '  version = "0.3.0", releaseId = "r-0.3.0",\n',
    RT,
    breakPart,
    "})\n",
  })
end

-- รุ่น 0.3 ที่ MIGRATE พัง (provider Apply error)
local SRC_03_MIGRATE_BAD = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.3.0", releaseId = "r-0.3.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter', Serialize = function(sys) return { n = sys._counter.n } end,\n",
  "      Apply = function(sys, old) error('MigrateState พังตามสั่ง') end },\n",
  "  },\n",
  "})\n",
})

-- รุ่น 0.3 ที่ SELFCHECK พัง
local SRC_03_SELFCHECK_BAD = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.3.0", releaseId = "r-0.3.0",\n',
  RT,
  "  selfChecks = {\n",
  "    { name = 'boom-check', fn = function(sys, ctx) return false, 'จงใจให้ SELFCHECK พัง' end },\n",
  "  },\n",
  "})\n",
})

-- รุ่น 0.2 ที่ teardown มี leak (จงใจไม่คืน Temp ของ KeybindService)
local SRC_02_LEAK = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.2.0", releaseId = "r-0.2.0-leak",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter', Serialize = function(sys) return { n = sys._counter.n } end,\n",
  "      Apply = function(sys, old) sys._counter = old and { n = old.n } or { n = 5 } end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { n = 5 } end,\n",
  "  -- จำลองโมดูลที่ไม่คืนทรัพยากร: Temp ของ KeybindService ไม่มีใครปล่อย\n",
  "  leakOnAssembly = true,\n",
  "})\n",
})

-- รุ่น 0.2 ที่ serializer พัง (ทำ snapshot ไม่ได้ = F-SNAP)
local SRC_02_SNAP_BAD = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.2.0", releaseId = "r-0.2.0-snapbad",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter', Serialize = function(sys) error('Serialize พังตามสั่ง') end,\n",
  "      Apply = function(sys, old) sys._counter = old and { n = old.n } or { n = 5 } end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { n = 5 } end,\n",
  "})\n",
})

local function maniFor(ver, sha)
  local m, err = Mani.Build({
    version = ver, releaseId = "r-" .. ver,
    files = { ["the-voider.lua"] = { sha256 = sha, size = 1000 } },
    minLoaderVersion = "0.2.0", channel = "stable",
  })
  assert(m, tostring(err))
  return m
end

local function newUpdater(onStep)
  local upd
  upd = Update.new({
    loadFn = function(src, cn)
      local f, e = load(src, cn and ("@" .. tostring(cn)) or "@bundle")
      if not f then return nil, tostring(e) end
      return f
    end,
    clock = (function() local t = 0; return function() t = t + 0.001; return t end end)(),
    time = function() return __VT.now end,
    logger = function() end,
    onStep = onStep and function(step, info) onStep(upd, step, info) end or nil,
  })
  return upd
end

-- สร้าง+ต่อระบบจาก source (ผ่าน Entry จริง) — ถ้า source จำเป็นต้อง leak
-- จะเพิ่ม Temp ที่ไม่มีใครปล่อยให้หลังประกอบเสร็จ
local function bootAndAttach(upd, src, extra)
  extra = extra or {}
  local ver = src:match('version%s*=%s*"([%d%.]+)"')
  local prevHost = rawget(_G, "__TV_HOST")
  rawset(_G, "__TV_HOST", {
    register = function(rec) upd:Attach(rec) end,
    checkUpdate = function() end,
  })
  rawset(_G, "__TV_BUNDLE_RUN", { source = src, manifest = maniFor(ver, Sha.hex(src)) })
  local f = load(src, "@boot")
  local sys = f()
  if extra.leak then
    -- จำลองโมดูลหลุด: Temp ของ "KeybindService" ที่ไม่ถูกปล่อยตอน teardown
    sys.runtime.Scope("KeybindService", function()
      sys.runtime.Temp({ tag = "leak-fixture" }, function() end)
    end)
  end
  rawset(_G, "__TV_HOST", prevHost)
  rawset(_G, "__TV_BUNDLE_RUN", nil)
  return sys
end

local SRC_03_OK = table.concat({
  "return __TV_PACKAGES.bundle.Entry(rawget(_G, '__TV_HOST'), {\n",
  '  version = "0.3.0", releaseId = "r-0.3.0",\n',
  RT,
  "  providers = {\n",
  "    { name = 'Counter', Serialize = function(sys) return { n = sys._counter.n } end,\n",
  "      Apply = function(sys, old) sys._counter = old and { n = old.n } or { n = 5 } end },\n",
  "  },\n",
  "  onAssembly = function(sys) sys._counter = sys._counter or { n = 5 } end,\n",
  "})\n",
})

H.test("L2/failures: F-SNAP — serializer พัง = ABORT ก่อน TEARDOWN (ระบบเดิมยังใช้ได้)", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local upd = newUpdater()
  local sys = bootAndAttach(upd, SRC_02_SNAP_BAD)
  sys.config:Set("VoidAim.fov", 42)

  local res = upd:Apply(SRC_03_OK, maniFor("0.3.0", Sha.hex(SRC_03_OK)))
  H.ok(not res.ok and res.path == "F-SNAP", res.detail)
  H.ok(res.bugId:match("^BUG%-UPD%-0%d%d$") ~= nil, "มี Bug ID (§11)")
  H.ok(res.detail:find("ก่อน TEARDOWN") ~= nil, "อ้างกฎ R4")
  H.eq(res.rolledBack, false, "ไม่ใช่ rollback — ยกเลิกก่อนทำลายอะไร")

  -- ระบบเดิมเดินต่อ: bus resume + ค่า config ยังอยู่ + ยังเป็นรุ่นเดิม
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not sys.bus:Stats().frozen, "bus ถูก resume คืน")
  H.eq(sys.config:Get("VoidAim.fov"), 42, "ค่าที่ตั้งไว้ยังอยู่ (ไม่มีอะไรถูกทำลาย)")
end)

H.test("L2/failures: F1 — orphan ที่ TEARDOWN = ABORT + rollback ใช้งานต่อได้จริง", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local rolledEvents = {}
  local upd
  upd = newUpdater(function(u, step, info)
    if step == "rollback.load" and info and info.system then
      -- สมัครภายใน Scope ของระบบทดสอบ (ไม่ปล่อยให้ตกเป็น _unscoped)
      info.system.runtime.Scope("L2Fixture", function()
        info.system.bus:On("update:rolledback", function(p) rolledEvents[#rolledEvents + 1] = p end)
      end)
    end
  end)
  local sys = bootAndAttach(upd, SRC_02_LEAK, { leak = true })
  sys.config:Set("VoidAim.fov", 88)
  sys._counter.n = 9
  H.ok(sys.registry:Snapshot("KeybindService").temps >= 1, "leak fixture ติดตั้งแล้ว")

  local res = upd:Apply(SRC_03_OK, maniFor("0.3.0", Sha.hex(SRC_03_OK)))
  H.ok(not res.ok and res.path == "F1", res.detail)
  H.ok(res.detail:find("ห้าม force%-clean") ~= nil)

  -- รายงาน orphan แยก 4 ชนิด + เจ้าของ
  H.eq(res.orphans.temps, 1, "temps=1 (ชิ้นที่จงใจไม่คืน)")
  H.eq(res.orphans.total, 1)
  H.ok(res.detail:find("KeybindService") ~= nil, "ระบุเจ้าของที่ค้าง")

  -- rollback: รุ่นเดิมกลับมา + ใช้งานได้จริง
  H.eq(res.rolledBack, true)
  local sysBack = upd:Active().system
  H.eq(upd:Active().version, "0.2.0")
  H.ok(sysBack ~= sys, "เป็นอินสแตนซ์ใหม่ของรุ่นเดิม (โหลดจาก snapshot.bundle)")
  H.ok(not sysBack.bus:Stats().frozen, "bus กลับมาทำงาน")
  H.eq(sysBack.config:Get("VoidAim.fov"), 88, "config กลับคืนจาก snapshot.configState")
  H.eq(sysBack._counter.n, 9, "state กลับคืนจาก snapshot.moduleStates")
  H.eq(sysBack.probe:LastReport().status, "ok", "adapter probe ผ่านหลัง rollback")
  H.eq(#rolledEvents, 1, "update:rolledback ถึงผู้ฟัง")
  H.eq(rolledEvents[1].bugId, res.bugId, "event ใส่ bugId เดียวกับ result")

  -- timing มีขั้น rollback ครบ
  H.ok(res.timing.steps["rollback.load"] ~= nil)
  H.ok(res.timing.steps["rollback.selfcheck"] ~= nil)
  H.ok(res.timing.steps["rollback.adapter-probe"] ~= nil)

  -- ยังเดินต่อได้: config เปลี่ยน + event ไหล
  local hit = {}
  sysBack.runtime.Scope("AfterF1", function()
    sysBack.bus:On("config:changed", function(p) hit[#hit + 1] = p end)
  end)
  sysBack.config:Set("VoidAim.fov", 99)
  H.eq(#hit, 1, "ระบบที่ rollback มาทำงานได้จริง (ไม่ใช่แค่โหลดโค้ดเก่า)")
end)

H.test("L2/failures: F2 — LOAD พัง / MIGRATE พัง = rollback ทั้งคู่", function()
  __GAME.reset()
  delfile("thevoider/config.json")

  -- LOAD: source รุ่นใหม่ไม่ใช่ Lua
  local upd = newUpdater()
  bootAndAttach(upd, SRC_OK_02)
  local badSrc = "this is not lua at all !!! ( ( ("
  local r1 = upd:Apply(badSrc, maniFor("0.3.0", Sha.hex(badSrc)))
  H.ok(not r1.ok and r1.path == "F2", r1.detail)
  H.ok(r1.detail:find("LOAD") ~= nil)
  H.eq(r1.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not upd:Active().system.bus:Stats().frozen, "ใช้งานต่อได้")

  -- MIGRATE: provider Apply error
  local upd2 = newUpdater()
  local sys2 = bootAndAttach(upd2, SRC_OK_02)
  sys2._counter.n = 7
  local r2 = upd2:Apply(SRC_03_MIGRATE_BAD, maniFor("0.3.0", Sha.hex(SRC_03_MIGRATE_BAD)))
  H.ok(not r2.ok and r2.path == "F2", r2.detail)
  H.ok(r2.detail:find("provider Counter") ~= nil)
  H.eq(upd2:Active().version, "0.2.0")
  H.eq(upd2:Active().system._counter.n, 7, "state รุ่นเดิมกลับคืน")
end)

H.test("L2/failures: F3 — SELFCHECK พัง = rollback + รุ่นเดิมยังเดิน", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local upd = newUpdater()
  bootAndAttach(upd, SRC_OK_02)
  local res = upd:Apply(SRC_03_SELFCHECK_BAD, maniFor("0.3.0", Sha.hex(SRC_03_SELFCHECK_BAD)))
  H.ok(not res.ok and res.path == "F3", res.detail)
  H.ok(res.detail:find("boom%-check") ~= nil, "ระบุ check ที่พัง")
  H.eq(res.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not upd:Active().system.bus:Stats().frozen)
end)

H.test("L2/failures: CR-REPLAY-001 — rollback (F3) ก็ต้อง replay คิวข้าม generation บนรุ่นเดิมที่กลับมา", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local seenCfg, seenTick = {}, 0
  local upd
  upd = newUpdater(function(u, step, info)
    if step == "rollback.load" and info and info.system then
      -- โมดูลรุ่นเดิมที่กลับมา Declare + สมัครรับก่อน rollback.resume
      -- (สมัครภายใน Scope ของระบบทดสอบ — ไม่ปล่อยให้ตกเป็น _unscoped)
      local s = info.system
      s.bus:Declare("world:tick", "drop")
      s.runtime.Scope("L2Fixture", function()
        s.bus:On("config:changed", function(p) seenCfg[#seenCfg + 1] = p end)
        s.bus:On("world:tick", function() seenTick = seenTick + 1 end)
      end)
    end
  end)
  local sys = bootAndAttach(upd, SRC_OK_02)
  sys.bus:Declare("world:tick", "drop")

  local res = upd:Apply(SRC_03_SELFCHECK_BAD, maniFor("0.3.0", Sha.hex(SRC_03_SELFCHECK_BAD)), {
    drainFns = {
      function()
        -- เหตุการณ์บน bus รุ่นเก่าระหว่างหน้าต่าง freeze (เดิมถูกทิ้งทั้งคิวตอน rollback)
        local s = upd:Active().system
        s.config:Set("VoidAim.fov", 444)             -- State → REPLAY บนรุ่นเดิม
        s.bus:Publish("world:tick", { n = 9 })       -- Transient → DROP
      end,
    },
  })
  H.ok(not res.ok and res.path == "F3", res.detail)
  H.eq(res.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")

  -- คิวข้าม generation ไปถึงรุ่นเดิมที่ rollback กลับมา + replay ตาม policy
  H.ok(res.replay ~= nil, "ผลลัพธ์ rollback มีรายงาน replay ให้ตรวจ (ไม่ใช่ทิ้งเงียบ)")
  H.ok(res.replay.carried >= 2,
    ("คิว freeze window ถูกส่งข้าม generation แม้จะ rollback (ได้ %d ตัว)"):format(res.replay.carried))
  H.ok(res.replay.carriedAccepted >= 1, "State event ถูกรับไป replay บนรุ่นเดิม")
  H.ok(res.replay.carriedDropped >= 1, "Transient ถูก DROP ตาม policy")
  H.eq(seenTick, 0, "world:tick (Transient) ไม่ถึงมือรุ่นเดิม — โลกจริง re-derive จาก Adapter")
  H.ok(#seenCfg >= 1, "config:changed (State) replay ถึงมือรุ่นเดิมหลัง rollback")
  H.eq(seenCfg[#seenCfg].value, 444, "ค่า state จากหน้าต่าง freeze ไม่หาย (LWW)")
  H.eq(upd:Active().system.config:Get("VoidAim.fov"), 444,
    "config รุ่นเดิมมีค่าจากหน้าต่าง freeze (snapshot ถ่ายหลัง drain → สอดคล้อง replay)")
  H.ok(not upd:Active().system.bus:Stats().frozen, "ใช้งานต่อได้จริง")
end)

H.test("L2/failures: F4 — adapter dead กลางอัปเดต (เป้าตายระหว่าง freeze) → rollback + re-derive", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local worldEvents = {}
  local upd
  upd = newUpdater(function(u, step, info)
    if step == "drain" then
      -- กลางหน้าต่าง freeze: API เกมตาย + event โลกเก่าถูกปล่อยเข้าคิว
      __GAME.kill("service:Players")
      upd:Active().system.bus:Publish("world:target-changed", { target = "A (ตายแล้ว)" })
    end
    if step == "rollback.load" and info and info.system then
      info.system.bus:Declare("world:target-changed", "drop") -- Transient → DROP เสมอ
      info.system.runtime.Scope("L2Fixture", function()
        info.system.bus:On("world:target-changed", function(p)
          worldEvents[#worldEvents + 1] = p
        end)
      end)
    end
    if step == "rollback.selfcheck" then
      -- จำลอง "ตายชั่วคราว": กู้ API กลับก่อนขั้น rollback.adapter-probe
      -- (ถ้าไม่กู้ ตัว rollback เองจะพัง → ฉากถัดไปพิสูจน์กรณีนั้นแยก)
      __GAME.restore("service:Players")
    end
  end)
  local sys = bootAndAttach(upd, SRC_OK_02)
  sys._counter.n = 3

  local res = upd:Apply(SRC_03_OK, maniFor("0.3.0", Sha.hex(SRC_03_OK)))
  H.ok(not res.ok and res.path == "F4", res.detail)
  H.ok(res.detail:find("ADAPTER PROBE") ~= nil)
  H.eq(res.rolledBack, true)

  H.eq(upd:Active().version, "0.2.0")
  H.ok(not upd:Active().system.bus:Stats().frozen, "ใช้งานต่อได้")

  -- event โลกเก่า (drop policy) ต้องไม่ย้อน state — ผู้ฟังต้องไม่เคยเห็น
  H.eq(#worldEvents, 0, "event Transient ถูก DROP — state โลกจริงต้อง re-derive จาก Adapter")
end)

H.test("L2/failures: F4 ถาวร — rollback เองก็เจอ dead = broken เสียงดัง (No Silent Degradation)", function()
  __GAME.reset()
  delfile("thevoider/config.json")
  local upd
  upd = newUpdater(function(u, step, info)
    if step == "drain" then
      __GAME.kill("service:Players") -- ตายตั้งแต่กลาง update และไม่กู้
    end
  end)
  bootAndAttach(upd, SRC_OK_02)
  local res = upd:Apply(SRC_03_OK, maniFor("0.3.0", Sha.hex(SRC_03_OK)))
  H.ok(not res.ok, res.detail)
  H.eq(res.path, "F4+ROLLBACK-FAIL")
  H.eq(res.broken, true)
  H.ok(res.detail:find("No Silent Degradation") ~= nil)
  H.ok(upd:Status().broken ~= nil, "Status มี broken ให้ Diagnostics เห็น")
  -- พังถาวรก็ยังต้องรายงาน bugId
  H.ok(res.bugId ~= nil)
end)
