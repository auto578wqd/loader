-- L1: Event Bus (§3.5 + §3.6) — publish/subscribe + freeze queue + replay policy
local H = PKG_harness
local Bus = PKG_eventbus
local Registry = PKG_registry
local Boundary = PKG_boundary

local function newBus(reg, bnd)
  return Bus.new({
    registry = reg,
    boundary = bnd,
    clock = VTNow,
    owner = "EventBus",
  })
end

-- ==== พื้นฐาน publish/subscribe ==============================================

H.test("bus: Declare + Publish + On — subscriber ได้ payload + metadata", function()
  local bus = newBus()
  bus:Declare("test:ping", "drop")
  local got
  bus:On("test:ping", function(payload, evt)
    got = { payload = payload, evt = evt }
  end)
  local n = bus:Publish("test:ping", { v = 42 })
  H.eq(n, 1, "ต้องส่งถึง 1 subscriber")
  H.ok(got, "subscriber ต้องได้รับ")
  H.eq(got.payload.v, 42, "payload ตรง")
  H.eq(got.evt.type, "test:ping", "metadata type ตรง")
  H.eq(got.evt.replayable, "drop", "metadata replayable ตรงตาม Declare")
  H.eq(got.evt.generation, 0, "generation เริ่มที่ 0")
  H.ok(type(got.evt.timestamp) == "number", "metadata มี timestamp")
end)

H.test("bus: หลาย subscriber ได้รับครบ + เรียงตามลำดับสมัคร", function()
  local bus = newBus()
  bus:Declare("test:order", "drop")
  local order = {}
  bus:On("test:order", function() order[#order + 1] = "A" end)
  bus:On("test:order", function() order[#order + 1] = "B" end)
  bus:On("test:order", function() order[#order + 1] = "C" end)
  H.eq(bus:Publish("test:order", {}), 3, "ส่งถึง 3 คน")
  H.eq(table.concat(order, ""), "ABC", "เรียงตามลำดับสมัคร")
end)

H.test("bus: policy ไม่ถูกต้อง = ปฏิเสทันที (กันพิมพ์ผิด)", function()
  local bus = newBus()
  local ok, err = pcall(bus.Declare, bus, "bad", "replai")
  H.ok(not ok, "policy พิมพ์ผิดต้อง error")
  H.ok(tostring(err):find("policy") ~= nil, "ข้อความ error ต้องบอกเรื่อง policy")
end)

H.test("bus: event ที่ไม่ Declare = policy drop (safe default) + นับ undeclared", function()
  local bus = newBus()
  bus:Publish("undeclared:event", {})
  H.eq(bus:Stats().undeclared, 1, "นับ undeclared ให้ Diagnostics เห็น")
end)

-- ==== subscription = resource ใน registry (§3.4) =============================

H.test("bus: On ภายใต้ Scope → subscription นับเป็น temp ของโมดูล + Release อัตโนมัติ", function()
  local reg = Registry.new({ task = task, drawing = Drawing, instance = Instance, clock = VTNow })
  local bus = newBus(reg)
  bus:Declare("cfg:x", "replay")
  local handle
  reg:Scope("M1", function()
    handle = bus:On("cfg:x", function() end)
  end)
  H.eq(reg:Snapshot("M1").temps, 1, "subscription ต้องนับเป็น temp ของ M1")
  reg:Release("M1") -- จำลอง Module:Destroy() คืนทรัพยากรของโมดูล
  H.eq(reg:Snapshot("M1").temps, 0, "หลัง Release ต้องหาย (orphan=0 อัตโนมัติ)")
  H.eq(bus:Stats().subscribers, 0, "subscriber ถูกถอดจริง ไม่ใช่แค่นับ")
end)

H.test("bus: subscriber พัง → boundary จับ + คนอื่นได้รับต่อ + นับ subscriberErrors", function()
  local bnd = Boundary.new({ clock = VTNow })
  local bus = newBus(nil, bnd)
  bus:Declare("test:boom", "drop")
  local gotAfter = false
  bus:On("test:boom", function() error("พังเอง") end)
  bus:On("test:boom", function() gotAfter = true end)
  H.eq(bus:Publish("test:boom", {}), 2, "ยังส่งถึง 2 คน (พังเองไม่ลาม)")
  H.ok(gotAfter, "คนหลังพังต้องได้รับต่อ")
  H.eq(bus:Stats().subscriberErrors, 1, "นับ error 1 ครั้ง")
  H.eq(bnd:Count("EventBus"), 1, "error ถูกนับที่เจ้าของ subscription")
end)

-- ==== freeze / resume (hot update §3.6 ขั้น 4/9) =============================

H.test("bus: Freeze → event ใหม่เข้าคิว (ไม่ dispatch) + Resume → replay ตาม policy", function()
  local bus = newBus()
  bus:Declare("transient:tick", "drop")       -- Transient → ทิ้ง
  bus:Declare("config:changed", "replay")      -- State → replay
  bus:Declare("sync:refresh", "idempotent")    -- Idempotent → replay

  local ticks, cfgs, syncs = 0, 0, 0
  bus:On("transient:tick", function() ticks = ticks + 1 end)
  bus:On("config:changed", function() cfgs = cfgs + 1 end)
  bus:On("sync:refresh", function() syncs = syncs + 1 end)

  bus:Freeze(2)
  H.eq(bus:Publish("transient:tick", {}), 0, "ระหว่าง freeze ต้องไม่ dispatch")
  H.eq(bus:Publish("config:changed", { fov = 90 }), 0, "เข้าคิวทั้งคู่")
  H.eq(bus:Publish("sync:refresh", {}), 0, "เข้าคิว")
  H.eq(bus:Stats().queued, 3, "คิวมี 3 event")
  H.eq(bus:Stats().frozen, true, "สถานะ frozen")

  local result = bus:Resume(2)
  H.eq(result.total, 3, "replay ดู 3 event")
  H.eq(result.dropped, 1, "transient ถูก DROP 1 ตัว")
  H.eq(result.replayed, 2, "replay 2 ตัว (state + idempotent)")
  H.eq(ticks, 0, "transient ต้องไม่ถึง subscriber (เหตุการณ์เก่าเลิกเป็นจริงแล้ว)")
  H.eq(cfgs, 1, "state event ถูก replay")
  H.eq(syncs, 1, "idempotent event ถูก replay")
  H.eq(bus:Stats().generation, 2, "generation เปลี่ยนตามที่ส่งให้ Resume")
end)

H.test("bus: replay เรียงตาม timestamp → last-write-wins (ค่าหลังสุดชนะ)", function()
  local bus = newBus()
  bus:Declare("config:changed", "replay")
  local lastFov
  bus:On("config:changed", function(p) lastFov = p.fov end)
  bus:Freeze(5)
  bus:Publish("config:changed", { fov = 100 })
  __VT.advance(0.01)
  bus:Publish("config:changed", { fov = 200 })
  bus:Resume(5)
  H.eq(lastFov, 200, "event หลังสุด (timestamp ท้าย) ต้องชนะ")
end)

H.test("bus: DropQueue — rollback กลับรุ่นเก่า ทิ้งคิวทั้งหมดไม่ replay", function()
  local bus = newBus()
  bus:Declare("config:changed", "replay")
  local got = 0
  bus:On("config:changed", function() got = got + 1 end)
  bus:Freeze(9)
  bus:Publish("config:changed", {})
  bus:Publish("config:changed", {})
  local dropped = bus:DropQueue()
  H.eq(dropped, 2, "ทิ้ง 2 ตัว")
  H.eq(got, 0, "ไม่มีอะไรถูก replay (รุ่นเก่า re-derive เอง)")
  H.eq(bus:Stats().frozen, false, "เลิก freeze แล้ว")
end)

H.test("bus: metadata ของ event ในคิวครบ 4 ช่อง (generation/timestamp/type/replayable)", function()
  local bus = newBus()
  bus:Declare("config:changed", "replay")
  bus:Freeze(7)
  bus:Publish("config:changed", { fov = 1 })
  local q = bus:Queue()
  H.eq(#q, 1, "คิว 1 ตัว")
  H.eq(q[1].generation, 0, "event ปล่อยก่อน freeze ใช้ generation ปัจจุบัน (0)")
  H.eq(q[1].type, "config:changed", "type ครบ")
  H.eq(q[1].replayable, "replay", "replayable ครบ")
  H.ok(type(q[1].timestamp) == "number", "timestamp ครบ")
  bus:Resume(7)
end)

-- ==== CR-REPLAY-001: คิวข้าม generation (Export/Import + payload) ============
-- ตามคำตัดสินเจ้าของโปรเจกต์ 1 ต.ค. 2026 (ตัวเลือก ข): event ที่ค้างในคิวระหว่าง
-- freeze ต้อง replay ข้าม generation ตาม Replay Policy §3.6 ดั้งเดิม
-- (Transient DROP / State-Config REPLAY LWW / Idempotent REPLAY /
--  สถานะโลกจริง DROP + re-derive จาก Adapter)

H.test("CR-REPLAY-001: Queue() คืน payload ครบ 5 ช่อง (รากปัญหาเดิมที่ทำให้ replay ข้ามรุ่นไม่ได้)", function()
  local bus = newBus()
  bus:Declare("config:changed", "replay")
  bus:Freeze(7)
  bus:Publish("config:changed", { fov = 42 })
  local q = bus:Queue()
  H.eq(#q, 1, "คิว 1 ตัว")
  H.eq(q[1].payload.fov, 42, "payload ต้องคืนด้วย (เดิมไม่คืน = รากปัญหาของ CR)")
  H.eq(q[1].type, "config:changed", "type ครบ")
  H.eq(q[1].replayable, "replay", "replayable ครบ")
  H.eq(q[1].generation, 0, "generation ครบ")
  H.ok(type(q[1].timestamp) == "number", "timestamp ครบ")
  bus:Resume(7)
end)

H.test("CR-REPLAY-001: ExportQueue — deep clone พร้อม payload + ไม่ล้างคิวเดิม", function()
  local bus = newBus()
  bus:Declare("config:changed", "replay")
  local got = 0
  bus:On("config:changed", function(p) got = p.fov end)
  bus:Freeze(3)
  bus:Publish("config:changed", { fov = 10 })
  local exported = bus:ExportQueue()
  H.eq(#exported, 1, "export ได้ 1 ตัว")
  H.eq(exported[1].payload.fov, 10, "payload มาครบ")
  exported[1].payload.fov = 999 -- แก้สำเนา
  H.eq(bus:Stats().queued, 1, "คิวเดิมไม่ถูกล้าง (bus รุ่นเก่าจะตายตาม TEARDOWN เอง)")
  bus:Resume(3)
  H.eq(got, 10, "deep clone จริง: การแก้สำเนาไม่กระทบคิวจริง")
end)

H.test("CR-REPLAY-001: ImportQueue — ใช้ได้เฉพาะขณะ frozen (replay ตอน Resume เท่านั้น)", function()
  local busA, busB = newBus(), newBus()
  busA:Declare("config:changed", "replay")
  busA:Freeze(1)
  busA:Publish("config:changed", {})
  local carried = busA:ExportQueue()
  local ok, err = pcall(busB.ImportQueue, busB, carried)
  H.ok(not ok, "ไม่ frozen ต้อง error — ห้าม event ไปจอดคิวโดยไม่มีทางออก")
  H.ok(tostring(err):find("frozen") ~= nil, "error บอกเหตุผลชัด")
end)

H.test("CR-REPLAY-001: ข้าม generation — Transient DROP / State REPLAY (LWW) / Idempotent REPLAY", function()
  local busA = newBus() -- รุ่นเก่า
  busA:Declare("world:tick", "drop")
  busA:Declare("config:changed", "replay")
  busA:Declare("sync:refresh", "idempotent")
  busA:Freeze(4)
  busA:Publish("world:tick", { n = 1 })          -- Transient → ต้อง DROP
  busA:Publish("config:changed", { fov = 100 })  -- State
  busA:Publish("config:changed", { fov = 200 })  -- State ท้ายสุด = LWW
  busA:Publish("sync:refresh", { id = "x" })     -- Idempotent → REPLAY
  local carried = busA:ExportQueue()
  H.eq(#carried, 4, "คิวรุ่นเก่า 4 ตัว ข้าม generation ได้ครบ")

  local busB = newBus() -- รุ่นใหม่: Declare ชุดเดียวกัน
  busB:Declare("world:tick", "drop")
  busB:Declare("config:changed", "replay")
  busB:Declare("sync:refresh", "idempotent")
  local ticks, lastFov, syncs = 0, nil, 0
  busB:On("world:tick", function() ticks = ticks + 1 end)
  busB:On("config:changed", function(p) lastFov = p.fov end)
  busB:On("sync:refresh", function() syncs = syncs + 1 end)
  busB:Freeze(4)
  local imp = busB:ImportQueue(carried)
  H.eq(imp.total, 4, "ดูทั้งคิว 4 ตัว")
  H.eq(imp.accepted, 3, "รับ 3 (state x2 + idempotent)")
  H.eq(imp.dropped, 1, "DROP transient 1 ตัว")
  local result = busB:Resume(4)
  H.eq(ticks, 0, "Transient ไม่ถึงมือรุ่นใหม่ (สถานะโลกจริง re-derive จาก Adapter)")
  H.eq(lastFov, 200, "State replay เรียงเวลา → last-write-wins")
  H.eq(syncs, 1, "Idempotent replay ครบ")
  H.eq(result.replayed, 3, "resume replay 3 ตัวรวมของข้ามรุ่น")
end)

H.test("CR-REPLAY-001: policy ตัดสินใหม่ตาม Declare ของรุ่นปลายทาง (รุ่นใหม่เปลี่ยนใจได้)", function()
  local busA = newBus()
  busA:Declare("feature:x", "replay") -- รุ่นเก่าถือว่าเป็น state
  busA:Freeze(1)
  busA:Publish("feature:x", { v = 1 })
  local carried = busA:ExportQueue()

  local busB = newBus()
  busB:Declare("feature:x", "drop") -- รุ่นใหม่ถือว่า transient แล้ว
  busB:Freeze(1)
  local imp = busB:ImportQueue(carried)
  H.eq(imp.accepted, 0, "รุ่นปลายทางเป็นเจ้าของคำตอบ — drop ตาม Declare ของตัวเอง")
  H.eq(imp.dropped, 1, "ตัวที่รุ่นเก่า stamp เป็น replay ก็ต้อง drop ตามรุ่นใหม่")
  busB:Resume(1)
end)

H.test("CR-REPLAY-001: ชนิดที่รุ่นปลายทางไม่ Declare = drop (safe default) + นับ undeclared", function()
  local busA = newBus()
  busA:Declare("legacy:only-old", "replay")
  busA:Freeze(1)
  busA:Publish("legacy:only-old", { v = 1 })
  local carried = busA:ExportQueue()

  local busB = newBus() -- ไม่ Declare ชนิดนี้ (event เลิกใช้แล้วในรุ่นใหม่)
  busB:Freeze(1)
  local imp = busB:ImportQueue(carried)
  H.eq(imp.dropped, 1, "ไม่ Declare = drop (กัน event หลุดโลกข้ามรุ่น)")
  H.eq(busB:Stats().undeclared, 1, "นับ undeclared ให้ Diagnostics จับ event ตายได้")
  busB:Resume(1)
end)

H.test("CR-REPLAY-001: payload ไม่ replay ได้ (ฝัง function) = drop + นับ importDropped", function()
  local busA = newBus()
  busA:Declare("bad:cb", "replay")
  busA:Freeze(1)
  busA:Publish("bad:cb", { fn = function() end }) -- ละเมิดสัญญา payload ตารางธรรมดา
  local carried = busA:ExportQueue()

  local busB = newBus()
  busB:Declare("bad:cb", "replay")
  busB:Freeze(1)
  local imp = busB:ImportQueue(carried)
  H.eq(imp.accepted, 0, "ห้ามผูกของมีชีวิตข้ามรุ่น — drop ก่อนเข้าคิว")
  H.eq(busB:Stats().importDropped, 1, "นับ importDropped ให้เห็นใน Diagnostics (§8.4)")
  busB:Resume(1)
end)

H.test("CR-REPLAY-001: event ข้ามรุ่นแทรกก่อนคิวที่เกิดระหว่าง MIGRATE (เรียงเวลาจริง)", function()
  local busA = newBus()
  busA:Declare("config:changed", "replay")
  busA:Freeze(2)
  busA:Publish("config:changed", { seq = "carried-old" })
  local carried = busA:ExportQueue()

  local busB = newBus()
  busB:Declare("config:changed", "replay")
  local order = {}
  busB:On("config:changed", function(p) order[#order + 1] = p.seq end)
  busB:Freeze(2)
  busB:Publish("config:changed", { seq = "migrate-new" }) -- เกิดระหว่าง MIGRATE บน bus ใหม่
  busB:ImportQueue(carried)
  busB:Resume(2)
  H.eq(table.concat(order, ","), "carried-old,migrate-new",
    "เกิดก่อน = replay ก่อน (timestamp เก่ากว่า แม้คนละ bus)")
end)

H.test("CR-REPLAY-001: metadata ข้ามรุ่นเก็บ generation/timestamp ต้นทาง + Stats นับ imported", function()
  local busA = newBus()
  busA:Declare("config:changed", "replay")
  busA:Freeze(5)
  busA:Publish("config:changed", { v = 1 })
  local carried = busA:ExportQueue()

  local busB = newBus()
  busB:Declare("config:changed", "replay")
  local meta
  busB:On("config:changed", function(_, evt) meta = evt end)
  busB:Freeze(9)
  busB:ImportQueue(carried)
  busB:Resume(9)
  H.eq(meta.generation, 0, "เก็บ generation ต้นทางตามจริง (เกิดสมัยรุ่นเก่า — ร่องรอยตรวจย้อนได้)")
  H.ok(type(meta.timestamp) == "number", "timestamp ต้นทางยังอยู่ครบ")
  H.eq(busB:Stats().generation, 9, "bus ปลายทางอยู่ generation 9 แล้ว")
  H.eq(busB:Stats().imported, 1, "Stats นับ imported ให้ Diagnostics (§8.4)")
end)

H.test("CR-REPLAY-001: Shutdown ไม่ล้างคิว — event ต้องรอดข้าม generation (export หลัง teardown)", function()
  local bus = newBus()
  bus:Declare("config:saved", "idempotent")
  bus:Freeze(2)
  bus:Publish("config:saved", { at = 1 })
  bus:Shutdown() -- TEARDOWN ของ node EventBus (ถูกทำลายเป็นลำดับสุดท้าย)
  local carried = bus:ExportQueue()
  H.eq(#carried, 1, "คิวรอดผ่าน Shutdown ให้ orchestrator export ทันหลัง teardown จบ")
  H.eq(carried[1].payload.at, 1, "payload ยังครบ (Idempotent ที่ hook ปล่อยตอนถอดระบบก็ต้องข้ามรุ่นได้)")
  H.eq(bus:Stats().subscribers, 0, "subscriber ถูกถอดครบตามสัญญาเดิมของ Shutdown")
end)

-- ==== สถิติ/ปิด ================================================================

H.test("bus: Stats นับ subscribers/published/perSec ครบ", function()
  local bus = newBus()
  bus:Declare("a:x", "drop")
  bus:On("a:x", function() end)
  bus:On("a:x", function() end)
  bus:Publish("a:x", {})
  local s = bus:Stats()
  H.eq(s.subscribers, 2, "subscribers=2")
  H.eq(s.published, 1, "published=1")
  H.eq(s.perSec, 1, "perSec=1 (เพิ่ง publish ภายใน 1 วิ)")
  H.eq(s.declared, 1, "declared=1")
end)

H.test("bus: Shutdown ถอดทุก subscriber", function()
  local bus = newBus()
  bus:Declare("a:y", "drop")
  bus:On("a:y", function() end)
  bus:Shutdown()
  H.eq(bus:Stats().subscribers, 0, "เหลือ 0")
end)
