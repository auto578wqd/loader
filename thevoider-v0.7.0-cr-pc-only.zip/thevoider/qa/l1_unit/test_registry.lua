-- L1: Resource Registry 4 ชนิด (§3.2 ข้อ 2, §3.4) — Spawn/Connect/NewRender/Temp + orphan=0
local H = PKG_harness
local Registry = PKG_registry
local Boundary = PKG_boundary

local function newRegistry()
  return Registry.new({
    task = task,
    drawing = Drawing,
    instance = Instance,
    clock = VTNow,
    debug = true,
  })
end

local function newBoundary()
  return Boundary.new({ clock = VTNow })
end

-- ==== Tasks ================================================================

H.test("registry: Spawn one-shot รันจริงแล้ว deregister อัตโนมัติ (ไม่กลายเป็น orphan)", function()
  local reg = newRegistry()
  local ran = false
  reg:Scope("M1", function()
    reg:Spawn("oneshot", function() ran = true end)
  end)
  H.ok(ran, "task ต้องรันทันที")
  local ok, snap = reg:VerifyZero("M1")
  H.ok(ok, "one-shot จบแล้วต้องไม่ค้างใน registry (tasks=" .. snap.tasks .. ")")
end)

H.test("registry: Spawn loop + ctx.ShouldRun + Cancel → ออกสะอาด orphan=0", function()
  local reg = newRegistry()
  local iterations = 0
  local h
  reg:Scope("M2", function()
    h = reg:Spawn("loop", function(ctx)
      while ctx.ShouldRun() do
        iterations = iterations + 1
        task.wait(0.1)
      end
    end)
  end)
  H.eq(reg:Snapshot("M2").tasks, 1, "ระหว่างรันต้องนับ 1")
  __VT.advance(0.35)
  H.ok(iterations >= 3, "loop ต้องเดิน >= 3 รอบ (ได้ " .. iterations .. ")")
  h.Cancel()
  __VT.advance(0.05)
  local ok, snap = reg:VerifyZero("M2")
  H.ok(ok, "หลัง Cancel ต้อง orphan=0 (tasks=" .. snap.tasks .. ")")
end)

H.test("registry: loop พังกลางทาง → boundary จับ + thread จบ + auto-deregister (ไม่ใช่ orphan ผี)", function()
  local reg = newRegistry()
  local bnd = newBoundary()
  reg:SetBoundary(bnd)
  reg:Scope("M3", function()
    reg:Spawn("crashy", function(ctx)
      while ctx.ShouldRun() do
        task.wait(0.1)
        error("boom")
      end
    end)
  end)
  __VT.advance(0.2)
  H.ok(bnd:Count("M3") >= 1, "error ต้องถูกจับ (count=" .. bnd:Count("M3") .. ")")
  local ok, snap = reg:VerifyZero("M3")
  H.ok(ok, "thread ตายต้อง deregister อัตโนมัติ (tasks=" .. snap.tasks .. ")")
end)

H.test("registry: Scope ซ้อนกันได้ + คืน owner เดิมหลังจบ + Owner() อ่านได้", function()
  local reg = newRegistry()
  local inner
  reg:Scope("Outer", function()
    H.eq(reg:Owner(), "Outer")
    reg:Scope("Inner", function()
      inner = reg:Owner()
    end)
    H.eq(reg:Owner(), "Outer", "จบ inner ต้องคืน outer")
  end)
  H.eq(inner, "Inner")
  H.ok(reg:Owner() == nil, "จบทั้งหมดต้องเป็น nil")
end)

-- ==== Connections ===========================================================

H.test("registry: Connect รับ event / error ใน handler โดนจับ / Release แล้วเงียบ", function()
  local reg = newRegistry()
  local bnd = newBoundary()
  reg:SetBoundary(bnd)
  local sig = __newSignal("Test")
  local got = {}

  reg:Scope("M4", function()
    reg:Connect(sig, function(v) table.insert(got, v) end)
  end)
  sig:Fire(1)
  sig:Fire(2)
  H.eq(#got, 2)

  -- handler ที่พัง: ต้องไม่ลามไป handler อื่น + boundary จับได้
  reg:Scope("M4", function()
    reg:Connect(sig, function() error("handler boom") end)
  end)
  sig:Fire(3)
  H.eq(#got, 3, "handler ปกติยังต้องทำงานหลัง handler อื่นพัง")
  H.ok(bnd:Count("M4") >= 1, "error ของ handler ต้องถูกนับที่ M4")

  reg:Release("M4")
  sig:Fire(4)
  H.eq(#got, 3, "หลัง Release ต้องไม่รับ event อีก")
  H.ok(reg:VerifyZero("M4"), "orphan=0 หลัง Release")
end)

-- ==== Render objects ========================================================

H.test("registry: NewRender('Line') สร้าง + apply props + Release เรียก Remove จริง", function()
  local reg = newRegistry()
  local h
  reg:Scope("M5", function()
    h = reg:NewRender("Line", { Thickness = 2, Visible = true })
  end)
  H.ok(h ~= nil and h.obj ~= nil)
  H.eq(h.obj.Thickness, 2)
  H.eq(h.obj.Visible, true)
  H.eq(reg:Snapshot("M5").renders, 1)
  h.Release()
  H.ok(h.obj.__removed, "Drawing ต้องถูก :Remove()")
  H.ok(reg:VerifyZero("M5"))
end)

H.test("registry: NewRender('Instance') — Instance.new + Props + Release → Destroy", function()
  local reg = newRegistry()
  local h
  reg:Scope("M6", function()
    h = reg:NewRender("Instance", {
      Class = "Part",
      Props = { Anchored = true, Size = "big" },
    })
  end)
  H.ok(h ~= nil and h.obj ~= nil)
  H.eq(h.obj.ClassName, "Part")
  H.eq(h.obj.Anchored, true)
  H.eq(h.obj.Size, "big")
  h.Release()
  H.ok(h.obj.__destroyed, "Instance ต้องถูก :Destroy()")
  H.ok(reg:VerifyZero("M6"))
end)

H.test("registry: NewRender เมื่อไม่มี Drawing library → nil + reason (graceful ไม่ throw)", function()
  local saved = Drawing
  Drawing = nil -- จำลอง executor ที่ไม่มี Drawing (DRAWING capability ปิด)
  local reg = Registry.new({ task = task, instance = Instance, clock = VTNow, debug = false })
  local h, why
  reg:Scope("M7", function()
    h, why = reg:NewRender("Line", {})
  end)
  Drawing = saved
  H.ok(h == nil, "ต้องคืน nil")
  H.ok(type(why) == "string" and #why > 0, "ต้องบอกเหตุผล: " .. tostring(why))
  H.ok(reg:VerifyZero("M7"), "ไม่มีอะไรค้าง")
end)

-- ==== Temporary resources ===================================================

H.test("registry: Temp — function disposer / auto-Destroy / auto-Disconnect ครบสามแบบ", function()
  local reg = newRegistry()
  local disposed = false
  local obj = { Name = "t1", Destroy = function(self) self.destroyed = true end }
  local connLike = __newSignal("TempSig"):Connect(function() end)

  local h1, h2, h3
  reg:Scope("M8", function()
    h1 = reg:Temp({ marker = true }, function(o) disposed = true end)
    h2 = reg:Temp(obj)
    h3 = reg:Temp(connLike)
  end)
  H.eq(reg:Snapshot("M8").temps, 3)
  h1.Release()
  H.ok(disposed, "function disposer ต้องถูกเรียก")
  h2.Release()
  H.ok(obj.destroyed, "auto :Destroy ต้องทำงาน")
  h3.Release()
  H.ok(reg:VerifyZero("M8"), "orphan=0 หลังปล่อยครบ")
end)

-- ==== ตรวจนับ / orphan ======================================================

H.test("registry: leak detection — สร้างแล้วไม่ปล่อย → VerifyZero=false + List บอกตัวที่ค้าง", function()
  local reg = newRegistry()
  reg:Scope("Leaky", function()
    reg:Spawn("leak", function(ctx)
      while ctx.ShouldRun() do task.wait(1) end
    end)
  end)
  local ok, snap = reg:VerifyZero("Leaky")
  H.ok(not ok, "ต้องตรวจจับ leak ได้")
  H.eq(snap.tasks, 1)
  local list = reg:List("Leaky")
  H.ok(#list == 1 and list[1]:find("leak", 1, true), "List ต้องระบุตัวที่ค้าง: " .. table.concat(list, ","))
  reg:Release("Leaky")
  H.ok(reg:VerifyZero("Leaky"), "Release แล้วต้องสะอาด")
end)

H.test("registry: Release(owner) คืนครบ 4 ชนิดในครั้งเดียว + นับจำนวนถูก", function()
  local reg = newRegistry()
  local sig = __newSignal("S")
  reg:Scope("All4", function()
    reg:Spawn("t1", function(ctx) while ctx.ShouldRun() do task.wait(1) end end)
    reg:Connect(sig, function() end)
    reg:NewRender("Circle", {})
    reg:Temp({ marker = 1 }, function() end)
  end)
  local snap = reg:Snapshot("All4")
  H.eq(snap.total, 4)
  H.eq(snap.tasks, 1)
  H.eq(snap.connections, 1)
  H.eq(snap.renders, 1)
  H.eq(snap.temps, 1)
  local rel = reg:Release("All4")
  H.eq(rel.total, 4, "ต้องปล่อยครบ 4 (ได้ " .. rel.total .. ")")
  H.ok(reg:VerifyZero("All4"))
end)

H.test("registry: ModuleTotals แยกของ Runtime.* ออก (ใช้ตอน hot update VERIFY §3.6 ขั้น 8)", function()
  local reg = newRegistry()
  reg:Scope("Runtime.Watchdog", function()
    reg:Spawn("monitor", function(ctx) while ctx.ShouldRun() do task.wait(1) end end)
  end)
  reg:Scope("VoidAim", function()
    reg:Spawn("aim", function(ctx) while ctx.ShouldRun() do task.wait(1) end end)
  end)
  local mt = reg:ModuleTotals()
  H.eq(mt.total, 1, "นับเฉพาะของโมดูล (ได้ " .. mt.total .. ")")
  H.eq(mt.owners["VoidAim"], 1)
  reg:Release("VoidAim")
  reg:Release("Runtime.Watchdog")
  H.eq(reg:ModuleTotals().total, 0)
end)

H.test("registry: ShouldRun/Beat ส่ง heartbeat ให้ watchdog อัตโนมัติ (loop เดิน = ยังหายใจ)", function()
  local reg = newRegistry()
  local beats = 0
  local fakeWd = {
    Beat = function(_, owner)
      if owner == "M9" then beats = beats + 1 end
    end,
  }
  reg:SetWatchdog(fakeWd)
  reg:Scope("M9", function()
    local h = reg:Spawn("beatloop", function(ctx)
      while ctx.ShouldRun() do task.wait(0.05) end
    end)
    __VT.advance(0.2)
    H.ok(beats >= 3, "beats ต้อง >= 3 (ได้ " .. beats .. ")")
    h.Cancel()
  end)
end)
