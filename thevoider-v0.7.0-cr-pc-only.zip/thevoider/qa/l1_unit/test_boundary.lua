-- L1: Error Boundary (§3.2 ข้อ 3) — จับ error รายโมดูล ไม่ลาม + stack + counter
local H = PKG_harness
local Boundary = PKG_boundary

H.test("boundary: Guard ผ่าน → คืนค่าผลลัพธ์ครบ", function()
  local b = Boundary.new({})
  local ok, x, y = b:Guard("X", function(a, c)
    return a + c, "s"
  end, 1, 2)
  H.ok(ok)
  H.eq(x, 3)
  H.eq(y, "s")
end)

H.test("boundary: Guard พัง → false + record(owner/err/stack/time) + counter ต่อโมดูล", function()
  local b = Boundary.new({ clock = function() return 123 end })
  local seen = {}
  b:On(function(owner, rec)
    seen.owner = owner
    seen.rec = rec
  end)
  local ok, rec = b:Guard("VoidESP", function()
    error("esp boom", 0)
  end)
  H.ok(not ok)
  H.eq(rec.owner, "VoidESP")
  H.eq(rec.err, "esp boom")
  H.ok(type(rec.stack) == "string" and #rec.stack > 0, "ต้องมี stack trace จริง")
  H.eq(rec.time, 123)
  H.eq(b:Count("VoidESP"), 1)
  H.eq(b:Count("VoidAim"), 0, "โมดูลอื่นต้องไม่โดนนับ")
  H.eq(seen.owner, "VoidESP", "subscriber ต้องได้รับแจ้ง")
  H.eq(seen.rec.err, "esp boom")
end)

H.test("boundary: นับสะสมต่อโมดูลแยกกัน + Reset รายตัว", function()
  local b = Boundary.new({})
  b:Guard("A", function() error("1") end)
  b:Guard("A", function() error("2") end)
  b:Guard("B", function() error("3") end)
  H.eq(b:Count("A"), 2)
  H.eq(b:Count("B"), 1)
  b:Reset("A")
  H.eq(b:Count("A"), 0)
  H.eq(b:Count("B"), 1, "Reset A ไม่กระทบ B")
end)

H.test("boundary: listener พังเอง → boundary ไม่ล่ม นับ error ได้ตามปกติ", function()
  local b = Boundary.new({})
  b:On(function() error("listener boom") end)
  local ok = b:Guard("M", function() return true end)
  H.ok(ok, "happy path ไม่กระทบ")
  local ok2 = b:Guard("M", function() error("x") end)
  H.ok(not ok2)
  H.eq(b:Count("M"), 1, "error ยังถูกนับแม้ listener พัง")
end)

H.test("boundary: records เก็บเป็น log ล่าสุด (Diagnostics ใช้ export §8.4)", function()
  local b = Boundary.new({ maxRecords = 3 })
  for i = 1, 5 do
    b:Guard("M", function() error("e" .. i, 0) end)
  end
  H.eq(#b:Records(), 3, "ring buffer ตัดเก่าเหลือ maxRecords")
  H.eq(b:Records()[#b:Records()].err, "e5")
end)
