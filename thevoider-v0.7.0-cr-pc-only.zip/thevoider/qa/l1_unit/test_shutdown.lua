-- L1: Shutdown Manager (§3.2 ข้อ 5 + §3.10) — กลับลำดับเป๊ะ + ห้าม force-clean
local H = PKG_harness
local Registry = PKG_registry
local Boundary = PKG_boundary
local Shutdown = PKG_shutdown

local function setup()
  local reg = Registry.new({ task = task, drawing = Drawing, instance = Instance, clock = VTNow })
  local bnd = Boundary.new({ clock = VTNow })
  reg:SetBoundary(bnd)
  local sd = Shutdown.new({})
  sd:SetBoundary(bnd)
  sd:SetRegistry(reg)
  return reg, bnd, sd
end

H.test("shutdown: ลำดับ Disable ทั้งหมดก่อน แล้ว Destroy ทั้งหมด (กลับลำดับ init เป๊ะ)", function()
  local reg, bnd, sd = setup()
  local calls = {}
  sd:Configure({ "Foundation", "Adapter", "VoidAim", "Hub" })
  local names = { "Foundation", "Adapter", "VoidAim", "Hub" }
  for _, n in ipairs(names) do
    sd:Register(n, {
      Disable = function() table.insert(calls, "Disable:" .. n) end,
      Destroy = function() table.insert(calls, "Destroy:" .. n) end,
    })
  end
  local report = sd:Run()
  H.eq(
    table.concat(calls, ","),
    "Disable:Hub,Disable:VoidAim,Disable:Adapter,Disable:Foundation,Destroy:Hub,Destroy:VoidAim,Destroy:Adapter,Destroy:Foundation",
    "ลำดับต้องกลับด้านเป๊ะ + Disable ครบก่อน Destroy"
  )
  H.ok(report.ok)
  H.eq(report.order[1], "Hub", "order ใน report = กลับลำดับ init")
end)

H.test("shutdown: Destroy ปล่อยทรัพยากรไม่ครบ → report orphan>0 + ok=false (ห้าม force-clean §3.6 F1)", function()
  local reg, bnd, sd = setup()
  sd:Configure({ "Runtime", "Leaky" })
  sd:Register("Leaky", {
    Disable = function() end,
    Destroy = function()
      -- จงใจไม่คืนอะไรเลย (จำลองโมดูลที่มีบั๊ก leak)
    end,
  })
  reg:Scope("Leaky", function()
    reg:Spawn("stuck", function(ctx)
      while ctx.ShouldRun() do task.wait(1) end
    end)
  end)
  local report = sd:Run()
  H.ok(not report.ok, "orphan > 0 = report.ok ต้องเป็น false")
  H.eq(report.orphans, 1)
  H.eq(reg:Snapshot("Leaky").tasks, 1, "ห้าม force-clean เงียบ ๆ — ของต้องยังค้างให้ผู้จัดการอัปเดตเห็นแล้ว ABORT")
  reg:Release("Leaky") -- เคลียร์เพื่อไม่หลุดรอบของเทสถัดไป
end)

H.test("shutdown: hook พังกลางทาง → boundary จับ + โมดูลที่เหลือยังถูกปิดครบ (ไม่ลาม)", function()
  local reg, bnd, sd = setup()
  local destroyed = {}
  sd:Configure({ "A", "B", "C" })
  sd:Register("A", { Destroy = function() destroyed.A = true end })
  sd:Register("B", {
    Destroy = function() error("destroy B พัง") end,
  })
  sd:Register("C", { Destroy = function() destroyed.C = true end })
  local report = sd:Run()
  H.ok(destroyed.A and destroyed.C, "A กับ C ต้องถูก Destroy ครบแม้ B พัง")
  H.ok(bnd:Count("B") >= 1, "error ของ B ต้องถูกจับที่ B")
  H.ok(report.ok, "orphan ยัง 0 (B ไม่มีทรัพยากรค้าง)")
end)

H.test("shutdown: assertZero (debug build) → orphan > 0 ต้อง error ทันที (assert อัตโนมัติ §3.4)", function()
  local reg, bnd, sd = setup()
  sd:Configure({ "Leaky2" })
  sd:Register("Leaky2", { Destroy = function() end })
  reg:Scope("Leaky2", function()
    reg:Spawn("stuck2", function(ctx)
      while ctx.ShouldRun() do task.wait(1) end
    end)
  end)
  local ok, err = pcall(function()
    sd:Run({ assertZero = true })
  end)
  H.ok(not ok, "ต้อง error")
  H.ok(tostring(err):find("ORPHAN", 1, true), "ข้อความต้องระบุ ORPHAN: " .. tostring(err))
  reg:Release("Leaky2")
end)

H.test("shutdown: node ที่ยังไม่มี hook (ยังไม่พัฒนา) = ข้ามไปได้ ไม่ถือเป็นความล้มเหลว", function()
  local reg, bnd, sd = setup()
  sd:Configure({ "EventBus", "VoidAim", "Hub" }) -- ยังไม่ Register hook ใด
  local report = sd:Run()
  H.ok(report.ok)
  H.eq(#report.rows, 0, "ไม่มี node ที่มี hook = ไม่มีแถวตรวจ")
  H.eq(#report.order, 3, "แต่ลำดับยังบันทึกครบ")
end)
