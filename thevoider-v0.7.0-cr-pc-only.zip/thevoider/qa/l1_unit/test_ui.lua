-- ============================================================================
-- The Voider — qa/l1_unit/test_ui.lua
-- L1 ของเฟส 1 UI Framework (§5.4 + §8.1–8.4 + DoD เฟส 1)
--
-- ครอบ: ThemeEngine (palette §8.1 / accent 4 / ปุ่มมาตรฐาน 44px) · Backend
-- (root/degraded/Fade/drag) · Hub (โครง §8.3/แท็บ/20 รอบ orphan/persistence/
-- พาเนล Diagnostics) · HUD (FPS/uptime/timer "ui"/ไดอักนอสติกย่อ/dot)
-- · Notification (คิว/TTL/สีตาม level/แปลใหม่) · PC-only guard (CR-PC-ONLY
-- 1 ต.ค. 2026: อุปกรณ์ทัชอย่างเดียว = เลย์เอาต์ desktop เดิม + ไม่มี TVMobile
-- + graph ไม่มี MobileLayout) · i18n key coverage 100% ทั้งสองภาษา (DoD)
-- ============================================================================

local H = PKG_harness
local RuntimeLib = PKG_init
local FoundationLib = PKG_foundation
local AdapterLib = PKG_adapter
local UiLib = PKG_ui
local ThemeLib = PKG_ui_theme
local BackendLib = PKG_ui_backend

-- ---- helper: สร้าง stack เต็ม (R + F + A + UI) แยก root ต่อเคส -----------------
--
-- opts.persistConfig = true → ไม่ลบไฟล์ config (ใช้ทดสอบว่า stack ใหม่
-- กู้ค่าที่ stack เก่าบันทึกไว้ — §3.7) ปกติ: ลบทุกครั้งเพื่อแยกเคส

local CONFIG_FILE = "thevoider/config.json"

local function bootStack(opts)
  opts = opts or {}
  __GAME.reset()
  if opts.touch ~= nil then __GAME.uis.TouchEnabled = opts.touch end
  if opts.keyboard ~= nil then __GAME.uis.KeyboardEnabled = opts.keyboard end
  if not opts.persistConfig then delfile(CONFIG_FILE) end
  __HUI = nil -- root ใหม่ต่อ stack

  local R = RuntimeLib.new({
    clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true,
  })
  R:Bootstrap()
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  local A = AdapterLib.new({ runtime = R, foundation = F, env = { game = game, workspace = workspace } })
  A:Bootstrap()
  local U = UiLib.new({ runtime = R, foundation = F, version = "0.6.0-test", clock = VTNow })
  U:Bootstrap()
  return R, F, A, U
end

local function findUI(U, name)
  return __UI.find(U.Backend.root, name)
end

local function fireDrag(rootHandle, gripHandle, dx, dy)
  gripHandle.obj.InputBegan:Fire({
    UserInputType = "MouseButton1", Input = { Delta = { X = 0, Y = 0 } },
  })
  rootHandle.obj.InputChanged:Fire({
    UserInputType = "MouseButton1", Input = { Delta = { X = dx, Y = dy } },
  })
  gripHandle.obj.InputEnded:Fire({ UserInputType = "MouseButton1" })
end

local function rgbEq(got, want, msg)
  H.ok(got and got.R ~= nil, (msg or "") .. " — ไม่ใช่สี")
  H.almost(got.R, want[1] / 255, 0.001, msg .. " R")
  H.almost(got.G, want[2] / 255, 0.001, msg .. " G")
  H.almost(got.B, want[3] / 255, 0.001, msg .. " B")
end

-- ==== ThemeEngine (§8.1) =======================================================

H.test("UI/theme: palette §8.1 ตรงเป๊ะ (6 สีหลัก)", function()
  local t = ThemeLib.new():Get()
  rgbEq(t.bg, { 0x0A, 0x0A, 0x14 }, "bg ดำหลุมดำ")
  rgbEq(t.card, { 0x12, 0x12, 0x1F }, "card ดำน้ำเงินเข้ม")
  rgbEq(t.border, { 0x7C, 0x3A, 0xED }, "border ม่วงนีออน (default accent)")
  rgbEq(t.hilite, { 0x22, 0xD3, 0xEE }, "hilite ฟ้านีออน")
  rgbEq(t.text, { 0xE5, 0xE7, 0xEB }, "text ขาวนวล")
  rgbEq(t.textDim, { 0x9C, 0xA3, 0xAF }, "textDim เทาหม่น")
  rgbEq(t.on, { 0x34, 0xD3, 0x99 }, "on เขียวมรกต")
  rgbEq(t.danger, { 0xF8, 0x71, 0x71 }, "danger แดงหลังคา")
end)

H.test("UI/theme: accent 4 ตัว + เปลี่ยนแล้ว token/ผู้สมัครเห็น (§8.2)", function()
  local th = ThemeLib.new()
  H.eq(#th:ListAccents(), 4, "accent 4 ตัว (ม่วง/ฟ้า/ชมพู/เขียว)")
  H.eq(th:Accent(), "purple", "default = purple")
  local seen = {}
  th:Subscribe(function(name) seen[#seen + 1] = name end)
  H.ok(th:SetAccent("cyan"), "ตั้ง cyan สำเร็จ")
  rgbEq(th:Get().border, { 0x22, 0xD3, 0xEE }, "border เปลี่ยนตาม cyan")
  H.eq(#seen, 1, "ผู้สมัครถูกแจ้ง 1 ครั้ง")
  local ok, err = th:SetAccent("rainbow")
  H.eq(ok, false, "ชื่อไม่รองรับ = ปฏิเสธ")
  H.eq(err.code, "UNSUPPORTED", "ระบุ code ตามสัญญา adapter-style")
  H.eq(#seen, 1, "ปฏิเสธแล้วไม่ปลุกผู้สมัคร")
end)

H.test("UI/theme: layout constants — ปุ่มมาตรฐาน 44px ทั้ง UI (CR-PC-ONLY)", function()
  local th = ThemeLib.new()
  local L = th:Get().layout
  H.ok(L.TOUCH_MIN >= 44, "TOUCH_MIN ≥ 44 (ความสูงปุ่มมาตรฐาน)")
  H.ok(L.TAB_H >= 44, "แท็บสูง ≥ 44")
  H.eq(L.ICON_TAB, nil, "PC-only guard: ไม่มี ICON_TAB ของมือถืออีกต่อไป (CR-PC-ONLY)")
  H.eq(th.TouchSize, nil, "PC-only guard: ไม่มี TouchSize() อีกต่อไป (CR-PC-ONLY)")
  H.eq(th:Get().anim.FAST, 0.15, "animation 0.15 วิ (§8.2)")
end)

-- ==== Backend =================================================================

H.test("UI/backend: root จาก gethui + resource ตกเป็นของ owner ตาม Scope", function()
  __HUI = nil
  local R = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R:Bootstrap()
  local be = BackendLib.new({ runtime = R, clock = VTNow })
  H.ok(be.available, "available เมื่อมี gethui")
  H.eq(be.root, gethui(), "root = gethui()")
  local h
  R.Scope("ProbeOwner", function()
    h = be:Create("Frame", { Name = "X", BackgroundTransparency = 1 })
  end)
  H.ok(h and h.obj, "สร้างได้")
  H.eq(h.obj.Parent, be.root, "Parent = root โดย default")
  H.eq(R.Snapshot("ProbeOwner").renders, 1, "นับเป็น render ของ owner (§3.9 #4)")
  h.Release()
  H.eq(R.Snapshot("ProbeOwner").renders, 0, "Release แล้วเหลือ 0")
end)

H.test("UI/backend: ไม่มี gethui → degraded + แจ้งครั้งเดียว (§3.2 ข้อ 0 pattern)", function()
  local R = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R:Bootstrap()
  local warns = {}
  local realGethui = gethui
  gethui = nil
  __HUI = nil
  local be = BackendLib.new({ runtime = R, logger = function(l, m) warns[#warns + 1] = m end })
  gethui = realGethui
  H.eq(be.available, false, "degraded")
  H.ok(#warns >= 1 and warns[1]:find("gethui") ~= nil, "แจ้งเหตุผลเป็น plain text")
  local h, why = be:Create("Frame", {})
  H.eq(h, nil, "สร้างไม่ได้ใน degraded")
  H.ok(why ~= nil, "คืน reason")
end)

H.test("UI/backend: Fade 0.15 วิ จบเอง (VT) — ไม่มี orphan", function()
  __HUI = nil
  local R = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R:Bootstrap()
  local be = BackendLib.new({ runtime = R, clock = VTNow })
  local h
  R.Scope("Fader", function()
    h = be:Create("Frame", { Name = "F", BackgroundTransparency = 1 })
    be:Fade(h, "BackgroundTransparency", 1, 0.4, 0.15)
  end)
  local base = R.Snapshot("Fader").tasks
  H.ok(base >= 1, "มี task fade จองไว้")
  __VT.advance(0.05)
  H.ok(h.obj.BackgroundTransparency > 0.4 and h.obj.BackgroundTransparency < 1,
    "ค่ากลางทาง (interpolate จริง ไม่กระโดด)")
  __VT.advance(0.2)
  H.almost(h.obj.BackgroundTransparency, 0.4, 0.001, "จบที่ปลายทาง")
  H.eq(R.Snapshot("Fader").tasks, base - 1, "task จบเอง = deregister (ไม่มี orphan)")
end)

H.test("UI/backend: MakeDraggable — เมาส์ + ทัช + onDragEnd", function()
  __HUI = nil
  local R = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R:Bootstrap()
  local be = BackendLib.new({ runtime = R, clock = VTNow })
  local root, grip, ends
  R.Scope("Dragger", function()
    root = be:Create("Frame", {
      Name = "Win", Position = UDim2.new(0.5, 0, 0.5, -40),
    })
    grip = be:Create("Frame", { Name = "Grip" })
    be:MakeDraggable(root, grip, { onDragEnd = function() ends = true end })
  end)
  fireDrag(root, grip, 12, -7)
  local p = root.obj.Position
  H.eq(p.X.Offset, 12, "เลื่อน X ตาม Delta")
  H.eq(p.Y.Offset, -47, "เลื่อน Y ตาม Delta")
  H.eq(ends, true, "onDragEnd ถูกเรียกเมื่อปล่อย")
  -- ทัช
  grip.obj.InputBegan:Fire({ UserInputType = "Touch", Input = { Delta = { X = 0, Y = 0 } } })
  root.obj.InputChanged:Fire({ UserInputType = "Touch", Input = { Delta = { X = 3, Y = 3 } } })
  grip.obj.InputEnded:Fire({ UserInputType = "Touch" })
  H.eq(root.obj.Position.X.Offset, 15, "ทัชลากได้เหมือนเมาส์")
  -- คีย์บอร์ดไม่ถูกนับเป็น drag
  grip.obj.InputBegan:Fire({ UserInputType = "Keyboard", Input = {} })
  root.obj.InputChanged:Fire({ UserInputType = "Keyboard", Input = { Delta = { X = 50, Y = 50 } } })
  H.eq(root.obj.Position.X.Offset, 15, "คีย์บอร์ดไม่ขยับ window")
end)

-- ==== โครง UI ทั้งชุด ==========================================================

H.test("UI/stack: สร้างครบ 3 node + โครงตาม §8.3 + coverage i18n 100% (DoD)", function()
  local R, F, A, U = bootStack()
  H.ok(U.Backend.available, "backend available")
  H.eq(U.Hub:Stats().built, true, "Hub สร้างแล้ว")
  H.eq(U.HUD:Stats().built, true, "HUD สร้างแล้ว")
  H.eq(U.Notify:Stats().built, true, "Notification สร้างแล้ว")
  H.eq(U.Mobile, nil, "PC-only guard: ไม่มี node MobileLayout (CR-PC-ONLY)")

  local hub = findUI(U, "Hub")
  H.ok(hub ~= nil, "มีหน้าต่าง Hub")
  local tabs = {}
  for _, c in ipairs(findUI(U, "Tabs")._children) do
    if c.Name:find("^Tab_") then tabs[#tabs + 1] = c end
  end
  H.eq(#tabs, 9, "แท็บ 8 โมดูล + Setup (§8.3)")
  H.ok(findUI(U, "Search") ~= nil, "มีแถบค้นหา (พื้นที่สงวน P1)")
  H.eq(findUI(U, "Search").TextEditable, false, "ค้นหายังไม่มีพฤติกรรม (§4.5)")
  H.ok(findUI(U, "TVHud") ~= nil, "มี HUD")
  H.ok(findUI(U, "TVNotify") ~= nil, "มี Notification layer")

  -- i18n coverage 100% ทั้งสองภาษา (DoD เฟส 1)
  local cov = F.I18n:Coverage()
  H.eq(cov.complete, true, ("coverage 100%% (missing th=%d en=%d)")
    :format(cov.th.missing, cov.en.missing))
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hub: แท็บสลับ + empty-state โปร่งใสตาม roadmap (§3.9 PENDING)", function()
  local R, F, A, U = bootStack()
  H.ok(U.Hub:SwitchTab("aim"), "สลับไปแท็บ aim")
  H.eq(U.Hub:Stats().tab, "aim", "แท็บปัจจุบัน = aim")
  H.eq(findUI(U, "Content_aim").Visible, true, "เนื้อหา aim เปิด")
  H.eq(findUI(U, "Content_setup").Visible, false, "เนื้อหา setup ปิด")
  local coming = findUI(U, "Content_aim"):FindFirstChild("Coming")
  H.ok(coming.Text:find("เฟส 2") ~= nil, "บอกเฟสตาม roadmap (ภาษาไทย)")
  H.eq(U.Hub:SwitchTab("hop"), true, "hop สลับได้")
  H.ok(findUI(U, "Content_hop"):FindFirstChild("Coming").Text:find("เฟส 4") ~= nil,
    "hop มาเฟส 4")
  H.eq(U.Hub:SwitchTab("nope"), false, "แท็บที่ไม่มี = ปฏิเสธ")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hub DoD: เปิด-ปิด-เปิด 20 รอบ — resource คงที่ orphan 0", function()
  local R, F, A, U = bootStack()
  local base = R.Snapshot("Hub")
  H.ok(base.total > 0, "hub ถือ resource อยู่จริง")
  for i = 1, 20 do
    U.Hub:Toggle()
    local snap = R.Snapshot("Hub")
    H.eq(snap.total, base.total, ("รอบ %d: จำนวน resource คงที่ (toggle ≠ teardown)"):format(i))
  end
  H.eq(U.Hub:Stats().visible, true, "จบ 20 รอบ (ตัวเลขคู่) = เปิด — พร้อมใช้งานต่อ")
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "TEARDOWN สะอาด (รวม UI ทั้ง 4 node)")
end)

H.test("UI/hub: persistence ของผู้ใช้ (§3.7) — open/pos/accent/lang", function()
  local R, F, A, U = bootStack()
  -- ตำแหน่งเริ่มต้นจาก config ที่ยังไม่มี = default
  H.eq(findUI(U, "Hub").Position.Y.Offset, -40, "default pos")
  -- ลากย้าย → บันทึก
  fireDrag(U.Hub.mainH, U.Hub.elems.header, 33, -11)
  local pos = F.Config:Get("ui.hub.pos")
  H.eq(pos.x, 33, "บันทึก pos.x ลง config")
  H.eq(pos.y, -51, "บันทึก pos.y ลง config (-40-11)")
  -- ปิด hub → บันทึก
  U.Hub:SetVisible(false)
  H.eq(F.Config:Get("ui.hub.open"), false, "บันทึก open=false")
  -- stack ใหม่: config กู้กลับมาครบ (ไม่ลบไฟล์ — ทดสอบ §3.7 ต่อเนื่อง)
  local R2, F2, A2, U2 = bootStack({ persistConfig = true })
  H.eq(findUI(U2, "Hub").Position.X.Offset, 33, "stack ใหม่: กู้ pos.x")
  H.eq(U2.Hub:Stats().visible, false, "stack ใหม่: กู้ open=false (เปิด pill แทน)")
  H.ok(findUI(U2, "OpenPill").Visible == true, "pill โผล่เมื่อ hub ถูกย่อไว้")
  U2.Hub:SetVisible(true)
  R.ShutdownAll({ assertZero = true })
  R2.ShutdownAll({ assertZero = true })
end)

H.test("UI/hub: เปลี่ยนภาษา → ป้ายทั้งชุดแปลใหม่ (DoD ห้ามค้างภาษาเดิม)", function()
  local R, F, A, U = bootStack()
  U.Hub:SwitchTab("aim")
  -- กดปุ่ม English ใน Setup (ผ่านปุ่มจริง)
  U.Hub.langBtns.en.obj.MouseButton1Click:Fire()
  H.eq(F.I18n:Lang(), "en", "ภาษาเปลี่ยนเป็น en")
  H.eq(F.Config:Get("i18n.lang"), "en", "บันทึกลง config")
  H.ok(findUI(U, "Search").Text:find("Search") ~= nil, "placeholder เป็นอังกฤษ")
  H.ok(findUI(U, "Content_aim"):FindFirstChild("Coming").Text:find("phase 2") ~= nil,
    "empty-state เป็นอังกฤษ")
  H.ok(U.Hub.elems.statusText.obj.Text:find("ready") ~= nil, "สถานะหัวเป็นอังกฤษ")
  -- กลับไทยผ่านปุ่ม
  U.Hub.langBtns.th.obj.MouseButton1Click:Fire()
  H.ok(findUI(U, "Content_aim"):FindFirstChild("Coming").Text:find("เฟส 2") ~= nil,
    "กลับไทยครบ")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hub: accent ผ่าน Setup — theme + config + fanout ทุก node", function()
  local R, F, A, U = bootStack()
  H.ok(U.Hub:TrySetAccent("cyan"), "ตั้ง cyan สำเร็จ")
  H.eq(U.Theme:Accent(), "cyan", "ThemeEngine เปลี่ยนจริง")
  H.eq(F.Config:Get("ui.accent"), "cyan", "บันทึก config")
  rgbEq(U.Theme:Get().border, { 0x22, 0xD3, 0xEE }, "token ใหม่")
  H.eq(U.Hub.tabBtns.setup.h.obj.BackgroundColor3, U.Theme:Get().accentB,
    "แท็บที่เลือกอยู่ใช้ accent ใหม่ (fanout ถึง hub)")
  -- stack ใหม่: กู้ accent จาก config (ไม่ลบไฟล์)
  local R2, F2, A2, U2 = bootStack({ persistConfig = true })
  H.eq(U2.Theme:Accent(), "cyan", "stack ใหม่ใช้ accent จาก config")
  -- ชื่อไม่รองรับ → ปฏิเสธ + แจ้ง ไม่เดา
  local ok = U2.Hub:TrySetAccent("gold")
  H.eq(ok, false, "ปฏิเสธ")
  H.ok(U2.Hub.feedback.h.obj.Text:find("ไม่รองรับ") ~= nil, "แจ้งในป้าย")
  H.eq(U2.Theme:Accent(), "cyan", "ไม่เปลี่ยนค่าเดิม")
  R.ShutdownAll({ assertZero = true })
  R2.ShutdownAll({ assertZero = true })
end)

H.test("UI/diag panel (§8.4): เปิดจาก Setup + โลโก้ 5 แตะ + ข้อมูลสด + กราฟวาดจริง", function()
  local R, F, A, U = bootStack()
  H.ok(U.Hub:OpenPanel(), "เปิดพาเนลจาก API (ปุ่ม Setup ใช้ path เดียวกัน)")
  H.eq(U.Hub:Stats().panelOpen, true, "สถานะเปิด")
  H.eq(findUI(U, "DiagPanel").Visible, true, "แผงมองเห็น")
  -- ข้อมูลสดจาก Diagnostics
  local frameTxt = U.Hub.pRows.frame.obj.Text
  H.ok(frameTxt:find("FPS") ~= nil, "ส่วนเฟรมมี FPS")
  H.ok(U.Hub.pRows.registry.obj.Text:find("task") ~= nil, "ส่วน Registry นับ 4 ชนิด")
  H.ok(U.Hub.pRows.objects.obj.Text:find("ยังไม่มีโมดูล") ~= nil, "ESP = PENDING โปร่งใส")
  -- มี sample → มีแท่งกราฟจริง
  F.Diag:Sample()
  F.Diag:Sample()
  U.Hub:RefreshPanel()
  H.ok(#U.Hub.graphBars >= 1, "กราฟ memory วาดเป็นแท่งจริง")
  H.ok(#U.Hub.graphBars <= 60, "แท่งถูกจำกัด ≤ 60")
  -- ปิดพาเนล → คืนแท่งทั้งหมด (กัน orphan สะสม)
  local nBars = #U.Hub.graphBars
  local before = R.Snapshot("Hub").renders
  U.Hub:ClosePanel()
  H.eq(R.Snapshot("Hub").renders, before - nBars, "ปิดแล้วคืนแท่งกราฟทุกตัว")
  H.ok(#U.Hub.graphBars == 0, "รายการแท่งถูกล้าง")
  -- โลโก้ 5 แตะ (ช่วงห่าง ≤ 2 วิ)
  local logo = findUI(U, "Logo")
  for i = 1, 5 do
    logo.MouseButton1Click:Fire()
  end
  H.eq(U.Hub:Stats().panelOpen, true, "5 แตะ = เปิดพาเนล (§8.4)")
  -- แตะเกิน 2 วิ = นับใหม่
  U.Hub:ClosePanel()
  __VT.advance(3)
  logo.MouseButton1Click:Fire()
  H.eq(U.Hub:Stats().panelOpen, false, "1 แตะ (หลังพ้น window) ยังไม่เปิด")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/diag panel: Export — มี clipboard คัดลอก / ไม่มี = พิมพ์คอนโซล (§8.4)", function()
  local R, F, A, U = bootStack()
  U.Hub:OpenPanel()
  -- มี clipboard (stub)
  U.Hub:DoExport()
  H.eq(__CLIP ~= nil and #__CLIP > 0, true, "คัดลอกลง clipboard จริง")
  H.ok(U.Hub.feedback.h.obj.Text:find("คัดลอก") ~= nil, "ป้ายยืนยันผลลัพธ์")
  -- ไม่มี clipboard
  local real = setclipboard
  setclipboard = nil
  __CLIP = nil
  local prints0 = #__OUT.prints
  U.Hub:DoExport()
  setclipboard = real
  H.ok(U.Hub.feedback.h.obj.Text:find("คอนโซล") ~= nil, "แจ้งว่าพิมพ์คอนโซลแทน")
  H.ok(#__OUT.prints > prints0, "ข้อความ export ถูกพิมพ์จริง (ไม่เงียบ §3.9 #5)")
  R.ShutdownAll({ assertZero = true })
end)

-- ==== HUD =====================================================================

H.test("UI/hud: FPS + uptime จาก frame task (VT) + ต่อ Diagnostics (§8.4)", function()
  local R, F, A, U = bootStack()
  __VT.advance(1.2)
  local st = U.HUD:Stats()
  H.ok(st.fps and st.fps >= 20 and st.fps <= 50, ("FPS อยู่ในช่วง virtual-time (~33): %s")
    :format(tostring(st.fps)))
  H.almost(st.uptimeSec, 1.2, 0.35, "uptime นับตามเวลาเสมือน")
  local snap = F.Diag:Snapshot()
  H.ok(snap.fps ~= nil, "Diagnostics เห็น FPS จาก provider")
  -- ป้ายถูกอัปเดต (4 ครั้ง/วิ)
  local fpsLabel = findUI(U, "Fps")
  H.ok(fpsLabel.Text:find("FPS") ~= nil, "ป้าย FPS มีค่า")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hud DoD: ต้นทุน UI render ≤ 0.5 ms/frame (timer \"ui\" ของ Diagnostics)", function()
  local R, F, A, U = bootStack()
  __VT.advance(2)
  local t = F.Diag:Snapshot().timers["ui"]
  H.ok(t and t.count >= 4, "timer ui ถูกวัดจริง (4 ครั้ง/วิ × 2 วิ)")
  local avg = t.total / t.count
  H.ok(avg <= 0.5, ("avg %.4f ms ≤ 0.5 ms (test env)"):format(avg))
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hud: ไดอักนอสติกย่อ — แตะสลับ + ตัวเลขสด + สถานะ adapter จาก bus", function()
  local R, F, A, U = bootStack()
  local bar = findUI(U, "Bar")
  bar.MouseButton1Click:Fire()
  H.eq(U.HUD:Stats().miniVisible, true, "แผงย่อเปิด")
  H.eq(findUI(U, "Mini").Visible, true, "มองเห็น")
  local reg = findUI(U, "MiniRegistry")
  H.ok(reg.Text:find("task") ~= nil, "ตัวเลข Registry สด")
  H.ok(findUI(U, "MiniBus").Text:find("Event Bus") ~= nil, "ตัวเลข Event Bus สด")
  -- adapter เสื่อม → จุดเปลี่ยนสี (bus adapter:health replay)
  F.Bus:Publish("adapter:health", { status = "degraded" })
  H.ok(U.HUD:Stats().miniVisible, true)
  local dot = findUI(U, "DotAdapter")
  H.eq(dot.BackgroundColor3, U.Theme:Get().warn, "จุด = เหลืองเมื่อ degraded")
  H.ok(findUI(U, "Adapter").Text:find("degraded") ~= nil, "ป้ายสถานะตามจริง")
  bar.MouseButton1Click:Fire()
  H.eq(findUI(U, "Mini").Visible, false, "แตะอีกครั้ง = ซ่อน")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/hud: ลากย้ายได้ (§5.4) + ปิด node แล้ว fpsProvider ถูกถอน", function()
  local R, F, A, U = bootStack()
  __VT.advance(0.4)
  local before = findUI(U, "Bar").Position.X.Offset
  fireDrag(U.HUD.bar, U.HUD.bar, 20, 8)
  H.eq(findUI(U, "Bar").Position.X.Offset, before + 20, "แถบขยับตามการลาก")
  U.HUD:Shutdown()
  H.ok(R.VerifyZero("HUD"), "HUD ปิดสะอาด")
  H.eq(F.Diag:Snapshot().fps, nil, "provider ถูกถอน (ไม่ชี้มาที่ node ตาย)")
  R.ShutdownAll({ assertZero = true })
end)

-- ==== Notification ============================================================

H.test("UI/notify: bus → toast แปลผ่าน i18n + สีตาม level (§8.1)", function()
  local R, F, A, U = bootStack()
  F.Bus:Publish("notify:user", {
    level = "warn",
    key = "notify.adapter.dead",
    params = { name = "Combat", reason = "เกมอัปเดต" },
  })
  H.eq(U.Notify:Stats().active, 1, "มี toast 1 อัน")
  local toast = findUI(U, "Toast")
  local msg = toast:FindFirstChild("Text")
  H.ok(msg.Text:find("Combat") ~= nil and msg.Text:find("ใช้ไม่ได้") ~= nil,
    "ข้อความแปลจาก key ด้วย params")
  local bar = findUI(U, "LevelBar")
  H.eq(bar.BackgroundColor3, U.Theme:Get().warn, "level warn = สีเหลืองอำพัน")
  -- level แปลก = info
  F.Bus:Publish("notify:user", { level = "weird", text = "ตรง ๆ" })
  H.eq(U.Notify:Stats().active, 2, "level ไม่รู้จัก = info")
  local toasts = __UI.findAll(U.Backend.root, "Toast")
  H.ok(toasts[2]:FindFirstChild("Text").Text:find("ตรง ๆ") ~= nil, "payload text ตรง")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/notify: คิวเกิน 4 = ปิดอันเก่าสุด + TTL หายเอง + แตะปิด", function()
  local R, F, A, U = bootStack()
  local base = R.Snapshot("Notification")
  H.ok(base.renders >= 3, "node ถือโครงของตัวเอง (gui+holder+list) — เกณฑ์เทียบมีค่าจริง")
  for i = 1, 6 do
    U.Notify:Push({ level = "info", text = "t" .. i })
  end
  local st = U.Notify:Stats()
  H.eq(st.active, 4, "เหลือ 4 อันล่าสุด")
  H.eq(st.droppedOldest, 2, "อันเก่าสุดถูกปลด 2 อัน")
  -- ที่เหลือ = t3,t4,t5,t6 (t1,t2 ถูกปลด) — findAll เรียงตามลำดับแทรกใน Holder
  -- ดังนั้นตัวแรกที่เจอ = t3 = เก่าสุดของที่ยังเปิดอยู่
  local first = __UI.findAll(U.Backend.root, "Toast")[1]
  H.ok(first:FindFirstChild("Text").Text:find("t3") ~= nil, "อันที่เหลือเริ่มจาก t3 (เก่าสุดโดนปลด 2 อัน)")
  local texts = {}
  for _, t in ipairs(__UI.findAll(U.Backend.root, "Toast")) do
    texts[#texts + 1] = t:FindFirstChild("Text").Text
  end
  H.eq(table.concat(texts, ","), "t3,t4,t5,t6", "ชุดที่เหลือครบ = 4 อันล่าสุดพอดี")
  -- แตะปิด
  first.MouseButton1Click:Fire()
  H.eq(U.Notify:Stats().active, 3, "แตะปิดได้ทันที")
  -- TTL หายเอง (VT)
  __VT.advance(6)
  H.eq(U.Notify:Stats().active, 0, "ครบ 5 วิ หายทั้งหมด")
  -- toast ทุกตัวปิดหมดแล้ว: resource ของ "Notification" ต้องกลับระดับตั้งต้น
  -- (VerifyZero ใช้ไม่ได้ที่นี่ — node ยังมีชีวิต ถือ gui/holder/subscription
  -- ของตัวเองตามดีไซน์ ของพวกนี้ถูกคืนตอน Shutdown) — ตัวที่ห้ามเหลือคือ
  -- ของ toast รายตัว (ปุ่ม/แถบ/ป้าย/มุม/เส้น/connection/TTL task)
  local after = R.Snapshot("Notification")
  H.eq(after.total, base.total, "resource กลับระดับตั้งต้น — ไม่มี orphan จาก toast สะสม")
  H.eq(after.renders, base.renders, "render ไม่รั่ว (มุม/เส้นของ toast ถูกคืน)")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/notify: เปลี่ยนภาษา → toast เปิดอยู่แปลใหม่ (ไม่ค้างภาษาเดิม)", function()
  local R, F, A, U = bootStack()
  F.Bus:Publish("notify:user", {
    level = "error",
    key = "notify.adapter.dead",
    params = { name = "X", reason = "Y" },
  })
  U.Hub.langBtns.en.obj.MouseButton1Click:Fire()
  local toast = __UI.findAll(U.Backend.root, "Toast")[1]
  local msg = toast:FindFirstChild("Text")
  H.ok(msg.Text:find("unavailable") ~= nil, "toast แปลเป็นอังกฤษทันที")
  H.eq(msg.Text, F.I18n:T("notify.adapter.dead", { name = "X", reason = "Y" }),
    "ตรงกับ i18n ปัจจุบันเป๊ะ")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/notify: UI ไม่มี (degraded) → plain text + นับสถิตะ (§3.2 ข้อ 0 pattern)", function()
  local realGethui = gethui
  gethui = nil
  __HUI = nil
  delfile(CONFIG_FILE)
  local R2 = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R2:Bootstrap()
  local F2 = FoundationLib.new({ runtime = R2 })
  F2:Bootstrap()
  local UiLibNoGui = UiLib.new({ runtime = R2, foundation = F2, version = "x", clock = VTNow })
  UiLibNoGui:Bootstrap()
  gethui = realGethui
  H.eq(UiLibNoGui.Backend.available, false, "degraded")
  local n0 = #__OUT.prints
  F2.Bus:Publish("notify:user", { level = "warn", text = "แจ้งผ่านคอนโซล" })
  local st = UiLibNoGui.Notify:Stats()
  H.eq(st.built, false, "ยังไม่ built")
  H.eq(st.plainText, 1, "นับเป็น plain text")
  H.ok(#__OUT.prints > n0, "พิมพ์ออกคอนโซลจริง")
  R2.ShutdownAll({ assertZero = true })
end)

-- ==== PC-only guard (CR-PC-ONLY — กันถอยหลังถาวร) ============================

H.test("UI/pc-only: อุปกรณ์ทัชอย่างเดียว (stub) ก็ได้เลย์เอาต์ desktop เดิมทุกค่า (CR-PC-ONLY)", function()
  local R, F, A, U = bootStack({ touch = true, keyboard = false })
  -- InputInfo ยังอ่านสถานะอินพุตได้จริง (API คงไว้ตามขอบเขต CR)
  local info = F.Keybind:InputInfo()
  H.eq(info.attached, true, "InputAdapter ต่ออยู่")
  H.eq(info.touchEnabled, true, "อ่านทัชได้ = true (อุปกรณ์ทัชอย่างเดียวจริง)")
  H.eq(info.keyboardEnabled, false, "คีย์บอร์ด = false")
  -- UI ไม่ปรับตัวให้มือถือ — เลย์เอาต์ desktop ทุกค่า (DoD §5.4 ฉบับ PC-only)
  local L = U.Theme:Get().layout
  local hub = findUI(U, "Hub")
  H.eq(hub.Size.X.Offset, L.HUB_W, "หน้าต่าง hub กว้าง HUB_W ตาม desktop")
  H.eq(hub.Size.Y.Offset, L.HUB_H, "สูง HUB_H ตาม desktop")
  local rail = findUI(U, "Tabs")
  H.ok(rail.Position.Y.Scale == 0, "แถบแท็บอยู่ฝั่งซ้ายตาม desktop (ไม่ย้ายลงล่าง)")
  H.eq(rail.Size.X.Offset, L.TAB_W, "แถบแท็บกว้าง TAB_W แนวตั้งฝั่งซ้าย")
  local list = rail:FindFirstChild("List")
  -- desktop = ค่า default ของ UIListLayout (แนวตั้ง) — โค้ด desktop ไม่สั่ง
  -- FillDirection ตรง ๆ (ต่างจากโหมดมือถือเดิมที่สั่ง Horizontal) จึงยอม nil
  H.ok(list ~= nil and (list.FillDirection == nil or list.FillDirection.Name == "Vertical"),
    "แท็บวางแนวตั้งตาม desktop (ไม่มีการสั่งแนวนอน)")
  local tabAim = findUI(U, "Tab_aim")
  H.ok(tabAim.Text ~= "⭐", "แท็บเป็นชื่อเต็ม ไม่ย่อเป็นไอคอนมือถือ")
  -- ไม่มีของของมือถือโผล่มา
  H.eq(findUI(U, "TVMobile"), nil, "ไม่มี layer TVMobile")
  H.eq(findUI(U, "QuickHub"), nil, "ไม่มีปุ่มลัดลอยมือถือ")
  H.eq(U.Mobile, nil, "ไม่มี node MobileLayout ใน assembler")
  -- graph ไม่มี MobileLayout (SSOT 38 node ตาม dependencies.md v1.6)
  local inGraph = {}
  for _, n in ipairs(R.Graph.initOrder) do inGraph[n] = true end
  H.ok(not inGraph.MobileLayout, "graph ไม่มี MobileLayout (39→38 ตาม CR)")
  H.ok(inGraph.Notification, "graph ยังมี Notification ครบ (L6)")
  R.ShutdownAll({ assertZero = true })
end)

H.test("UI/pc-only: InputInfo อ่านไม่ได้ = nil ทุกช่อง (ไม่เดา — API คงไว้ตาม CR)", function()
  -- stack ที่ keybind ยังไม่ต่อ input (จำลอง adapter ตายตอน attach)
  local R2 = RuntimeLib.new({ clock = VTNow, task = task, instance = Instance, debug = true })
  R2:Bootstrap()
  local F2 = FoundationLib.new({ runtime = R2 })
  F2:Bootstrap()
  H.eq(F2.Keybind:InputInfo().attached, false, "ยังไม่ต่อ = attached=false")
  H.eq(F2.Keybind:InputInfo().touchEnabled, nil, "ไม่มีค่า = nil (ไม่เดา)")
  H.eq(F2.Keybind:InputInfo().keyboardEnabled, nil, "ไม่มีค่า = nil (ไม่เดา)")
  R2.ShutdownAll({ assertZero = true })
end)

-- ==== ปิดทั้งชั้น ==============================================================

H.test("UI/teardown: ShutdownAll ครบทั้ง 3 node ตาม graph กลับด้าน (§3.10)", function()
  local R, F, A, U = bootStack()
  F.Bus:Publish("notify:user", { level = "info", text = "ค้างไว้ก่อนปิด" })
  __VT.advance(0.5)
  local rep = R.ShutdownAll({ assertZero = true })
  H.ok(rep.ok, "orphan 0 ทุก node")
  local uiRows = {}
  for _, row in ipairs(rep.rows) do
    if row.name == "Hub" or row.name == "HUD"
      or row.name == "Notification" then
      uiRows[#uiRows + 1] = row.name .. ":" .. tostring(row.ok)
    end
  end
  H.eq(#uiRows, 3, "มี row ของ UI ทั้ง 3 node ใน report (ลำดับกลับด้านตาม graph — MobileLayout ตัดตาม CR-PC-ONLY)")
  H.eq(U.Hub:Stats().built, false, "hub ปิดแล้ว")
  H.eq(U.Notify:Stats().active, 0, "toast ถูกล้าง")
end)
