-- L1: Dependency Graph (generated) — ตรวจโครงสร้างตาม §3.10
local H = PKG_harness
local G = PKG_graph

H.test("graph: initOrder เริ่ม L0 (BootstrapPreflight) จบ L6 (Notification)", function()
  H.eq(G.initOrder[1], "BootstrapPreflight")
  H.eq(G.initOrder[#G.initOrder], "Notification")
end)

H.test("graph: shutdownOrder = reverse(initOrder) เป๊ะ ๆ (SSOT เดียว §3.10)", function()
  H.eq(#G.shutdownOrder, #G.initOrder)
  for i, n in ipairs(G.initOrder) do
    H.eq(G.shutdownOrder[#G.shutdownOrder - i + 1], n, "reverse mismatch ที่ตำแหน่ง " .. i)
  end
end)

H.test("graph: ครบ 38 node ไม่มีชื่อซ้ำ (CR-PC-ONLY: ตัด MobileLayout 39→38)", function()
  H.eq(#G.initOrder, 38)
  local seen = {}
  for _, n in ipairs(G.initOrder) do
    H.ok(not seen[n], "ชื่อซ้ำ: " .. n)
    seen[n] = true
  end
  H.ok(not seen.MobileLayout, "PC-only guard: graph ต้องไม่มี MobileLayout (CR-PC-ONLY)")
end)

H.test("graph: provider มาก่อน consumer ทุก edge (หลักการ Init §3.10)", function()
  local pos = {}
  for i, n in ipairs(G.initOrder) do pos[n] = i end
  local edges = 0
  for consumer, deps in pairs(G.deps) do
    for _, d in ipairs(deps) do
      H.ok(pos[d] < pos[consumer], ("%s → %s: provider ต้องมาก่อน consumer"):format(d, consumer))
      edges = edges + 1
    end
  end
  H.eq(edges, G.edges, "จำนวน edge ต้องตรง metadata")
end)

H.test("graph: Hub ขึ้นกับ Feature Module ทั้ง 8 (expand 'ทุก Feature Module (L5)')", function()
  local dep = {}
  for _, d in ipairs(G.deps.Hub) do dep[d] = true end
  for _, m in ipairs({ "VoidAim", "VoidESP", "VoidMacro", "CombatCore", "Race", "Fruit", "Movement", "ServerHop" }) do
    H.ok(dep[m], "Hub ต้องขึ้นกับ " .. m)
  end
  H.ok(dep.ConfigService and dep.I18nService, "Hub ยังขึ้นกับ Config+I18n")
end)

H.test("graph: Watchdog หลัง ErrorBoundary / Migration หลัง ConfigService", function()
  local pos = {}
  for i, n in ipairs(G.initOrder) do pos[n] = i end
  H.ok(pos.ErrorBoundary < pos.Watchdog)
  H.ok(pos.ConfigService < pos.MigrationService)
  H.ok(pos.WorldAdapter < pos.TargetService, "TargetService ใช้ WorldAdapter = adapter ต้องมาก่อน")
end)

H.test("graph: ลำดับชั้นถูกต้องตามที่แก้ v1.1 — L3=Game Adapter มาก่อน L4=Shared Services", function()
  local pos = {}
  for i, n in ipairs(G.initOrder) do pos[n] = i end
  H.eq(G.layers.PlayerAdapter, 3)
  H.eq(G.layers.TargetService, 4)
  H.ok(pos.PlayerAdapter < pos.TargetService)
end)

H.test("graph: capabilityDeps — ServerHop ต้องมี HTTP (ฟีเจอร์เน็ต)", function()
  H.ok(G.capabilityDeps.ServerHop ~= nil)
  H.eq(G.capabilityDeps.ServerHop[1], "HTTP")
end)
