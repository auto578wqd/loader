-- ============================================================================
-- The Voider — qa/l1_unit/stub_game.lua (L1/L2 เท่านั้น — ห้ามปนกับโค้ดจริง)
-- โลกเกมจำลองสำหรับทดสอบ Game Adapter (§3.3) — ต่อยอดจาก stub_env.lua
--
-- ต้องโหลดหลัง stub_env.lua (ใช้ __newSignal)
--
-- ของที่จำลอง:
--   Vector3 (arithmetic + Magnitude/Unit) | mini-instance (FindFirstChild/
--   GetChildren) | Players + LocalPlayer + leaderstats (Bounty/Level) +
--   Character (Humanoid/HumanoidRootPart/Tool) | Workspace + CurrentCamera |
--   RunService (Heartbeat/RenderStepped) | UserInputService (IsKeyDown +
--   InputBegan/InputEnded + จำลองกดคีย์) | ReplicatedStorage.Remotes.Skill
--   (นับ FireServer) | Raycast คุมผลได้จากเทส
--
-- การทำ API ตายเพื่อทดสอบ graceful degradation (§3.3 กฎ 3):
--   __GAME.kill("leaderstats")   ลบ leaderstats ออกจาก LocalPlayer
--   __GAME.kill("camera")        ลบ CurrentCamera
--   __GAME.kill("remotes")       ลบ ReplicatedStorage.Remotes
--   __GAME.kill("character")     ลบ Character ของ LocalPlayer
--   __GAME.kill("service:Players") GetService("Players") โยน error
--   __GAME.restore(name)         กู้คืนทั้งหมดข้างต้น
--   __GAME.reset()               สร้างโลกใหม่ทั้งหมด
-- ============================================================================

-- ---- Vector3 -----------------------------------------------------------------

local function newVec(x, y, z)
  x, y, z = x or 0, y or 0, z or 0
  return setmetatable({ X = x, Y = y, Z = z }, {
    __add = function(a, b) return newVec(a.X + b.X, a.Y + b.Y, a.Z + b.Z) end,
    __sub = function(a, b) return newVec(a.X - b.X, a.Y - b.Y, a.Z - b.Z) end,
    __unm = function(a) return newVec(-a.X, -a.Y, -a.Z) end,
    __mul = function(a, b)
      if type(a) == "number" then return newVec(a * b.X, a * b.Y, a * b.Z) end
      if type(b) == "number" then return newVec(a.X * b, a.Y * b, a.Z * b) end
      return newVec(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X)
    end,
    __eq = function(a, b) return a.X == b.X and a.Y == b.Y and a.Z == b.Z end,
    __tostring = function(v) return ("%.2f, %.2f, %.2f"):format(v.X, v.Y, v.Z) end,
    __index = function(v, k)
      if k == "Magnitude" then
        return math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
      elseif k == "Unit" then
        local m = math.sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z)
        if m == 0 then return newVec(0, 0, 0) end
        return newVec(v.X / m, v.Y / m, v.Z / m)
      end
      return nil
    end,
  })
end

Vector3 = { new = newVec }

-- ---- mini instance -------------------------------------------------------------

local function newInst(className, name)
  local inst = {
    ClassName = className,
    Name = name or className,
    _children = {},
  }
  inst.FindFirstChild = function(self, childName)
    for _, c in ipairs(self._children) do
      if c.Name == childName then return c end
    end
    return nil
  end
  inst.GetChildren = function(self)
    local out = {}
    for i, c in ipairs(self._children) do out[i] = c end
    return out
  end
  inst.AddChild = function(self, child)
    table.insert(self._children, child)
    return child
  end
  return inst
end

local function newIntValue(name, value)
  local v = newInst("IntValue", name)
  v.Value = value
  return v
end

-- ---- โลกทั้งใบ -------------------------------------------------------------------

__GAME = {}

function __GAME.reset()
  __GAME.remoteCalls = {}
  __GAME.keyStates = {}
  __GAME.raycastHandler = function() return nil end -- default: ทะลุ (เทสเซ็ตเอง)
  __GAME.deadParts = {}                             -- { leaderstats, camera, remotes, character }
  __GAME.serverInfo = { jobId = "job-test-001", maxPlayers = 12 }

  -- LocalPlayer + ผู้เล่นอื่น
  local function makePlayer(name, userId, opts)
    opts = opts or {}
    local p = newInst("Player", name)
    p.UserId = userId
    p.Team = opts.team or "Pirates"
    p.Neutral = opts.neutral or false
    -- leaderstats (Bounty / Level)
    local stats = newInst("Folder", "leaderstats")
    stats:AddChild(newIntValue("Bounty", opts.bounty or 0))
    stats:AddChild(newIntValue("Level", opts.level or 1))
    p.leaderstats = stats
    p:AddChild(stats)
    -- Character
    local char = newInst("Model", name)
    local root = newInst("Part", "HumanoidRootPart")
    root.Position = opts.position or newVec(0, 5, 0)
    root.Size = newVec(2, 2, 1)
    char:AddChild(root)
    local humanoid = newInst("Humanoid", "Humanoid")
    humanoid.Health = opts.health or 100
    humanoid.MaxHealth = opts.maxHealth or 100
    humanoid.MoveDirection = newVec(0, 0, 0)
    humanoid._state = opts.state or "Running"
    humanoid.GetState = function()
      return humanoid._state
    end
    char:AddChild(humanoid)
    if opts.weapon then
      local tool = newInst("Tool", opts.weapon)
      char:AddChild(tool)
    end
    p.Character = char
    return p
  end

  __GAME.makePlayer = makePlayer

  local localPlayer = makePlayer("TestUser", 111, {
    bounty = 5000, level = 100, weapon = "Katana",
    position = newVec(0, 5, 0),
  })
  local bot1 = makePlayer("BotOne", 222, {
    bounty = 12500, level = 250, team = "Marines",
    weapon = "Sword", position = newVec(30, 5, 40),
  })
  local bot2 = makePlayer("BotTwo", 333, {
    bounty = 750, level = 55, team = "Pirates",
    position = newVec(-20, 5, -10),
  })

  local Players = newInst("Players", "Players")
  Players.LocalPlayer = localPlayer
  Players.GetPlayers = function()
    return { localPlayer, bot1, bot2 }
  end
  __GAME.players = Players
  __GAME.localPlayer = localPlayer

  -- Workspace + parts + CurrentCamera
  local Workspace = newInst("Workspace", "Workspace")
  local ground = newInst("Part", "Ground")
  ground.Position = newVec(0, 0, 0)
  ground.Size = newVec(512, 1, 512)
  Workspace:AddChild(ground)
  local obstacle = newInst("Part", "Wall")
  obstacle.Position = newVec(10, 5, 10)
  obstacle.Size = newVec(1, 10, 20)
  Workspace:AddChild(obstacle)
  Workspace.Raycast = function(_, origin, direction)
    return __GAME.raycastHandler(origin, direction)
  end
  __GAME.workspace = Workspace

  local camera = newInst("Camera", "Camera")
  local cframe = { Position = newVec(0, 8, -12) }
  cframe.LookVector = newVec(0, 0, 1)
  camera.CFrame = cframe
  camera.FieldOfView = 70
  Workspace.CurrentCamera = camera
  __GAME.camera = camera

  -- UserInputService
  local UIS = {
    KeyboardEnabled = true,
    MouseEnabled = true,
    TouchEnabled = true,
    GamepadEnabled = true,
    InputBegan = __newSignal("InputBegan"),
    InputEnded = __newSignal("InputEnded"),
    IsKeyDown = function(_, key)
      return __GAME.keyStates[key] == true
    end,
  }
  __GAME.uis = UIS

  -- RunService
  local RunService = {
    Heartbeat = __newSignal("Heartbeat"),
    RenderStepped = __newSignal("RenderStepped"),
    IsClient = function() return true end,
    IsServer = function() return false end,
  }
  __GAME.runService = RunService

  -- ReplicatedStorage + Remotes
  local ReplicatedStorage = newInst("Folder", "ReplicatedStorage")
  local remotes = newInst("Folder", "Remotes")
  local skillRemote = newInst("RemoteEvent", "Skill")
  skillRemote.FireServer = function(_, ...)
    __GAME.remoteCalls[#__GAME.remoteCalls + 1] = { remote = "Skill", args = { ... } }
    return true
  end
  skillRemote.OnClientEvent = __newSignal("OnClientEvent")
  remotes:AddChild(skillRemote)
  ReplicatedStorage:AddChild(remotes)
  __GAME.replicatedStorage = ReplicatedStorage

  -- services registry
  local services = {
    Players = Players,
    Workspace = Workspace,
    UserInputService = UIS,
    RunService = RunService,
    ReplicatedStorage = ReplicatedStorage,
  }
  __GAME.services = services
end

-- game global — GetService ตามสเปค Roblox (service ตาย = error ทันที)
game = {
  GetService = function(_, name)
    if __GAME.deadParts["service:" .. name] then
      error("GetService: " .. tostring(name) .. " ใช้ไม่ได้ (จำลองเกมอัปเดตหาย)", 0)
    end
    local svc = __GAME.services[name]
    if svc == nil then
      error("GetService: unknown service " .. tostring(name), 0)
    end
    return svc
  end,
}

-- workspace global (Roblox มีตัวแปร global นี้)
local wsMeta = {
  __index = function(_, k)
    return __GAME.workspace[k]
  end,
}
workspace = setmetatable({}, wsMeta)

-- ---- การทำ API ตาย / กู้คืน (ทดสอบ §3.3 กฎ 3) --------------------------------

function __GAME.kill(part)
  __GAME.deadParts[part] = true
  local lp = __GAME.localPlayer
  if part == "leaderstats" and lp then
    if lp:FindFirstChild("leaderstats") then
      -- ลบออกจาก children ด้วย (FindFirstChild ต้องเห็นความจริง)
      for i, c in ipairs(lp._children) do
        if c.Name == "leaderstats" then table.remove(lp._children, i) break end
      end
    end
    lp.leaderstats = nil
  elseif part == "camera" and __GAME.workspace then
    __GAME.workspace.CurrentCamera = nil
  elseif part == "remotes" and __GAME.replicatedStorage then
    for i, c in ipairs(__GAME.replicatedStorage._children) do
      if c.Name == "Remotes" then table.remove(__GAME.replicatedStorage._children, i) break end
    end
  elseif part == "character" and lp then
    lp.Character = nil
  elseif part == "humanoid" and lp and lp.Character then
    for i, c in ipairs(lp.Character._children) do
      if c.Name == "Humanoid" then table.remove(lp.Character._children, i) break end
    end
  end
end

function __GAME.restore(part)
  __GAME.deadParts[part] = nil
  local lp = __GAME.localPlayer
  if part == "leaderstats" and lp and not lp:FindFirstChild("leaderstats") then
    local stats = newInst("Folder", "leaderstats")
    stats:AddChild(newIntValue("Bounty", 5000))
    stats:AddChild(newIntValue("Level", 100))
    lp:AddChild(stats)
    lp.leaderstats = stats
  elseif part == "camera" and __GAME.workspace then
    __GAME.workspace.CurrentCamera = __GAME.camera
  elseif part == "remotes" and __GAME.replicatedStorage then
    if not __GAME.replicatedStorage:FindFirstChild("Remotes") then
      -- สร้างใหม่จาก remote เดิม (เก็บ reference ไว้ใน reset)
      local remotes = newInst("Folder", "Remotes")
      local skillRemote = newInst("RemoteEvent", "Skill")
      skillRemote.FireServer = function(_, ...)
        __GAME.remoteCalls[#__GAME.remoteCalls + 1] = { remote = "Skill", args = { ... } }
        return true
      end
      skillRemote.OnClientEvent = __newSignal("OnClientEvent")
      remotes:AddChild(skillRemote)
      __GAME.replicatedStorage:AddChild(remotes)
    end
  elseif part == "character" and lp then
    __GAME.reset() -- ง่ายและเนียนที่สุดสำหรับเคสนี้: โลกใหม่
  elseif part == "humanoid" and lp then
    __GAME.reset()
  end
end

-- ---- helper สำหรับเทส ------------------------------------------------------------

--- จำลองกดคีย์ (ส่ง InputBegan + เก็บสถานะ IsKeyDown)
function __GAME.pressKey(key)
  __GAME.keyStates[key] = true
  __GAME.uis.InputBegan:Fire({ KeyCode = key, UserInputType = "Keyboard" })
end

function __GAME.releaseKey(key)
  __GAME.keyStates[key] = false
  __GAME.uis.InputEnded:Fire({ KeyCode = key, UserInputType = "Keyboard" })
end

--- จำนวนครั้งที่ remote ถูกเรียก (กรองตามชื่อได้)
function __GAME.remoteCallCount(remoteName)
  local n = 0
  for _, call in ipairs(__GAME.remoteCalls) do
    if remoteName == nil or call.remote == remoteName then
      n = n + 1
    end
  end
  return n
end

-- สร้างโลกแรก
__GAME.reset()
