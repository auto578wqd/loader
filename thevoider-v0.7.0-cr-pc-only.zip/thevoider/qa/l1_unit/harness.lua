-- ============================================================================
-- The Voider — qa/l1_unit/harness.lua
-- เฟรมเวิร์กเทส L1 (Unit) — น้อยชิ้น ตรวจได้ ไม่พึ่ง dependency ภายนอก
-- ใช้คู่กับ scripts/tv_l1_runtime.js (fengari runner)
-- ============================================================================

local H = {}

H.tests = {}

--- ลงทะเบียนเคส: H.test("ชื่อ", function() ... end)
function H.test(name, fn)
  table.insert(H.tests, { name = name, fn = fn })
end

-- ---- assertion helpers (error ที่โยน = เคสนั้น fail ทันที) -----------------

function H.ok(cond, msg)
  if not cond then
    error(msg or "expected truthy", 2)
  end
end

function H.eq(a, b, msg)
  if a ~= b then
    error((msg or "eq failed") .. (" (got=%s want=%s)"):format(tostring(a), tostring(b)), 2)
  end
end

function H.almost(a, b, tol, msg)
  if math.abs(a - b) > tol then
    error((msg or "almost failed") .. (" (got=%s want=%s ±%s)"):format(tostring(a), tostring(b), tostring(tol)), 2)
  end
end

--- รันทุกเคสที่ลงทะเบียน — คืน { pass, fail, failures }
function H.run()
  local pass, fail = 0, 0
  local failures = {}
  for _, t in ipairs(H.tests) do
    local ok, err = pcall(t.fn)
    if ok then
      pass = pass + 1
    else
      fail = fail + 1
      table.insert(failures, { name = t.name, err = tostring(err) })
      print(("  [FAIL] %s -- %s"):format(t.name, tostring(err)))
    end
  end
  print(("L1_RESULT pass=%d fail=%d total=%d"):format(pass, fail, pass + fail))
  return { pass = pass, fail = fail, failures = failures }
end

return H
