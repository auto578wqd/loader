-- L1: Direct Services (§3.5) — query-only interface registry + L1: JSON codec (§3.7)
local H = PKG_harness
local Services = PKG_services

-- ==== Services ================================================================

H.test("services: Define + Get + MustGet + List", function()
  local s = Services.new()
  s:Define("Target", {
    GetCurrentTarget = function() return nil end,
    GetCandidates = function() return {} end,
  })
  H.ok(s:Get("Target"), "Get ได้หลัง Define")
  H.ok(s:MustGet("Target"), "MustGet ได้")
  H.eq(#s:List(), 1, "List มี 1")
  H.eq(s:List()[1], "Target", "ชื่อตรง")
end)

H.test("services: MustGet ชื่อที่ไม่มี = error พร้อมรายชื่อที่มีจริง (fail-fast)", function()
  local s = Services.new()
  s:Define("Camera", { GetState = function() return {} end })
  local ok, err = pcall(s.MustGet, s, "TargetService")
  H.ok(not ok, "ต้อง error")
  H.ok(tostring(err):find("Camera") ~= nil, "error ต้องบอกชื่อที่มีอยู่จริง")
end)

H.test("services: Define ซ้ำ = error; opts.replace = แทนที่ได้ (hot update)", function()
  local s = Services.new()
  s:Define("A", { F = function() return 1 end })
  local ok = pcall(s.Define, s, "A", { F = function() return 2 end })
  H.ok(not ok, "ซ้ำไม่ replace ต้อง error")
  s:Define("A", { F = function() return 2 end }, { replace = true })
  H.eq(s:MustGet("A").F(), 2, "replace ได้ตัวใหม่")
  H.eq(#s:List(), 1, "จำนวนไม่งอก")
end)

H.test("services: query-only — field ไม่ใช่ function = error (§3.5 กฎ 1)", function()
  local s = Services.new()
  local ok, err = pcall(s.Define, s, "Bad", { Name = "ข้อมูล" })
  H.ok(not ok, "ต้องปฏิเสธ")
  H.ok(tostring(err):find("query") ~= nil, "error ต้องอ้างกฎ query-only")
end)

H.test("services: Undefine ถอน + Stats", function()
  local s = Services.new()
  s:Define("X", { F = function() end })
  H.ok(s:Undefine("X"), "undefine สำเร็จ")
  H.ok(not s:Get("X"), "Get ไม่ได้แล้ว")
  H.ok(not s:Undefine("X"), "undefine ซ้ำ = false (idempotent)")
  H.eq(s:Stats().count, 0, "count=0")
end)

-- ==== JSON codec ================================================================

local Json = PKG_json

local function roundtrip(t)
  local encoded = Json.encode(t)
  local decoded = Json.decode(encoded)
  return encoded, decoded
end

H.test("json: round-trip ข้อมูลธรรมดาทุกชนิด (null/bool/int/float/string/ไทย)", function()
  local src = {
    n = nil,
    t = true,
    f = false,
    i = 42,
    neg = -7,
    fp = 3.5,
    s = "hello",
    thai = "ทดสอบภาษาไทย",
    esc = "บรรทัด\nแท็บ\t\"คำพูด\"\\สแลช",
  }
  local encoded, decoded = roundtrip(src)
  H.eq(decoded.t, true, "bool true")
  H.eq(decoded.f, false, "bool false")
  H.eq(decoded.i, 42, "int")
  H.eq(decoded.neg, -7, "จำนวนลบ")
  H.almost(decoded.fp, 3.5, 1e-9, "float")
  H.eq(decoded.s, "hello", "string")
  H.eq(decoded.thai, "ทดสอบภาษาไทย", "string ไทย")
  H.eq(decoded.esc, "บรรทัด\nแท็บ\t\"คำพูด\"\\สแลช", "escape ครบ")
  H.ok(encoded:find('"i":42') ~= nil, "จำนวนเต็มไม่มี .0")
end)

H.test("json: round-trip โครงสร้างซ้อน (array ใน object ใน array)", function()
  local src = {
    players = {
      { name = "A", bounty = 100, tags = { "pvp", "boss" } },
      { name = "B", bounty = 250, tags = {} },
    },
    count = 2,
  }
  local _, decoded = roundtrip(src)
  H.eq(#decoded.players, 2, "array ระดับนอก")
  H.eq(decoded.players[1].name, "A", "object ใน array")
  H.eq(decoded.players[1].tags[2], "boss", "array ใน object ใน array")
  H.eq(#decoded.players[2].tags, 0, "array ว่างรอดับลึก")
end)

H.test("json: key เรียงเสถียร — encode สองครั้งได้ byte ตรงกัน (diff/md5 ได้)", function()
  local t = { z = 1, a = 2, m = { y = 1, b = 2 } }
  H.eq(Json.encode(t), Json.encode(t), "เสถียรทุกครั้ง")
end)

H.test("json: encode ตัวเลขพิเศษ/ประเภทห้าม = error ชัดเจน", function()
  H.ok(not pcall(Json.encode, { x = 0 / 0 }), "NaN ต้อง error")
  H.ok(not pcall(Json.encode, { x = math.huge }), "Inf ต้อง error")
  H.ok(not pcall(Json.encode, { fn = function() end }), "function ต้อง error")
  H.ok(not pcall(Json.encode, { [1] = "a", extra = true }), "array ผสม key ต้อง error")
  H.ok(not pcall(Json.encode, { [42] = "a" }), "key ตัวเลขต้อง error")
end)

H.test("json: decode ขยะ = error พร้อมตำแหน่ง (ให้แก้ไฟล์ config มือได้)", function()
  local bad = {
    "{",                          -- ไม่ปิด
    "{\"a\":}",                   -- ค่าหาย
    "{\"a\":1}ขยะ",               -- ขยะท้าย
    "[1,2,]",                     -- comma ค้าง
    "{\"a\":01}",                 -- เลขนำศูนย์ (ผิดสเปค JSON)
    "\"ไม่ปิด",                    -- string ไม่ปิด
  }
  for _, s in ipairs(bad) do
    local ok = pcall(Json.decode, s)
    H.ok(not ok, ("ต้อง error: %s"):format(s))
  end
end)

H.test("json: decode \\u escape — latin / ไทย / surrogate pair (อีโมจิ)", function()
  H.eq(Json.decode("\"\\u0041\""), "A", "latin")
  H.eq(Json.decode("\"\\u0e01\""), "ก", "ไทย (U+0E01)")
  H.eq(Json.decode("\"\\ud83d\\ude00\""), "\240\159\152\128", "surrogate pair U+1F600")
  H.ok(not pcall(Json.decode, "\"\\ud83d\""), "surrogate เดี่ยวต้อง error")
end)

H.test("json: encode ตัวอักษรควบคุม → \\u00XX (ไฟล์สะอาดบรรทัดเดียว)", function()
  local encoded = Json.encode({ s = "a\1b" })
  H.eq(encoded, '{"s":"a\\u0001b"}', "คุมรูปแบบ escape")
end)
