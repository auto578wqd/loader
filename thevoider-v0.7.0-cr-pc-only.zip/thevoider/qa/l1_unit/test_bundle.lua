-- L1: bundle.lua — System Bundle entry (สัญญา handle + default selfChecks + Entry)
local H = PKG_harness
local Bundle = PKG_bundle

local function buildOpts()
  return {
    version = "0.3.0",
    releaseId = "r-bundle-test",
    runtime = { clock = VTNow, task = task, drawing = Drawing, instance = Instance, debug = true },
    env = { game = game, workspace = workspace },
  }
end

H.test("bundle: Build ครบสัญญา system handle ทุกช่อง (update.lua ต้องการ)", function()
  __GAME.reset()
  local sys = Bundle.Build(buildOpts())
  H.eq(sys.version, "0.3.0")
  H.eq(sys.releaseId, "r-bundle-test")
  H.ok(sys.runtime and sys.foundation and sys.adapter, "ครบ 3 layer")
  H.ok(sys.bus and sys.config and sys.migration, "foundation services")
  H.ok(sys.shutdown and sys.registry and sys.boundary and sys.watchdog and sys.diag, "runtime services")
  H.ok(sys.probe and type(sys.probe.Probe) == "function" and type(sys.probe.LastReport) == "function",
    "probe object")
  H.eq(type(sys.providers), "table", "providers เป็น list")
  H.eq(#sys.providers, 0, "เฟส 0 production: ไม่มี provider (ไม่สร้างล่วงหน้า §4.5)")
  H.ok(#sys.selfChecks >= 7, "default selfChecks ติดตั้ง (" .. #sys.selfChecks .. " ตัว)")
  -- โลกปกติ → adapter health ok จริงจาก stub
  H.eq(sys.probe:LastReport().status, "ok", "Self-Probe รันตอน Bootstrap แล้ว")
end)

H.test("bundle: default selfChecks ทุกตัวผ่าน + จับพังได้ (เชื่อม update F3)", function()
  __GAME.reset()
  local sys = Bundle.Build(buildOpts())
  local ctx = { generation = sys.bus:Stats().generation, manifest = { version = "0.3.0" } }
  for _, check in ipairs(sys.selfChecks) do
    local ok, detail = check.fn(sys, ctx)
    H.ok(ok, ("check %s: %s"):format(check.name, tostring(detail)))
  end

  -- พังจริงได้: kill service Players → probe-ran ยัง ok (รายงานเก่า) แต่
  -- ลอง check bus-active กับ frozen จริง
  sys.bus:Freeze(99)
  for _, check in ipairs(sys.selfChecks) do
    if check.name == "bus-active" then
      local ok = check.fn(sys, ctx)
      H.ok(not ok, "bus-active ต้องจับ frozen ได้")
    end
  end
  sys.bus:Resume(99)
end)

H.test("bundle: spec.selfChecks ของ release ต่อท้าย + providers ตรวจสัญญา", function()
  __GAME.reset()
  local called = {}
  local sys = Bundle.Build({
    version = "0.3.0", releaseId = "r2",
    runtime = buildOpts().runtime, env = buildOpts().env,
    selfChecks = { { name = "extra", fn = function(s) called[#called + 1] = s.version; return true end } },
    providers = { { name = "P1", Serialize = function() return {} end, Apply = function() end } },
  })
  H.eq(#sys.providers, 1)
  H.eq(sys.providers[1].name, "P1")
  local last = sys.selfChecks[#sys.selfChecks]
  H.eq(last.name, "extra", "selfCheck ของ release อยู่ท้ายสุด")
  last.fn(sys, {})
  H.eq(called[1], "0.3.0")

  -- provider ไม่ครบสัญญา = error ชัด
  H.ok(pcall(Bundle.Build, {
    version = "0.3.0", releaseId = "r3", runtime = buildOpts().runtime, env = buildOpts().env,
    providers = { { name = "P1", Serialize = function() end } },
  }) == false, "provider ไม่มี Apply = error ตั้งแต่ Build")
end)

H.test("bundle: Entry — host.register ได้ system+source+manifest จาก loader", function()
  __GAME.reset()
  local savedRun = rawget(_G, "__TV_BUNDLE_RUN")
  rawset(_G, "__TV_BUNDLE_RUN", { source = "SRC-X", manifest = { version = "0.3.0" } })
  local registered = {}
  local host = { register = function(rec) registered[#registered + 1] = rec end }
  local sys = Bundle.Entry(host, buildOpts())
  H.eq(#registered, 1, "host.register ถูกเรียก 1 ครั้ง")
  H.eq(registered[1].system, sys)
  H.eq(registered[1].source, "SRC-X", "source มาจาก __TV_BUNDLE_RUN (loader ตั้งไว้)")
  H.eq(registered[1].manifest.version, "0.3.0")
  rawset(_G, "__TV_BUNDLE_RUN", savedRun)
end)

H.test("bundle: ปิดระบบที่ Build ขึ้นมา — ShutdownAll รายงาน ok + orphan 0 (§3.4)", function()
  __GAME.reset()
  local sys = Bundle.Build(buildOpts())
  local report = sys.runtime.ShutdownAll({ assertZero = true })
  H.ok(report.ok, "teardown ของระบบเต็มผ่าน")
  H.eq(report.orphans, 0, "orphan รวม 4 ชนิด = 0")
end)
