-- L1: update.lua — Hot Update Orchestrator ทุก path (§3.6)
-- ใช้ "fake system" (system handle ตามสัญญา พร้อมจุดฉีดพัง) + Bus ตัวจริง
-- (Freeze/Resume/Stats/generation เป็นของจริง) — ฉาก full system จริงทั้งชุดอยู่ที่ L2
local H = PKG_harness
local U = PKG_update
local BusLib = PKG_eventbus
local Ver = PKG_version
local Mani = PKG_manifest
local Sha = PKG_sha256

-- ชุดนี้ตรวจ protocol ของ update ไม่ใช่ระดับ integrity — ต่อ crypto เป็นของจริง
-- (stub_env ตอบ 64-zeros สำหรับ input อื่น ทำให้ tier crypto-api พังลวง ๆ)
local __origCryptoHash = crypto and crypto.hash or nil
crypto.hash = function(algo, s)
  if algo ~= "sha256" then return __origCryptoHash and __origCryptoHash(algo, s) or nil end
  return Sha.hex(s)
end

-- ---- fake system factory ------------------------------------------------------

local function makeFakeSystem(knobs)
  knobs = knobs or {}
  local sys = {}
  local bus = BusLib.new({ owner = "TestSystem" }) -- Bus จริง: freeze/resume/generation จริง
  sys.bus = bus
  sys.version = knobs.version or "0.2.0"
  sys.releaseId = knobs.releaseId or "r-old"
  sys._replaced = nil
  sys.config = {
    Data = function()
      if knobs.configData == false then return nil end
      return knobs.configData or { schemaVersion = 2, settings = { VoidAim = { fov = 95 } } }
    end,
    Replace = function(_, cfg)
      if knobs.replaceFails then error("replace boom") end
      sys._replaced = cfg
      return true
    end,
    Get = function(_, p)
      if p == "schemaVersion" then return 2 end
      return nil
    end,
  }
  sys.migration = {
    Run = function(_, cfg)
      if knobs.migrateFails then error("migration boom") end
      return cfg
    end,
  }
  local tdRows = knobs.teardownRows or {
    { name = "EventBus", orphan = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 } },
  }
  sys.shutdown = {
    Run = function()
      local total = 0
      for _, r in ipairs(tdRows) do total = total + (r.orphan and r.orphan.total or 0) end
      return { rows = tdRows, orphans = total, ok = total == 0 }
    end,
  }
  sys.registry = { Release = function() end }
  sys.watchdog = { Stop = function() end, entries = {} }
  sys.probe = {
    Probe = function()
      return {
        status = knobs.probeStatus or "ok",
        summary = knobs.probeSummary or "stub ok",
        adapters = {}, impacted = {},
      }
    end,
    LastReport = function() return { status = knobs.probeStatus or "ok" } end,
  }
  sys.providers = knobs.providers or {}
  sys.selfChecks = knobs.selfChecks or {
    { name = "stub-ok", fn = function() return true end },
  }
  sys.diag = { Mark = function() end }
  return sys
end

-- แหล่ง "bundle" ที่โหลดได้: "SRC:0.2.0" / "SRC:0.3.0" ...
-- specs[src] = knobs ของระบบที่จะเกิดจาก source นั้น
-- state.broken[src] = true → loadFn compile ไม่ผ่าน (ฉากพัง)
local state = { specs = {}, broken = {} }

local function loadFn(src, chunkName)
  if type(src) ~= "string" or #src == 0 then
    return nil, "source ว่าง"
  end
  if state.broken[src] then
    return nil, ("compile ไม่ผ่าน (ถูกสั่งให้พัง): %s"):format(tostring(chunkName))
  end
  local spec = state.specs[src]
  if not spec then
    return nil, ("ไม่มี spec ของ source %q"):format(src)
  end
  return function()
    if spec.execFails then error("bundle exec พัง (จงใจ)") end
    return makeFakeSystem(spec)
  end
end

local function maniFor(ver, sha, rid)
  local m, err = Mani.Build({
    version = ver,
    releaseId = rid or ("r-" .. ver),
    files = { ["the-voider.lua"] = { sha256 = sha, size = 5 } },
    minLoaderVersion = "0.2.0",
    channel = "stable",
  })
  assert(m, tostring(err))
  return m
end

-- clock กำหนดได้: ทุกครั้งที่ถูกเรียก +1 ms → totalMs ตรวจได้ทุก step
local function makeClock(stepMs)
  local t = 0
  return function()
    t = t + (stepMs or 0.001)
    return t
  end
end

-- ------------------------------------------------------------------------------

H.test("update: happy path v0.2.0→v0.3.0 — atomic + rollback target + replay + timing", function()
  state.specs = {}
  state.broken = {}
  state.specs["SRC:0.2.0"] = { version = "0.2.0", releaseId = "r-0.2.0" }
  state.specs["SRC:0.3.0"] = { version = "0.3.0", releaseId = "r-0.3.0" }

  local clock = makeClock(0.001)
  local stepLog = {}
  local got = {} -- ผู้ฟังบน bus ของระบบใหม่ (ต่อที่ขั้น load ผ่าน info.system)
  local upd -- ประกาศก่อน: closure ด้านล่างอ้างถึงเป็น upvalue (ถ้าประกาศทีหลังจะกลายเป็น global nil)
  upd = U.new({
    loadFn = loadFn,
    clock = clock,
    time = function() return 1000 end,
    logger = function() end,
    onStep = function(step, info)
      stepLog[#stepLog + 1] = {
        step = step,
        active = upd:Active() and upd:Active().version or nil,
        staged = upd:Staged() and upd:Staged().version or nil,
      }
      if step == "load" and info and info.system then
        info.system.bus:On("update:succeeded", function(p) got[#got + 1] = p end)
      end
    end,
  })

  local sysOld = makeFakeSystem(state.specs["SRC:0.2.0"])
  upd:Attach({ system = sysOld, source = "SRC:0.2.0", manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })

  local src03 = "SRC:0.3.0"
  local res = upd:Apply(src03, maniFor("0.3.0", Sha.hex(src03)))

  H.ok(res.ok, res.detail or "path=" .. tostring(res.path))
  H.eq(res.path, "OK")
  H.eq(upd:Active().version, "0.3.0", "NEW เป็น active หลัง commit")
  H.eq(upd:RollbackTarget().version, "0.2.0", "OLD เก็บเป็น rollback target (คงไว้ถึง release ถัดไป)")
  H.eq(res.rolledBack, false)
  H.ok(res.bugId == nil, "สำเร็จ = ไม่มี bug (§11 ครอบเฉพาะกรณีพัง)")

  -- integrity โหมด software (stub_env ไม่มี crypto จริง — ตรวจจริงตาม §7.2)
  H.ok(res.integrity and res.integrity.ok)
  H.ok(res.integrity.mode == "software" or res.integrity.mode == "crypto-api")

  -- timing: มีทุก step + รวมอยู่ในงบ
  H.ok(res.timing.totalMs > 0, "totalMs > 0")
  H.ok(res.timing.overBudget == false, "ไม่เกินงบ 5s (§9.1)")
  for _, k in ipairs({ "pre-stage", "freeze", "drain", "snapshot", "snapshot-validate",
      "teardown", "verify", "load", "migrate", "resume", "selfcheck", "adapter-probe", "commit" }) do
    H.ok(res.timing.steps[k] ~= nil, "timing มีขั้น " .. k)
  end

  -- snapshot ครบ 7 ช่อง + เก็บไว้ดูย้อนหลังได้
  local snap = res.snapshot
  H.eq(snap.version, "0.2.0")
  H.eq(snap.releaseId, "r-0.2.0")
  H.eq(snap.bundle, "SRC:0.2.0")
  H.ok(type(snap.manifest) == "table")
  H.ok(type(snap.moduleStates) == "table")
  H.ok(type(snap.configState) == "table")
  H.ok(type(snap.timestamp) == "number")

  -- ATOMIC: ก่อน commit ทุกจุด OLD ยังเป็น active / NEW ยังเป็น staged เท่านั้น
  local atLoad, atCommit
  for _, row in ipairs(stepLog) do
    if row.step == "load" then atLoad = row end
    if row.step == "commit" then atCommit = row end
  end
  H.ok(atLoad ~= nil, "มีขั้น load ใน log")
  H.eq(atLoad.active, "0.2.0", "ขั้น load: OLD ยัง active")
  H.eq(atLoad.staged, "0.3.0", "ขั้น load: NEW ยังเป็น staged เท่านั้น")
  H.eq(atCommit.active, "0.3.0", "ขั้น commit: NEW ขึ้นเป็น active ตรงนี้เท่านั้น")
  H.ok(atCommit.staged == nil, "หลัง commit staged ถูกเคลียร์")

  -- เหตุการณ์ update:succeeded ถึงผู้ฟังจริง (ระบบใหม่แจ้งผู้ใช้ §3.6 ขั้น 12)
  H.eq(#got, 1, "update:succeeded ประกาศ 1 ครั้ง")
  H.eq(got[1].to.version, "0.3.0")

  -- ใช้งานต่อได้จริง: bus ของระบบใหม่ไม่ frozen + generation เดิน
  local stats = upd:Active().system.bus:Stats()
  H.ok(not stats.frozen, "bus ระบบใหม่กลับมาทำงาน")
  H.ok(stats.generation >= 1, "generation เดินหน้าแล้ว")

  -- เรียก Apply ซ้ำรุ่นเดิม = NOOP
  local res2 = upd:Apply(src03, maniFor("0.3.0", Sha.hex(src03)))
  H.ok(res2.ok)
  H.eq(res2.path, "NOOP")
  H.eq(upd:Active().version, "0.3.0", "NOOP ไม่แตะระบบ")
end)

H.test("update: F0 — manifest เสีย / ลดเวอร์ชันบน stable / hash ไม่ตรง (ระบบเดิมไม่ถูกแตะ)", function()
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" } }
  state.broken = {}
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local frozenBefore = upd:Active().system.bus:Stats().frozen

  -- (ก) manifest ไม่ผ่าน Validate
  local r1 = upd:Apply("SRC:0.9.0", { version = "0.9.0" })
  H.ok(not r1.ok and r1.path == "F0")
  H.ok(r1.bugId:match("^BUG%-UPD%-0%d%d$") ~= nil, "ทุก failure มี Bug ID (§11)")
  H.ok(r1.detail:find("PRE%-STAGE") ~= nil)

  -- (ข) stable ปฏิเสธการลดเวอร์ชัน
  local r2 = upd:Apply("SRC:0.1.0", maniFor("0.1.0", Sha.hex("SRC:0.1.0")))
  H.ok(not r2.ok and r2.path == "F0")
  H.ok(r2.detail:find("Version Gate") ~= nil)

  -- (ค) integrity: sha256 ไม่ตรง = ไฟล์เสียหาย
  local r3 = upd:Apply("SRC:0.3.0", maniFor("0.3.0", string.rep("0", 64)))
  H.ok(not r3.ok and r3.path == "F0")
  H.ok(r3.detail:find("integrity") ~= nil)
  H.ok(r3.integrity and not r3.integrity.ok)

  -- (ง) loader เก่าเกิน minLoaderVersion
  local upd2 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end,
    loaderVersion = "0.2.0" })
  upd2:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local m4 = Mani.Build({
    version = "0.3.0", releaseId = "r4",
    files = { ["the-voider.lua"] = { sha256 = Sha.hex("SRC:0.3.0"), size = 5 } },
    minLoaderVersion = "0.4.0", channel = "stable",
  })
  local r4 = upd2:Apply("SRC:0.3.0", m4)
  H.ok(not r4.ok and r4.path == "F0")
  H.ok(r4.detail:find("loader v0%.4%.0") ~= nil, "บอกผู้ใช้ตรง ๆ ว่าต้องรัน loader ใหม่")

  -- ทุกกรณี: ระบบเดิมไม่ถูกแตะ (ไม่ freeze ไม่ teardown)
  H.eq(frozenBefore, false)
  H.eq(upd:Active().version, "0.2.0")
  H.ok(upd:Active().system.bus:Stats().frozen == false, "bus เดิมยังเดินตามปกติ")
end)

H.test("update: F-SNAP — snapshot พัง = ABORT ก่อน TEARDOWN + ระบบเดิมเดินต่อ (R4)", function()
  -- (ก) serializer ของ provider พัง
  state.specs = { ["SRC:0.2.0"] = {
    version = "0.2.0",
    providers = { { name = "P1", Serialize = function() error("serialize boom") end,
      Apply = function() end } },
  } }
  state.broken = {}
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  local sysOld = makeFakeSystem(state.specs["SRC:0.2.0"])
  upd:Attach({ system = sysOld, source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })

  local r1 = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r1.ok and r1.path == "F-SNAP", r1.detail)
  H.ok(r1.bugId ~= nil)
  H.ok(r1.detail:find("ก่อน TEARDOWN") ~= nil, "ระบุจุดยกเลิกตามกฎ R4")
  H.eq(r1.rolledBack, false, "ไม่ใช่ rollback — ยกเลิกก่อนทำลาย")
  -- ระบบเดิมยังเดิน: bus ถูก Resume คืน + freeze เปิดใช้ใหม่
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not sysOld.bus:Stats().frozen, "bus เดิม resume แล้ว (ไม่ค้าง frozen)")

  -- (ข) state มี function ฝัง = serialize ไม่ได้
  state.specs["SRC:0.2.0"] = {
    version = "0.2.0",
    providers = { { name = "P1", Serialize = function() return { bad = print } end,
      Apply = function() end } },
  }
  local upd2 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd2:Attach({ system = makeFakeSystem(state.specs["SRC:0.2.0"]), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local r2 = upd2:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r2.ok and r2.path == "F-SNAP")
  H.ok(r2.detail:find("serialize") ~= nil, "ระบุว่าค่า serialize ไม่ได้")

  -- (ค) โค้ดรุ่นเดิม (snapshot.bundle) compile ไม่ผ่าน = recover ไม่ได้
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" } }
  state.broken = {}
  local upd3 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  local sys3 = makeFakeSystem(state.specs["SRC:0.2.0"])
  upd3:Attach({ system = sys3, source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  state.broken["SRC:0.2.0"] = true -- ทำให้ "โค้ดรุ่นเดิม" โหลดกลับไม่ได้กลางด้าน
  local r3 = upd3:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r3.ok and r3.path == "F-SNAP", r3.detail)
  H.ok(r3.detail:find("compile ไม่ผ่าน") ~= nil, "ตรวจ recover จริงก่อน TEARDOWN")
  H.eq(upd3:Active().version, "0.2.0", "อยู่รุ่นเก่าต่อ")
  state.broken["SRC:0.2.0"] = false
end)

H.test("update: F1 — orphan ที่ TEARDOWN = ABORT + ROLLBACK กลับรุ่นเดิมใช้ได้จริง", function()
  -- ระบบเดิมมี leak: teardown report orphan temps=1
  state.specs = { ["SRC:0.2.0"] = {
    version = "0.2.0",
    teardownRows = {
      { name = "EventBus", orphan = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 } },
      { name = "KeybindService", orphan = { tasks = 0, connections = 0, renders = 0, temps = 1, total = 1 } },
    },
  }, ["SRC:0.3.0"] = { version = "0.3.0" } }
  state.broken = {}

  local rolledEvents = {}
  local upd = U.new({
    loadFn = loadFn, clock = makeClock(), logger = function() end,
    onStep = function(step, info)
      if step == "rollback.load" and info and info.system then
        -- ผู้ฟังบน bus ของระบบที่กำลังกู้คืน (ต่อก่อน rollback.resume จึงเห็น event)
        info.system.bus:On("update:rolledback", function(p) rolledEvents[#rolledEvents + 1] = p end)
      end
    end,
  })
  upd:Attach({ system = makeFakeSystem(state.specs["SRC:0.2.0"]), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })

  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not res.ok and res.path == "F1", res.detail)
  H.ok(res.bugId ~= nil)
  H.ok(res.detail:find("ห้าม force%-clean") ~= nil, "ระบุกฎ F1")
  -- รายงาน orphan แยก 4 ชนิด + เจ้าของ
  H.eq(res.orphans.temps, 1)
  H.eq(res.orphans.total, 1)
  H.ok(res.detail:find("KeybindService") ~= nil, "ระบุเจ้าของที่ค้าง")

  -- rollback: กลับมาเป็นรุ่นเดิม + เป็น "อินสแตนซ์ใหม่ของรุ่นเดิม" + ใช้ได้จริง
  H.eq(res.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not upd:Active().system.bus:Stats().frozen, "bus กลับมาทำงาน")
  H.eq(#rolledEvents, 1, "update:rolledback ถึงผู้ฟัง (แจ้งผู้ใช้ §3.6)")
  H.eq(rolledEvents[1].path, "F1")

  -- timing รวมรวม rollback steps ด้วย
  H.ok(res.timing.steps["rollback.load"] ~= nil, "timing มีขั้น rollback.load")
  H.ok(res.timing.steps["rollback.adapter-probe"] ~= nil)

  -- snapshot ยังอยู่ให้ดูย้อนหลัง
  H.eq(res.snapshot.version, "0.2.0")

  -- พังซ้ำอีกรอบ (สองรอบติด) ก็ต้อง rollback ได้อีก — ไม่ค้าง in-flight
  local res2 = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not res2.ok and res2.path == "F1")
  H.eq(res2.rolledBack, true)
end)

H.test("update: F2 — LOAD พัง / MIGRATE พัง (migration/replace/provider)", function()
  -- (ก) LOAD: bundle รุ่นใหม่ compile ไม่ผ่าน
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" } }
  state.broken = { ["SRC:0.3.0"] = true }
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local r1 = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r1.ok and r1.path == "F2", r1.detail)
  H.ok(r1.detail:find("LOAD") ~= nil)
  H.eq(r1.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")

  -- (ข) MIGRATE: migration chain พัง
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" },
    ["SRC:0.3.0"] = { version = "0.3.0", migrateFails = true } }
  state.broken = {}
  local upd2 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd2:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local r2 = upd2:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r2.ok and r2.path == "F2")
  H.ok(r2.detail:find("Migration") ~= nil)
  H.eq(upd2:Active().version, "0.2.0")

  -- (ค) MIGRATE: Replace พัง
  state.specs["SRC:0.3.0"] = { version = "0.3.0", replaceFails = true }
  local upd3 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd3:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local r3 = upd3:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r3.ok and r3.path == "F2")
  H.ok(r3.detail:find("Replace") ~= nil)

  -- (ง) MIGRATE: provider Apply พัง
  state.specs["SRC:0.3.0"] = { version = "0.3.0",
    providers = { { name = "P1", Serialize = function() return {} end,
      Apply = function() error("apply boom") end } } }
  local upd4 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd4:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local r4 = upd4:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not r4.ok and r4.path == "F2")
  H.ok(r4.detail:find("provider P1") ~= nil)

  -- ทุกรอบ: กลับมาใช้งานได้จริง (bus ไม่ frozen)
  for i, u in ipairs({ upd, upd2, upd3, upd4 }) do
    H.eq(u:Active().version, "0.2.0", ("รอบ %d ยังอยู่รุ่นเดิม"):format(i))
    H.ok(not u:Active().system.bus:Stats().frozen, ("รอบ %d ใช้งานต่อได้"):format(i))
  end
end)

H.test("update: F3 — SELFCHECK พัง = ROLLBACK + ยังใช้งานต่อได้", function()
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" },
    ["SRC:0.3.0"] = { version = "0.3.0",
      selfChecks = { { name = "boom", fn = function() return false, "จงใจให้พัง" end } } } }
  state.broken = {}
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not res.ok and res.path == "F3", res.detail)
  H.ok(res.detail:find("SELFCHECK") ~= nil)
  H.ok(res.detail:find("boom") ~= nil, "ระบุ check ที่พัง")
  H.eq(res.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")
  H.ok(not upd:Active().system.bus:Stats().frozen)
end)

H.test("update: F4 — ADAPTER PROBE dead = ROLLBACK (+ และถ้า rollback เองก็เจอ dead = broken)", function()
  -- (ก) รุ่นใหม่ probe dead → rollback สำเร็จ
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" },
    ["SRC:0.3.0"] = { version = "0.3.0", probeStatus = "dead", probeSummary = "PlayerAdapter ตาย" } }
  state.broken = {}
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not res.ok and res.path == "F4", res.detail)
  H.ok(res.detail:find("ADAPTER PROBE") ~= nil)
  H.eq(res.rolledBack, true)
  H.eq(upd:Active().version, "0.2.0")

  -- (ข) rollback เองก็เจอ dead (เกมเปลี่ยนจริง) = broken เสียงดัง ไม่แอบอ้าง
  state.specs["SRC:0.2.0"] = { version = "0.2.0", probeStatus = "dead", probeSummary = "ตายทั้งคู่" }
  local upd2 = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  upd2:Attach({ system = makeFakeSystem(state.specs["SRC:0.2.0"]), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local res2 = upd2:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(not res2.ok, res2.detail)
  H.eq(res2.path, "F4+ROLLBACK-FAIL")
  H.eq(res2.broken, true)
  H.ok(res2.detail:find("No Silent Degradation") ~= nil)
  H.ok(upd2.broken ~= nil and upd2.broken.message ~= nil, "Status มี broken ให้เห็น")
  H.ok(res2.bugId ~= nil)

  -- (ค) ห้าม Apply ต่อโดยแอบอ้างว่าใช้ได้ — แต่ระบบเดิมที่ rollback ไม่สำเร็จ
  --    ต้องระบุ broken ชัด ๆ (Status)
  H.ok(upd2:Status().broken ~= nil)
end)

H.test("update: เวลาเกินงบ = บันทึกเป็น warning (ไม่ใช่เหตุ rollback)", function()
  state.specs = { ["SRC:0.2.0"] = { version = "0.2.0" }, ["SRC:0.3.0"] = { version = "0.3.0" } }
  state.broken = {}
  local upd = U.new({
    loadFn = loadFn, clock = makeClock(0.001), logger = function() end,
    budgetMs = 1, -- งบต่ำกว่าเวลาจริงของ protocol (~สิบ ๆ ms) → overBudget แน่นอน
  })
  upd:Attach({ system = makeFakeSystem({}), source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })
  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")))
  H.ok(res.ok, "เกินงบเวลา = warning ไม่ใช่ความพัง (อัปเดตสำเร็จ atomic อยู่)")
  H.ok(res.timing.overBudget, "flag overBudget ตรง")
  H.ok(#res.warnings >= 1 and res.warnings[1]:find("เกินงบ") ~= nil, "มี warning บอกตามจริง")
end)

H.test("update: สัญญา — Attach ไม่ครบ / Apply ก่อน Attach / ซ้อน protocol", function()
  local upd = U.new({ loadFn = loadFn, clock = makeClock(), logger = function() end })
  H.ok(pcall(upd.Apply, upd, "x", {}) == false, "Apply ก่อน Attach = error ชัด")
  H.ok(pcall(upd.Attach, upd, { system = { version = "1" } }) == false,
    "Attach ไม่ครบสัญญา = error ชัด (กันระบบไม่ตรง contract ผ่านเงียบ ๆ)")
end)

H.test("update: cleanup — คืน crypto stub ต้นฉบับให้ชุดถัดไป", function()
  crypto.hash = __origCryptoHash
  H.ok(type(crypto.hash) == "function", "คืนแล้ว")
end)
