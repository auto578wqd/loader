-- L1: Diagnostics (§8.4 รุ่นแรก) — gate เจ้าของโปรเจกต์: "ใช้งานได้ก่อน feature ใหญ่"
local H = PKG_harness
local Diag = PKG_diagnostics
local Bus = PKG_eventbus
local Registry = PKG_registry
local Boundary = PKG_boundary
local RuntimeLib = PKG_init

local function newStack()
  local R = RuntimeLib.new({
    clock = VTNow,
    task = task,
    drawing = Drawing,
    instance = Instance,
    debug = true,
  })
  local bus = Bus.new({ registry = R.Registry, boundary = R.Boundary, clock = VTNow, owner = "EventBus" })
  local diag = Diag.new({
    clock = VTNow,
    time = function() return 1790000000 end,
    bus = bus,
    registry = R.Registry,
    boundary = R.Boundary,
    capability = R.Capability,
  })
  return R, bus, diag
end

H.test("diag: Begin/End จับเวลาต่อโมดูล — min/avg/max/count", function()
  local _, _, diag = newStack()
  for i = 1, 3 do
    diag:Begin("VoidAim")
    __VT.advance(0.002) -- 2ms (เวลาเสมือน) ทุกรอบเท่ากัน
    diag:End("VoidAim")
  end
  local t = diag:Snapshot().timers["VoidAim"]
  H.eq(t.count, 3, "นับ 3 รอบ")
  H.ok(t.min > 0, "มีค่า min")
  H.ok(t.max >= t.min, "max >= min")
  H.almost(t.total, 3 * t.min, 1e-6, "รอบเท่ากัน 3 รอบ: total = 3 × min")
  local ms = diag:End("VoidAim") -- ไม่มี Begin คู่ = nil (idempotent ไม่พัง)
  H.eq(ms, nil, "End ไม่คู่ = nil ไม่ error")
end)

H.test("diag: Mark + MarkStartup + uptime", function()
  local _, _, diag = newStack()
  diag:MarkStartup(123.4)
  diag:Mark("hotUpdateMs", 2100)
  local s = diag:Snapshot()
  H.almost(s.marks.startupMs, 123.4, 0.001, "startupMs")
  H.almost(s.marks.hotUpdateMs, 2100, 0.001, "hotUpdateMs")
  H.eq(s.uptimeSec, 0, "uptime จาก startedAt")
end)

H.test("diag: Sample เก็บ ring buffer + จำกัดจำนวน (ย้อนหลัง 15 นาที)", function()
  local _, _, diag = newStack()
  diag:Sample()
  diag:Sample()
  diag:Sample()
  H.eq(diag:SampleCount(), 3, "เก็บ 3 sample")
  for _ = 1, Diag.MAX_SAMPLES + 10 do
    diag:Sample()
  end
  H.eq(diag:SampleCount(), Diag.MAX_SAMPLES, "จำกัดที่ MAX_SAMPLES (ตัดของเก่า)")
end)

H.test("diag: Snapshot รวมทุก section — registry/bus/boundary/capability/uptime", function()
  local R, bus, diag = newStack()
  R.Registry:Scope("M1", function()
    R.Registry:Spawn("loop", function(ctx)
      while ctx.ShouldRun() do
        task.wait(0.1)
      end
    end)
  end)
  bus:Declare("x:y", "drop")
  bus:Publish("x:y", {})
  diag:Sample()

  local s = diag:Snapshot()
  H.eq(s.registry.tasks, 1, "registry.tasks เห็น task ของ M1")
  H.eq(s.bus.published, 1, "bus.published ตรง")
  H.ok(type(s.boundaryCounters) == "table", "มี boundary counters")
  H.ok(s.capability ~= nil, "มี capability report (probe แล้วตอนสร้าง R? — ถ้าไม่มีก็ nil ได้ แต่ต้องไม่พัง)")
  H.ok(type(s.uptimeSec) == "number", "มี uptime")
  -- คืน resource กัน leak ข้ามเคส
  R.Registry:Release("M1")
end)

H.test("diag: SetAdapterHealth → Snapshot เห็น + Export แสดงทุก adapter", function()
  local _, _, diag = newStack()
  diag:SetAdapterHealth({
    status = "degraded",
    summary = "Adapter มีปัญหา: PlayerAdapter เสื่อม (GetBounty)",
    adapters = {
      PlayerAdapter = { status = "degraded", deadMethods = { "GetBounty" } },
      CameraAdapter = { status = "ok", deadMethods = {} },
    },
  })
  local s = diag:Snapshot()
  H.eq(s.adapterHealth.status, "degraded", "Snapshot เห็นสถานะ")
  local out = diag:Export()
  H.ok(out:find("PlayerAdapter") ~= nil, "Export แสดง adapter ที่เสื่อม")
  H.ok(out:find("GetBounty") ~= nil, "Export ระบุ method ที่ตาย")
  H.ok(out:find("CameraAdapter") ~= nil, "Export แสดง adapter ที่ ok ด้วย")
end)

H.test("diag: Export ครบทุก section หลัก + stack trace จาก boundary", function()
  local R, _, diag = newStack()
  -- ฉีด error 1 อันให้ boundary จับ (แล้ว Export ต้องเห็น)
  R.Boundary:Guard("TestModule", function()
    error("จำลองบั๊กในโมดูลทดสอบ")
  end)
  diag:MarkStartup(50)
  diag:Begin("VoidESP")
  diag:End("VoidESP")

  local out = diag:Export()
  H.ok(out:find("Diagnostics Export") ~= nil, "หัวรายงาน")
  H.ok(out:find("Registry") ~= nil, "section Registry (4 ชนิด)")
  H.ok(out:find("Event Bus") ~= nil, "section Event Bus")
  H.ok(out:find("Direct Services") ~= nil, "section Services")
  H.ok(out:find("Keybind") ~= nil, "section Keybind")
  H.ok(out:find("Error Boundary") ~= nil, "section Error Boundary")
  H.ok(out:find("TestModule") ~= nil, "ชื่อโมดูลที่พังปรากฏ")
  H.ok(out:find("จำลองบั๊กในโมดูลทดสอบ") ~= nil, "ข้อความ error ปรากฏ")
  H.ok(out:find("VoidESP") ~= nil, "ตัวจับเวลารายโมดูลปรากฏ")
  H.ok(out:find("จบรายงาน") ~= nil, "ท้ายรายงาน")
end)

H.test("diag: ExportToClipboard คัดลอกจริงเมื่อมี clipboard (คืนข้อความเสมอ)", function()
  local _, _, diag = newStack()
  local text, copied = diag:ExportToClipboard()
  H.ok(#text > 50, "คืนข้อความครบ")
  H.ok(copied, "stub มี setclipboard → copied = true")
  H.eq(__CLIP, text, "เนื้อหา clipboard ตรงกับข้อความ")
end)

H.test("diag: Shutdown ล้าง sample (resource ทั้งหมดอยู่ใน memory)", function()
  local _, _, diag = newStack()
  diag:Sample()
  diag:Shutdown()
  H.eq(diag:SampleCount(), 0, "ล้างแล้ว")
end)
