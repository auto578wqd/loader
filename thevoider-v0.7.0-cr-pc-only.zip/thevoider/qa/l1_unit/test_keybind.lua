-- L1: Keybind Service (§5.3) — bind/conflict/persist + trigger ผ่าน InputAdapter จริง
local H = PKG_harness
local Keybind = PKG_keybind
local Bus = PKG_eventbus
local Config = PKG_config
local Migration = PKG_migration
local Registry = PKG_registry
local Boundary = PKG_boundary
local InputAdapter = PKG_adapter_input
local RuntimeLib = PKG_init

local function newRuntime()
  return RuntimeLib.new({
    clock = VTNow,
    task = task,
    drawing = Drawing,
    instance = Instance,
    debug = true,
  })
end

local function newKeybind(R, bus, cfg)
  return Keybind.new({
    bus = bus,
    config = cfg,
    registry = R.Registry,
    boundary = R.Boundary,
    clock = VTNow,
    owner = "KeybindService",
  })
end

local function newConfigWithBus(bus)
  return Config.new({
    bus = bus,
    migration = Migration.new({ clock = VTNow }),
    clock = VTNow,
    time = function() return 1790000000 end,
  })
end

H.test("keybind: Bind + KeyOf + Actions", function()
  local R = newRuntime()
  local kb = newKeybind(R, Bus.new({ clock = VTNow }))
  H.ok(kb:Bind("toggle", "LeftControl"), "bind สำเร็จ")
  H.eq(kb:KeyOf("toggle"), "LeftControl", "KeyOf ตรง")
  H.eq(kb:Actions()[1], "toggle", "Actions มีรายการ")
end)

H.test("keybind: คีย์ชนกับ action อื่น = ปฏิเสธ + แจ้ง notify:user + ไม่เขียนทับ", function()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("notify:user", "idempotent")
  local notices = {}
  bus:On("notify:user", function(p) notices[#notices + 1] = p end)
  local kb = newKeybind(newRuntime(), bus)
  kb:Bind("toggle", "K")
  local ok, info = kb:Bind("panic", "K")
  H.ok(not ok, "ต้องปฏิเสธ")
  H.eq(info.conflictedWith, "toggle", "บอกว่าชนกับอะไร")
  H.eq(kb:KeyOf("panic"), nil, "ไม่มีการเขียนทับเงียบ ๆ")
  H.eq(kb:KeyOf("toggle"), "K", "ตัวเดิมอยู่ครบ")
  H.ok(#notices >= 1, "แจ้งผู้ใช้")
  H.eq(notices[1].key, "notify.keybind.conflict", "key ที่ i18n แปลได้")
end)

H.test("keybind: action ย้ายคีย์ใหม่ได้ — คีย์เก่าถูกปลดอัตโนมัติ", function()
  local kb = newKeybind(newRuntime(), Bus.new({ clock = VTNow }))
  kb:Bind("toggle", "K")
  kb:Bind("toggle", "L")
  H.eq(kb:KeyOf("toggle"), "L", "ผูกคีย์ใหม่")
  local ok, _ = kb:Bind("other", "K")
  H.ok(ok, "คีย์เก่า K ว่างแล้ว ผูกใหม่ได้")
end)

H.test("keybind: Unbind + คีย์คืนสู่อิสระ", function()
  local kb = newKeybind(newRuntime(), Bus.new({ clock = VTNow }))
  kb:Bind("toggle", "K")
  H.ok(kb:Unbind("toggle"), "unbind สำเร็จ")
  H.eq(kb:KeyOf("toggle"), nil, "ไม่มีคีย์แล้ว")
  H.ok(not kb:Unbind("toggle"), "unbind ซ้ำ = false (idempotent)")
end)

H.test("keybind: Bind → บันทึกลง config ทันที (ของผู้ใช้คือของมีค่า)", function()
  local bus = Bus.new({ clock = VTNow })
  local cfg = newConfigWithBus(bus)
  cfg:Load()
  local kb = newKeybind(newRuntime(), bus, cfg)
  kb:Bind("toggle", "K")
  H.eq(cfg:Get("Keybinds.toggle"), "K", "เข้า config จริง")
  kb:Unbind("toggle")
  H.eq(cfg:Get("Keybinds.toggle"), nil, "unbind เอาออกจาก config จริง")
end)

H.test("keybind: LoadFromConfig กู้ binding จาก config + แจ้งจำนวน", function()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("notify:user", "idempotent")
  local cfg = newConfigWithBus(bus)
  cfg:Load()
  cfg:Set("Keybinds.toggle", "K")
  cfg:Set("Keybinds.panic", "P")
  local kb = newKeybind(newRuntime(), bus, cfg)
  local n = kb:LoadFromConfig()
  H.eq(n, 2, "กู้ได้ 2 รายการ")
  H.eq(kb:KeyOf("toggle"), "K", "toggle=K")
  H.eq(kb:KeyOf("panic"), "P", "panic=P")
end)

H.test("keybind: OnAction subscription เป็น temp ของโมดูล (orphan=0 §3.4)", function()
  local R = newRuntime()
  local kb = newKeybind(R, Bus.new({ clock = VTNow }))
  local h
  R.Registry:Scope("M1", function()
    h = kb:OnAction("toggle", function() end)
  end)
  H.eq(R.Registry:Snapshot("M1").temps, 1, "นับเป็น temp ของ M1")
  R.Registry:Release("M1")
  H.eq(R.Registry:Snapshot("M1").temps, 0, "คืนอัตโนมัติ")
end)

H.test("keybind: AttachInput + กดคีย์จริงผ่าน InputAdapter → action ทำงาน (end-to-end)", function()
  __GAME.reset()
  local R = newRuntime()
  local bus = Bus.new({ clock = VTNow })
  local kb = newKeybind(R, bus)
  kb:Bind("toggle", "K")

  local input = InputAdapter.new({ env = { game = game }, runtime = R })
  kb:AttachInput(input)

  local fired = 0
  R.Registry:Scope("M1", function()
    kb:OnAction("toggle", function() fired = fired + 1 end)
  end)

  __GAME.pressKey("K")   -- กดลง
  __GAME.releaseKey("K") -- ปล่อย (ต้องไม่ fire ซ้ำ)
  H.eq(fired, 1, "action ทำงาน 1 ครั้งจากการกด 1 ครั้ง (ไม่นับตอนปล่อย)")

  -- connection ของ KeybindService ต้องถูกลงทะเบียนในชื่อ node
  local snap = R.Registry:Snapshot("KeybindService")
  H.eq(snap.connections, 2, "InputBegan+InputEnded ของ KeybindService = 2 connection")
  kb:Shutdown()
  local okZero = R.Registry:VerifyZero("KeybindService")
  H.ok(okZero, "หลัง Shutdown ของ KeybindService ต้อง orphan=0")
end)

H.test("keybind: AttachInput ซ้ำ = error + Stats", function()
  __GAME.reset()
  local R = newRuntime()
  local kb = newKeybind(R, Bus.new({ clock = VTNow }))
  local input = InputAdapter.new({ env = { game = game }, runtime = R })
  kb:AttachInput(input)
  local ok = pcall(kb.AttachInput, kb, input)
  H.ok(not ok, "ห้ามต่อซ้ำ")
  local s = kb:Stats()
  H.ok(s.inputAttached, "Stats บอกต่อแล้ว")
  H.ok(type(s.actions) == "number", "Stats มี actions")
  kb:Shutdown()
end)

H.test("keybind: Trigger — ปุ่มลัดมือถือจำลองการกดผ่าน path เดียวกัน", function()
  local R = newRuntime()
  local kb = newKeybind(R, Bus.new({ clock = VTNow }))
  kb:Bind("toggle", "K")
  local fired = 0
  -- ตามกติกา: โมดูลสมัคร listener ภายใต้ Scope ของตัวเองเสมอ (§3.4)
  R.Registry:Scope("M1", function()
    kb:OnAction("toggle", function() fired = fired + 1 end)
  end)
  kb:Trigger("toggle")
  H.eq(fired, 1, "Trigger เดิน path เดียวกับกดคีย์จริง")
  H.eq(R.Registry:Snapshot("M1").temps, 1, "subscription นับเป็นของ M1")
end)
