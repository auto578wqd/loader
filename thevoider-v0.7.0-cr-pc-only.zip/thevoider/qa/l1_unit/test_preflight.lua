-- L1: Bootstrap Preflight (§3.2 ข้อ 0) — plain text + หยุด + ไม่มี UI
local H = PKG_harness
local Pre = PKG_preflight

H.test("preflight: ไม่มี HTTP function → fail ขั้น http_function + ข้อความไทย 1 บรรทัด", function()
  local lines = {}
  local r = Pre.Run({
    env = {}, -- ไม่มี http function เลย
    urls = { "https://example.test/1" },
    log = function(m) table.insert(lines, m) end,
  })
  H.ok(not r.ok)
  H.eq(r.stage, "http_function")
  H.eq(#lines, 1, "ต้องแจ้ง plain text 1 บรรทัดพอดี")
  H.ok(lines[1]:find("The Voider", 1, true), "ต้องมีชื่อสคริปต์")
  H.ok(lines[1]:find("HTTP", 1, true), "ต้องบอกสาเหตุ HTTP")
  H.ok(lines[1]:find("Volt", 1, true), "ต้องบอกขอบเขต Volt เท่านั้น")
end)

H.test("preflight: มี http_request + CDN ตอบ 200 → ok + คืน httpFn ให้ loader ใช้ต่อ", function()
  local env = {
    http_request = function(req)
      return { StatusCode = 200, Body = "ok" }
    end,
  }
  local r = Pre.Run({ env = env, urls = { "https://a.test/1" }, log = function() end })
  H.ok(r.ok)
  H.eq(r.stage, "done")
  H.eq(r.httpName, "http_request")
  H.eq(r.url, "https://a.test/1")
  H.ok(type(r.httpFn) == "function")
end)

H.test("preflight: URL แรกล่ม ตัวที่สองผ่าน → ใช้ตัวที่สอง (fallback 4-URL)", function()
  local calls = {}
  local env = {
    http_request = function(req)
      table.insert(calls, req.Url)
      if #calls == 1 then
        return { StatusCode = 503, Body = "" }
      end
      return { StatusCode = 200, Body = "ok" }
    end,
  }
  local r = Pre.Run({
    env = env,
    urls = { "https://a.test/1", "https://b.test/2" },
    log = function() end,
  })
  H.ok(r.ok)
  H.eq(r.url, "https://b.test/2")
  H.eq(#calls, 2, "ต้องไล่ตามลำดับจนกว่าจะได้")
end)

H.test("preflight: HTTP มีแต่ CDN เข้าไม่ได้ทั้งหมด → fail ขั้น cdn + ข้อความไทย", function()
  local lines = {}
  local env = {
    http_request = function(req)
      return { StatusCode = 0, Body = "" }
    end,
  }
  local r = Pre.Run({
    env = env,
    urls = { "https://a.test/1", "https://b.test/2" },
    log = function(m) table.insert(lines, m) end,
  })
  H.ok(not r.ok)
  H.eq(r.stage, "cdn")
  H.eq(#lines, 1)
  H.ok(lines[1]:find("CDN", 1, true) or lines[1]:find("GitHub", 1, true))
end)

H.test("preflight: syn.request ทางเลือกใช้ได้ (ชื่อไหนก็ตาม executor รองรับ)", function()
  local env = {
    syn = {
      request = function(req)
        return { StatusCode = 200, Body = "ok" }
      end,
    },
  }
  local r = Pre.Run({ env = env, urls = { "https://a.test/1" }, log = function() end })
  H.ok(r.ok)
  H.eq(r.httpName, "syn.request")
end)

H.test("preflight: GET-only API (httpget คืน string) ก็ใช้ได้", function()
  local env = {
    httpget = function(url) return "file-content-here" end,
  }
  local r = Pre.Run({ env = env, urls = { "https://a.test/1" }, log = function() end })
  H.ok(r.ok)
  H.eq(r.httpName, "httpget")
end)

H.test("preflight: http_request โยน error กับ URL แรก (มีชื่อแต่พัง) → ไป URL ถัดไปได้", function()
  local env = {
    http_request = function(req)
      if req.Url:find("/1") then
        error("connection refused")
      end
      return { StatusCode = 200, Body = "ok" }
    end,
  }
  local r = Pre.Run({
    env = env,
    urls = { "https://a.test/1", "https://a.test/2" },
    log = function() end,
  })
  H.ok(r.ok)
  H.eq(r.url, "https://a.test/2", "ต้องไปต่อที่ URL ถัดไปเมื่อตัวแรกเรียกพัง")
  H.eq(r.httpName, "http_request")
end)
