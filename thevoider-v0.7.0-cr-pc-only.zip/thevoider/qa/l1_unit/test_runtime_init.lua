-- L1: Runtime ประกอบรวม (init.lua) — Bootstrap + ใช้งานจริงย่อ + ShutdownAll สะอาด
local H = PKG_harness
local RuntimeLib = PKG_init

local function newRuntime()
  return RuntimeLib.new({
    task = task,
    drawing = Drawing,
    instance = Instance,
    clock = VTNow,
  })
end

H.test("runtime: Bootstrap — probe 8 capability + ติด watchdog monitor + อ่านลำดับจาก graph จริง", function()
  local R = newRuntime()
  R:Bootstrap()
  H.ok(R.Capability.report ~= nil, "ต้อง probe แล้ว")
  H.eq(R.Snapshot("Runtime.Watchdog").tasks, 1, "monitor ต้องทำงาน")
  H.eq(#R.Shutdown.order, 38, "ลำดับ shutdown มาจาก graph 38 node (CR-PC-ONLY: ตัด MobileLayout 39→38)")
  H.eq(R.Shutdown.order[1], "BootstrapPreflight", "ลำดับ = initOrder")
  R:ShutdownAll()
  local ok, snap = R.VerifyZero()
  H.ok(ok, "หลัง ShutdownAll ต้องเหลือ 0 (total=" .. snap.total .. ")")
end)

H.test("runtime: ใช้งานจริงย่อ — โมดูล 2 ตัว + หายใจผ่าน ShouldRun + ปิดสะอาดตาม graph", function()
  local R = newRuntime()
  R:Bootstrap()

  -- โมดูลจำลอง VoidAim (มีชื่อใน graph L5) — lifecycle ผ่าน Runtime ทั้งหมด
  R.Shutdown:Register("VoidAim", {
    Disable = function() end,
    Destroy = function()
      R.Release("VoidAim")
    end,
  })
  R.Watchdog:Register("VoidAim", { period = 0.5 })
  R.Scope("VoidAim", function()
    R.Spawn("aimloop", function(ctx)
      while ctx.ShouldRun() do task.wait(0.1) end
    end)
    R.Spawn("renderloop", function(ctx)
      while ctx.ShouldRun() do task.wait(0.2) end
    end)
  end)

  -- โมดูลจำลอง VoidESP — มีทั้ง task + render + connection ครบ 3 ชนิด
  local sig = __newSignal("EspTick")
  R.Shutdown:Register("VoidESP", {
    Disable = function() end,
    Destroy = function()
      R.Release("VoidESP")
    end,
  })
  R.Watchdog:Register("VoidESP", { period = 0.5 })
  R.Scope("VoidESP", function()
    R.Spawn("esploop", function(ctx)
      while ctx.ShouldRun() do task.wait(0.15) end
    end)
    R.NewRender("Circle", { Thickness = 1 })
    R.Connect(sig, function() end)
  end)

  __VT.advance(2)
  H.eq(R.Snapshot("VoidAim").tasks, 2)
  local espSnap = R.Snapshot("VoidESP")
  H.eq(espSnap.tasks, 1)
  H.eq(espSnap.renders, 1)
  H.eq(espSnap.connections, 1)

  -- ทั้งสองโมดูลยังหายใจ → watchdog ไม่มี action
  H.ok(R.Watchdog:Entry("VoidAim") ~= nil, "ยังถูกเฝ้าอยู่")

  -- hot update VERIFY ใช้ ModuleTotals: นับเฉพาะโมดูล (ไม่รวม monitor ของ Runtime)
  H.eq(R.ModuleTotals().total, 5, "VoidAim task2 + VoidESP task1+render1+conn1 = 5")

  local report = R.ShutdownAll()
  H.ok(report.ok, "orphan 0 ทุก node ที่ลงทะเบียน")
  H.ok(R.VerifyZero(), "registry ว่างสนิทหลังปิดทั้งหมด")
  H.eq(R.ModuleTotals().total, 0)
end)

H.test("runtime: โมดูลเงียบ → watchdog restart → ฟื้นไม่ได้ → ปิด — จบด้วย ShutdownAll สะอาด", function()
  local R = newRuntime()
  R:Bootstrap()
  local events = {}
  R.Shutdown:Register("Race", {
    Disable = function() table.insert(events, "disable") end,
    Destroy = function()
      R.Release("Race")
    end,
  })
  R.Watchdog:Register("Race", {
    period = 1,
    onRestart = function(owner, n) table.insert(events, "restart" .. n) end,
    onDisable = function(owner, reason)
      table.insert(events, "closed:" .. reason)
    end,
  })
  -- ไม่ spawn loop = เงียบสนิท
  __VT.advance(10)
  H.eq(events[1], "restart1", "ต้อง restart ก่อน (ได้ " .. table.concat(events, ",") .. ")")
  H.ok(table.concat(events, ","):find("closed:stalled-after-restart", 1, true) ~= nil,
    "ยังเงียบ = ปิด + แจ้งเหตุผล (events=" .. table.concat(events, ",") .. ")")
  R:ShutdownAll()
  H.ok(R.VerifyZero())
end)

H.test("runtime: ลายเซ็น API ตรงแผน §3.2 — Spawn/Connect/NewRender/Temp คืน handle ทั้ง 4 ชนิด", function()
  local R = newRuntime()
  R:Bootstrap()
  local sig = __newSignal("Sig")
  local h1, h2, h3, h4
  R.Scope("APITest", function()
    h1 = R.Spawn("t", function(ctx) while ctx.ShouldRun() do task.wait(1) end end)
    h2 = R.Connect(sig, function() end)
    h3 = R.NewRender("Text", { Text = "hi" })
    h4 = R.Temp({ m = 1 }, function() end)
  end)
  H.ok(h1 and h2 and h3 and h4, "ทั้ง 4 API ต้องคืน handle")
  H.ok(h1.__registry_handle and h2.__registry_handle and h3.__registry_handle and h4.__registry_handle)
  H.eq(h3.obj.Text, "hi")
  R.Release("APITest")
  H.ok(R.VerifyZero("APITest"))
  R:ShutdownAll()
  H.ok(R.VerifyZero())
end)
