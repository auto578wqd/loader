-- L1: Watchdog (§3.2 ข้อ 4) — stall → restart 1 ครั้ง → ปิด + backoff + ไม่ลาม
local H = PKG_harness
local Registry = PKG_registry
local Boundary = PKG_boundary
local Watchdog = PKG_watchdog

local function newWD()
  local reg = Registry.new({ task = task, drawing = Drawing, instance = Instance, clock = VTNow })
  local bnd = Boundary.new({ clock = VTNow })
  reg:SetBoundary(bnd)
  local wd = Watchdog.new({ clock = VTNow, checkInterval = 0.25, stallFactor = 3 })
  wd:SetRegistry(reg)
  wd:SetBoundary(bnd)
  reg:SetWatchdog(wd)
  return reg, bnd, wd
end

H.test("watchdog: โมดูลหายใจปกติ (loop ผ่าน ShouldRun) → ไม่มี action ใดตลอด 10 วิ", function()
  local reg, bnd, wd = newWD()
  local restarts, disables = 0, 0
  wd:Register("Healthy", {
    period = 1,
    onRestart = function() restarts = restarts + 1 end,
    onDisable = function() disables = disables + 1 end,
  })
  wd:Start()
  reg:Scope("Healthy", function()
    reg:Spawn("hb", function(ctx)
      while ctx.ShouldRun() do task.wait(0.5) end
    end)
  end)
  __VT.advance(10)
  H.eq(restarts, 0, "หายใจปกติต้องไม่ถูก restart")
  H.eq(disables, 0, "หายใจปกติต้องไม่ถูกปิด")
  wd:Stop()
  reg:Release(nil)
end)

H.test("watchdog: เงียบเกิน threshold → restart 1 ครั้งก่อน (ไม่ปิดทันที)", function()
  local reg, bnd, wd = newWD()
  local restarts, disables = 0, 0
  wd:Register("Stalled", {
    period = 1,
    onRestart = function() restarts = restarts + 1 end,
    onDisable = function() disables = disables + 1 end,
  })
  wd:Start()
  -- ไม่ spawn อะไรเลย = เงียบสนิท (threshold 1x3 = 3 วิ)
  __VT.advance(3.4)
  H.eq(restarts, 1, "ต้อง restart 1 ครั้งพอดี (ได้ " .. restarts .. ")")
  H.eq(disables, 0, "ยังไม่ disable ทันที")
  -- หลัง restart ยังเงียบต่อ → threshold แรม 2 เท่า (3x2=6) → ปิด
  __VT.advance(7)
  H.eq(restarts, 1, "ไม่ restart ซ้ำเกินโควตา")
  H.eq(disables, 1, "restart แล้วยังเงียบ = ปิด + แจ้ง")
  wd:Stop()
  reg:Release(nil)
end)

H.test("watchdog: restart แล้วกลับมาหายใจ → ไม่ถูกปิด + ยังเฝ้าต่อ", function()
  local reg, bnd, wd = newWD()
  local disables = 0
  wd:Register("Recover", {
    period = 1,
    onRestart = function(owner)
      -- จำลอง ModuleManager re-enable: เปิด loop หายใจใหม่
      reg:Scope(owner, function()
        reg:Spawn("hb2", function(ctx)
          while ctx.ShouldRun() do task.wait(0.5) end
        end)
      end)
    end,
    onDisable = function() disables = disables + 1 end,
  })
  wd:Start()
  __VT.advance(12)
  H.eq(disables, 0, "ฟื้นแล้วต้องไม่ถูกปิด (disables=" .. disables .. ")")
  H.ok(wd:Entry("Recover") ~= nil, "ยังต้องถูกเฝ้าต่อ")
  wd:Stop()
  reg:Release(nil)
end)

H.test("watchdog: backoff — พังซ้ำแล้วสมัครใหม่ → threshold แรมขึ้น (กัน infinite restart)", function()
  local reg, bnd, wd = newWD()
  local restarts, disables = 0, 0
  local function enroll()
    wd:Register("Flappy", {
      period = 1,
      onRestart = function() restarts = restarts + 1 end,
      onDisable = function() disables = disables + 1 end,
    })
  end
  enroll()
  wd:Start()
  __VT.advance(3.4) -- restart #1 (threshold 3)
  __VT.advance(7)   -- disable #1 (threshold 6)
  H.eq(disables, 1)
  H.eq(restarts, 1)
  enroll() -- พังซ้ำ/เปิดใหม่ → history x2 = threshold 6
  __VT.advance(3.4)
  H.eq(restarts, 1, "ต้องไม่ restart เร็วเหมือนเดิม (backoff ทำงาน)")
  __VT.advance(3)
  H.eq(restarts, 2, "พ้น threshold ใหม่ (6 วิ) จึง restart ได้")
  wd:Stop()
  reg:Release(nil)
end)

H.test("watchdog: onRestart พังเอง → ไปทางปิดทันที (ไม่ลาม ไม่ค้าง)", function()
  local reg, bnd, wd = newWD()
  local disables = 0
  wd:Register("Broken", {
    period = 1,
    onRestart = function() error("cannot restart") end,
    onDisable = function() disables = disables + 1 end,
  })
  wd:Start()
  __VT.advance(3.4)
  H.eq(disables, 1, "restart ไม่ได้ = ปิดเลย")
  H.ok(bnd:Count("Runtime.Watchdog") >= 1, "error ของ restart ต้องถูกบันทึกที่ Runtime.Watchdog")
  wd:Stop()
  reg:Release(nil)
end)

H.test("watchdog: Stop() → monitor หยุด + คืนทรัพยากรตัวเอง (orphan=0 เช่นกัน)", function()
  local reg, bnd, wd = newWD()
  wd:Register("X", { period = 1 })
  wd:Start()
  H.eq(reg:Snapshot("Runtime.Watchdog").tasks, 1, "monitor ต้องทำงาน")
  wd:Stop()
  __VT.advance(0.3)
  local ok, snap = reg:VerifyZero("Runtime.Watchdog")
  H.ok(ok, "monitor ต้องคืนทรัพยากร (tasks=" .. snap.tasks .. ")")
end)

H.test("watchdog: Beat ก่อน/หลัง Unregister ไม่พัง (เผื่อโมดูล beat ช้ากว่าปิด)", function()
  local reg, bnd, wd = newWD()
  wd:Register("Late", { period = 1 })
  wd:Beat("Late")
  wd:Unregister("Late")
  wd:Beat("Late") -- ไม่มี entry แล้ว — ต้อง no-op ไม่ error
  H.ok(true)
  reg:Release(nil)
end)
