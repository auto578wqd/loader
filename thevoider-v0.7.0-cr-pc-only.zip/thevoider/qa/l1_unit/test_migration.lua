-- L1: Migration Service (§3.7) — ลูกโซ่ทีละขั้น ห้ามข้าม + idempotent + ห้ามทิ้งข้อมูล
-- (gate ของเจ้าของโปรเจกต์: "config migration ต้องทดสอบย้อนกลับ" — ส่วน end-to-end อยู่ test_config)
local H = PKG_harness
local Migration = PKG_migration

-- migration จำลอง 3 ขั้นสำหรับทดสอบกลไก: v1→v2→v3→v4
local function chainOf3()
  local m = Migration.new({ clock = VTNow })
  m:Register(1, function(cfg)
    cfg.b = cfg.a -- ย้าย a → b
    cfg.a = nil
    return cfg
  end)
  m:Register(2, function(cfg)
    cfg.c = cfg.b * 10 -- b → c (สะสม)
    return cfg
  end)
  m:Register(3, function(cfg)
    cfg.d = cfg.c + 1
    return cfg
  end)
  return m
end

H.test("migration: ลูกโซ่ v1→v4 รันครบทุกขั้นตามลำดับ", function()
  local m = chainOf3()
  local cfg = { schemaVersion = 1, a = 5 }
  cfg = m:Run(cfg, 4)
  H.eq(cfg.schemaVersion, 4, "ถึงเวอร์ชันเป้าหมาย")
  H.eq(cfg.b, 5, "ขั้น 1: a→b")
  H.eq(cfg.c, 50, "ขั้น 2: b*10→c")
  H.eq(cfg.d, 51, "ขั้น 3: c+1→d")
  H.eq(#m:LastRun().steps, 3, "รัน 3 ขั้นจริง")
  H.ok(not m:LastRun().noop, "ไม่ใช่ no-op")
end)

H.test("migration: ห้ามข้ามขั้น — ขั้นขาดกลางลูกโซ่ = error ทันที", function()
  local m = Migration.new({ clock = VTNow })
  m:Register(1, function(cfg) return cfg end)
  m:Register(3, function(cfg) return cfg end) -- ขาด 2→3
  local ok, err = pcall(m.Run, m, { schemaVersion = 1 }, 4)
  H.ok(not ok, "ต้อง error")
  H.ok(tostring(err):find("v2→v3") ~= nil, "error ต้องระบุขั้นที่ขาด")
  H.ok(tostring(err):find("ห้ามข้าม") ~= nil, "อ้างกฎห้ามข้ามขั้น (§3.7)")
end)

H.test("migration: idempotent — Run กับ config รุ่นล่าสุดแล้ว = no-op เป๊ะ (ตารางเดิมไม่ถูกแตะ)", function()
  local m = chainOf3()
  local cfg = { schemaVersion = 4, keep = "ต้นฉบับ" }
  local same = m:Run(cfg, 4)
  H.ok(same == cfg, "คืนตารางเดียวกัน (reference เดิม)")
  H.eq(cfg.keep, "ต้นฉบับ", "ข้อมูลไม่ถูกแตะ")
  H.ok(m:LastRun().noop, "รายงาน no-op")
  H.eq(#m:LastRun().steps, 0, "ไม่มีขั้นถูกรัน")
end)

H.test("migration: idempotent — migrate แล้ว migrate ซ้ำรอบสอง = ไม่เปลี่ยนผลลัพธ์เพิ่ม", function()
  local m = chainOf3()
  local cfg = m:Run({ schemaVersion = 1, a = 5 }, 4)
  H.eq(cfg.d, 51, "รอบแรก d=51")
  local cfg2 = m:Run(cfg, 4) -- รอบสอง (จำลองโหลดซ้ำ)
  H.ok(cfg2 == cfg, "คืนตารางเดิม")
  H.eq(cfg2.d, 51, "ค่าไม่เปลี่ยนเพิ่ม (ไม่ทวีคูณ)")
end)

H.test("migration: Keep — ค่าเก่าถูกเก็บใน _legacy ไม่ทิ้ง (ห้ามทิ้ง §3.7)", function()
  local m = Migration.new({ clock = VTNow })
  m:Register(1, function(cfg)
    m.Keep(cfg, "oldName", cfg.oldName)
    cfg.oldName = nil
    return cfg
  end)
  local cfg = m:Run({ schemaVersion = 1, oldName = "ของมีค่าของผู้ใช้" }, 2)
  H.eq(cfg.oldName, nil, "key เก่าถูกถอดออก")
  H.eq(cfg._legacy["oldName"], "ของมีค่าของผู้ใช้", "แต่ค่าถูกเก็บใน _legacy ครบ")
end)

H.test("migration: step พังกลางลูกโซ่ = error พร้อมชื่อขั้น (ไม่กลืนเงียบ)", function()
  local m = Migration.new({ clock = VTNow })
  m:Register(1, function(cfg) error("แหล่งข้อมูลเกมเปลี่ยน") end)
  local ok, err = pcall(m.Run, m, { schemaVersion = 1 }, 2)
  H.ok(not ok, "ต้อง error")
  H.ok(tostring(err):find("v1→v2") ~= nil, "บอกขั้นที่พัง")
  H.ok(tostring(err):find("แหล่งข้อมูลเกมเปลี่ยน") ~= nil, "บอนข้อความต้นเหตุ")
end)

H.test("migration: schemaVersion ไม่ใช่ตัวเลข = error (ไฟล์เสีย — ผู้เรียกจัด fallback)", function()
  local m = Migration.new({ clock = VTNow })
  local ok = pcall(m.Run, m, { schemaVersion = "สอง" }, 2)
  H.ok(not ok, "ต้อง error")
end)

H.test("migration: ลงทะเบียนขั้นซ้ำ = error + Steps รายงานครบ", function()
  local m = Migration.new({ clock = VTNow })
  m:Register(1, function(cfg) return cfg end)
  local ok = pcall(m.Register, m, 1, function(cfg) return cfg end)
  H.ok(not ok, "ซ้ำต้อง error")
  H.eq(table.concat(m:Steps(), ","), "v1→v2", "Steps รายงานถูก")
  H.eq(m:Latest(), 2, "Latest = 2")
end)
