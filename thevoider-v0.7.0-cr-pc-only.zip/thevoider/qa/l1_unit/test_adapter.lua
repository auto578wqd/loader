-- L1: Game Adapter 6 API + Self-Probe + graceful degradation (§3.3 ทั้ง 3 กฎ)
local H = PKG_harness
local RuntimeLib = PKG_init
local BusLib = PKG_eventbus
local PlayerAdapter = PKG_adapter_player
local CharacterAdapter = PKG_adapter_character
local CombatAdapter = PKG_adapter_combat
local CameraAdapter = PKG_adapter_camera
local InputAdapter = PKG_adapter_input
local WorldAdapter = PKG_adapter_world
local SelfProbe = PKG_adapter_probe

local ENV = { game = game, workspace = workspace }

local function newAdapters(R)
  local player = PlayerAdapter.new({ env = ENV })
  local character = CharacterAdapter.new({ env = ENV, playerAdapter = player })
  local combat = CombatAdapter.new({ env = ENV, playerAdapter = player, characterAdapter = character })
  local camera = CameraAdapter.new({ env = ENV })
  local input = InputAdapter.new({ env = ENV, runtime = R })
  local world = WorldAdapter.new({ env = ENV, playerAdapter = player })
  return player, character, combat, camera, input, world
end

local function newProbe(R, adapters)
  return SelfProbe.new({
    adapters = adapters,
    graph = R and R.Graph or PKG_graph,
    bus = adapters.__bus,
    time = function() return 1790000000 end,
  })
end

-- ==== โลกปกติ: ทุก API ทำงาน =================================================

H.test("adapter/player: GetLocalPlayer + GetBounty/GetLevel/GetTeam/GetStats", function()
  __GAME.reset()
  local p = PlayerAdapter.new({ env = ENV })
  local lp = p:GetLocalPlayer()
  H.ok(lp, "ได้ LocalPlayer")
  H.eq(p:GetBounty(lp), 5000, "Bounty จาก leaderstats")
  H.eq(p:GetLevel(lp), 100, "Level จาก leaderstats")
  H.eq(p:GetTeam(lp), "Pirates", "Team")
  local stats = p:GetStats(lp)
  H.eq(stats.name, "TestUser", "GetStats รวมครบ")
  H.eq(stats.bounty, 5000, "GetStats.bounty")
end)

H.test("adapter/character: GetCharacter/GetRoot/IsAlive/GetState/GetMoveDirection", function()
  __GAME.reset()
  local p, c = newAdapters()
  local lp = p:GetLocalPlayer()
  H.ok(c:GetCharacter(lp), "ได้ Character")
  H.ok(c:GetRoot(lp), "ได้ HumanoidRootPart")
  H.eq(c:IsAlive(lp), true, "มีชีวิต (Health=100)")
  local st = c:GetState(lp)
  H.eq(st.alive, true, "state.alive")
  H.eq(st.health, 100, "state.health")
  H.eq(st.state, "Running", "state ชื่อ humanoid normalize เป็น string")
  H.ok(c:GetMoveDirection(lp), "ได้ MoveDirection (Vector3)")
end)

H.test("adapter/combat: GetEquippedWeapon + FireSkill ส่ง remote จริง + GetRemotes", function()
  __GAME.reset()
  local p, c, combat = newAdapters()
  local w = combat:GetEquippedWeapon()
  H.eq(w.name, "Katana", "อาวุธที่ถือ (Tool แรก)")
  local okFire = combat:FireSkill("Z")
  H.ok(okFire, "FireSkill ผ่าน remote สำเร็จ")
  H.eq(__GAME.remoteCallCount("Skill"), 1, "remote ถูกเรียกจริง 1 ครั้ง")
  local remotes = combat:GetRemotes()
  H.ok(#remotes >= 1, "เห็น remote ที่รู้จัก")
  -- cooldown = PENDING โปร่งใส (ไม่แอบอ้างว่าใช้ได้)
  local cd, err = combat:GetSkillCooldown("Z")
  H.eq(cd, nil, "cooldown ยังไม่มีค่า")
  H.eq(err.code, "PENDING", "ระบุ PENDING ชัดเจน")
end)

H.test("adapter/combat: FireSkill ค่าผิด = ERROR / มือเปล่า = nil ไม่ใช่ error", function()
  __GAME.reset()
  local _, _, combat = newAdapters()
  local ok, err = combat:FireSkill("")
  H.ok(not ok, "skill ว่าง = ปฏิเสธ")
  H.eq(err.code, "ERROR", "code ERROR (ไม่ใช่ GONE)")
  -- ปลดอาวุธ: สร้าง player ไม่มี Tool
  local bare = __GAME.makePlayer("BareHands", 999, {})
  H.eq(combat:GetEquippedWeapon(bare), nil, "มือเปล่า = nil (ค่าปกติ)")
end)

H.test("adapter/camera: GetPosition/GetLookVector/GetFOV + SetLock=PENDING โปร่งใส", function()
  __GAME.reset()
  local cam = CameraAdapter.new({ env = ENV })
  H.almost(cam:GetPosition().Z, -12, 0.001, "ตำแหน่งกล้อง")
  H.almost(cam:GetLookVector().Z, 1, 0.001, "ทิศกล้อง")
  H.eq(cam:GetFOV(), 70, "FOV")
  local ok, err = cam:SetLock(nil)
  H.ok(not ok, "SetLock ยังไม่ทำ")
  H.eq(err.code, "PENDING", "ระบุ PENDING + เฟสที่จะมา")
  local _, err2 = cam:WorldToScreen(nil)
  H.eq(err2.code, "PENDING", "WorldToScreen PENDING เช่นกัน")
end)

H.test("adapter/input: IsKeyDown + OnInput ได้ down/up + KeyboardEnabled", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance })
  local input = InputAdapter.new({ env = ENV, runtime = R })
  H.eq(input:IsKeyDown("E"), false, "ยังไม่กด = false")
  H.eq(input:KeyboardEnabled(), true, "คีย์บอร์ดเปิด")
  local events = {}
  R.Registry:Scope("M1", function()
    input:OnInput(function(inp)
      events[#events + 1] = inp
    end)
  end)
  __GAME.pressKey("E")
  __GAME.releaseKey("E")
  H.eq(#events, 2, "ได้ 2 event (down + up)")
  H.eq(events[1].key, "E", "normalize ชื่อคีย์")
  H.eq(events[1].state, "down", "state down ก่อน")
  H.eq(events[2].state, "up", "state up ตามหลัง")
  H.eq(events[1].inputType, "Keyboard", "inputType Keyboard")
  -- connection เป็นของ M1
  H.eq(R.Registry:Snapshot("M1").connections, 2, "2 connection ของ M1")
  R.Registry:Release("M1")
end)

H.test("adapter/world: GetPlayers/GetOthers/GetServerInfo/RaycastClear/GetDistance", function()
  __GAME.reset()
  local p, _, _, _, _, world = newAdapters()
  H.eq(#world:GetPlayers(), 3, "ผู้เล่น 3 คน")
  H.eq(#world:GetOthers(), 2, "ผู้เล่นอื่น 2 (ไม่รวม local)")
  local info = world:GetServerInfo()
  H.eq(info.playerCount, 3, "server info นับถูก")
  -- raycast คุมผลผ่าน handler
  __GAME.raycastHandler = function() return { hit = true } end
  H.eq(world:RaycastClear(Vector3.new(0, 5, 0), Vector3.new(0, 5, 10)), false, "มีของบัง = ไม่โล่ง")
  __GAME.raycastHandler = function() return nil end
  H.eq(world:RaycastClear(Vector3.new(0, 5, 0), Vector3.new(0, 5, 10)), true, "ทะลุ = โล่ง")
  local d = world:GetDistance(Vector3.new(0, 0, 0), Vector3.new(3, 4, 0))
  H.almost(d, 5, 0.001, "ระยะทาง 3-4-5")
end)

-- ==== Self-Probe รวม =========================================================

H.test("adapter/probe: โลกครบ → ทั้ง 6 adapter status ok + summary ครบ", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance })
  local p, c, combat, cam, input, world = newAdapters(R)
  local bus = BusLib.new({ clock = VTNow })
  local probe = SelfProbe.new({
    adapters = {
      PlayerAdapter = p, CharacterAdapter = c, CombatAdapter = combat,
      CameraAdapter = cam, InputAdapter = input, WorldAdapter = world,
    },
    graph = PKG_graph,
    bus = bus,
    time = function() return 1790000000 end,
  })
  local report = probe:Probe()
  H.eq(report.status, "ok", "สถานะรวม ok")
  H.eq(report.summary, "Adapter ครบทั้ง 6 API", "สรุปครบ")
  local n = 0
  for _ in pairs(report.adapters) do n = n + 1 end
  H.eq(n, 6, "รายงานครบ 6 adapter")
  H.eq(report.adapters.PlayerAdapter.status, "ok", "PlayerAdapter ok")
end)

H.test("adapter/probe: สายตาย — PlayerAdapter ตาย → รายงาน consumer ที่กระทบตาม graph", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance })
  local p, c, combat, cam, input, world = newAdapters(R)
  __GAME.kill("service:Players") -- Players service ตายทั้งตัว

  local probe = SelfProbe.new({
    adapters = {
      PlayerAdapter = p, CharacterAdapter = c, CombatAdapter = combat,
      CameraAdapter = cam, InputAdapter = input, WorldAdapter = world,
    },
    graph = PKG_graph,
    bus = BusLib.new({ clock = VTNow }),
    time = function() return 1790000000 end,
  })
  local report = probe:Probe()
  H.eq(report.adapters.PlayerAdapter.status, "dead", "PlayerAdapter dead")
  local impacted = report.impacted["PlayerAdapter"]
  H.ok(impacted, "มีรายงาน impact")
  local consumerSet = {}
  for _, cons in ipairs(impacted.consumers) do consumerSet[cons] = true end
  H.ok(consumerSet["TargetService"], "TargetService กระทบ (dep ตรงตาม graph)")
  H.ok(consumerSet["Race"], "Race กระทบ")
  H.ok(consumerSet["Fruit"], "Fruit กระทบ")
  H.ok(report.summary:find("PlayerAdapter") ~= nil, "summary ระบุตัวที่ตาย")
end)

-- ==== graceful degradation (§3.3 กฎ 3) ========================================

H.test("adapter/graceful: leaderstats หาย → GetBounty คืน GONE + Probe เห็น degraded + กลับมา ok หลัง restore", function()
  __GAME.reset()
  local p = PlayerAdapter.new({ env = ENV })
  __GAME.kill("leaderstats")
  local v, err = p:GetBounty()
  H.eq(v, nil, "ไม่มีค่า")
  H.eq(err.code, "GONE", "code GONE (เกมอัปเดต)")
  local h = p:Probe()
  H.eq(h.status, "degraded", "probe เห็นเสื่อมบางส่วน")
  H.ok(#h.deadMethods >= 2, "ระบุ method ที่ตาย (GetBounty/GetLevel/GetStats)")
  -- กู้คืน → probe กลับมา ok (re-probe ได้ §3.6 ขั้น 11)
  __GAME.restore("leaderstats")
  local h2 = p:Probe()
  H.eq(h2.status, "ok", "กลับมา ok หลัง restore")
end)

H.test("adapter/graceful: camera หาย → CameraAdapter dead ทั้งตัว + แจ้ง notify ผ่าน bus", function()
  __GAME.reset()
  local cam = CameraAdapter.new({ env = ENV })
  local bus = BusLib.new({ clock = VTNow })
  bus:Declare("notify:user", "idempotent")
  bus:Declare("adapter:health", "replay")
  local notices, health = {}, {}
  bus:On("notify:user", function(p) notices[#notices + 1] = p end)
  bus:On("adapter:health", function(p) health[#health + 1] = p end)

  __GAME.kill("camera")
  local probe = SelfProbe.new({
    adapters = { CameraAdapter = cam },
    graph = PKG_graph,
    bus = bus,
    time = function() return 1790000000 end,
  })
  local report = probe:Probe()
  H.eq(report.adapters.CameraAdapter.status, "dead", "camera dead")
  H.eq(#notices, 1, "แจ้งผู้ใช้ 1 ครั้ง (notify.adapter.dead)")
  H.eq(notices[1].key, "notify.adapter.dead", "key แจ้งถูก")
  H.eq(#health, 1, "ประกาศ adapter:health 1 ครั้ง")
  H.eq(health[1].status, "dead", "สถานะใน event ตรง")
end)

H.test("adapter/graceful: remote หาย → FireSkill GONE + probe degraded (ไม่พังทั้งระบบ)", function()
  __GAME.reset()
  local _, _, combat = newAdapters()
  __GAME.kill("remotes")
  local ok, err = combat:FireSkill("Z")
  H.ok(not ok, "FireSkill ล้ม")
  H.eq(err.code, "GONE", "code GONE")
  H.eq(combat:Probe().status, "degraded", "probe เห็นเสื่อม (แต่ไม่ dead — GetEquippedWeapon ยังอยู่)")
end)

H.test("adapter/graceful: character หาย → CharacterAdapter dead + IsAlive คืน GONE ไม่ใช่ false หลอก", function()
  __GAME.reset()
  local p, c = newAdapters()
  __GAME.kill("character")
  local alive, err = c:IsAlive()
  H.eq(alive, nil, "คืน nil ไม่ใช่ false (แยก 'ไม่รู้' กับ 'ตาย')")
  H.eq(err.code, "GONE", "code GONE")
  H.eq(c:Probe().status, "dead", "probe ตายทั้งตัว")
end)

H.test("adapter/probe: เรียกซ้ำ (re-probe) ได้ — รายงานใหม่ทับเก่า + LastReport ตรง", function()
  __GAME.reset()
  local p = PlayerAdapter.new({ env = ENV })
  local probe = SelfProbe.new({
    adapters = { PlayerAdapter = p },
    graph = PKG_graph,
    bus = BusLib.new({ clock = VTNow }),
    time = function() return 1790000000 end,
  })
  H.eq(probe:Probe().status, "ok", "รอบแรก ok")
  __GAME.kill("leaderstats")
  H.eq(probe:Probe().status, "degraded", "รอบสอง degraded (re-probe จับสถานะใหม่)")
  H.eq(probe:LastReport().status, "degraded", "LastReport = รายงานล่าสุด")
  __GAME.restore("leaderstats")
  H.eq(probe:Probe().status, "ok", "รอบสามกลับมา ok")
end)
