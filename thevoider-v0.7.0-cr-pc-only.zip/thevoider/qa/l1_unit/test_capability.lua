-- L1: Capability Detection (§3.2 ข้อ 1) — probe จริง 8 ตัว + graceful เมื่อขาด
local H = PKG_harness
local Capability = PKG_capability

H.test("capability: probe ครบ 8 ตัว — ทุกตัวมี supported/detail ครบ", function()
  local cap = Capability.new({ env = _G })
  local rep = cap:Probe()
  H.eq(#Capability.NAMES, 8)
  for _, n in ipairs(Capability.NAMES) do
    H.ok(rep[n] ~= nil, n .. " ต้องอยู่ใน report")
    H.ok(type(rep[n].supported) == "boolean")
    H.ok(type(rep[n].detail) == "string" and #rep[n].detail > 0, n .. " ต้องมี detail")
  end
end)

H.test("capability: stub environment เต็ม → 8/8 SUPPORTED", function()
  local cap = Capability.new({ env = _G })
  local rep = cap:Probe()
  for _, n in ipairs(Capability.NAMES) do
    H.ok(rep[n].supported, n .. " ควร SUPPORTED ใน stub เต็ม (" .. rep[n].detail .. ")")
  end
end)

H.test("capability: ไม่มี Drawing → DRAWING=false + ไม่ crash + ฟีเจอร์อื่นยัง probe ได้ (แยกอิสระ)", function()
  local saved = Drawing
  Drawing = nil
  local cap = Capability.new({ env = _G })
  cap:Probe()
  Drawing = saved
  local ok, detail = cap:Has("DRAWING")
  H.ok(not ok)
  H.ok(detail:find("Drawing", 1, true), "detail ต้องอธิบาย: " .. detail)
  H.ok(cap.report.TASK.supported, "TASK ยังผ่านแม้ Drawing หาย")
  H.ok(cap.report.HOOK.supported, "HOOK ยังผ่านแม้ Drawing หาย")
end)

H.test("capability: HOOK probe ทดสอบจริง — hook ต้องมีผลต่อการเรียก (102 ไม่ใช่ 2)", function()
  local cap = Capability.new({ env = _G })
  local rep = cap:Probe()
  H.ok(rep.HOOK.supported, "stub hookfunction ต้องผ่าน (detail: " .. rep.HOOK.detail .. ")")
  H.ok(__TV_HOOK_PROBE_BASE == nil, "probe ต้องเก็บกวาด global ที่ใช้ทดสอบ")
end)

H.test("capability: CRYPTO ผ่าน Known-Answer Test (SHA-256 ถูกต้องจริง)", function()
  local cap = Capability.new({ env = _G })
  local rep = cap:Probe()
  H.ok(rep.CRYPTO.supported, "stub crypto ต้องผ่าน KAT (detail: " .. rep.CRYPTO.detail .. ")")
end)

H.test("capability: CRYPTO ตอบ 64-hex แต่ digest ผิด → false + แจ้งใช้ตรวจระดับ 2", function()
  local saved = crypto.hash
  crypto.hash = function() return string.rep("f", 64) end
  local cap = Capability.new({ env = _G })
  cap:Probe()
  crypto.hash = saved
  local ok, detail = cap:Has("CRYPTO")
  H.ok(not ok, "digest ผิด = ใช้ SHA-256 จริงไม่ได้")
  H.ok(detail:find("ระดับ 2", 1, true), "ต้องบอกว่าจะใช้การตรวจระดับ 2: " .. detail)
end)

H.test("capability: HTTP มีชื่อ API แต่เรียกจริงไม่ผ่าน (500) → false (probe จริง ไม่ใช่แค่ชื่อ)", function()
  local savedResponder = __STUBS.httpResponder
  __STUBS.httpResponder = function(req)
    return { StatusCode = 500, Body = "" }
  end
  local cap = Capability.new({ env = _G })
  cap:Probe()
  __STUBS.httpResponder = savedResponder
  local ok = cap:Has("HTTP")
  H.ok(not ok, "ตอบ 500 ทุกครั้ง = ไม่ support จริง")
end)

H.test("capability: FILEIO round-trip จริง (เขียน→อ่าน→ลบ) + ไฟล์ทดสอบถูกลบ", function()
  local cap = Capability.new({ env = _G })
  local rep = cap:Probe()
  H.ok(rep.FILEIO.supported, "stub file API ต้องผ่าน: " .. rep.FILEIO.detail)
  H.ok(not isfile("thevoider_probe.tmp"), "probe ต้องลบไฟล์ทดสอบเสร็จ")
end)

H.test("capability: Summary ออก 8 บรรทัดครบสำหรับ Diagnostics (§8.4)", function()
  local cap = Capability.new({ env = _G })
  local lines = cap:Summary()
  H.eq(#lines, 8)
  H.ok(lines[1]:find("DRAWING", 1, true))
  H.ok(lines[8]:find("CRYPTO", 1, true))
end)
