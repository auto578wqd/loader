-- L1: manifest.lua — Validate ครบทุกช่องบังคับ (§7.1) + Verify 3 ระดับ (§7.2)
local H = PKG_harness
local M = PKG_manifest
local S = PKG_sha256

local BODY = "TV-BUNDLE BODY เพื่อการทดสอบ 1234567890"
local BODY_SHA = nil -- เติมในรอบแรกของเทส (คำนวณจริง)

local function goodManifest(over)
  over = over or {}
  local m = {
    product = "the-voider",
    version = over.version or "0.3.0",
    releaseId = over.releaseId or "r2026-10-01-01",
    files = over.files or {
      ["the-voider.lua"] = {
        sha256 = over.sha256 or (BODY_SHA or string.rep("0", 64)),
        size = over.size or #BODY,
      },
    },
    minLoaderVersion = over.minLoaderVersion or "0.3.0",
    channel = over.channel or "stable",
  }
  for k, v in pairs(over.extra or {}) do m[k] = v end
  return m
end

H.test("manifest: Decode ผ่านเมื่อ JSON สมบูรณ์ + ปฏิเสธทุกชนิดของเสีย", function()
  BODY_SHA = S.hex(BODY)
  -- ปกติ
  local okJson = [[{
    "product": "the-voider", "version": "0.3.0", "releaseId": "r2026-10-01-01",
    "files": { "the-voider.lua": { "sha256": "]] .. BODY_SHA .. [[", "size": 2000 } },
    "minLoaderVersion": "0.3.0", "channel": "stable"
  }]]
  local m, err = M.Decode(okJson, {})
  H.ok(m ~= nil, tostring(err))
  H.eq(m.version, "0.3.0")
  H.eq(m.channel, "stable")

  -- JSON พัง
  local m2, err2 = M.Decode("{not json", {})
  H.ok(m2 == nil and err2:find("parse") ~= nil)

  -- ไม่ใช่ string
  local m3, err3 = M.Decode(nil, {})
  H.ok(m3 == nil)

  -- ขาดช่องบังคับแบบต่าง ๆ (Validate ละเอียด)
  H.ok(#M.Validate({ product = "other", version = "0.3.0", releaseId = "r",
    files = { a = { sha256 = string.rep("a", 64), size = 5 } },
    minLoaderVersion = "0.3.0", channel = "stable" }) >= 1, "product ผิด")
  H.ok(#M.Validate(goodManifest({ releaseId = "" })) >= 1, "releaseId ว่าง")
  H.ok(#M.Validate(goodManifest({ version = "0.3" })) >= 1, "version ผิดรูปแบบ")
  H.ok(#M.Validate(goodManifest({ minLoaderVersion = "" })) >= 1, "minLoaderVersion ขาด")
  H.ok(#M.Validate(goodManifest({ channel = "beta" })) >= 1, "channel นอกลิสต์")
  H.ok(#M.Validate(goodManifest({ files = {} })) >= 1, "files ว่าง")
  H.ok(#M.Validate(goodManifest({ sha256 = "zz" .. string.rep("0", 62) })) >= 1, "sha256 ไม่ใช่ hex")
  -- ตัวพิมพ์ใหญ่: Lua %x รองรับ A-F → Validate ยอม (จริง ๆ Verify เปรียบเทียบ
  -- แบบ lower ทั้งสองฝั่ง จึงไม่มีปัญหาความหมาย)
  H.eq(#M.Validate(goodManifest({ sha256 = "ABCD" .. string.rep("0", 60) })), 0,
    "hex ตัวพิมพ์ใหญ่ผ่าน Validate (Verify ใช้ lower เทียบ)")
end)

H.test("manifest: Validate ครบถ้วน = รายการว่าง", function()
  BODY_SHA = S.hex(BODY)
  H.eq(#M.Validate(goodManifest(), {}), 0)
  local built, berr = M.Build({
    version = "0.3.0", releaseId = "r1", minLoaderVersion = "0.3.0",
    files = { ["the-voider.lua"] = { sha256 = BODY_SHA, size = #BODY } },
  })
  H.ok(built ~= nil, tostring(berr))
  H.eq(built.channel, "stable")
end)

H.test("manifest: Verify ระดับ 1 (crypto-api) — ตรง/ไม่ตรง", function()
  BODY_SHA = S.hex(BODY)
  local m = goodManifest()
  -- ต่อ crypto จริง (pure-Lua แทน) เหมือน executor ที่มี crypto
  local saved = crypto.hash
  crypto.hash = function(algo, s) return S.hex(s) end
  local v = M.Verify(BODY, "the-voider.lua", m, { env = _G })
  H.ok(v.ok, v.detail)
  H.eq(v.mode, "crypto-api")
  H.ok(v.detail:find("เต็มรูปแบบ") ~= nil, "รายงานระดับตรวจตามจริง (§7.2)")

  -- hash ไม่ตรง = ไฟล์เสียหาย
  local mBad = goodManifest({ sha256 = string.rep("0", 64) })
  local v2 = M.Verify(BODY, "the-voider.lua", mBad, { env = _G })
  H.ok(not v2.ok)
  H.ok(v2.detail:find("ไม่ตรง") ~= nil)
  crypto.hash = saved
end)

H.test("manifest: Verify ระดับ 2 (software) — วัดเวลาจริง + ตกไประดับ 3 เมื่อเกินงบ", function()
  BODY_SHA = S.hex(BODY)
  local m = goodManifest()
  -- ไม่มี crypto → software
  local saved, savedSyn = rawget(_G, "crypto"), rawget(_G, "syn")
  rawset(_G, "crypto", nil); rawset(_G, "syn", nil)
  local v = M.Verify(BODY, "the-voider.lua", m, { env = _G, softwareBudgetMs = 10000 })
  H.ok(v.ok, v.detail)
  H.eq(v.mode, "software")
  H.ok(v.ms >= 0, "วัดเวลาจริง")
  H.ok(v.detail:find("โหมดซอฟต์แวร์") ~= nil)

  -- งบ 0 ms → hash ไม่มีทางจบในงบ → ต้องตกไประดับ 3 (level2)
  local src = "--[[ TV-BUNDLE version=0.3.0 releaseId=r2026-10-01-01 ]]\n" .. BODY
  local m2 = goodManifest({
    sha256 = S.hex(src), size = #src,
  })
  local v2 = M.Verify(src, "the-voider.lua", m2, { env = _G, softwareBudgetMs = 0 })
  H.eq(v2.mode, "level2", "เกินงบ = ตรวจระดับพื้นฐาน (บอกตามจริง ไม่อวดอ้าง)")
  H.ok(v2.ok, v2.detail)
  H.ok(v2.detail:find("ระดับพื้นฐาน") ~= nil)

  -- level2: ขนาดไม่ตรง
  local m3 = goodManifest({ sha256 = S.hex(src), size = #src + 1 })
  local v3 = M.Verify(src, "the-voider.lua", m3, { env = _G, softwareBudgetMs = 0 })
  H.ok(not v3.ok)
  H.ok(v3.detail:find("ขนาดไม่ตรง") ~= nil)

  -- level2: ไม่มี header marker
  local m4 = goodManifest({ sha256 = S.hex(BODY), size = #BODY })
  local v4 = M.Verify(BODY, "the-voider.lua", m4, { env = _G, softwareBudgetMs = 0 })
  H.ok(not v4.ok)
  H.ok(v4.detail:find("header marker") ~= nil)

  rawset(_G, "crypto", saved); rawset(_G, "syn", savedSyn)
end)

H.test("manifest: Verify — ไม่มีไฟล์ชื่อนั้นใน manifest = ปฏิเสธ", function()
  local m = goodManifest()
  local v = M.Verify(BODY, "tv.lua", m, { env = _G })
  H.ok(not v.ok)
  H.ok(v.detail:find("ไม่มีไฟล์") ~= nil)
end)

H.test("manifest: cleanup — คืน crypto ต้นฉบับ (กัน assertion กลางทางทิ้ง global เป็น nil)", function()
  if rawget(_G, "crypto") == nil then
    rawset(_G, "crypto", { hash = function(algo, s)
      if algo == "sha256" and s == "TheVoider-KAT" then
        return "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee"
      end
      return string.rep("0", 64)
    end })
    H.ok(true, "สร้าง stub คืนตามต้นฉบับ stub_env")
  else
    H.ok(true, "crypto ยังอยู่ — ไม่ต้องทำอะไร")
  end
end)
