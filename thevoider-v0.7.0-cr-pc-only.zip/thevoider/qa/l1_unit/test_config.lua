-- L1: Config Service (§3.7) — round-trip ย้อนกลับ (gate เจ้าของโปรเจกต์) +
-- fallback ไฟล์เสีย .bak + event ครบ
local H = PKG_harness
local Config = PKG_config
local Migration = PKG_migration
local Bus = PKG_eventbus
local Json = PKG_json

-- storage หน่วยความจำแบบ inject (isolation ต่อเคส)
local function memStorage()
  local mem = {}
  return {
    kind = "memory",
    path = "test-memory",
    exists = function() return mem.data ~= nil end,
    read = function()
      if mem.data == nil then return nil, "ยังไม่เคยเขียน" end
      return mem.data
    end,
    write = function(content)
      mem.data = content
      return true
    end,
  }
end

local function newConfig(storage, bus)
  local m = Migration.new({ clock = VTNow })
  local c = Config.new({
    storage = storage,
    bus = bus,
    migration = m,
    clock = VTNow,
    time = function() return 1790000000 end,
  })
  return c
end

-- ==== gate #2: save → load วนกลับ ข้อมูลไม่หาย ==============================

H.test("config: Save → Load ใหม่ (คนละ instance) ค่าครบทุกชนิด (round-trip)", function()
  local storage = memStorage()
  local bus = Bus.new({ clock = VTNow })

  local c1 = newConfig(storage, bus)
  c1:Load()
  c1:Set("VoidAim.fov", 90)
  c1:Set("VoidAim.mode", "Pro")
  c1:Set("i18n.lang", "en")
  c1:Set("flags.list", { "a", "b" })
  local okSave = c1:Save()
  H.ok(okSave, "Save สำเร็จ")

  -- โหลดใหม่ด้วย instance ใหม่ (จำลองเปิดเกมครั้งถัดไป)
  local c2 = newConfig(storage, bus)
  c2:Load()
  H.eq(c2:Get("VoidAim.fov"), 90, "ตัวเลขไม่หาย")
  H.eq(c2:Get("VoidAim.mode"), "Pro", "string ไม่หาย")
  H.eq(c2:Get("i18n.lang"), "en", "ค่าระดับ 2 ชั้นไม่หาย")
  H.eq(c2:Get("flags.list")[2], "b", "array ไม่หาย")
  H.eq(c2.status, "file", "โหลดจากไฟล์จริง")
  H.eq(c2:Get("schemaVersion"), Config.CURRENT_SCHEMA_VERSION, "schemaVersion ปัจจุบัน")
end)

H.test("config: migration end-to-end ย้อนกลับ v1→v2 — ค่า FOV ย้ายถึง + legacy เก็บ + โหลดซ้ำได้อีก", function()
  local storage = memStorage()
  local bus = Bus.new({ clock = VTNow })

  -- เขียนไฟล์ config v1 ตามรูปแบบเก่า (Aimbot.FOV — ชื่อชั่วคราวตามแผน §3.7)
  local v1 = {
    schemaVersion = 1,
    profile = { name = "หลัก", createdAt = 1, updatedAt = 1 },
    settings = {
      Aimbot = { FOV = 90, mode = "EZ" },
      i18n = { lang = "th" },
    },
  }
  storage.write(Json.encode(v1))

  -- โหลดครั้งแรก: migrate v1→v2
  local c1 = newConfig(storage, bus)
  c1:Load()
  H.eq(c1.status, "migrated", "สถานะ = migrated")
  H.eq(c1:Get("VoidAim.fov"), 90, "ค่า FOV ย้ายจาก Aimbot.FOV มา VoidAim.fov ครบ")
  H.eq(c1:Get("_legacy")["settings.Aimbot"].FOV, 90, "ของเก่าเก็บใน _legacy (ห้ามทิ้ง)")
  H.eq(c1:Get("schemaVersion"), 2, "เป็นรุ่นปัจจุบันแล้ว")

  -- บันทึกแล้วโหลดซ้ำ (round-trip หลัง migration — ข้อมูลสำคัญต้องไม่หายอีกรอบ)
  c1:Save()
  local c2 = newConfig(storage, bus)
  c2:Load()
  H.eq(c2.status, "file", "รอบสองโหลดไฟล์ปกติ (ไม่ migrate ซ้ำ)")
  H.eq(c2:Get("VoidAim.fov"), 90, "FOV ยังอยู่หลังโหลดซ้ำ")
  H.eq(c2:Get("_legacy")["settings.Aimbot"].FOV, 90, "legacy ยังอยู่")

  -- ค่าใหม่ที่ตั้งหลัง migration ก็ต้องอยู่
  c2:Set("VoidAim.fov", 130, { save = true })
  local c3 = newConfig(storage, bus)
  c3:Load()
  H.eq(c3:Get("VoidAim.fov"), 130, "ค่าที่แก้หลัง migration บันทึก/โหลดซ้ำได้ครบ")
end)

H.test("config: [BUG-014 regression] default ใน settings อ่านได้ทันทีหลัง Load (path สองระดับ §3.7)", function()
  -- บั๊กเดิม: Get/Set ไล่จากราก config → default ใน settings.VoidAim หาไม่เจอ
  -- และ Set เขียนหลุดขึ้นระดับบนสุด — แก้เป็น path ระดับโมดูลอยู่ใต้ settings เสมอ
  local c = newConfig(memStorage(), Bus.new({ clock = VTNow }))
  c:Load()
  H.eq(c:Get("VoidAim.fov"), 120, "default จาก settings.VoidAim.fov อ่านได้ทันที")
  H.eq(c:Get("i18n.lang"), "th", "default ภาษาไทย")
  H.eq(c:Get("schemaVersion"), Config.CURRENT_SCHEMA_VERSION, "ระดับบนสุดอ่านตรง")
  c:Set("VoidAim.fov", 99)
  H.eq(c.cfg.settings.VoidAim.fov, 99, "Set เขียนลงใต้ settings จริง (โครงตาม §3.7)")
  H.eq(c.cfg.VoidAim, nil, "ไม่หลุดไประดับบนสุดของ config")
end)

-- ==== fallback ไฟล์เสีย ========================================================

H.test("config: ไฟล์ decode ไม่ผ่าน → .bak + default + แจ้ง notify:user", function()
  local storage = memStorage()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("notify:user", "idempotent")
  local notices = {}
  bus:On("notify:user", function(p) notices[#notices + 1] = p end)

  storage.write("{ ไฟล์เสียไม่ใช่ JSON ]]")
  local c = newConfig(storage, bus)
  c:Load()
  H.eq(c.status, "corrupted", "สถานะ corrupted")
  H.eq(c:Get("VoidAim.fov"), 120, "ใช้ค่า default ให้ระบบเดินต่อ")
  H.ok(#c:ListBackups() >= 1, "สร้าง .bak ไว้ 1 รายการ")
  H.ok(#notices >= 1, "แจ้งผู้ใช้แล้ว")
  H.eq(notices[#notices].key, "notify.config.corrupted", "แจ้งด้วย key ที่ i18n แปลได้")
end)

H.test("config: migration พัง (ขั้นขาด) → .bak + default + ไม่พังทั้งระบบ", function()
  local storage = memStorage()
  local bus = Bus.new({ clock = VTNow })
  -- schemaVersion = 0: ไม่มีขั้น 0→1 → ห้ามข้ามขั้น → migration_failed
  storage.write(Json.encode({ schemaVersion = 0, settings = {} }))
  local c = newConfig(storage, bus)
  c:Load()
  H.eq(c.status, "migration-failed", "สถานะ migration-failed")
  H.eq(c:Get("VoidAim.fov"), 120, "fallback default ใช้งานได้ทันที")
end)

H.test("config: ยังไม่มีไฟล์ → default + แจ้ง (ครั้งแรกของผู้ใช้)", function()
  local c = newConfig(memStorage(), Bus.new({ clock = VTNow }))
  local info = c:Load()
  H.eq(info.status, "default", "สถานะ default")
  H.eq(c:Get("i18n.lang"), "th", "ภาษาเริ่มต้นไทย")
end)

-- ==== Get/Set/events ==========================================================

H.test("config: Set → publish config:changed พร้อม path+value (โมดูลฟังได้)", function()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("config:changed", "replay")
  local got
  bus:On("config:changed", function(p) got = p end)
  local c = newConfig(memStorage(), bus)
  c:Load()
  c:Set("VoidAim.fov", 77)
  H.ok(got, "event ถึง subscriber")
  H.eq(got.path, "VoidAim.fov", "path ตรง")
  H.eq(got.value, 77, "value ตรง")
  H.ok(c.dirty, "ทำเครื่องหมาย dirty")
end)

H.test("config: Set(path, nil, {save=true}) → Save ทันที + event config:saved", function()
  local storage = memStorage()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("config:saved", "idempotent")
  local saved = 0
  bus:On("config:saved", function() saved = saved + 1 end)
  local c = newConfig(storage, bus)
  c:Load()
  c:Set("VoidAim.fov", 88, { save = true })
  H.eq(saved, 1, "config:saved ประกาศ 1 ครั้ง")
  H.ok(storage.exists(), "เขียนลง storage จริง")
end)

H.test("config: Data() คืนสำเนา (แก้สำเนาไม่กระทบต้นฉบับ) — ใช้ทำ Rollback Snapshot", function()
  local c = newConfig(memStorage(), Bus.new({ clock = VTNow }))
  c:Load()
  local copy = c:Data()
  copy.settings.VoidAim.fov = 999
  H.eq(c:Get("VoidAim.fov"), 120, "ต้นฉบับไม่โดนแตะ (สำเนาลึกจริง)")
end)

H.test("config: Replace — hot update/rollback คืน config ทั้งก้อน + ประกาศ", function()
  local bus = Bus.new({ clock = VTNow })
  bus:Declare("config:replaced", "replay")
  local replaced = 0
  bus:On("config:replaced", function() replaced = replaced + 1 end)
  local c = newConfig(memStorage(), bus)
  c:Load()
  local snap = c:Data()
  c:Set("VoidAim.fov", 55)
  H.eq(c:Get("VoidAim.fov"), 55, "แก้แล้ว")
  c:Replace(snap)
  H.eq(c:Get("VoidAim.fov"), 120, "Replace คืนค่า snapshot ได้")
  H.eq(replaced, 1, "ประกาศ config:replaced")
  local ok = pcall(c.Replace, c, { schemaVersion = 1 })
  H.ok(not ok, "Replace schemaVersion ผิด = ปฏิเสธ")
end)

H.test("config: Shutdown บันทึก dirty อัตโนมัติ (ของผู้ใช้คือของมีค่า)", function()
  local storage = memStorage()
  local c = newConfig(storage, Bus.new({ clock = VTNow }))
  c:Load()
  c:Set("VoidAim.mode", "Legend") -- dirty แต่ไม่ Save
  c:Shutdown()
  local c2 = newConfig(storage, Bus.new({ clock = VTNow }))
  c2:Load()
  H.eq(c2:Get("VoidAim.mode"), "Legend", "Shutdown บันทึกของที่ค้างไว้")
end)

H.test("config: ไฟล์จริงผ่าน readfile/writefile (FILEIO storage เริ่มต้น)", function()
  delfile("thevoider/config.json")
  local bus = Bus.new({ clock = VTNow })
  local c = Config.new({
    bus = bus,
    migration = Migration.new({ clock = VTNow }),
    clock = VTNow,
    time = function() return 1790000000 end,
  })
  H.eq(c:StorageKind(), "file", "มี FILEIO ต้องใช้ไฟล์จริง")
  c:Load()
  c:Set("VoidAim.fov", 66, { save = true })
  H.ok(isfile("thevoider/config.json"), "ไฟล์เกิดจริง")
  local c2 = Config.new({
    bus = bus,
    migration = Migration.new({ clock = VTNow }),
    clock = VTNow,
    time = function() return 1790000000 end,
  })
  c2:Load()
  H.eq(c2:Get("VoidAim.fov"), 66, "ค่ากลับมาจากไฟล์จริง")
  delfile("thevoider/config.json")
end)
