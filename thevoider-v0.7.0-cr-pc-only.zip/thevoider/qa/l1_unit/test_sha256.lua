-- L1: sha256.lua — pure-Lua SHA-256 (§7.2 ระดับ 2) + crypto probe (ระดับ 1)
-- ค่า KAT ทั้งหมดคำนวณด้วย python hashlib แล้ว (ตรวจซ้ำด้วย
-- test นี้ทุกครั้ง — ถ้า implementation เพี้ยนเมื่อไหร่เทสจะแดงทันที)
local H = PKG_harness
local S = PKG_sha256

H.test("sha256: KAT 3 ตัวหลัก (empty/abc/TheVoider-KAT)", function()
  H.eq(S.hex(""), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  H.eq(S.hex("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
  H.eq(S.hex("TheVoider-KAT"), "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee")
end)

H.test("sha256: padding edge 55/56/63/64/65 ไบต์ (ขอบเขตบล็อก 64 + ช่อง 8 ไบต์)", function()
  H.eq(S.hex(string.rep("x", 55)), "d5e285683cd4efc02d021a5c62014694958901005d6f71e89e0989fac77e4072")
  H.eq(S.hex(string.rep("x", 56)), "04c26261370ee7541549d16dee320c723e3fd14671e66a099afe0a377c16888e")
  H.eq(S.hex(string.rep("x", 63)), "75220b47218278e656f2013bb8f0c455a25eaf01e86c64924e9d48d89776d6f2")
  H.eq(S.hex(string.rep("x", 64)), "7ce100971f64e7001e8fe5a51973ecdfe1ced42befe7ee8d5fd6219506b5393c")
  H.eq(S.hex(string.rep("x", 65)), "9537c5fdf120482f7d58d25e9ed583f52c02b4e304ea814db1633ad565aed7e9")
end)

H.test("sha256: ข้อความยาวหลายบล็อก (1000 และ 400 ไบต์)", function()
  H.eq(S.hex(string.rep("a", 1000)), "41edece42d63e8d9bf515a9ba6932e1c20cbc9f5a5d134645adb5db1b9737ea3")
  H.eq(S.hex(string.rep("0123456789", 40)), "5db999e69b23b7a8ec7ef25adc1dcb4fcc7062e12547fe3a7fbcfbe714ed2789")
end)

H.test("sha256: selfTest ผ่าน + ตัวพิมพ์เล็ก 64 ตัวเสมอ", function()
  local ok, detail = S.selfTest()
  H.ok(ok, detail)
  local d = S.hex("TheVoider-KAT")
  H.eq(#d, 64)
  H.eq(d:lower(), d, "digest ต้องเป็นตัวพิมพ์เล็กเสมอ (เทียบกับ manifest ได้ตรง ๆ)")
end)

H.test("sha256: probe — ระดับ 1 (crypto API) ใช้ได้เมื่อผ่าน KAT เท่านั้น", function()
  -- stub_env: crypto.hash ตอบ KAT ถูกเฉพาะ "TheVoider-KAT" → probe ต้องผ่าน
  local name, fn = S.probe(_G)
  H.eq(name, "crypto.hash(algo, s)")
  H.ok(type(fn) == "function")
  -- แต่การ hash ข้อความอื่นด้วย crypto จริงต้องคำนวณถูก — ต่อ stub จริงเข้าไป
  -- (ใน executor จริง crypto.hash เป็นของระบบ — ที่นี่ใช้ pure-Lua ต่อให้เทสสมจริง)
  local saved = crypto.hash
  crypto.hash = function(algo, s)
    H.eq(algo, "sha256")
    return S.hex(s)
  end
  local hex, api = S.cryptoHex(_G, "hello world")
  H.eq(api, "crypto.hash(algo, s)")
  H.eq(hex, "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9")
  crypto.hash = saved
end)

H.test("sha256: probe — API มีชื่อแต่ hash ผิด = ไม่ใช้ (กัน 'มีชื่อแต่ใช้ไม่ได้')", function()
  local saved = crypto.hash
  crypto.hash = function(algo, s)
    return string.rep("0", 64) -- ตอบ 64-hex แต่ค่าผิด
  end
  local name, why = S.probe(_G)
  H.ok(name == nil, "probe ต้องไม่ยกให้ API ที่ hash ผิด")
  H.ok(tostring(why):find("Known%-Answer") ~= nil, "เหตุผลระบุชัด")
  crypto.hash = saved
end)

H.test("sha256: probe — ไม่มี crypto เลย = บอกตรง ๆ", function()
  local saved, savedSyn = rawget(_G, "crypto"), rawget(_G, "syn")
  rawset(_G, "crypto", nil)
  rawset(_G, "syn", nil)
  local name, why = S.probe(_G)
  H.ok(name == nil)
  H.ok(tostring(why):find("ไม่มี crypto API") ~= nil)
  rawset(_G, "crypto", saved)
  rawset(_G, "syn", savedSyn)
end)
