-- ============================================================================
-- The Voider — qa/l1_unit/stub_env.lua (L1 เท่านั้น — ห้ามปนกับโค้ดจริง)
-- สภาพแวดล้อมทดสอบสำหรับ fengari: stub Roblox/executor + virtual-time scheduler
-- ต่อยอดแนวทางชุดทดสอบ v3.x ที่พิสูจน์แล้ว (virtual time + pcall-safe)
-- ============================================================================

__TV_PACKAGES = {}

-- ==== เก็บ output ไว้ตรวจ (print/warn capture) ============================

__OUT = { prints = {}, warns = {} }

__RAW_PRINT = print -- fengari print ตัวจริง (ใช้ flush ผลเทสออกจอ)

function __FLUSH_OUT()
  for _, l in ipairs(__OUT.prints) do
    __RAW_PRINT(l)
  end
end

print = function(...)
  local parts = {}
  for i = 1, select("#", ...) do
    parts[i] = tostring(select(i, ...))
  end
  table.insert(__OUT.prints, table.concat(parts, " "))
end

warn = function(...)
  local parts = {}
  for i = 1, select("#", ...) do
    parts[i] = tostring(select(i, ...))
  end
  table.insert(__OUT.warns, table.concat(parts, " "))
end

-- ==== virtual time + task stub =============================================
-- task.spawn = รันทันทีจนถึง yield แรก (semantics เดียวกับ Roblox)
-- task.wait  = yield พร้อมเวลา แล้ว scheduler ปลุกตามคิวเวลาเสมือน
-- __VT.advance(sec) = เดินเวลาเสมือนไปข้างหน้า (ใช้ในเทสแทนการรอจริง)

__VT = { now = 0, wake = {}, cancelled = {} }

function __VT.schedule(co, delay)
  table.insert(__VT.wake, { t = __VT.now + (delay or 0), co = co })
end

function __VT.popNext(target)
  local best, bestI = nil, nil
  for i, w in ipairs(__VT.wake) do
    if w.t <= target and (best == nil or w.t < best.t) then
      best, bestI = w, i
    end
  end
  if bestI then
    table.remove(__VT.wake, bestI)
  end
  return best
end

function __VT.spawnNow(fn, ...)
  local co = coroutine.create(fn)
  local ok, req = coroutine.resume(co, ...)
  if not ok then
    error("VT spawn error: " .. tostring(req), 0)
  end
  if coroutine.status(co) ~= "dead" and type(req) == "table" and req.__wait then
    __VT.schedule(co, req.delay)
  end
  return co
end

function __VT.advance(sec)
  local target = __VT.now + sec
  while true do
    local item = __VT.popNext(target)
    if not item then break end
    if not __VT.cancelled[item.co] then
      __VT.now = item.t
      local ok, req = coroutine.resume(item.co)
      if not ok then
        error("VT thread error: " .. tostring(req), 0)
      end
      if coroutine.status(item.co) ~= "dead" and type(req) == "table" and req.__wait then
        __VT.schedule(item.co, req.delay)
      end
    end
  end
  __VT.now = target
end

function VTNow()
  return __VT.now
end

task = {
  spawn = function(fn, ...)
    return __VT.spawnNow(fn, ...)
  end,
  wait = function(t)
    coroutine.yield({ __wait = true, delay = t or 0.03 })
    return __VT.now
  end,
  delay = function(t, fn)
    return __VT.spawnNow(function()
      task.wait(t)
      fn()
    end)
  end,
  defer = function(fn)
    return __VT.spawnNow(function()
      task.wait(0)
      fn()
    end)
  end,
  cancel = function(co)
    __VT.cancelled[co] = true
    for i = #__VT.wake, 1, -1 do
      if __VT.wake[i].co == co then
        table.remove(__VT.wake, i)
      end
    end
  end,
}

-- ==== signal stub (RBXScriptSignal ย่อ) ====================================

function __newSignal(name)
  local s = { Name = name, _handlers = {} }
  s.Connect = function(self, fn)
    local conn = { Connected = true }
    function conn:Disconnect()
      conn.Connected = false
      for i, h in ipairs(s._handlers) do
        if h == fn then
          table.remove(s._handlers, i)
          break
        end
      end
    end
    table.insert(s._handlers, fn)
    return conn
  end
  s.Fire = function(self, ...)
    local handlers = {}
    for _, h in ipairs(s._handlers) do table.insert(handlers, h) end
    for _, h in ipairs(handlers) do h(...) end
  end
  return s
end

-- ==== executor API stub =====================================================

Drawing = {
  new = function(kind)
    local props = {
      __kind = kind, __removed = false,
      Visible = false, Thickness = 1, Color = "white", Text = "", Size = 12,
    }
    props.Remove = function(self)
      self.__removed = true
    end
    return props
  end,
}

-- Instance stub แบบเต็ม (เฟส 1 UI): เก็บ property + ต้นไม้ Parent/_children
-- + Destroy แบบ cascade (ลูกตายพร้อมพ่อ และถอดตัวออกจากพ่อ) + signal ของ GUI
-- (MouseButton1Click/MouseEnter/MouseLeave/InputBegan/InputEnded/InputChanged)
-- — ใช้ร่วมกับ registry (Runtime.NewRender "Instance") และ UI backend
-- รักษาสัญญาเดิม: ClassName/Name/__destroyed/Destroy เพื่อ test_registry เดิมเดินต่อ
local function __newGuiInstance(cls)
  local obj = {
    ClassName = cls,
    Name = cls,
    __destroyed = false,
    _children = {},
  }
  obj.FindFirstChild = function(self, childName)
    for _, c in ipairs(self._children) do
      if c.Name == childName then return c end
    end
    return nil
  end
  obj.GetChildren = function(self)
    local out = {}
    for i, c in ipairs(self._children) do out[i] = c end
    return out
  end
  obj.Destroy = function(self)
    if rawget(self, "__destroyed") then return end
    rawset(self, "__destroyed", true)
    local par = rawget(self, "_parentRef")
    if par and rawget(par, "_children") then
      for i, c in ipairs(par._children) do
        if c == self then table.remove(par._children, i) break end
      end
    end
    rawset(self, "_parentRef", nil)
    local kids = {}
    for _, c in ipairs(self._children) do kids[#kids + 1] = c end
    for _, c in ipairs(kids) do
      if type(c.Destroy) == "function" then c:Destroy() end
    end
    self._children = {}
  end
  -- signal ของ GUI (ต่อผ่าน Runtime.Connect ในโค้ดจริง — stub ใช้ __newSignal)
  obj.MouseButton1Click = __newSignal("MouseButton1Click")
  obj.MouseEnter = __newSignal("MouseEnter")
  obj.MouseLeave = __newSignal("MouseLeave")
  obj.InputBegan = __newSignal("InputBegan")
  obj.InputEnded = __newSignal("InputEnded")
  obj.InputChanged = __newSignal("InputChanged")
  return setmetatable(obj, {
    __index = function(t, k)
      if k == "Parent" then return rawget(t, "_parentRef") end
      return nil
    end,
    __newindex = function(t, k, v)
      if k == "Parent" then
        local old = rawget(t, "_parentRef")
        if old == v then return end
        if old and rawget(old, "_children") then
          for i, c in ipairs(old._children) do
            if c == t then table.remove(old._children, i) break end
          end
        end
        rawset(t, "_parentRef", v)
        if v and rawget(v, "_children") then
          table.insert(v._children, t)
        end
        return
      end
      rawset(t, k, v)
    end,
  })
end

Instance = { new = __newGuiInstance }

-- hidden UI root ของ executor (จำลอง gethui ของ Volt) — UI ทั้งหมดเกาะที่นี่
-- เทสรีเซ็ตได้: __HUI = nil แล้วเรียก gethui() ใหม่
gethui = function()
  if __HUI == nil then
    __HUI = Instance.new("ScreenGui")
    __HUI.Name = "HuiRoot"
    -- รากของ gethui ไม่ถูกทำลายโดยใคร (คนทำลายคือผู้สร้างเท่านั้น)
    __HUI.Destroy = function() end
  end
  return __HUI
end

-- UDim2 / Color3 / Enum / UDim stub (production: global จริงของ Roblox — lint ไม่ห้ามชื่อเหล่านี้)
UDim2 = {
  new = function(x, sx, y, sy)
    return { __udim2 = true, X = { Scale = x, Offset = sx }, Y = { Scale = y, Offset = sy } }
  end,
}
UDim = {
  new = function(scale, offset)
    return { __udim = true, Scale = scale, Offset = offset }
  end,
}
Color3 = {
  new = function(r, g, b)
    return { __color3 = true, R = r or 0, G = g or 0, B = b or 0 }
  end,
  fromRGB = function(r, g, b)
    return { __color3 = true, R = (r or 0) / 255, G = (g or 0) / 255, B = (b or 0) / 255 }
  end,
}
Enum = setmetatable({}, {
  __index = function(t, cat)
    local e = setmetatable({}, {
      __index = function(tt, item)
        local v = { __enum = true, EnumType = cat, Name = item }
        rawset(tt, item, v)
        return v
      end,
    })
    rawset(t, cat, e)
    return e
  end,
})

-- helper สำหรับเทส UI: หา instance ตามชื่อจาก root (กว้างสุดก่อน)
__UI = {
  find = function(root, name)
    if not root or not root._children then return nil end
    for _, c in ipairs(root._children) do
      if c.Name == name then return c end
    end
    for _, c in ipairs(root._children) do
      local r = __UI.find(c, name)
      if r then return r end
    end
    return nil
  end,
  findAll = function(root, name, out)
    out = out or {}
    if not root or not root._children then return out end
    for _, c in ipairs(root._children) do
      if c.Name == name then out[#out + 1] = c end
      __UI.findAll(c, name, out)
    end
    return out
  end,
}

game = {
  GetService = function(self, name)
    if name == "UserInputService" then
      if not __UIS then
        __UIS = {
          KeyboardEnabled = true, MouseEnabled = true, TouchEnabled = true,
          InputBegan = __newSignal("InputBegan"),
          InputEnded = __newSignal("InputEnded"),
        }
      end
      return __UIS
    end
    error("GetService: unknown service " .. tostring(name), 0)
  end,
}

-- file API (FILEIO)
__FILES = {}
writefile = function(path, content) __FILES[path] = content end
readfile = function(path)
  if __FILES[path] == nil then
    error("readfile: not found " .. tostring(path), 0)
  end
  return __FILES[path]
end
isfile = function(path) return __FILES[path] ~= nil end
delfile = function(path) __FILES[path] = nil end

-- clipboard (CLIPBOARD) — __CLIP = ค่าคลิปบอร์ดเสมือน
__CLIP = nil
setclipboard = function(s) __CLIP = s end
getclipboard = function() return __CLIP end

-- http (HTTP) — ปรับพฤติกรรมได้จากเทสผ่าน __STUBS.httpResponder
__STUBS = {
  httpResponder = function(req)
    return { StatusCode = 200, Body = "ok" }
  end,
}
http_request = function(req)
  return __STUBS.httpResponder(req)
end

-- crypto (CRYPTO) — Known-Answer Test ตรงกับ core/runtime/capability.lua
crypto = {
  hash = function(algo, s)
    if algo == "sha256" and s == "TheVoider-KAT" then
      return "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee"
    end
    return string.rep("0", 64)
  end,
}

-- hookfunction (HOOK) — stub แทนที่ "ตัวแปร global ที่เก็บฟังก์ชันนั้น"
-- (จำลองพฤติกรรม executor จริงที่ hook มีผลต่อการเรียก — probe ของเราใช้ global)
hookfunction = function(orig, replacement)
  for k, v in pairs(_G) do
    if v == orig then
      _G[k] = replacement
      return true
    end
  end
  return false
end
