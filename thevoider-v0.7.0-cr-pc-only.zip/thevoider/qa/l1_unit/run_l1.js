// ============================================================================
// The Voider — L1 runner (fengari) — รันชุดเทส qa/l1_unit ทั้งหมด
// ใช้: npm install  &&  npm test     (หรือ node qa/l1_unit/run_l1.js)
// ลำดับโหลด: stub_env → packages (graph/preflight/capability/registry/boundary/
// watchdog/shutdown/init) → tests 7 ไฟล์ → รัน harness → สรุปผล
// exit code != 0 เมื่อมีเคส fail (ใช้ต่อใน CI ได้)
// ============================================================================
const fs = require('fs');
const path = require('path');

let fengari;
try {
  fengari = require('fengari');
} catch (e) {
  // fallback: หา fengari จาก scripts/node_modules ของเวิร์กสเปซ (ใช้ตอนพัฒนากับเครื่องเรา)
  try {
    fengari = require(path.resolve(__dirname, '..', '..', '..', 'scripts', 'node_modules', 'fengari'));
  } catch (e2) {
    console.error('[run_l1] ไม่พบ fengari — รัน "npm install" ใน root ของ repo ก่อน');
    process.exit(1);
  }
}
const { lua, lauxlib, lualib, to_luastring } = fengari;

const REPO = path.resolve(__dirname, '..', '..');

// [ชื่อ package, ไฟล์, เป็น package (return ค่า) หรือไม่]
const FILES = [
  ['stub_env', 'qa/l1_unit/stub_env.lua', false],
  ['stub_game', 'qa/l1_unit/stub_game.lua', false],
  ['harness', 'qa/l1_unit/harness.lua', true],
  // ---- runtime (L1) ----
  ['graph', 'core/runtime/graph.lua', true],
  ['preflight', 'core/runtime/preflight.lua', true],
  ['capability', 'core/runtime/capability.lua', true],
  ['registry', 'core/runtime/registry.lua', true],
  ['boundary', 'core/runtime/boundary.lua', true],
  ['watchdog', 'core/runtime/watchdog.lua', true],
  ['shutdown', 'core/runtime/shutdown.lua', true],
  ['init', 'core/runtime/init.lua', true],
  // ---- foundation (L2) — ลำดับตาม dependency ----
  ['json', 'core/foundation/json.lua', true],
  ['services', 'core/foundation/services.lua', true],
  ['eventbus', 'core/foundation/eventbus.lua', true],
  ['migration', 'core/foundation/migration.lua', true],
  ['config', 'core/foundation/config.lua', true],
  ['i18n', 'core/foundation/i18n.lua', true],
  ['keybind', 'core/foundation/keybind.lua', true],
  ['diagnostics', 'core/foundation/diagnostics.lua', true],
  ['foundation', 'core/foundation/init.lua', true],
  // ---- game adapter (L3) — ลำดับตาม dependency ----
  ['adapter_common', 'core/adapter/_common.lua', true],
  ['adapter_player', 'core/adapter/player.lua', true],
  ['adapter_character', 'core/adapter/character.lua', true],
  ['adapter_combat', 'core/adapter/combat.lua', true],
  ['adapter_camera', 'core/adapter/camera.lua', true],
  ['adapter_input', 'core/adapter/input.lua', true],
  ['adapter_world', 'core/adapter/world.lua', true],
  ['adapter_probe', 'core/adapter/probe.lua', true],
  ['adapter', 'core/adapter/init.lua', true],
  // ---- ui (L6 — เฟส 1) ----
  ['ui_backend', 'core/ui/_backend.lua', true],
  ['ui_theme', 'core/ui/theme.lua', true],
  ['ui_hub', 'core/ui/hub.lua', true],
  ['ui_hud', 'core/ui/hud.lua', true],
  ['ui_notify', 'core/ui/notify.lua', true],
  ['ui', 'core/ui/init.lua', true],
  // ---- loader-domain (รอบ 4: Loader v2 + Update/Rollback §3.6/§7) ----
  ['version', 'core/runtime/version.lua', true],
  ['sha256', 'core/runtime/sha256.lua', true],
  ['manifest', 'core/runtime/manifest.lua', true],
  ['update', 'core/runtime/update.lua', true],
  ['bundle', 'core/runtime/bundle.lua', true],
  ['loadermain', 'core/runtime/loader_main.lua', true],
  // ---- tests: runtime (ชุดเดิม) ----
  ['test_graph', 'qa/l1_unit/test_graph.lua', false],
  ['test_preflight', 'qa/l1_unit/test_preflight.lua', false],
  ['test_boundary', 'qa/l1_unit/test_boundary.lua', false],
  ['test_registry', 'qa/l1_unit/test_registry.lua', false],
  ['test_watchdog', 'qa/l1_unit/test_watchdog.lua', false],
  ['test_shutdown', 'qa/l1_unit/test_shutdown.lua', false],
  ['test_capability', 'qa/l1_unit/test_capability.lua', false],
  ['test_runtime_init', 'qa/l1_unit/test_runtime_init.lua', false],
  // ---- tests: foundation + adapter (รอบใหม่) ----
  ['test_eventbus', 'qa/l1_unit/test_eventbus.lua', false],
  ['test_services', 'qa/l1_unit/test_services.lua', false],
  ['test_migration', 'qa/l1_unit/test_migration.lua', false],
  ['test_config', 'qa/l1_unit/test_config.lua', false],
  ['test_i18n', 'qa/l1_unit/test_i18n.lua', false],
  ['test_keybind', 'qa/l1_unit/test_keybind.lua', false],
  ['test_diagnostics', 'qa/l1_unit/test_diagnostics.lua', false],
  ['test_adapter', 'qa/l1_unit/test_adapter.lua', false],
  // ---- tests: ui (เฟส 1) ----
  ['test_ui', 'qa/l1_unit/test_ui.lua', false],
  // ---- tests: loader-domain (รอบ 4) ----
  ['test_version', 'qa/l1_unit/test_version.lua', false],
  ['test_sha256', 'qa/l1_unit/test_sha256.lua', false],
  ['test_manifest', 'qa/l1_unit/test_manifest.lua', false],
  ['test_update', 'qa/l1_unit/test_update.lua', false],
  ['test_bundle', 'qa/l1_unit/test_bundle.lua', false],
  // ---- regression (กฎเหล็ก §11 — บั๊กทุกตัวกลายเป็น test case ถาวร) ----
  ['regression_bug_014', 'qa/regression/BUG-014_config-path-resolution.lua', false],
  ['regression_bug_015', 'qa/regression/BUG-015_adapter-error-pair.lua', false],
  ['regression_bug_016', 'qa/regression/BUG-016_hex-literal-integer-wrap.lua', false],
  ['regression_cr_replay_001', 'qa/regression/CR-REPLAY-001_cross-generation-replay.lua', false],
];

const L = lauxlib.luaL_newstate();
lualib.luaL_openlibs(L);

function runChunk(name, code, isPackage) {
  let wrapped;
  if (isPackage) {
    wrapped = `local __m = (function()\n${code}\nend)(); __TV_PACKAGES[${JSON.stringify(name)}] = __m; PKG_${name} = __m;`;
  } else {
    wrapped = `do\n${code}\nend`;
  }
  const st = lauxlib.luaL_loadbuffer(L, to_luastring(wrapped), null, to_luastring('@' + name));
  if (st !== lua.LUA_OK) {
    console.log(`[LOAD FAIL ${name}]`, lua.lua_tojsstring(L, -1));
    process.exit(1);
  }
  const st2 = lua.lua_pcall(L, 0, 0, 0);
  if (st2 !== lua.LUA_OK) {
    console.log(`[RUN FAIL ${name}]`, lua.lua_tojsstring(L, -1));
    process.exit(1);
  }
}

console.log('===== The Voider L1 — Runtime Layer (fengari + virtual time) =====');
for (const [name, rel, isPackage] of FILES) {
  const file = path.join(REPO, rel);
  runChunk(name, fs.readFileSync(file, 'utf8'), isPackage);
}

// รัน harness ทั้งชุด — fail > 0 = error ทันทีเพื่อให้ exit code ไม่ใช่ 0
runChunk('__run_l1', `
local s = PKG_harness.run()
__FLUSH_OUT() -- แสดงรายละเอียดเคสที่ fail ก่อน (ถ้ามี)
assert(s.fail == 0, ("L1_FAILED pass=%d fail=%d"):format(s.pass, s.fail))
__OUT.prints = {}
print("L1_ALL_GREEN")
__FLUSH_OUT()
`, false);

console.log('===== L1 RUNNER DONE =====');
