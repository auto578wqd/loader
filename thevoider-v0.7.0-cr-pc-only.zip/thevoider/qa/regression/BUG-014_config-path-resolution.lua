-- ============================================================================
-- BUG-014 — Regression test ถาวร (กฎเหล็ก §11: บั๊กทุกตัวกลายเป็น test case)
--
-- BUG ID:     BUG-014
-- รากปัญหา:   Config:Get/Set ไล่ path จากราก config ตรง ๆ แทนที่จะไล่จาก
--             cfg.settings ตามโครงแผน freeze §3.7 → (1) ค่า default ที่อยู่ใน
--             settings.VoidAim.fov อ่านไม่เจอ (คืน nil หลัง Load) (2) Set
--             สร้าง key ใหม่หลุดขึ้นระดับบนสุดของ config (cfg.VoidAim แทน
--             cfg.settings.VoidAim) — เคส Set→Get ผ่านเพราะ "ผิดตรงกันทั้งคู่"
--             จน L2 full-stack จับได้ตอนอ่าน default
-- การแก้:      path สองระดับ — path ระดับโมดูล ("VoidAim.fov", "i18n.lang",
--             "Keybinds.toggle") อยู่ใต้ cfg.settings เสมอ; path ระดับบนสุด
--             (schemaVersion/profile/settings/_legacy) อ่านตรง (RESERVED_TOP)
-- Regression: เคสด้านล่าง — default อ่านได้ทันทีหลัง Load + Set เขียนลง
--             settings จริง + ไม่หลุดระดับ (พบครั้งแรกใน L1 รอบ Foundation)
-- โมดูลที่เกี่ยว: core/foundation/config.lua
-- เวอร์ชันที่แก้: 0.2.0
-- ============================================================================

local H = PKG_harness
local Config = PKG_config
local Migration = PKG_migration
local Bus = PKG_eventbus

H.test("regression/BUG-014: config path สองระดับ — default อ่านได้ + Set อยู่ใต้ settings", function()
  local c = Config.new({
    storage = {
      kind = "memory",
      exists = function() return false end,
      read = function() return nil, "ยังไม่เคยเขียน" end,
      write = function() return true end,
    },
    bus = Bus.new({ clock = VTNow }),
    migration = Migration.new({ clock = VTNow }),
    clock = VTNow,
    time = function() return 1790000000 end,
  })
  c:Load()
  -- (1) กันอาการเดิม: default ใน settings ต้องอ่านได้ทันที (เดิมคืน nil)
  H.eq(c:Get("VoidAim.fov"), 120, "default จาก settings.VoidAim.fov ต้องอ่านได้")
  H.eq(c:Get("i18n.lang"), "th", "default i18n.lang ต้องอ่านได้")
  -- (2) กันอาการเดิม: Set ต้องเขียนลงใต้ settings ไม่หลุดระดับบนสุด
  c:Set("VoidAim.fov", 99)
  H.eq(c.cfg.settings.VoidAim.fov, 99, "Set เขียนลง settings จริง")
  H.eq(c.cfg.VoidAim, nil, "ห้ามหลุดขึ้นระดับบนสุดของ config")
  -- (3) ระดับบนสุดยังอ่านตรง
  H.eq(c:Get("schemaVersion"), Config.CURRENT_SCHEMA_VERSION, "schemaVersion อ่านตรงระดับบนสุด")
end)
