-- ============================================================================
-- CR-REPLAY-001 — Regression test ถาวร (กฎเหล็ก §11: ทุกการแก้ที่ผ่าน CR
-- กลายเป็น test case ถาวรเพื่อกันการถอยหลังของพฤติกรรม)
--
-- CR ID:      CR-REPLAY-001 (อนุมัติโดยเจ้าของโปรเจกต์ 1 ตุลาคม 2026 — ตัวเลือก ข)
-- รากปัญหา:   Bus:Queue() ไม่คืน payload ทำให้ update.lua (loader-domain)
--             ยกคิวของ bus รุ่นเก่าข้าม generation ไม่ได้ — พฤติกรรมที่เกิดจริง
--             คือ DROP queued events ทั้ง freeze window แล้วพึ่ง re-derive จาก
--             Adapter ทั้งหมด ซึ่งขัด Replay Policy §3.6 ดั้งเดิม
--             (State/Config/Idempotent ต้อง REPLAY)
-- การแก้:      eventbus.lua เพิ่ม Bus:ExportQueue (deep clone พร้อม payload) +
--             Bus:ImportQueue (policy ตัดสินใหม่ตาม Declare ของรุ่นปลายทาง
--             ใช้ได้เฉพาะขณะ frozen) — update.lua export หลัง TEARDOWN แล้ว
--             import ก่อน Resume ทั้ง path สำเร็จและ path rollback
-- Regression: เคสด้านล่าง — พิสูจน์ที่ระดับ orchestrator (Update:Apply) ว่า
--             (1) path สำเร็จ: event State ใน freeze window ข้าม generation
--                 ไป replay บนรุ่นใหม่ / Transient ถูก DROP ตาม policy
--             (2) path rollback (F3): event State ข้าม generation ไป replay บน
--                 รุ่นเดิมที่กลับมา เช่นกัน (rollback ≠ ทิ้งทั้งคิวอีกต่อไป)
-- โมดูลที่เกี่ยว: core/foundation/eventbus.lua, core/runtime/update.lua
-- เวอร์ชันที่แก้: 0.5.0 (eventbus 0.2.0 → 0.3.0)
-- ============================================================================

local H = PKG_harness
local U = PKG_update
local BusLib = PKG_eventbus
local Mani = PKG_manifest
local Sha = PKG_sha256

-- ต่อ crypto เป็น sha256 จริง "ระดับเคส" (self-contained — ห้าม patch ที่ระดับ
-- ไฟล์ เพราะเคส cleanup ของ test_update คืน crypto stub ตอนรัน ก่อนถึงเคสของชุดนี้)
local function withRealSha()
  local saved = crypto and crypto.hash or nil
  crypto.hash = function(algo, s)
    if algo ~= "sha256" then return saved and saved(algo, s) or nil end
    return Sha.hex(s)
  end
  return function() crypto.hash = saved end
end

-- ---- fake system factory (รูปเดียวกับ test_update.lua — Bus ตัวจริง) --------

local function makeFakeSystem(knobs)
  knobs = knobs or {}
  local sys = {}
  local bus = BusLib.new({ owner = "TestSystem" })
  sys.bus = bus
  sys.version = knobs.version or "0.2.0"
  sys.releaseId = knobs.releaseId or "r-old"
  sys._replaced = nil
  sys._cfgStore = { schemaVersion = 2, settings = { VoidAim = { fov = 95 } } }
  sys.config = {
    Data = function() return sys._cfgStore end,
    Replace = function(_, cfg)
      if knobs.replaceFails then error("replace boom") end
      sys._replaced = cfg
      return true
    end,
    Get = function(_, p)
      if p == "schemaVersion" then return 2 end
      return nil
    end,
  }
  sys.migration = { Run = function(_, cfg) return cfg end }
  sys.shutdown = {
    Run = function()
      return {
        rows = { { name = "EventBus", orphan = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 } } },
        orphans = 0, ok = true,
      }
    end,
  }
  sys.registry = { Release = function() end }
  sys.watchdog = { Stop = function() end }
  sys.probe = {
    Probe = function()
      return { status = "ok", summary = "stub ok", adapters = {}, impacted = {} }
    end,
    LastReport = function() return { status = "ok" } end,
  }
  sys.providers = knobs.providers or {}
  sys.selfChecks = knobs.selfChecks or { { name = "stub-ok", fn = function() return true end } }
  sys.diag = { Mark = function() end }
  return sys
end

local state = { specs = {} }

local function loadFn(src, chunkName)
  local spec = state.specs[src]
  if not spec then
    return nil, ("ไม่มี spec ของ source %q"):format(tostring(src))
  end
  return function() return makeFakeSystem(spec) end
end

local function maniFor(ver, sha)
  local m, err = Mani.Build({
    version = ver, releaseId = "r-" .. ver,
    files = { ["the-voider.lua"] = { sha256 = sha, size = 5 } },
    minLoaderVersion = "0.2.0", channel = "stable",
  })
  assert(m, tostring(err))
  return m
end

local function makeClock()
  local t = 0
  return function() t = t + 0.001; return t end
end

-- ------------------------------------------------------------------------------

H.test("regression/CR-REPLAY-001: path สำเร็จ — คิว freeze window ข้าม generation ไป replay บนรุ่นใหม่ตาม policy", function()
  local restoreSha = withRealSha()
  state.specs = {}
  state.specs["SRC:0.2.0"] = { version = "0.2.0", releaseId = "r-0.2.0" }
  state.specs["SRC:0.3.0"] = { version = "0.3.0", releaseId = "r-0.3.0" }

  local seenCfg, seenTick = {}, 0
  local upd
  upd = U.new({
    loadFn = loadFn,
    clock = makeClock(),
    time = function() return 1000 end,
    logger = function() end,
    onStep = function(step, info)
      if step == "load" and info and info.system then
        -- โมดูลรุ่นใหม่ Declare + สมัครรับบน bus รุ่นใหม่ก่อน RESUME ทำงาน
        -- (fake system ไม่มี foundation จริง จึงต้อง Declare เอง — ระบบจริง
        --  foundation ประกาศ SYSTEM_EVENTS ให้แล้วตอน bundle สร้าง)
        local s = info.system
        s.bus:Declare("config:changed", "replay")
        s.bus:Declare("world:tick", "drop")
        s.bus:On("config:changed", function(p) seenCfg[#seenCfg + 1] = p end)
        s.bus:On("world:tick", function() seenTick = seenTick + 1 end)
      end
    end,
  })

  local oldSys = makeFakeSystem(state.specs["SRC:0.2.0"])
  oldSys.bus:Declare("config:changed", "replay")
  oldSys.bus:Declare("world:tick", "drop")
  upd:Attach({ system = oldSys, source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })

  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")), {
    drainFns = {
      function()
        -- เหตุการณ์ในหน้าต่าง freeze (บน bus รุ่นเก่า — จุดที่เคยถูกทิ้งทั้งคิว)
        local bus = upd:Active().system.bus
        bus:Publish("config:changed", { path = "VoidAim.fov", value = 555 }) -- State
        bus:Publish("world:tick", { n = 1 })                                 -- Transient
      end,
    },
  })

  H.ok(res.ok, res.detail)
  H.eq(res.path, "OK")
  -- ตัวเลขจากของจริง: คิว 2 ตัวข้าม generation + replay ตาม policy
  H.eq(res.replay.carried, 2, "คิวรุ่นเก่า 2 ตัวถูกส่งข้าม generation (เดิม = ทิ้งทั้งคิว)")
  H.eq(res.replay.carriedAccepted, 1, "State ถูกรับไป replay")
  H.eq(res.replay.carriedDropped, 1, "Transient ถูก DROP ตอน import ตาม policy")
  H.eq(seenTick, 0, "Transient ไม่ถึงมือรุ่นใหม่ (โลกจริง re-derive จาก Adapter)")
  H.eq(#seenCfg, 1, "State event replay ถึงมือโมดูลรุ่นใหม่จริง")
  H.eq(seenCfg[1].value, 555, "payload ข้าม generation มาครบ (ไม่ใช่แค่ metadata)")
  restoreSha()
end)

H.test("regression/CR-REPLAY-001: path rollback (F3) — คิว freeze window ข้าม generation ไป replay บนรุ่นเดิมที่กลับมา", function()
  local restoreSha = withRealSha()
  state.specs = {}
  state.specs["SRC:0.2.0"] = { version = "0.2.0", releaseId = "r-0.2.0" }
  state.specs["SRC:0.3.0"] = {
    version = "0.3.0", releaseId = "r-0.3.0",
    selfChecks = { { name = "boom", fn = function() return false, "จงใจพัง" end } },
  }

  local seenCfg = {}
  local upd
  upd = U.new({
    loadFn = loadFn,
    clock = makeClock(),
    time = function() return 1000 end,
    logger = function() end,
    onStep = function(step, info)
      if step == "rollback.load" and info and info.system then
        -- โมดูลรุ่นเดิมที่กลับมา สมัครรับก่อน rollback.resume
        info.system.bus:Declare("config:changed", "replay")
        info.system.bus:On("config:changed", function(p) seenCfg[#seenCfg + 1] = p end)
      end
    end,
  })

  local oldSys = makeFakeSystem(state.specs["SRC:0.2.0"])
  oldSys.bus:Declare("config:changed", "replay")
  upd:Attach({ system = oldSys, source = "SRC:0.2.0",
    manifest = maniFor("0.2.0", Sha.hex("SRC:0.2.0")) })

  local res = upd:Apply("SRC:0.3.0", maniFor("0.3.0", Sha.hex("SRC:0.3.0")), {
    drainFns = {
      function()
        upd:Active().system.bus:Publish("config:changed", { path = "VoidAim.fov", value = 444 })
      end,
    },
  })

  H.ok(not res.ok and res.path == "F3", res.detail)
  H.eq(res.rolledBack, true)
  H.ok(res.replay ~= nil, "ผลลัพธ์ rollback มีรายงาน replay ให้ตรวจ (ไม่ใช่ทิ้งเงียบ)")
  H.eq(res.replay.carried, 1, "คิวรุ่นเก่า 1 ตัวถูกส่งข้าม generation ตามด้วย rollback")
  H.eq(res.replay.carriedAccepted, 1, "State event ถูกรับไป replay บนรุ่นเดิม")
  H.eq(#seenCfg, 1, "config:changed replay ถึงมือรุ่นเดิมหลัง rollback จริง")
  H.eq(seenCfg[1].value, 444, "ค่า state จากหน้าต่าง freeze ไม่หาย (LWW)")
  restoreSha()
end)
