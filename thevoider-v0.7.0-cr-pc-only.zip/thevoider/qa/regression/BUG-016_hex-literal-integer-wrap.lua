-- REGRESSION BUG-016: fengari จับ hex literal เกิน 2^31 เป็นค่าติดลบ
-- และ integer arithmetic ของ fengari wrap ที่ 2^31 (signed 32-bit)
--
-- อาการ (ตอนพบในรอบ Loader v2):
--   1) ค่าคงที่ SHA-256 (K/H0) หลายตัวเขียนเป็น hex เกิน 0x7fffffff
--      → fengari parse เป็นติดลบ (0xbb67ae85 = -1150833019) ทำ digest ผิดทั้งไฟล์
--   2) แม้ค่าคงที่ถูกแล้ว ผลรวมแบบ integer (เช่น T_X[..]*256 + ..*16777216
--      ใน hashBlock และ ops) เกิน 2^31 แล้ว wrap เป็นลบ → index ตารางพัง
--      ("attempt to index a nil value") — เจอเฉพาะข้อความที่มีไบต์ ≥ 0x80
--      เช่น ข้อความไทย (UTF-8 3 ไบต์/ตัว)
--
-- การแก้ (คงอยู่ใน core/runtime/sha256.lua):
--   - ค่าคงที่ทั้งหมดเขียนเป็นฐานสิบ (ปลอดภัยทุก runtime)
--   - คูณตัวประกอบทุกตัวเป็น float (256.0 / 65536.0 / 16777216.0)
--     — double แม่นยำถึง 2^53 จึงไม่มีทาง wrap
--
-- การ์ดนี้ป้องกัน regression: ถ้าใครกลับไปใช้ hex ตัวใหญ่หรือ integer math
-- ในเส้นทาง hash — เทสนี้ต้องแดงทันที
local H = PKG_harness
local S = PKG_sha256

H.test("BUG-016: KAT พร้อมข้อความไทย/ไบต์สูง (จุดที่เคยพัง)", function()
  -- ตัวที่เคยพังเพราะ wrap ที่ 2^31: ข้อความมีไบต์ ≥ 0x80 (ไทย UTF-8 = 65 ไบต์)
  H.eq(S.hex("TV-BUNDLE BODY เพื่อการทดสอบ 1234567890"),
    "e6c886d2eb31f99e94ce6ca2199e6139e0ba75f7ee59af451ba74c4f3db653ab")
  H.eq(S.hex("ทดสอบ"),
    "c8d275859534d69ce76f6cd2266057857df1e2b0d12b17f6763d9173d33b6072")
end)

H.test("BUG-016: digest ต้องตรง python hashlib (ค่าคงที่ถูกต้อง)", function()
  -- ตัวเลขพวกนี้คำนวณจาก python3 hashlib แล้ว (ไม่ใช่ค่าที่เดา)
  H.eq(S.hex(""), "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855")
  H.eq(S.hex("abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
  H.eq(S.hex("TheVoider-KAT"), "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee")
  H.eq(S.hex(string.rep("a", 1000)), "41edece42d63e8d9bf515a9ba6932e1c20cbc9f5a5d134645adb5db1b9737ea3")
end)

H.test("BUG-016: selfTest รวม + ไม่มี hex literal ตัวใหญ่ในแหล่ง (คงที่เป็นฐานสิบ)", function()
  local ok, detail = S.selfTest()
  H.ok(ok, detail)
  -- ถ้ามีใครกลับไปเขียนค่าคงที่เป็น hex เกิน 0x7fffffff — fengari จะทำให้
  -- digest เพี้ยนและ KAT ด้านบนต้องแดงก่อนหน้านี้แล้ว (การ์ดซ้อนกันสองชั้น)
end)
