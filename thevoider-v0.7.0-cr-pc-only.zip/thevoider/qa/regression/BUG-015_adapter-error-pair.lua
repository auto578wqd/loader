-- ============================================================================
-- BUG-015 — Regression test ถาวร (กฎเหล็ก §11: บั๊กทุกตัวกลายเป็น test case)
--
-- BUG ID:     BUG-015 (2 อาการจากต้นเหตุเดียว: การเขียน expression รับคู่ค่าผิด)
-- รากปัญหา:   (ก) core/adapter/combat.lua ใช้ `rs:FindFirstChild and ...`
--             ซึ่งเป็นไวยากรณ์ Lua ที่ผิด (method access ไม่มีวงเล็บใน expression
--             = "function arguments expected") — โหลดไฟล์ไม่ผ่านเลย
--             (ข) core/adapter/character.lua เรียก humanoidOf() แล้วรับค่าเดียว
--             ทั้งที่ฟังก์ชันคืนคู่ (hum, err) → err หาย → IsAlive คืน (nil, nil)
--             → ผู้เรียก index err.code พัง ("attempt to index a nil value")
-- การแก้:      (ก) dot access + type check: `type(rs.FindFirstChild)=="function"`
--             ก่อนเรียกจริง (ทุกจุดที่เช็ค method มีอยู่) (ข) รับคู่ค่าครบทุกจุด
--             (`local hum, humErr = humanoidOf(...)` → คืน humErr ต่อ)
-- Regression: (ก) ชุดเทส adapter โหลด+รันได้ (load ครั้งแรกของ L1 จับเอง)
--             (ข) เคสด้านล่าง — Character หายแล้วทุก method ต้องคืน err ที่
--             มี .code จริง ไม่ใช่ nil
-- โมดูลที่เกี่ยว: core/adapter/combat.lua, core/adapter/character.lua
-- เวอร์ชันที่แก้: 0.2.0
-- ============================================================================

local H = PKG_harness
local RuntimeLib = PKG_init
local PlayerAdapter = PKG_adapter_player
local CharacterAdapter = PKG_adapter_character
local CombatAdapter = PKG_adapter_combat

H.test("regression/BUG-015: adapter คืนคู่ค่า (ผล, err) ครบ — err มี .code จริงเสมอ", function()
  __GAME.reset()
  local R = RuntimeLib.new({ clock = VTNow, task = task, drawing = Drawing, instance = Instance })
  local player = PlayerAdapter.new({ env = { game = game } })
  local character = CharacterAdapter.new({ env = { game = game }, playerAdapter = player })
  local combat = CombatAdapter.new({
    env = { game = game },
    playerAdapter = player,
    characterAdapter = character,
  })

  __GAME.kill("character")

  -- (ข) กันอาการเดิม: ทุก method ต้องคืน err ที่ index .code ได้ (เดิม err = nil)
  local alive, err1 = character:IsAlive()
  H.eq(alive, nil, "IsAlive คืน nil เมื่อไม่รู้สถานะ (ไม่ใช่ false หลอก)")
  H.eq(type(err1) == "table" and err1.code, "GONE", "err1.code = GONE (เดิม nil → caller พัง)")

  local state, err2 = character:GetState()
  H.eq(state, nil, "GetState คืน nil")
  H.eq(err2.code, "GONE", "err2.code = GONE")

  local md, err3 = character:GetMoveDirection()
  H.eq(md, nil, "GetMoveDirection คืน nil")
  H.eq(err3.code, "GONE", "err3.code = GONE")

  -- (ก) กันอาการเดิม: combat ใช้ dot access + type check ต้องโหลด/เรียกได้ปกติ
  local w, wErr = combat:GetEquippedWeapon()
  H.eq(w, nil, "อาวุธ: ไม่มี character = คืน nil")
  H.eq(wErr.code, "GONE", "อาวุธ err.code = GONE")

  __GAME.restore("character")
end)
