# 🕳️ THE VOIDER
## แผนพัฒนาฉบับเต็ม (Master Development Plan) — v2.1 (APPROVED / FROZEN)

> **สถานะเอกสาร:** 🟢 **APPROVED / FROZEN v2.1** — แก้ครบทั้งรีวิว 14 จุด (รอบแรก) + 7 จุด hardening (รอบสอง) + 4 จุดสุดท้ายและขอบเขต executor (รอบสาม freeze) — **ห้ามแก้แผนอีก** รอบ review แผนจบที่นี่ งานถัดไปคือเฟส 0
> **[CR-PC-ONLY — อนุมัติ 1 ต.ค. 2026]** แพลตฟอร์มเป้าหมายเปลี่ยนเป็น **PC/Desktop only บน Volt** (Mobile = ไม่รองรับ/ไม่ทดสอบ/ไม่รับประกัน) — การแก้ไขทุกจุดในแผนฉบับนี้หลังวันที่ดังกล่าวเป็น **annotation อ้างอิง CR-PC-ONLY เท่านั้น** ไม่ใช่การเขียนใหม่ (จุดที่กระทบ: §1 หลัก 4, §2 ตารางคู่แข่ง, §3.1 โครงไม้ UI, §3.2 INPUT, Input API, §3.8 ต้นไม้ไฟล์, §4.3 VoidAim/VoidMacro, §4.4 อัปเกรด 7 ข้อ, §5.3 roadmap, **§5.4 DoD เฟส 1 ฉบับ PC-only**, §5.6, §8.3) — รายละเอียด CR เต็ม: `docs/CHANGELOG.md` v0.7.0
> **เวอร์ชันแผน:** 2.1 | **วันที่:** 30 กันยายน 2026 (freeze: 1 ตุลาคม 2026) | **ผู้จัดทำ:** Super Z | **แก้จาก:** v1.0 (8/10) → v2.0 (รอบสอง ~95%) → v2.1 แก้เฉพาะ 7 จุด hardening + คำผิด 3 จุด + รอบสาม (freeze) 4 จุดสุดท้าย + ขอบเขต "Volt เท่านั้น" **ไม่มีฟีเจอร์ใหม่แม้แต่รายการเดียว**
>
> **หลักคิดกลางของ v2.0:** เปลี่ยน mindset จาก *"ทำให้สมบูรณ์แบบ"* เป็น ***"ทุก requirement ต้องมีวิธีวัดที่พิสูจน์ได้"*** — ทุกเกณฑ์ในเอกสารนี้ต้องระบุได้ว่าวัดอย่างไร ที่ไหน และผ่านที่ตัวเลขเท่าไร

| ข้อมูลโปรเจกต์ | รายละเอียด |
|---|---|
| ชื่อ | **The Voider** — Blox Fruits PvP Script ฉบับของเรา 100% |
| ขอบเขต | Blox Fruits เกมเดียว (เน้นลึก ไม่กระจายหลายเกม) + **executor เป้าหมาย: Volt เท่านั้น** (executors อื่นไม่รองรับ ไม่ทดสอบ ไม่รับประกัน) |
| แนวคิดหลัก | "ไม่มีคีย์ ไม่มีข้อจำกัด ใครก็ใช้ได้ — เพราะเป็นของเราเอง" |
| รูปแบบการพัฒนา | แบ่ง 5 เฟส ส่งมอบทีละเฟส + จัดลำดับความสำคัญฟีเจอร์เป็น **P0/P1/P2** |
| การกระจาย | GitHub + Loader (4-URL + Version Gate + Manifest SHA-256) + อัปเดตสดพร้อม cleanup |
| ธีม UI | Void นีออน (ดำ–ม่วง–ฟ้าเรือง, glassmorphism) + Developer Diagnostics ซ่อน |
| มาตรฐานคุณภาพ | สูงสุด — ทดสอบ 3 ชั้น (Unit/Integration/Live) + Regression + Performance Budget + Capability Detection |
| นิยาม "เสร็จ" | 100% ของ *behavior* ใน Behavioral Acceptance Matrix ของระดับนั้น — ไม่ใช่จำนวนโค้ด |

---

## 📑 สารบัญ

0. [บันทึกการแก้ไข v1.0 → v2.0 → v2.1 (รีวิว 14 จุด + hardening 7 จุด + freeze รอบสาม 4 จุด)](#0-บันทึกการแก้ไข-v10--v20--v21-รีวิว-14-จุด--hardening-7-จุด--freeze-รอบสาม-4-จุด)
1. [สรุปผู้บริหาร (Executive Summary)](#1-สรุปผู้บริหาร-executive-summary)
2. [Feature Audit v2 — จากการนับ Keyword สู่ Behavioral Matrix](#2-feature-audit-v2--จากการนับ-keyword-สู่-behavioral-matrix)
3. [สถาปัตยกรรม v2 (Architecture)](#3-สถาปัตยกรรม-v2-architecture)
4. [ข้อกำหนดฟีเจอร์ v2 — P0 / P1 / P2 (Feature Specification)](#4-ข้อกำหนดฟีเจอร์-v2--p0--p1--p2-feature-specification)
5. [แผนพัฒนา 5 เฟส v2 — DoD ที่วัดได้ (Roadmap)](#5-แผนพัฒนา-5-เฟส-v2--dod-ที่วัดได้-roadmap)
6. [กลยุทธ์คุณภาพ v2 — Unit / Integration / Live (QA Strategy)](#6-กลยุทธ์คุณภาพ-v2--unit--integration--live-qa-strategy)
7. [ระบบกระจายและอัปเดตสด v2 — SHA-256 Manifest (Distribution)](#7-ระบบกระจายและอัปเดตสด-v2--sha-256-manifest-distribution)
8. [การออกแบบ UI v2 + Developer Diagnostics (UI Design)](#8-การออกแบบ-ui-v2--developer-diagnostics-ui-design)
9. [Performance Budget (งบประมาณทรัพยากร)](#9-performance-budget-งบประมาณทรัพยากร)
10. [ความเสี่ยงและแผนรับมือ v2 (Risk Register)](#10-ความเสี่ยงและแผนรับมือ-v2-risk-register)
11. [กฎเหล็กของโปรเจกต์ (Iron Rules)](#11-กฎเหล็กของโปรเจกต์-iron-rules)
12. [ขั้นตอนถัดไปและบันทึกการอนุมัติ (Next Steps)](#12-ขั้นตอนถัดไปและบันทึกการอนุมัติ-next-steps)

---

## 0. บันทึกการแก้ไข v1.0 → v2.0 → v2.1 (รีวิว 14 จุด + hardening 7 จุด + freeze รอบสาม 4 จุด)

รีวิวของคุณให้คะแนนแผนเดิม 8/10 และชี้ 14 จุด ซึ่งผมยอมรับทั้งหมดและแก้ครบในเอกสารฉบับนี้ ตารางนี้คือ "ใบเสร็จรับเงิน" — ทุกจุดระบุว่าแก้ที่หมวดไหนและแก้อย่างไร เพื่อให้ตรวจสอบย้อนกลับได้ง่าย:

| # | จุดรีวิว | สถานะ | แก้ที่ไหน | สรุปการแก้ |
|---|---|---|---|---|
| 1 🔴 | Audit วัดจาก "จำนวน keyword" ไม่ใช่พฤติกรรมจริง | ✅ แก้แล้ว | §2 | ตัวเลข keyword ลดบทบาทเหลือ "ตัวชี้วัดขนาด" เท่านั้น + เพิ่ม **Behavioral Feature Matrix** เป็นมาตรฐาน parity ใหม่ + นิยาม "100%" ใหม่เป็น "100% ของ behavior ที่อยู่ใน acceptance matrix" |
| 2 🔴 | Game Adapter Layer ถูกพูดถึงแต่ไม่อยู่ในโครงจริง | ✅ แก้แล้ว | §3.1, §3.3 | เพิ่มเป็น layer จริงในสถาปัตยกรรม 6 API + Adapter Self-Probe + ห้ามโมดูลแตะเกมโดยตรง |
| 3 🔴 | Hot Update ไม่มี Unload/Cleanup/State Migration | ✅ แก้แล้ว | §3.4, §3.6 | Module lifecycle เพิ่ม `Destroy` + `SerializeState` + `MigrateState` + **Hot Update Protocol 12 ขั้น** พร้อมตรวจ registry = 0 ก่อนสลับ |
| 4 🔴 | Event Bus เท่านั้น = เข้มเกินไปสำหรับ hot path | ✅ แก้แล้ว | §3.5 | เปลี่ยนเป็น **Hybrid**: Event Bus สำหรับ lifecycle/config/notification/cross-module signal + **Direct Service Interface** สำหรับ hot path (target/prediction/camera/per-frame) |
| 5 🔴 | ตัวเลข DoD ตายตัวเกินจริง (0.01s / 0.1s / 60fps / 100%) | ✅ แก้แล้ว | §5 | ทุกเกณฑ์เขียนใหม่เป็น "วิธีวัด + tolerance ตาม runtime + upper-bound จาก test environment" + ตารางเทียบเป้าเดิม ❌ → เป้าใหม่ ✅ |
| 6 🔴 | QA ต้องแยก Unit / Integration / Live | ✅ แก้แล้ว | §6.1–6.2 | แยกเป็น 3 ชั้น L1/L2/L3 + ชุดทดสอบแยกเป็น Regression / Performance / Stress & Long-run / Compatibility |
| 7 🔴 | 3 Executors ควรใช้ Capability Detection | ✅ แก้แล้ว | §3.2, §6.3 | เพิ่ม **Runtime Capability Layer**: ตรวจ 8 capability จริงตอน startup + ฟีเจอร์เช็คก่อนเปิด + graceful disable + แจ้งเหตุผลเป็นภาษาไทย |
| 8 🟠 | Config ต้องมี Schema Version + Migration | ✅ แก้แล้ว | §3.7 | โครง config มี `schemaVersion` + ลูกโซ่ migration ทีละเวอร์ชัน + fallback: backup → restore defaults → แจ้งผู้ใช้ |
| 9 🟠 | MD5 → SHA-256 / Signed Manifest | ✅ แก้แล้ว | §7.1–7.3 | Manifest ใหม่: Version + SHA-256 + Size + Release ID + MinLoaderVersion + ความจริงเรื่อง hashing ใน executor (มี capability ใช้เลย, ไม่มี = fallback ตรวจระดับ 2 + บอกตามจริง) + signed manifest = P2 |
| 10 🟠 | Scope Creep — ทุกอย่างเป็น v1.0 requirement พร้อมกัน | ✅ แก้แล้ว | §4.2 | แบ่ง **P0 (ต้องมีใน v1.0)** / **P1 (ควรมี ไม่บล็อก v1.0)** / **P2 (experimental หลัง core stable)** + กติกา "v1.0 เสร็จเมื่อ P0 ครบ" |
| 11 🟡 | 15 ระบบ vs 8 ระบบ ใช้ taxonomy เดียว | ✅ แก้แล้ว | §1, §4.1 | ใช้ลำดับชั้นเดียวทั้งเอกสาร: **15 Feature Domains → 8 Product Modules → 20+ Internal Services** พร้อมตาราง mapping |
| 12 🟡 | เพิ่ม Performance Budget + Diagnostics ตั้งแต่ Foundation | ✅ แก้แล้ว | §8.4, §9 | งบประมาณ 10 ตัวชี้วัด (CPU/Memory/Connections/Event/GC/Startup/Hot update) + Developer Diagnostics ซ่อนในแท็บ Setup + กติกา "Performance Budget ห้ามแย่ลงโดยไม่มีเหตุผลที่บันทึกไว้" |
| 13 🟡 | Safety Layer ควรแยกเป็น Runtime Layer ชัดเจน | ✅ แก้แล้ว | §3.2 | ยกให้เป็น **Runtime Layer** เต็มรูปแบบ: Capability Detection + Task Registry + Connection Registry + Error Boundary + Watchdog + Shutdown Manager |
| 14 🟢 | บั๊ก → regression test ถาวร (ชอบ ให้เก็บไว้) | ✅ เก็บไว้ + เพิ่ม | §11 | เก็บกฎเดิม + เพิ่ม **"No undocumented hotfix"**: ทุก fix ต้องมี BUG ID / Root Cause / Fix / Regression Test / Affected Modules / Version Fixed |

### รอบสอง: 7 จุด Hardening + คำผิด (จากรีวิว v2.0 ~95%)

รีวิวรอบสองตัดสินว่า v2.0 ผ่านการแก้ 14 จุดแล้ว แต่เหลือ **architecture hardening** อีก 7 จุดที่ควรเก็บก่อนเริ่มเฟส 0 — รอบแก้นี้ทำเฉพาะ 7 จุดนี้ + คำผิด 3 จุด **ไม่เพิ่มฟีเจอร์ใหม่** ตามเงื่อนไข scope freeze:

| # | จุดรีวิวรอบสอง | สถานะ | แก้ที่ไหน | สรุปการแก้ |
|---|---|---|---|---|
| H1 🔴 | Hot Update ไม่มี FAIL → ROLLBACK ชัด ๆ (force-clean แล้วไปต่อ = อันตราย) | ✅ แก้แล้ว | §3.6 | VERIFY orphan > 0 = **ABORT + คืน snapshot รุ่นเดิม** (เลิก force-clean ไปต่อ) + เพิ่ม **Rollback Paths F0–F4** ครบทุกจุดที่พังได้ (PRE-STAGE / VERIFY / LOAD+MIGRATE / SELFCHECK / ADAPTER PROBE) + กฎ "ผู้ใช้ห้ามค้างสถานะครึ่ง ๆ" + DoD เพิ่ม failure injection ทุกเส้นทาง |
| H2 🔴 | ขาด Render/Object Registry — orphan 0 ตรวจได้แค่ task+connection | ✅ แก้แล้ว | §3.1, §3.2, §3.4 | Task+Connection Registry รวมเป็น **Resource Registry เดียวครอบ 4 ชนิด** (Tasks / Connections / Drawing-Render / Temporary) + API ใหม่ `Runtime.NewRender` / `Runtime.Temp` + orphan = 0 ตรวจ**รวมทุกชนิด**ทุกจุดที่อ้างถึง (Destroy / VERIFY / DoD / §9) |
| H3 🔴 | Event replay อาจย้อน state (เป้า A ตายระหว่าง freeze) | ✅ แก้แล้ว | §3.6 | ทุก event มี metadata 4 ช่อง (generation / timestamp / type / replayable) + **Replay Policy 3 ชนิด**: Transient → DROP, State/Config → REPLAY (last-write-wins), Idempotent → REPLAY ได้ + กฎ "state ของโลกจริง re-derive จาก Adapter ไม่ใช้ event เก่า" + ฉากทดสอบ "เป้าตายระหว่าง freeze" |
| H4 🔴 | DoD ขัดกับ P0/P1 (Visual Editor เป็น P1 แต่ถูกวางใน DoD รับเฟส 3) | ✅ แก้แล้ว | §5.1, §5.5, §5.6 | กฎใหม่ทุกเฟส: **P0 DoD = MUST PASS / P1 DoD = SHOULD PASS (ไม่ผ่าน = ย้าย backlog v1.1 เฟสผ่านได้) / P2 ไม่ตรวจรับใน v1.0** — แยก DoD เฟส 2 และเฟส 3 เป็นสองบล็อกชัดเจน |
| H5 🟠 | Performance ต้องแยก L2 benchmark กับ L3 reality | ✅ แก้แล้ว | §9.1–9.2, §6.2 | §9.1 เปลี่ยนเป็น **L2 Performance Budget (engineering benchmark — ห้ามอ้างเป็น performance เครื่องผู้ใช้)** + ใหม่ §9.2 **L3 Performance Baseline**: เก็บ median/p95/max + เทียบ baseline ก่อน-หลังเปิดฟีเจอร์บนเครื่องเดิม |
| H6 🟠 | HTTP edge case: core ยังไม่โหลด = ไม่มี UI ให้แจ้ง | ✅ แก้แล้ว | §3.2 | แยก **Bootstrap Preflight (ระดับ 0 ใน loader)** ออกจาก Runtime Capability — bootstrap fail = แจ้ง plain text ผ่านคอนโซล executor แล้วหยุด ไม่สัญญาเปิด Notification UI ในสถานการณ์ที่เปิดไม่ได้ |
| H7 🟠 | Dependency Graph ต้องเป็น artifact จริง ไม่ใช่แค่คำพูด | ✅ แก้แล้ว | §3.10 (ใหม่), §3.2, §3.8 | ไฟล์ `docs/architecture/dependencies.md` เป็น **source of truth เดียว** ของทั้ง Init() และ Shutdown/TEARDOWN + build validation 3 ชั้น (missing / circular / invalid) ไม่ผ่าน = ไม่ได้ build |

**คำผิดที่แก้ตามรีวิว:** "เชื้อสายไม่มีใน" → "จะไม่เป็นส่วนหนึ่งของ" (§1) | "ชื่อชั่วคราม" → "ชื่อชั่วคราว" (§3.7) | "Budget ห้าน่าลง" → **"Performance Budget ห้ามแย่ลงโดยไม่มีเหตุผลที่บันทึกไว้"** (§6.2, §9.3, §11)

**สัญญาของรอบแก้นี้:** แก้เฉพาะ 7 จุด + คำผิดเท่านั้น — ไม่มีฟีเจอร์ใหม่ ไม่มีการขยับขอบเขต หลังอนุมัติ = freeze แผนและเริ่มเฟส 0 ทันที

**สิ่งที่คงไว้จาก v1.0 โดยไม่แก้** (เพราะรีวิวยืนยันว่าถูกทาง): ปรัชญา "ไม่มี key ตั้งแต่ไลน์แรก", VoidAim 3 โหมด (EZ/Pro/Legend), จังหวะส่งมอบ 5 เฟส, ธีม Void นีออน, ทิศทาง loader 4-URL + version gate, กติกา "ห้ามทำงานเงียบ" และ Update Log ทุกการเปลี่ยนแปลง

### รอบสาม: Freeze — 4 จุดสุดท้าย + ขอบเขต executor (จากรีวิว v2.1 พร้อม freeze)

รีวิวรอบสามสรุปว่า **แกนสถาปัตยกรรมผ่านแล้ว** (14 จุดรอบแรก + 7 จุด hardening อยู่ครบในเอกสาร) เหลือแก้เพียง 4 จุดเล็ก ๆ ก่อน freeze พร้อมกำหนดขอบเขต executor ให้ชัด — รอบนี้**ไม่เพิ่มฟีเจอร์ใด ๆ** และเป็นรอบแก้แผน**รอบสุดท้าย**:

| # | จุดรีวิวรอบสาม | สถานะ | แก้ที่ไหน | สรุปการแก้ |
|---|---|---|---|---|
| R1 🟢 | ชื่อ §3.2 "ห้าองค์ประกอบ" ไม่ตรงจำนวนจริง (มี 6 รายการ ลำดับ 0–5) | ✅ แก้แล้ว | §3.2, §5.2, §5.3, §12 | เปลี่ยนเป็น **"Runtime Layer — 5 องค์ประกอบ + 1 Bootstrap Preflight"** ทุกจุดที่อ้างถึงทั้งเอกสาร |
| R2 🟢 | Executive Summary ยังใช้ "connection/task orphan" ไม่ตรงกับ Resource Registry 4 ชนิดของ v2.1 | ✅ แก้แล้ว | §1, §5.4, §6.2, §8.4 | เปลี่ยนเป็น **"Resource orphan = 0"** พร้อมแยก **Tasks = 0 / Connections = 0 / Render = 0 / Temporary = 0** — terminology ตรงกันทั้งเอกสาร |
| R3 🟢 | Rollback ดีแล้ว แต่ควร lock กฎ atomic update | ✅ แก้แล้ว | §3.6 | เพิ่ม **ATOMIC UPDATE RULE**: OLD = active / NEW = staged — **ห้ามประกาศ release ใหม่เป็น active จนกว่า LOAD → MIGRATE → SELFCHECK → ADAPTER PROBE ผ่านครบ** |
| R4 🟢 | Rollback Snapshot ควรกำหนดสิ่งที่เก็บให้ชัด | ✅ แก้แล้ว | §3.6 | เพิ่ม schema บังคับ 7 ช่อง (version / releaseId / bundle / manifest / moduleStates / configState / timestamp) + กฎ **"สร้างและตรวจว่า recover ได้ก่อน TEARDOWN เด็ดขาด"** |
| R5 🔵 | ขอบเขต executor: ให้รองรับ Volt เท่านั้น | ✅ แก้แล้ว | §3.2, §5.7, §6.1, §6.3, §10, §12 | ตัด Solara/Delta ออกจากทุกจุด — **ทดสอบ/รับประกันบน Volt เท่านั้น** executors อื่นไม่รองรับ ไม่ทดสอบ ไม่รับประกัน |

**ผลของรอบนี้:** สถานะเอกสารเปลี่ยนเป็น 🟢 **APPROVED / FROZEN v2.1** (1 ตุลาคม 2026) — **ห้ามแก้แผนอีก** เว้นแต่ระหว่างพัฒนาพบ requirement ใหม่หรือข้อจำกัดจริงจากการทดสอบ ซึ่งต้องบันทึกเป็น change request แยกต่างหาก รอบ review แผนจบที่นี่ — ต่อจากนี้คืองานสร้างระบบเฟส 0

---

## 1. สรุปผู้บริหาร (Executive Summary)

**The Voider คืออะไร** — สคริปต์ Blox Fruits สาย PvP ที่เขียนขึ้นใหม่ทั้งหมดจากศูนย์ โดยนำความรู้ บทเรียน และเทคโนโลยีทั้งหมดจากโปรเจกต์ Cokeboys NoKey Edition (v2.2 ถึง v3.1) มาเป็นฐานราก แต่**ไม่คัดลอกโค้ดเดิมแม้แต่บรรทัดเดียว** ชื่อ "The Voider" สื่อถึงหลุมดำ — ดูดทุกเทคนิคที่ดีที่สุดมาไว้ที่เดียว และไม่ปล่อยให้บั๊กหลุดออกไปหาผู้ใช้

**ทำไม "ของเราเอง" ถึงดีกว่า — จากประสบการณ์จริง** — งานกว่า 90% ในโปรเจกต์เดิมคือการ "สู้กับระบบ key ของ Cokeboys": auth hook หลอก, toast guard 15 ลายเซ็น, GUI sanitizer, จนถึงบั๊ก 128 bytes ที่ hook ของเราบล็อก loader ของเราเอง ปัญหาเหล่านี้**จะไม่เป็นส่วนหนึ่งของ The Voider** เพราะไม่มี key ตั้งแต่ไลน์แรกของการออกแบบ นอกจากนี้เราควบคุมโค้ด 100% — เกมอัปเดตเมื่อไรแก้ได้ทันทีด้วยตัวเอง

**หัวใจที่เปลี่ยนไปจาก v1.0:** แผนเดิมตั้งเป้าด้วยตัวเลขสวย ๆ ("0 error", "แม่น 100%", "60fps") ซึ่งฟังดูดีแต่พิสูจน์ไม่ได้บน runtime จริงที่มี frame scheduling, ping และพฤติกรรม executor เข้ามาเกี่ยวข้อง แผน v2.0 จึงเปลี่ยนเป็น: **ทุก requirement มีวิธีวัดที่พิสูจน์ได้** — ระบุว่าวัดที่ชั้นทดสอบไหน (L1/L2/L3), tolerance เท่าไร, และ upper-bound ที่ยอมรับได้อ้างอิงจาก test environment ที่ควบคุมได้

**เป้าหมายหลัก 5 ข้อ (ปรับให้วัดได้ทุกข้อ):**

1. **Feature Parity แบบพฤติกรรม** — ครบทุก *behavior* ที่กำหนดใน Behavioral Acceptance Matrix ของทุกโมดูล P0 (นิยาม "100%" ใหม่อยู่ใน §2.3) ไม่ใช่ครบตามจำนวนจุดโค้ดของคู่แข่ง
2. **VoidAim ยอดเยี่ยมที่สุด** — แม่น ฉลาด และ**ใช้ง่ายที่สุดในตลาด** (เปิดครั้งเดียวใช้ได้เลย แต่ลึกพอสำหรับมืออาชีพ) — วัดความสำเร็จผ่าน matrix ของ VoidAim และ L3 checklist "ผู้ใช้ใหม่เปิดใช้สำเร็จใน 10 วินาที"
3. **เสถียรแบบพิสูจน์ได้** — ไม่มี error ที่ไม่มี Bug ID, ผ่าน stress test 2 ชั่วโมงตามเกณฑ์ Performance Budget (§9), memory ไม่โตแบบ monotonic, **Resource orphan = 0** ทุกครั้งหลัง Destroy — แยกเป็น **Tasks = 0 / Connections = 0 / Render = 0 / Temporary = 0** (วัดจาก Resource Registry ครอบทั้ง 4 ชนิด §3.2)
4. **ใช้ง่ายที่สุด** — UI ภาษาไทยเต็มรูปแบบ (คู่แข่งไม่มี), ~~รองรับมือถือจริงจัง~~ *(CR-PC-ONLY 1 ต.ค. 2026: PC/Desktop only บน Volt — Mobile ไม่รองรับ/ไม่ทดสอบ/ไม่รับประกัน)*, ฟีเจอร์ไหนเปิดไม่ได้เพราะ runtime ไม่รองรับต้อง**บอกผู้ใช้เสมอ** (No Silent Degradation)
5. **อัปเดตสดที่ปลอดภัยจริง** — hot update มี cleanup ครบวงจร (§3.6): serialize state → destroy → ตรวจ registry ว่าง → โหลดใหม่ → migrate state → self-check — ไม่ใช่ "รัน loader ซ้ำแล้วหวังว่าจะไม่พัง"

**Taxonomy กลางของโปรเจกต์ (ใช้คำเดียวกันทั้งเอกสาร — ตอบจุดรีวิว #11):**

```text
15 Feature Domains   = ภาษาการตรวจสอบ (พื้นที่ความสามารถของคู่แข่ง — จาก audit)
        ↓ จัดกลุ่มเป็นผลิตภัณฑ์
8 Product Modules    = ภาษาผลิตภัณฑ์ (สิ่งที่ผู้ใช้เห็นเป็นแท็บใน UI)
        ↓ สร้างด้วยชิ้นส่วนภายใน
20+ Internal Services = ภาษาวิศวกรรม (สิ่งที่เราสร้างจริงในโค้ด)
```

**ตัวเลขสำคัญของแผน:** 15 Feature Domains → 8 Product Modules → 20+ Internal Services | ฟีเจอร์จัด 3 ระดับ P0/P1/P2 | พัฒนา 5 เฟส ~9–12 รอบส่งมอบ | ทดสอบ 3 ชั้น (L1/L2/L3) + 4 ชุดทดสอบ | ภาษาไทย + อังกฤษ | **executor เป้าหมาย: Volt เท่านั้น**

---

## 2. Feature Audit v2 — จากการนับ Keyword สู่ Behavioral Matrix

### 2.1 บทบาทใหม่ของตัวเลข keyword (ตอบจุดรีวิว #1)

การนับ keyword ในไฟล์จริง `cokeboys-bloxfruits-NOKKEY.lua` (2,372,671 ไบต์) ยังมีค่า — แต่เฉพาะในบทบาทที่มันตอบได้จริง: **ตัวชี้วัดขนาดและความหนาแน่นของระบบ** ใช้ชี้ที่ยกมา ใช้ประเมินขนาดงาน และใช้กำหนดพื้นที่ที่ต้องไปสำรวจพฤติกรรม

> **344 จุดในโค้ด ≠ 344 พฤติกรรมของฟีเจอร์** — ตัวเลขนี้จึงไม่ถูกใช้เป็นหลักฐานความครบถ้วนอีกต่อไป

### 2.2 ตาราง 15 Feature Domains (เก็บไว้ในฐานะ "แผนที่ขนาดของคู่แข่ง")

| # | Feature Domain | จุดอ้างอิง (ตัวชี้วัดขนาด) | สิ่งที่ตรวจพบ |
|---|---|---|---|
| 1 | **Fruit System** | 508 | Auto Roll Fruits, Auto-Store Fruit, Fruit Transform, Fruit Stock, Fruit Gacha, Awakening |
| 2 | **Smart Macro** | 399 | Smart Macro Guide, Macro Slots หลายชุด, Soru Skill Macro, Mobile Macro Slots — ระบบใหญ่ที่สุด จุดขายหลักของเขา *(หมายเหตุ: ฝั่งเราไม่ทำ Mobile Macro Slots — MC-012 OUT OF SCOPE ตาม CR-PC-ONLY)* |
| 3 | **ESP System** | 364 | Name, Level, Race, Ken, Health Bar, Distance, Combat State, Bounty, Indicators |
| 4 | **Aimbot System** | 344 | Aimbot หลัก + Skill Aimbot (86) + Soru Aimbot (30) + Key/Mode/Prediction/Exclude |
| 5 | **Player/Combat** | 256/142 | Anti Combo, Anti Stun, Ability Trigger, Ability Range Check, Attack Delay, Acidum Rifle M1 |
| 6 | **Config System** | 216 | Config บันทึก/โหลด + Preset (102 จุด) |
| 7 | **Race System** | 171 | Auto V3, Auto V4, Smart V3, Smart V4, HideV4Effects |
| 8 | **FFlags System** | 162 | FastFlags + Auto Apply on Launch |
| 9 | **Sword/Gun Combat** | 135/109 | อาวุธดาบ+ปืน + Block Editor + Combo (107) |
| 10 | **Bounty System** | 138 | ติดตาม Bounty + แสดงใน ESP ด้วยสี |
| 11 | **Teleport** | 89 | วาร์ปจุดต่าง ๆ + Auto Teleport Loader |
| 12 | **Server Hop** | 84 | สลับเซิร์ฟเวอร์ |
| 13 | **Observation (Ken)** | 54 | Auto Ken, Auto Observation |
| 14 | **Multi-language** | 6 ภาษา | สเปน โปรตุเกส ฝรั่งเศส ฟิลิปปินส์ เวียดนาม อินโดนีเซีย (**ไม่มีไทย**) |
| 15 | **ระบบเสริม** | — | Anti-AFK, Theme, Keybind, Movement Boosts (Air Jump, Sang Z, Yama Z, Soul Guitar Momentum, Dash/Jump Boost), รองรับมือถือ *(ฝั่งเราไม่รองรับมือถือ — CR-PC-ONLY)* |

**ข้อค้นพบ 3 ข้อที่ยังใช้ได้เต็ม ๆ:** (1) Cokeboys คือสคริปต์ PvP ล้วน ("Quest" พบแค่ 1 จุด vs Aimbot 344) → The Voider โฟกัส PvP ถูกทาง (2) Smart Macro ใหญ่กว่า Aimbot ซะอีก → ผู้ใช้อยู่เพื่อคอมโบอัตโนมัติ (3) ไม่มีภาษาไทยใน 6 ภาษา → ช่องว่างที่เราเจาะทันทีวันแรก

### 2.3 นิยามใหม่ของ "Feature Parity 100%" (ใช้ทั้งเอกสาร)

> **Feature Parity 100% = 100% ของ behavior ที่อยู่ใน Behavioral Acceptance Matrix ของโมดูลนั้นผ่านการทดสอบ** — ไม่ใช่ 100% ของจำนวนจุดในไฟล์ต้นทาง

Matrix เขียนขึ้นจากการสำรวจพฤติกรรมจริงของ Cokeboys ในแต่ละ domain (ใช้ตำแหน่งโค้ดจากตาราง §2.2 เป็นแหล่งสำรวจ) แล้วกำหนด Input → Expected Behavior → Edge Cases → วิธีวัด ทุกแถว**ต้องผ่าน**ถึงนับว่า parity ครบ

### 2.4 Behavioral Feature Matrix — โครงแบบและตัวอย่างจริง

**โครงแบบมาตรฐาน (ทุกโมดูลใช้แบบเดียวกัน):**

| Behavior | Input / Trigger | Expected Behavior | Edge Cases | วัดที่ชั้น |
|---|---|---|---|---|
| ชื่อพฤติกรรม | สิ่งที่ผู้ใช้/ระบบทำ | ผลที่ต้องเกิด (วัดได้) | สถานการณ์พิเศษที่ต้องรอด | L1 / L2 / L3 |

**ตัวอย่างที่ 1 — VoidAim ระดับ P0 (ตัวอย่างเต็มชุด):**

| Behavior | Input / Trigger | Expected Behavior | Edge Cases | วัดที่ชั้น |
|---|---|---|---|---|
| Main Aim: ล็อกเป้า | เปิด Aim + กดคีย์ล็อก | ล็อกเป้าตามเงื่อนไข (ใกล้สุดใน FOV) ภายใน frame เดียวกัน/ถัดไป | เป้าตายกลางล็อก / หลุดระยะ / เข้า safe zone / respawn ใน FOV เดิม | L2 + L3 |
| Prediction v1 (ping) | ping สูงขณะล็อก | ชดเชยตำแหน่งยิงตาม ping ที่วัดได้ | ping เปลี่ยนกลางไฟต์ / เป้าวาร์ปด้วย Soru / เป้าหยุดกะทันหัน | L2 (virtual time) |
| Exclude list | เพิ่มชื่อลงบัญชีดำ | ไม่เลือกชื่อนั้นเป็นเป้าเด็ดขาด | ชื่อต่างตัวพิมพ์ใหญ่-เล็ก / ตัวอักษรพิเศษ / รายชื่อว่าง / ผู้เล่นออกจากเกมกลางล็อก | L1 + L2 |
| Target Priority | ตั้งเกณฑ์ (ใกล้สุด/เลือดน้อย/bounty สูง) | เลือกเป้าอันดับ 1 ตามเกณฑ์เสมอ | สองเป้าคะแนนเท่ากัน / เป้าใหม่เข้ามากลางล็อก (ไม่สะเทือนถ้ายังไม่เปลี่ยนเกณฑ์) | L2 |
| สลับโหมด EZ→Pro→Legend | กดสลับโหมด | ค่าตั้งของโหมดเดิมคงเดิมทุกตัวเมื่อสลับกลับ | สลับกลางล็อกเป้า / สลับกลางเล่น macro | L2 |
| ปลดล็อกเมื่อปล่อยคีย์ | ปล่อยคีย์ล็อก | ปลดทันที คืนกล้องให้ผู้ใช้คุมเอง | ปล่อยพร้อมกับที่เป้าตาย / ปล่อยระหว่างเฟรม render | L1 + L2 |
| Skill Aimbot รายสกิล | ใช้สกิล Z/X/C/V/F/M1 ขณะล็อก | เล็งตามพารามิเตอร์เฉพาะของสกิลนั้น | สกิล cooldown อยู่ / เปลี่ยนอาวุธกลางล็อก | L2 + L3 |
| Soru Aimbot | เป้าออกนอกระยะ M1 | เด้ง Soru เข้าหาเป้าแล้วล็อกต่อ | Soru cooldown / เป้าบินข้ามกำแพง / ระยะเกินซ้ำ ๆ ต่อเนื่อง | L2 + L3 |

**ตัวอย่างที่ 2 — Void ESP ระดับ P0 (ย่อ — ชุดเต็มอยู่ใน repo):**

| Behavior | Expected Behavior | Edge Cases ตัวอย่าง | วัดที่ชั้น |
|---|---|---|---|
| ข้อมูลครบ 9 ชนิด (name/level/race/ken/hp/distance/combat/bounty/indicator) | แสดงถูกต้องทุกชนิดพร้อมกัน | ผู้เล่นเข้า/ออกกลางเกม / ตาย / ไกลเกิน max distance | L2 (จำลอง 50 ผู้เล่น) |
| Max Distance filter | ผู้เล่นเกินระยะหายจาก ESP ทันที | ผู้เล่นวิ่งข้ามเส้นระยะไปมาถี่ ๆ | L2 |
| Bounty Colors | สีตามช่วง bounty ที่กำหนด | bounty เปลี่ยนขณะแสดงผลอยู่ | L2 |

**ตัวอย่างที่ 3 — Void Macro ระดับ P0 (ย่อ):**

| Behavior | Expected Behavior | Edge Cases ตัวอย่าง | วัดที่ชั้น |
|---|---|---|---|
| บันทึกคอมโบ | เก็บ action + timing ทุกขั้นถูกลำดับ | อัดยาว 50+ ขั้น / กดซ้อนหลายคีย์ในเฟรมเดียว | L1 + L2 |
| เล่นซ้ำ | **action sequence match = 100%** (ทุก action ถูกเรียกตามลำดับ — แยกจาก timing ที่วัดแบบ tolerance ตาม §5) | ตายกลางเล่น / สลับชุดกลางเล่น / ยกเลิกกลางคัน | L2 |
| สลับสล็อต | สลับชุดได้ทันที ชุดเดิมไม่พัง | สลับกลางเล่นซ้ำ | L2 |

### 2.5 แผนงานสร้าง Matrix ให้ครบทุกโมดูล

Matrix แบบเต็มของทั้ง 8 Product Modules (ประมาณการ 120–160 แถวรวม) จะถูกเขียนเป็น **deliverable ของเฟส 0** เก็บใน `qa/matrices/<module>.md` ของ repo และเป็นเอกสารมีชีวิต — เจอ behavior ใหม่ที่สำคัญ = เพิ่มแถวใหม่เสมอ ไม่มีข้อยกเว้น การเขียน matrix ก่อนเขียนโค้ดโมดูลนั้น ๆ คือขั้นตอนบังคับของทุกเฟส (ห้ามเขียนโค้ดก่อนมี matrix)

---

## 3. สถาปัตยกรรม v2 (Architecture)

### 3.1 โครงสถาปัตยกรรมใหม่ (ตามโครงที่เจ้าของโปรเจกต์เสนอ — ตอบจุดรีวิว #2, #13)

```text
THE VOIDER
│
├── Loader
│   ├── Version Gate
│   ├── Manifest (SHA-256)
│   ├── Integrity Check
│   └── Update Manager
│
├── Runtime Layer                       ← ใหม่: ยกจาก Safety Layer เล็ก ๆ เดิมเป็นชั้นเต็ม
│   ├── Capability Detection            (รู้ว่า executor ตัวนี้ทำอะไรได้จริง + Bootstrap Preflight)
│   ├── Resource Registry               ← ใหม่ v2.1: ตัวครอบเดียว ตรวจ orphan รวมทุกชนิด
│   │   ├── Tasks                       (ทุก loop — Runtime.Spawn)
│   │   ├── Connections                 (ทุก event connection — Runtime.Connect)
│   │   ├── Drawing / Render Objects    (ทุก Drawing/Instance ที่สร้าง — Runtime.NewRender)
│   │   └── Temporary Resources         (tween/timer/อ็อบเจ็กต์ชั่วคราว — Runtime.Temp)
│   ├── Error Boundary                  (จับ error ต่อโมดูล ไม่ให้ลาม)
│   ├── Watchdog                        (เฝ้าดูว่าโมดูลไหนหยุดหายใจ)
│   └── Shutdown Manager                (ปิดทุกอย่างตาม dependency graph ย้อนกลับ — §3.10)
│
├── Foundation
│   ├── Event Bus                       (lifecycle / config / notification / signal)
│   ├── Services                        (Direct Service Interface สำหรับ hot path)
│   ├── Config + Config Migration       (schemaVersion + ลูกโซ่ migration)
│   ├── Keybind Manager
│   ├── i18n (ไทย/อังกฤษ)
│   └── Diagnostics                     (วัด performance budget ตั้งแต่เฟส 0)
│
├── Game Adapter                        ← ใหม่: ประตูเดียวที่แตะเกมจริง
│   ├── Player API
│   ├── Character API
│   ├── Combat API
│   ├── Camera API
│   ├── Input API
│   └── World / Server API
│
├── Feature Modules
│   ├── ⭐ VoidAim
│   ├── Void ESP
│   ├── Void Macro
│   ├── Combat Core
│   ├── Race
│   ├── Fruit
│   ├── Movement
│   └── Server Hop / Teleport
│
└── UI
    ├── Main Hub
    ├── HUD
    ├── Notification
    └── Mobile Layer   ← CR-PC-ONLY 1 ต.ค. 2026: ตัดออกจาก product scope (PC/Desktop only)
```

**ภาพการไหลของข้อมูล (เทียบกับ v1.0 ที่ Game Adapter ยังไม่มีในโครง):**

```mermaid
flowchart TB
    subgraph LOAD["🚪 Loader"]
        L1["4-URL Fallback"] --> L2["Version Gate"]
        L2 --> L3["Manifest + SHA-256"]
        L3 --> L4["Update Manager"]
    end
    LOAD --> RT
    subgraph RT["⚙️ Runtime Layer"]
        R1["Capability Detection"]
        R2["Resource Registry (Task/Conn/Render/Temp)"]
        R3["Error Boundary + Watchdog"]
        R4["Shutdown Manager"]
    end
    RT --> FOUND
    subgraph FOUND["🧱 Foundation"]
        F1["Event Bus"]
        F2["Services (Direct Interface)"]
        F3["Config + Migration"]
        F4["i18n + Keybind"]
        F5["Diagnostics"]
    end
    FOUND --> GA
    subgraph GA["🎮 Game Adapter — ประตูเดียวสู่เกม"]
        G1["Player / Character"]
        G2["Combat / Camera"]
        G3["Input / World"]
    end
    GA --> MODS
    subgraph MODS["🕳️ Feature Modules"]
        M1["⭐ VoidAim"]
        M2["VoidESP"]
        M3["VoidMacro"]
        M4["Combat / Race / Fruit"]
        M5["Movement / Server Hop"]
    end
    MODS --> UI
    subgraph UIL["✨ UI — Void Neon"]
        U1["Hub / HUD"]
        U2["Notification / Mobile"]  %% Mobile ตัดออกตาม CR-PC-ONLY — เหลือ Notification เท่านั้น %%
    end
```

### 3.2 Runtime Layer — 5 องค์ประกอบ + 1 Bootstrap Preflight (ตอบจุดรีวิว #7, #13 + hardening #2, #6 + freeze R1)

**0) Bootstrap Preflight — ระดับตรวจที่แยกออกจาก Runtime Capability (hardening #6)** — รันใน **loader ก่อนโหลด core** ตรวจเฉพาะ prerequisite ที่ loader เองต้องใช้: มี HTTP request function จริง (ชื่อไหนก็ตาม executor รองรับ) + เข้าถึง GitHub/CDN ได้ — ถ้าไม่มี: **แจ้งเป็น plain text ผ่านคอนโซลของ executor** (`print`/`warn` ข้อความไทยชัดเจนหนึ่งบรรทัด) แล้วหยุดทำงานทันที — **ไม่มี UI ใด ๆ เพราะ core ยังไม่ถูกโหลด จึงห้ามสัญญาว่าจะเปิด Notification ได้ในสถานการณ์นี้** ตัวอย่างข้อความ: `[The Voider] รันสคริปต์ไม่ได้: ไม่พบระบบเชื่อมต่ออินเทอร์เน็ต (HTTP) — The Voider รองรับการใช้งานบน Volt เท่านั้น` สองระดับนี้ตั้งใจแยกกันชัดเจน: **Preflight (ก่อน core) = plain text + หยุด / Runtime Capability (หลัง core) = Notification UI + graceful disable**

**1) Capability Detection (Runtime)** — ตอน startup ระบบ**ทดสอบจริง** (เรียกใช้ใน sandbox แล้วดูผล ไม่ใช่แค่เช็คว่ามีชื่อ function — เพราะบาง executor มีชื่อแต่พัง) ว่า runtime ปัจจุบันทำอะไรได้:

| Capability | ใช้โดยฟีเจอร์ | ถ้าไม่มี |
|---|---|---|
| `DRAWING` | VoidESP overlay, FOV Circle | ESP ปิด + แจ้งเหตุผลภาษาไทย ฟีเจอร์อื่นใช้ได้ปกติ |
| `HOOK` | FFlags, combat helpers บางตัว | ฟีเจอร์ที่ต้อง hook ปิดแบบ graceful |
| `HTTP` | Server Hop, Stock Check, Hot Update | ฟีเจอร์เน็ตปิด + แจ้งผ่าน Notification UI — **กรณี "ไม่มี HTTP เลยจน loader โหลดไม่ได้" ถูกจัดการที่ Bootstrap Preflight (ข้อ 0) ก่อนหน้านี้แล้ว สองระดับไม่ปนกัน** |
| `FILEIO` | Config save/load, Macro import/export | Config ใช้แบบ session-only (หน่วยความจำ) + แจ้งว่าไม่บันทึกถาวร |
| `INPUT` | Keybind เสริม *(Mobile Aim Button ตัดออกตาม CR-PC-ONLY 1 ต.ค. 2026 — VA-033 OUT OF SCOPE)* | ใช้เฉพาะ UserInputService พื้นฐานที่มีทุก runtime |
| `CLIPBOARD` | Export config/macro เป็นข้อความ | เปิดกล่องข้อความให้คัดลอกเอง |
| `TASK` | loop/scheduler ของทุกโมดูล | Fallback ไปใช้ spawn/delay มาตรฐาน |
| `CRYPTO` | ตรวจ SHA-256 ระหว่าง hot update ในเกม | ตรวจแบบระดับ 2 (version+size+marker) + แจ้งระดับการตรวจที่ได้จริง |

ผลการตรวจเก็บเป็น Capability Report แสดงใน Developer Diagnostics (§8.4) และทุกฟีเจอร์**ต้องเช็ค capability ก่อนเปิด** — ไม่ hard-code ว่า executor ไหนรองรับอะไร (ตาราง executor เหลือบทบาท "ผลทดสอบอ้างอิง" เท่านั้น โดยผลทดสอบอ้างอิงของโปรเจกต์นี้เก็บจาก **Volt เท่านั้น** ตามขอบเขต §6.3 — probe จริงใหม่ทุก release เพราะเวอร์ชัน Volt ที่อัปเดตแล้วให้ผลต่างกันได้)

**2) Resource Registry — ตัวครอบเดียว สี่ชนิด (hardening #2)** — โมดูลห้ามจองทรัพยากรเองดิบ ๆ ต้องผ่าน API ของ registry ทั้งหมด แล้วได้ handle กลับมา:

```lua
Runtime.Spawn(name, fn)          -- task/loop          (เดิม Task Registry)
Runtime.Connect(signal, fn)      -- event connection   (เดิม Connection Registry)
Runtime.NewRender(kind, props)   -- Drawing/Instance สำหรับ ESP/FOV circle/overlay ← ใหม่ v2.1
Runtime.Temp(obj)                -- ทรัพยากรชั่วคราว tween/timer/อ็อบเจ็กต์ที่ต้องคืน ← ใหม่ v2.1
```

ทำไมต้องรวมเป็นตัวเดียว: v2.0 มีแค่ Task Registry + Connection Registry แต่ `Destroy()` สัญญาว่า "คืน render object จนเหลือ 0" โดยที่ไม่มี registry เก็บ render object เลย = **ตรวจ orphan ได้แค่ครึ่งเดียว** v2.1 จึงรวมทั้งสี่ชนิดไว้ใน Resource Registry เดียว → ตอน Disable/Destroy ระบบเก็บคืนได้ครบทั้งสี่ชนิด และ **orphan = 0 ตรวจรวมทุกชนิด** — watchdog ใช้ตรวจ task ตาย/ค้าง, Error Boundary ใช้ตัวนับต่อโมดูล, และ hot update (§3.6 ขั้น VERIFY) ตรวจทั้งสี่ชนิดก่อนสลับรุ่น มี assert อัตโนมัติใน debug build — เหลือเกิน 0 ตัวใดตัวหนึ่ง = ไม่ผ่าน DoD ของโมดูลนั้น

**3) Error Boundary** — entry point ทุกตัวของโมดูลรันภายใต้ boundary: error ถูกจับ → ปิดเฉพาะโมดูลนั้น + แจ้งผู้ใช้สวย ๆ + บันทึก log พร้อม stack trace ลง Diagnostics → ระบบที่เหลือเดินต่อ พร้อมตัวนับ error ต่อโมดูลให้ watchdog ใช้ตัดสิน

**4) Watchdog** — โมดูลทุกตัวต้อง "รายงานหายใจ" ตามรอบที่ตนประกาศ (เช่น โมดูล per-frame = ทุกวินาที) โมดูลไหนเงียบเกิน threshold → พยายาม restart หนึ่งครั้ง → ยังเงียบ = ปิด + แจ้งผู้ใช้ (กัน infinite restart ด้วย exponential backoff) — นี่คือ Crash Rescue ของ v3.0 ที่ยกระดับเป็นระบบ

**5) Shutdown Manager** — จัดลำดับปิดที่ถูกต้องเสมอ: UI → Feature Modules → Game Adapter → Foundation → Runtime โดย**ลำดับของโมดูลมาจาก Dependency Graph (§3.10) ซึ่งเป็น source of truth เดียวกับลำดับ Init() แต่กลับด้าน** (hardening #7) ใช้ทั้งใน hot update (§3.6) unload ปกติ และตอนกด "ปิดสคริปต์" จาก UI

### 3.3 Game Adapter Layer — ประตูเดียวสู่เกม (ตอบจุดรีวิว #2)

| API | ครอบคลุมอะไร | ตัวอย่างเมธอด |
|---|---|---|
| **Player API** | local player, สถิติ, team, bounty, crew | `GetLocalPlayer()`, `GetBounty(player)` |
| **Character API** | humanoid, อวัยวะ, state (สตัน/ragdoll/บิน), VFX | `GetRoot(player)`, `IsAlive(player)`, `GetState(player)` |
| **Combat API** | อาวุธ, สกิล, cooldown, remote bindings, M1 combo | `GetEquippedWeapon()`, `GetSkillCooldown(skill)`, `FireSkill(skill)` |
| **Camera API** | ตำแหน่ง/ทิศ/FOV กล้อง, ล็อกกล้อง | `GetPosition()`, `GetLookVector()`, `SetLock(target)` |
| **Input API** | คีย์บอร์ด/เมาส์ *(ทัช: API ยังอยู่เพราะ PC จอสัมผัสใช้ได้ แต่ไม่รับประกัน UI บนอุปกรณ์ทัชอย่างเดียว — CR-PC-ONLY)* | `IsKeyDown(key)`, `OnInput(callback)` |
| **World API** | entities ในฉาก, ระยะทาง, raycast/line-of-sight, server info | `GetPlayers()`, `RaycastClear(from, to)`, `GetServerInfo()` |

**กฎ 3 ข้อของ Adapter:**

1. **ฟีเจอร์โมดูลห้ามแตะ game objects โดยตรง** — ทุกการเข้าถึงเกมผ่าน adapter เท่านั้น (บังคับด้วย lint rule ใน build script + ตรวจใน code review ทุกรอบ) เมื่อเกมอัปเดตเปลี่ยน remote/โครงสร้าง เราแก้**ไฟล์ adapter จุดเดียว** แล้ว VoidAim/ESP/Macro/Combat กลับมาใช้ได้ทั้งหมด — นี่คือการแก้ที่ "คุ้มที่สุดของทั้งแผน" ตามที่รีวิวระบุ
2. **Adapter Self-Probe ตอน startup** — ทดสอบหา instance/property/remote ที่รู้จักทั้งหมด แล้วรายงาน "Adapter Health": ครบ / เสื่อมบางส่วน (ระบุ API ตัวไหนตาย) — ผลพ่วง: นี่คือ **capability detection เวอร์ชันเกม** ทำงานคู่กับ capability ของ executor ใน §3.2
3. **เสื่อมอย่างสง่างาม** — ถ้าเกมอัปเดตแล้ว API ตัวไหนตาย: ฟีเจอร์ที่พึ่ง API นั้น**ปิดตัวเอง + แจ้งผู้ใช้** "รออัปเดต The Voider" แทนที่จะพังทั้งสคริปต์ และเราจ่าย hot update จุดแก้ได้ในวันเดียว

### 3.4 Module Lifecycle v2 — เพิ่ม Destroy + State Migration (ตอบจุดรีวิว #3)

วงจรชีวิตโมดูลเปลี่ยนจาก 4 สถานะเดิม (`Init/Enable/Disable/Update`) เป็น **7 สถานะ** — สองตัวท้ายคือหัวใจที่ทำให้ hot update เป็นระบบจริง:

```lua
Module:Init(context)       -- รับ dependencies/services, ยังไม่แตะเกม, คืนสถานะสำเร็จ/ล้มเหลว
Module:Enable()            -- เริ่มทำงานจริง
Module:Disable()           -- หยุดชั่วคราว (เก็บ state ไว้ในหน่วยความจำ)
Module:Update(dt)          -- ตัวเลือก: โมดูลที่ต้องการ per-frame เท่านั้น
Module:SerializeState()    -- คืนตาราง state ธรรมดา (พร้อม schemaVersion ของ state)
Module:MigrateState(old)   -- รับ state จากรุ่นก่อน แปลงเป็นรูปแบบรุ่นปัจจุบัน
Module:Destroy()           -- หยุดถาวร: คืนทุก task/connection/render object ให้ registry จนเหลือ 0
```

**กฎเหล็กของ Destroy:** หลัง `Destroy()` จบ, **Resource Registry ทั้ง 4 ชนิด** (tasks + connections + render objects + temporary resources) ของโมดูลนั้น**ต้องเท่ากับ 0 รวมทุกชนิด** — มี assertion ตรวจอัตโนมัติใน debug build และเป็นเงื่อนไขผ่าน DoD ทุกเฟส โมดูลไหนผ่านไม่ได้ = โมดูลนั้นยังไม่เสร็จ (ไม่ใช่ "เกือบเสร็จ")

### 3.5 นโยบายสื่อสาร — Hybrid: Event Bus + Direct Service (ตอบจุดรีวิว #4)

ยกเลิกกฎ "ทุกอย่างผ่าน Event Bus 100%" ของ v1.0 และแทนที่ด้วยการแบ่งตามลักษณะงานจริง:

| ชนิดการสื่อสาร | ช่องทาง | เหตุผล |
|---|---|---|
| Lifecycle (โมดูลเปิด/ปิด/พัง) | **Event Bus** | ความถี่ต่ำ ทุกโมดูลสนใจ แยกชิ้นได้ |
| Notification / แจ้งเตือนผู้ใช้ | **Event Bus** | decouple ระหว่างโมดูลกับ UI |
| Config change | **Event Bus** | กระจายถึงทุกโมดูลพร้อมกัน |
| Cross-module signal ทั่วไป (เป้าตาย, กำลังสลับเซิร์ฟเวอร์) | **Event Bus** | ความถี่ต่ำ-กลาง |
| **Hot path**: target query, prediction, camera state, combat state, คำนวณ per-frame | **Direct Service Interface** | Event = overhead + debug ยาก — hot path ต้องเรียกตรง อ่านค่า กลับทันที |

**ตัวอย่าง Services ที่โมดูลเรียกตรง (ไม่ผ่าน bus):**

```lua
TargetService:GetCurrentTarget()                          -- เป้าปัจจุบัน (หรือ nil)
TargetService:GetCandidates(fov, filters)                 -- รายการเป้าตามเงื่อนไข
PredictionService:GetPredictedPosition(target, leadTime)  -- Vector3 ที่ทำนาย
CameraService:GetState()                                  -- ตำแหน่ง/ทิศ/FOV ปัจจุบัน
CombatStateService:IsStunned(player)                      -- สถานะสตันของผู้เล่นรายคน
```

**กฎคู่ของ Services:** (1) Service = สำหรับ *query* ที่ตอบเร็ว ไม่มี side effect แฝง (2) ถ้าการทำงานนั้นเปลี่ยน state ที่โมดูลอื่นสนใจ → ยังต้องประกาศผ่าน Event Bus เสมอ เพื่อไม่ให้ใครพลาด event

### 3.6 Hot Update Protocol — 12 ขั้น + Rollback Paths (ตอบจุดรีวิว #3 + hardening #1, #3)

v1.0 เขียนไว้แค่ "สลับตัวเองแบบสด ๆ" ซึ่งเสี่ยง duplicate loop / memory leak / event ซ้ำตามที่รีวิวชี้ v2.0 กำหนดเป็น protocol ที่พิสูจน์ได้ และ v2.1 เพิ่มหลักประกันสามข้อ: **(1) ทุกจุดที่อาจพังมีเส้นทาง rollback กลับรุ่นเดิม — ห้าม force-clean แล้วไปต่อ** (2) event ที่ค้างในคิวมีนโยบาย replay ชัดเจน ไม่ย้อน state และ (3) ตามรอบ freeze — **ATOMIC UPDATE RULE** (release ใหม่ไม่ active จนกว่าจะผ่าน LOAD → MIGRATE → SELFCHECK → ADAPTER PROBE ครบ) + **Rollback Snapshot 7 ช่อง** ที่ตรวจว่า recover ได้แล้วเท่านั้นจึง TEARDOWN:

```text
HOT-UPDATE PROTOCOL (v0.4 → v0.5 ตัวอย่าง) — 12 ขั้น + 5 rollback paths

 1. PUBLISH   ฝั่งเรา: build ใหม่ + อัป manifest (version, sha256, minLoader)
 2. DETECT    loader เห็น version ใหม่ → ถามผู้ใช้ (หรือ auto ถ้าเปิดโหมด auto ไว้)
 3. PRE-STAGE ดาวน์โหลดรุ่นใหม่ + ตรวจความถูกต้นฉบับ (SHA-256/ระดับ 2) ให้ผ่านก่อนแตะระบบเดิม
              └─ ไม่ผ่าน = ยกเลิกอัปเดต ระบบเดิมยังเดินต่อโดยไม่กระทบ (path F0)
 4. FREEZE    Event Bus หยุดรับ event ใหม่ — event ที่มาถึงเข้าคิวพร้อม metadata
              (generation, timestamp, type, replayable — ดู Replay Policy ด้านล่าง)
 5. DRAIN     รอ hot path ของ frame ปัจจุบันทำงานจบสนิท
 6. SNAPSHOT  SERIALIZE ทุกโมดูล: SerializeState() → เก็บ oldState ทั้งชุด
              + สร้าง Rollback Snapshot ตาม schema 7 ช่อง (ด้านล่าง) ไว้ในหน่วยความจำ
                สำหรับ rollback ทุกเส้นทาง F1–F4 — สร้างเสร็จ + ตรวจว่า recover ได้แล้ว
                จึงจะไป TEARDOWN ได้ (กฎ R4 ด้านล่าง)
 7. TEARDOWN  Shutdown Manager: Disable → Destroy ทุกโมดูล (ตาม dependency graph ย้อนกลับ §3.10)
 8. VERIFY    Resource Registry ทั้ง 4 ชนิด (tasks/connections/render/temp) ต้อง = 0
              ├─ orphan = 0 → ไปขั้นถัดไป
              └─ orphan > 0 → ABORT UPDATE + ROLLBACK: คืน snapshot รุ่นเดิม → อยู่รุ่นเก่าต่อ
                              + BUG-XXX + แจ้งเราทันที (ห้ามเงียบ)
                              ⛔ เลิกวิธีเดิมของ v2.0 (force-clean แล้วไปต่อ) — ถ้า cleanup
                                 ไม่สมบูรณ์ = ระบบไม่น่าไว้ใจ ห้ามเอาไปโหลดรุ่นใหม่เด็ดขาด
 9. LOAD      โหลดโค้ดรุ่นใหม่ (ที่ PRE-STAGE ตรวจผ่านแล้ว — เสี่ยงโหลดพังต่ำสุด)
10. MIGRATE   โมดูลใหม่ทุกตัว: Init → MigrateState(oldState ของตัวเอง) → Enable
11. RESUME    เปิด Event Bus + จัดการ event ในคิวตาม Replay Policy (ด้านล่าง)
12. SELFCHECK watchdog heartbeat ทุกโมดูล + version report + รัน L1 self-test ชุดย่อ
    REPORT    แจ้งผู้ใช้: "อัปเดตสำเร็จ v0.4 → v0.5 (ใช้เวลา 3.2 วิ, orphan 0)"
```

**ROLLBACK PATHS — ทุกจุดที่พังได้ มีทางกลับรุ่นเดิม (hardening #1):**

```text
F0. PRE-STAGE fail (โหลดไม่ได้ / hash ไม่ผ่าน)   → ยกเลิกอัปเดต — ระบบเดิมเดินต่อ (ไม่มีอะไรถูกทำลาย)
F1. VERIFY fail (orphan > 0)                       → ABORT + คืน snapshot รุ่นเดิม + BUG-XXX + แจ้งเราทันที
F2. LOAD/MIGRATE fail (โค้ดใหม่รันไม่ขึ้น /          → ROLLBACK: โหลด snapshot รุ่นเดิมกลับ + state เดิม
   MigrateState error)                                + BUG-XXX
F3. SELFCHECK fail (heartbeat ไม่มา / self-test        → ROLLBACK กลับรุ่นเดิมอัตโนมัติ + BUG-XXX
   พังหลังอัปเดต)
F4. ADAPTER PROBE fail (รุ่นใหม่เรียก API เกมไม่ได้    → ปิดเฉพาะโมดูลที่กระทบตามกฎ Adapter §3.3 —
   หลัง migrate)                                      ถ้าโมดูล P0 ใช้ไม่ได้เลย = ROLLBACK ทั้งรุ่น + BUG-XXX
```

**หลักการของ rollback:** ผู้ใช้ต้องไม่เคยอยู่ในสถานะ "ครึ่ง ๆ กลาง ๆ" — อัปเดตไม่สำเร็จ = กลับรุ่นเดิมที่ใช้ได้ 100% เสมอ แล้วรอรุ่นถัดไปที่แก้แล้ว ทุกเส้นทาง F0–F4 มี BUG-XXX ของตัวเอง (กฎเหล็ก §11) และผลลัพธ์สุดท้ายต้องรายงานผู้ใช้เป็นภาษาไทยเสมอ (No Silent Degradation)

**ATOMIC UPDATE RULE — กฎล็อกสถานะ active (freeze R3):** **ห้ามประกาศ release ใหม่เป็น active จนกว่า LOAD → MIGRATE → SELFCHECK → ADAPTER PROBE จะผ่านครบทุกขั้น**

```text
ระหว่างอัปเดต (FREEZE → จนกว่าจะผ่านครบ):
  OLD = active           ← รุ่นที่ยังเป็นเจ้าของระบบอยู่ (มี snapshot คุ้มทุกเส้นทาง F1–F4)
  NEW = staged           ← โหลด/ทดสอบได้ แต่ยังไม่มีสิทธิ์เป็นรุ่นที่รันจริง

NEW ผ่านครบทุกขั้นเท่านั้น จึงสลับ:
  NEW = active
  OLD = rollback target  ← คงไว้จนถึง release ถัดไป ไม่ทำลายทันที
```

กฎนี้ทำให้ "กลับรุ่นเดิมได้เสมอ" เป็นความจริงเชิงโครงสร้าง ไม่ใช่ความหวัง — รุ่นเดิมไม่ถูกแทนที่จนกว่ารุ่นใหม่จะพิสูจน์ว่าใช้ได้จริง และผลคือ VERIFY (ขั้น 8) ที่พัง = ABORT เท่านั้น ไม่มี "ลองไปต่อ"

**ROLLBACK SNAPSHOT — schema บังคับ 7 ช่อง (freeze R4):**

```text
Rollback Snapshot
├── version        เวอร์ชันรุ่นเดิม (เช่น "0.4.2")
├── releaseId      รหัส release รุ่นเดิม (อ้างรุ่นเดียวกับ manifest §7.1)
├── bundle         โค้ดรุ่นเดิมที่กำลังรัน — โหลดกลับได้ทันที
├── manifest       สำเนา manifest ของรุ่นเดิม
├── moduleStates   oldState ทุกโมดูล (จาก SerializeState ขั้น 6)
├── configState    config ที่ใช้อยู่ ณ ตอน freeze
└── timestamp      เวลาที่สร้าง snapshot
```

**กฎของ snapshot:** ต้อง**สร้างเสร็จและตรวจแล้วว่า recover ได้จริง** (ครบทั้ง 7 ช่อง + อ่านกลับ/validate ผ่าน) **ก่อนถึงขั้น TEARDOWN เด็ดขาด** — snapshot เสีย = ABORT อัปเดตแล้วอยู่รุ่นเก่าต่อ ห้าม "snapshot เสียแล้วค่อยไปทำลายของเดิม" เพราะจะไม่เหลือทางกลับให้ผู้ใช้เลย (ตรวจใน L2 ด้วยฉาก "ฉีดให้ snapshot เสีย" — ผลที่ต้องได้: ABORT + ระบบเดิมเดินต่อ + BUG-XXX)

**EVENT REPLAY POLICY — กัน state ย้อนหลัง (hardening #3):** ทุก event ในคิวต้องมี metadata 4 ช่อง: `generation` (เลขรุ่นที่ปล่อย event) / `timestamp` / `type` / `replayable` แล้วตอน RESUME จัดการตาม 3 กรณี:

| ชนิด event | ตัวอย่าง | ตอน hot update เสร็จ |
|---|---|---|
| **Transient** (เหตุการณ์ที่เกิดแล้วเกิดเลย ในอดีต) | เป้า A ตาย, frame tick, ผู้เล่นเดินถึงจุด X | **DROP ทิ้ง** — เหตุการณ์เก่าเลิกเป็นจริงแล้ว ไม่มีทาง "เกิดซ้ำ" ได้ |
| **State/Config** (สถานะปัจจุบันที่ยังมีผล) | config เปลี่ยน, keybind ใหม่, โหมดที่ผู้ใช้เลือก | **REPLAY** เรียงตาม timestamp — last-write-wins |
| **Idempotent** (ทำซ้ำก็ได้ผลเดิม) | sync สถานะ, ขอ refresh รายการ | **REPLAY ได้** ปลอดภัยโดยธรรมชาติ |

**กฎกัน state ย้อนหลัง (edge case ที่รีวิวยก):** ก่อน update เป้า = A ระหว่าง freeze เป้า A ตายและ B กลายเป็นเป้า — การ replay event "target = A" จะย้อน state ผิด ดังนั้น **event ที่ describe สถานะของโลกจริง (เป้า/ตำแหน่ง/มีชีวิต) = Transient → DROP ทิ้งทั้งหมด** และให้โมดูลรุ่นใหม่**อ่านสถานะจริงใหม่จาก Game Adapter (re-derive)** แทนการเชื่อ event เก่า — replay จริงมีไว้สำหรับ config/lifecycle เท่านั้น นี่คือการปิดช่องบั๊กประเภท BUG-017 (target switch ผิดหลังตาย) ตั้งแต่ต้นทาง
**เกณฑ์ผ่านของ protocol (วัดได้):** Resource Registry orphan (รวม 4 ชนิด) = 0 ทุกครั้ง | **Rollback Snapshot ครบ 7 ช่อง + ตรวจ recover ได้ก่อน TEARDOWN ทุกครั้ง (ฉากฉีดให้ snapshot เสีย = ABORT + อยู่รุ่นเก่าต่อ)** | **atomic update ถูกต้อง: NEW กลายเป็น active ก็ต่อเมื่อผ่าน LOAD → MIGRATE → SELFCHECK → ADAPTER PROBE ครบ** | เวลารวม ≤ 5 วินาทีใน test environment (บันทึกเป็น metric ทุกครั้ง) | state ที่ migrate แล้วใช้งานได้จริง (ทดสอบด้วย L2: อัปเดตกลางล็อกเป้า/กลางเล่น macro แล้วเฟสนั้นต้องเดินต่อ) | **failure injection ทุกเส้นทาง F0–F4 ใน L2: ฉีดให้พังทีละเส้นทาง แล้วผลลัพธ์ต้องเป็น "กลับรุ่นเดิม + ใช้งานได้ 100% + มี BUG-XXX" ทุกครั้ง** | replay policy ผ่านฉากจำลอง "เป้าตายระหว่าง freeze": เป้าที่ได้หลังอัปเดตต้องเป็นเป้าตามโลกจริง ไม่ใช่เป้าที่ตายแล้ว | ทดสอบ v→v+1 และ v→v+2 (ข้ามหนึ่งเวอร์ชัน) ทุกเฟส

### 3.7 Config Schema & Migration (ตอบจุดรีวิว #8)

**โครงสร้าง config ทุกไฟล์:**

```lua
{
  schemaVersion = 3,                    -- บังคับมีทุกไฟล์ — ตัวเลขเดียวบอกเวอร์ชันโครงสร้าง
  profile = {
    name      = "หลัก",
    createdAt = 1790000000,
    updatedAt = 1790000000,
  },
  settings = {
    VoidAim  = { mode = "EZ", fov = 120, ... },
    VoidESP  = { ... },
    VoidMacro = { ... },
    -- ตามโมดูล
  },
}
```

**ลูกโซ่ Migration:** เก็บเป็นฟังก์ชันรายขั้น `migrations[1] = v1→v2`, `migrations[2] = v2→v3`, ... โหลดไฟล์เก่าเข้ามาแล้วไล่รันทีละขั้นจนถึงเวอร์ชันปัจจุบัน — ห้ามข้ามขั้น ตัวอย่างจริงตัวแรกที่ต้องเตรียมตั้งแต่เฟส 0: `Aimbot.FOV` (ชื่อชั่วคราวระหว่างพัฒนา) → `VoidAim.FOV` ทุกขั้น migration มี unit test เป็นของตัวเอง (L1)

**Fallback เมื่อ config เสีย:** parse ไม่ผ่าน → สำรองไฟล์เก่าเป็น `.bak` พร้อม timestamp → โหลดค่า default → แจ้งผู้ใช้ + เปิดหน้าโหลด `.bak` กลับได้จากแท็บ Setup

**หลักการ:** config ของผู้ใช้คือของมีค่า — **ห้ามทิ้งเด็ดขาด** แม้จะเลิกรองรับชื่อ key เก่าก็ต้อง migrate ไม่ใช่ลบทิ้ง

### 3.8 โครงสร้างไฟล์ในการพัฒนา

```text
the-voider/
├── loader.lua              ← จุดเข้าเดียวที่ผู้ใช้รัน (4-URL + version gate + manifest)
├── core/
│   ├── runtime/            ← capability+preflight, resource registry (4 ชนิด), watchdog, error boundary, shutdown
│   ├── foundation/         ← event bus, services, config+migration, i18n, keybind, diagnostics
│   ├── adapter/            ← player.lua, character.lua, combat.lua, camera.lua, input.lua, world.lua
│   ├── modules/            ← voidaim.lua, esp.lua, macro.lua, combat.lua,
│   │                          race.lua, fruit.lua, movement.lua, serverhop.lua
│   └── ui/                 ← theme.lua, hub.lua, hud.lua, notify.lua (mobile.lua ตัดออกตาม CR-PC-ONLY)
├── build/build.lua         ← รวมทุกโมดูลเป็นไฟล์เดียว + lint "ห้ามแตะเกมนอก adapter" + สร้าง manifest
├── qa/
│   ├── matrices/           ← Behavioral Acceptance Matrix ทุกโมดูล (deliverable เฟส 0)
│   ├── l1_unit/            ← ทดสอบฟังก์ชัน/โมดูลเดี่ยว
│   ├── l2_integration/     ← โมดูล + adapter + bus + config
│   ├── l3_live/            ← checklist ทดสอบในเกมจริง
│   └── regression/         ← BUG-XXX_ชื่อบั๊ก.lua หนึ่งไฟล์ต่อหนึ่งบั๊กที่เคยเกิด
└── docs/
    ├── architecture/
    │   └── dependencies.md  ← Dependency Graph — source of truth เดียวของ Init/Shutdown (§3.10)
    └── ...เอกสารทุกโมดูล + CHANGELOG
```

การพัฒนาแยกไฟล์เพื่อความสะอาด ตัวส่งมอบจริงคือ**ไฟล์เดียว** (`the-voider.lua` + alias `tv.lua`) ที่ build รวมทุกอย่าง — เหมือนระบบที่พิสูจน์แล้วกับ v3.1

### 3.9 หลักการออกแบบ 7 ข้อ (ปรับจาก 5 ข้อของ v1.0)

1. **Module Isolation ครบวงจร** — โมดูลอิสระพร้อม lifecycle ครบ 7 สถานะ หนึ่งพังไม่ลาม แก้ไฟล์เดียวระบบกลับ
2. **Hybrid Communication** — bus สำหรับ lifecycle/config/signal, direct service สำหรับ hot path (§3.5)
3. **Single Source of Game Access** — เกมถูกแตะจาก Game Adapter เท่านั้น (§3.3)
4. **Everything Registered** — ทุก task/connection/render object/temporary resource ผ่าน Resource Registry (4 ชนิด) เสมอ ไม่มีของหลุดระบบ
5. **Fail-Safe + No Silent Degradation** — พังต้องแจ้ง ปิดฟีเจอร์เพราะ capability/probe ต้องบอกผู้ใช้เสมอ
6. **Measurable Requirements** — ทุกเกณฑ์มีวิธีวัด + tolerance (หลักคิดกลางของ v2.0)
7. **Config เป็นของผู้ใช้** — schema + migration + ห้ามทิ้ง (§3.7)

### 3.10 Dependency Graph — Source of Truth เดียวของลำดับการทำงาน (hardening #7)

Shutdown Manager และ Init() ต้องอ่านลำดับจาก**แหล่งเดียวกัน** ไม่ใช่สอง logic คนละที่ที่ "หวังว่าตรงกัน" — แหล่งนั้นคือไฟล์ `docs/architecture/dependencies.md` ซึ่ง build อ่านแล้ว validate ทุกครั้งก่อนออกไฟล์จริง:

```text
ตัวอย่างโครงร่าง (รายการจริงสร้างในเฟส 0 พร้อม Behavioral Matrix):

VoidAim       → TargetService, PredictionService, CameraService, CombatStateService
Void ESP      → TargetService, EspRenderer, ObjectPool
Void Macro    → InputAdapter, MacroSerializer
Combat Core   → CombatStateService, AbilitySequencer
Race          → PlayerAdapter
UI Hub        → ConfigService, I18nService, ทุก Feature Module (สร้างแท็บ)
```

**Build-time validation 3 ชั้น (รันทุก build — ไม่ผ่าน = ไม่ได้ build):**

1. **Missing dependency** — โมดูลประกาศ dependency ที่ไม่มีอยู่จริงในระบบ = บล็อก build ทันที
2. **Circular dependency** — A→B→A วนกลับ = บล็อก build ทันที
3. **Invalid dependency** — ชื่อ service/โมดูลสะกดผิดหรือไม่ได้ขึ้นทะเบียน = บล็อก build ทันที

**การใช้งานจริง:** Init() เรียง **ตามลำดับ dependency (ผู้ให้บริการก่อนผู้ใช้บริการ)** ส่วน Shutdown Manager และ TEARDOWN ใน hot update (§3.6 ขั้น 7) เรียง **ย้อนกลับเป๊ะ ๆ จาก graph เดียวกัน** — แก้ graph ที่เดียว ทั้งสองฝั่งเปลี่ยนตามอัตโนมัติ ไม่มีทางขัดกัน และ dependency นี้ยังเป็นข้อมูลให้ Adapter Self-Probe รู้ด้วยว่า API ตัวไหนตายแล้วจะกระทบโมดูลไหนบ้าง

---

## 4. ข้อกำหนดฟีเจอร์ v2 — P0 / P1 / P2 (Feature Specification)

### 4.1 Taxonomy เดียวทั้งเอกสาร (ตอบจุดรีวิว #11)

ตาราง mapping ฉบับสมบูรณ์ — ใช้คำสามชั้นนี้เหมือนกันทั้งเอกสารและทั้ง repo:

| Feature Domain (15 — จาก audit §2.2) | Product Module (8 — ที่ผู้ใช้เห็น) | Internal Services ตัวอย่าง (20+ — ที่สร้างจริง) |
|---|---|---|
| Aimbot + Soru | ⭐ **VoidAim** | TargetService, PredictionService, AimEngine, SkillAimProfiles |
| ESP | **Void ESP** | EspRenderer, ObjectPool, EspFilter |
| Smart Macro | **Void Macro** | MacroRecorder, MacroPlayer, EditorModel, MacroSerializer |
| Player/Combat + Sword/Gun + Bounty + Ken | **Combat Core** | CombatStateService, BountyTracker, AbilitySequencer, BlockEditor |
| Race | **Race** | RaceDetector, V4Sequencer |
| Fruit | **Fruit** | FruitDB, StockWatcher, RollController |
| ระบบเสริม (Movement Boosts) | **Movement** | MovementProfiler, BoostApplier |
| Teleport + Server Hop | **Server Hop / Teleport** | ServerHop, TeleportService |
| Config + Preset + FFlags | *(Foundation — ไม่ใช่แท็บแยก)* | ConfigService, MigrationService, PresetService, FFlagService |
| Multi-language | *(Foundation)* | I18nService |
| Anti-AFK / Safety | *(Runtime Layer)* | Watchdog, KeepAlive |

### 4.2 ระบบจัดลำดับ P0 / P1 / P2 (ตอบจุดรีวิว #10)

**หลักการ:** "v1.0 เสร็จ = P0 ครบ + ผ่าน acceptance ทุกแถว" — P1 ไม่มีสิทธิ์บล็อกการเปิดตัวแม้แต่รายการเดียว (เลื่อนไป v1.1 ได้เสมอ) P2 ทำต่อเมื่อ core stable แล้วเท่านั้น — กัน flagship feature กลายเป็นหลุมดำดูด scope

| ระดับ | ความหมาย | กติกา |
|---|---|---|
| **P0 — ต้องมีใน v1.0** | Parity หลักของทั้ง 8 โมดูล + โครงสร้าง (Runtime/Adapter/Config/Loader) | ขาดข้อเดียว = v1.0 ยังไม่เสร็จ |
| **P1 — ควรมี** | อัปเกรด usability/performance ที่เพิ่มความได้เปรียบ | ทำเท่าที่ทัน ไม่บล็อก v1.0, เลื่อนเป็น v1.1 ได้ |
| **P2 — Experimental** | prediction learning, combo simulator, auto retaliate, race timing profiles | เริ่มหลัง v1.0 stable, ทีละชิ้น, มี flag `experimental` ใน UI |

### 4.3 ตารางฟีเจอร์ทั้งโปรเจกต์ (P0/P1/P2)

| Product Module | P0 (ต้องมีใน v1.0) | P1 (ควรมี) | P2 (หลัง stable) |
|---|---|---|---|
| ⭐ **VoidAim** | 3 โหมด EZ/Pro/Legend, Main Aimbot, Skill Aimbot (Z/X/C/V/F/M1), Soru Aimbot + Normal Soru, Aim Key/Mode, Prediction v1 (ping-based), Exclude list, FOV + FOV Circle Visual | Void Prediction v2 (ping+velocity+ทิศทาง), Smart Target Priority, Auto Switch, Aim Stats, ~~Mobile Aim Button~~ *(OUT OF SCOPE ตาม CR-PC-ONLY)*, Preset สถานการณ์ 1 คลิก | Prediction Learning (สถิติ pattern รายบุคคล) |
| **Void ESP** | Parity ครบ 9 ชนิด (name/level/race/ken/hp/distance/combat/bounty/indicator) + Text Size ปรับได้ + Bounty Colors + โหมด Compact/Verbose | Chams Outline, Rare Fruit Alert, กรอง Bounty ขั้นต่ำ, ธีมสี 5 ชุด | — |
| **Void Macro** | Macro Slots หลายชุด + สลับด่วน, บันทึก/เล่นซ้ำ, Soru Skill Macro, ~~Mobile Slots~~ *(OUT OF SCOPE ตาม CR-PC-ONLY)*, Timing Tuner (resolution 0.01s + tolerance ตาม §5) | Visual Macro Editor, Macro Import/Export, Interactive Guide | Combo Learning / แนะนำคอมโบอัตโนมัติ |
| **Combat Core** | Anti Combo (+Skull/Soru), Anti Stun, Ability Trigger + Range Check, Attack Delay, Block Editor (Before/After), Combo System, Acidum Rifle M1, Auto Skull Guitar | — | **Combo Simulator** (จำลอง timeline + ดาเมจ), **Auto Retaliate Profile** |
| **Race** | Auto V3, Auto V4, Smart V3, Smart V4, HideV4Effects, HideControlEffects, ActivateRaceV4 | — | Race Timing Profiles (จูนจังหวะรายเผ่า) |
| **Fruit** | Auto Roll, Auto-Store (หมุนได้+ซื้อมา), Transform, Stock Checker, Gacha, Awakening Moves | Fruit Value Table, Stock Notification, Auto-Store Safety whitelist | — |
| **Movement** | Parity ครบ: Infinite Air Jump (+Hold), Super Jump (80–200), Sang Z, Yama Z, Soul Guitar Momentum, Diamond M1, Dash/Jump Boost | Movement Profile (รวมบูสต์เป็น preset สลับ 1 คลิก — งานเล็ก จึงอยู่ P1 ไม่ใช่ P2) | Advanced movement tuning |
| **Server Hop / Teleport** | วาร์ปครบ + Server Hop (parity 89 + 84 จุด) | — | — |
| **Foundation/UI** | Config + Preset + Schema Migration, i18n ไทย/อังกฤษ, Keybind Manager, HUD, Notification, **Developer Diagnostics**, Anti-AFK, Theme Void Neon | ค้นหาฟีเจอร์ใน hub | — |
| **Runtime/Loader** | Capability Detection + Bootstrap Preflight, Resource Registry (Tasks/Connections/Render/Temp), Error Boundary, Watchdog, Shutdown Manager (ตาม Dependency Graph §3.10), 4-URL + Version Gate + Manifest (SHA-256), Hot Update Protocol 12 ขั้น + Rollback Paths F0–F4 | โหมด auto-update | Signed Manifest (§7.3) |
| **QA (ส่วนของงาน ไม่ใช่ฟีเจอร์)** | Matrix ทุกโมดูล, L1+L2 ครบ, Regression suite, Stress 2 ชม., Capability Matrix บน Volt | Long-run 8 ชม. (ค้างคืน) | Chaos testing |

**หมายเหตุการจัดระดับที่ควรรู้ตอนอนุมัติ:** ตามคำแนะนำในรีวิว **Combo Simulator, Auto Retaliate, Prediction Learning, Race Timing Profiles ถูกย้ายไป P2 ทั้งหมด** (v1.0 เปิดตัวได้โดยไม่มีสี่อย่างนี้) ส่วน Movement Profile อยู่ P1 เพราะเป็นแค่การมัดรวมค่าที่มีแล้วเป็น preset ไม่ใช่งาน "advanced" ในความหมายของรีวิว — ถ้าคุณเห็นต่างบอกปรับได้ทันที

### 4.4 ⭐ VoidAim — รายละเอียดระบบเรือธง (P0 + P1)

**ปรัชญา:** "เปิดเดียวก็เทพ ปรับลึกก็โหด" — แก้ปัญหา aimbot ทั่วไปที่ต้องตั้ง 20 ค่าก่อนใช้ได้

| ระดับ | สำหรับใคร | ต้องทำอะไร | ได้อะไร |
|---|---|---|---|
| 🟢 **EZ Mode** (ค่าตั้งต้น) | ทุกคน | สวิตช์เดียว | ระบบจัดการทุกอย่างเอง — เลือกเป้า ทำนาย ปรับความแม่น ยิงเมื่อมั่นใจ |
| 🔵 **Pro Mode** | ผู้เล่นประจำ | ปรับ ~8 ค่าหลัก | FOV, ระยะล็อก, ลำดับความสำคัญเป้า, คีย์ลัด, การทำนาย |
| 🟣 **Legend Mode** | มืออาชีพ | ปรับได้ทุกอย่าง | Per-skill aimbot, ผสาน macro, soru aimbot, โหมดเป้าหมายพิเศษ |

**อัปเกรด 7 อย่างที่ Cokeboys ไม่มี** (จาก v1.0 — ตอนนี้จัดระดับชัดเจน): 1) Void Prediction v2 **[P1]** 2) Smart Target Priority **[P1]** 3) Auto Switch **[P1 — เกณฑ์วัดใหม่อยู่ §5]** 4) FOV Circle Visual **[P0]** 5) Aim Stats **[P1]** 6) ~~Mobile Aim Button~~ **[ตัดออกตาม CR-PC-ONLY 1 ต.ค. 2026 — ไม่ทำ ไม่ย้าย P2]** 7) Preset สถานการณ์ 1 คลิก **[P1]** — และเพิ่มใหม่: 8) Prediction Learning **[P2]**

**เกณฑ์ความสำเร็จของ VoidAim (แบบวัดได้ — รายละเอียด DoD เต็มอยู่ §5 เฟส 2):** ผ่านทุกแถวของ matrix §2.4 | EZ Mode: ผู้ใช้ใหม่เปิดใช้สำเร็จใน 10 วินาที (วัดจาก L3 checklist จริง) | ไม่เกิด duplicate lock ทั้ง suite (generation token assert) | aim update cost ≤ 0.8ms/frame ใน test env

### 4.5 หลักการส่งมอบของทุกโมดูล

ทุกโมดูลที่ลงมือเขียนต้องผ่านลำดับเดียวกันเสมอ: **(1) เขียน Behavioral Matrix ก่อน → (2) คุณรีวิว matrix → (3) เขียนโค้ด + L1/L2 → (4) ทดสอบ L3 ในเกมจริง → (5) ปิด acceptance ทีละแถว** ไม่มีโมดูลไหนเขียนโค้ดก่อนมี matrix และไม่มีแถวไหน "ผ่านเพราะน่าจะได้" — ทุกแถวต้องมีหลักฐานการทดสอบกำกับ

---

## 5. แผนพัฒนา 5 เฟส v2 — DoD ที่วัดได้ (Roadmap)

### 5.1 กติกาเกณฑ์ผ่านแบบใหม่ (ตอบจุดรีวิว #5)

ทุกเกณฑ์ใน v2.0 เขียนตามสูตรเดียวกัน: **[พฤติกรรมที่ต้องเกิด] + [วิธีวัด: ชั้นทดสอบไหน/เครื่องมืออะไร] + [ค่าเป้าจาก test environment ที่ควบคุมได้ หรือ tolerance ตาม runtime จริง]**

**โครงสร้าง DoD ของทุกเฟส (กฎเพิ่มจาก hardening #4):** แต่ละเฟสแบ่งเกณฑ์รับงานออกจากกันชัดเจน — **P0 DoD = MUST PASS** (ไม่ผ่าน = เฟสไม่จบ ไม่มีข้อยกเว้น) / **P1 DoD = SHOULD PASS** (ไม่ผ่าน = ย้ายเข้า backlog v1.1 อย่างเปิดเผย **เฟสผ่านได้ตามปกติ** ไม่ถือว่าล้มเหลว) / **P2 = ไม่ตรวจรับใน v1.0** — กติกานี้ทำให้ตาราง P0/P1/P2 ของ §4.2 กับ DoD ของทุกเฟสพูดภาษาเดียวกันจริง (แก้จุดที่ v2.0 ยังวางของ P1 ปนใน DoD รับงานของเฟส 3)

**ตารางแก้เป้าหมายที่ "แม่นเกินจริง" ของ v1.0 ทั้งหมด:**

| เป้าเดิม v1.0 ❌ | ปัญหา | เป้าใหม่ v2.0 ✅ |
|---|---|---|
| Auto Switch ภายใน 0.1 วินาที | runtime จริงมี frame scheduling + ping — ตัวเลขนี้สัญญาไปก่อนวัดไม่ได้ | Target switch เกิดทันทีเมื่อเงื่อนไขเปลี่ยน (**frame เดียวกันหรือ frame ถัดไป** — วัดใน L2 virtual-time) + **ห้ามเกิด duplicate lock** (generation token assert) + upper-bound ที่วัดได้จริงบันทึกเป็น metric จาก test environment ทุกเฟส |
| Macro timing แม่น 0.01 วินาที | ไม่มี runtime ไหนการันตีความละเอียดระดับนี้แบบ absolute | รองรับ **requested delay resolution 0.01s** + acceptance วัด **actual execution timing เทียบ virtual-time test**: tolerance = ±1 frame ของอัตราเฟรมเป้าหมาย (±16.7ms ที่ 60fps) และบันทึก jitter จริงเป็น metric ต่อ release (บน Volt) |
| UI ลื่น 60fps | เครื่องผู้ใช้ต่างกัน — 60fps เป็นของเครื่อง ไม่ใช่ของเรา | **Frame budget แทน**: UI render cost ≤ 0.5 ms/frame ใน test environment (วัดจาก Diagnostics) + ใน stress test ไม่ก่อให้เกิด frame drop เพิ่มเกิน 5% จาก baseline |
| Macro เล่นซ้ำแม่น 100% | "100%" กำกวม — หมายถึงอะไร? | แยกเป็นสองข้อ: **action sequence match = 100%** (ทุก action ถูกเรียกตามลำดับครบถ้วน — วัดใน L2) + **timing อยู่ใน tolerance** ตามแถวบน (สองอย่างนี้คนละเกณฑ์ ห้ามรวม) |
| 0 error เด้ง | นับ "ไม่เด้ง" ยังไงในเครื่องคนอื่น | ทุก error ที่เกิดต้องมี **Bug ID + root cause + regression test ผ่านแล้ว** ก่อนปิด (§11) + error counter ต่อโมดูลจาก Error Boundary เทียบกับ session log ต้องชนกัน 100% (ไม่มี error ที่รอดจากการบันทึก) |
| สลับเป้าตาย-ใหม่ 0.1 วิ (เฟส 2 เดิม) | ซ้ำกับข้อแรก | รวมเป็นเกณฑ์ "frame เดียวกัน/ถัดไป + ไม่ duplicate + upper-bound จาก test env" ข้อเดียว |
| ไม่ค้างเฟรมเกิน 3 วินาที | วัดยังไงในเครื่องผู้ใช้? | วัดใน test environment ด้วย virtual-time watchdog: ไม่มี task ไหน block เกิน 3 วินาที (assert) + ใน L3 ใช้ observation checklist (จับเวลาด้วยตา + วิดีโออ้างอิง) |

### 5.2 ภาพรวม 5 เฟส (โครงเดิม + เฟส 0 ขยายตามสถาปัตยกรรมใหม่)

| เฟส | ชื่อ | สิ่งที่ได้ | รอบส่งมอบ | เวอร์ชัน |
|---|---|---|---|---|
| 0 | 🏗️ Foundation + Runtime | Runtime Layer ครบ 5 องค์ประกอบ + 1 Bootstrap Preflight (Resource Registry รวม 4 ชนิด) + Dependency Graph + Foundation + Adapter โครงแรก + Loader v2 + Matrix ทุกโมดูล + ระบบทดสอบ 3 ชั้น | 2–3 | v0.1–v0.2 |
| 1 | 🎨 UI Framework | UI Void Neon เต็ม + HUD + Notification + ~~มือถือ~~ *(CR-PC-ONLY: ตัดออก)* + Diagnostics เต็มรูปแบบ | 1–2 | v0.3 |
| 2 | ⭐ VoidAim + ESP | ระบบเรือธง P0 ครบ 3 โหมด + ESP P0 + P1 บางส่วน | 2–3 | v0.4–v0.6 |
| 3 | 🎹 Macro + Combat | Macro P0 ครบ + Combat P0 ครบ | 2–3 | v0.7–v0.9 |
| 4 | 🌟 Race + Fruit + Polish | ทุกโมดูล P0 ครบ + stress + capability matrix + **เปิดตัว v1.0** | 2 | v1.0 🚀 |

*หมายเหตุ: รอบส่งมอบเพิ่มจากแผนเดิมเล็กน้อยในเฟส 0 เพราะ Runtime Layer + Matrix เป็นงานขึ้น — นี่คือราคาที่คุ้มของสถาปัตยกรรมที่ "นิ่งขึ้นมาก" ตามที่รีวิวให้การรับรอง*

### 5.3 เฟส 0 — Foundation + Runtime (ขยายจากเดิม)

**สิ่งที่สร้าง:** Runtime Layer ครบ 5 องค์ประกอบ + 1 Bootstrap Preflight (preflight ระดับ 0 ใน loader / capability detection / resource registry 4 ชนิด / error boundary / watchdog / shutdown) + **Dependency Graph v1 + build validation 3 ชั้น (§3.10)** | Event Bus + Services | Config + Schema Migration + Fallback | i18n + Keybind | **Diagnostics รุ่นแรก** | Game Adapter โครงแรก (ครบ 6 API ระดับพื้นฐาน + self-probe) | Build system + lint | Loader v2 (manifest ใหม่) | **Behavioral Matrix ทั้ง 8 โมดูล** (คุณรีวิวก่อนเขียนโค้ดโมดูลจริง) | Test harness L1/L2 + ฉาก L3 แรก

**สิ่งที่คุณได้ทดสอบ:** รัน loader เข้าเกม → HUD + Adapter Health report → สลับภาษาไทย → รันซ้ำ 10 รอบ → **hot update จำลอง v0.1→v0.2 ในเกมจริง** (ดู protocol 12 ขั้น + ทดลองฉีดพัง 1 เส้นทาง เช่น ตัดเน็ตกลาง LOAD แล้วดูระบบกลับรุ่นเดิมให้ดู) → รายงานเวลา/orphan ทุกขั้น

**DoD (วัดได้ทุกข้อ):**
- L1+L2 ผ่านครบทุกชุดที่มีในเฟสนี้ (ผลรันชุดทดสอบแนบทุกรอบส่งมอบ)
- Registry assert: หลัง Disable/Destroy ทุกโมดูล resource orphan รวม 4 ชนิด (task/connection/render/temp) = **0** (assert อัตโนมัติ ไม่ใช่ตาดู)
- Hot update v→v+1 และ v→v+2: สำเร็จ + orphan 0 + เวลารวมบันทึกเป็น metric (เป้า ≤ 5s ใน test env) + **failure injection ผ่านครบทุกเส้นทาง F0–F4 (กลับรุ่นเดิมได้ทุกครั้ง + มี BUG-XXX ทุกครั้ง)** + **ฉาก "Rollback Snapshot เสียก่อน TEARDOWN" = ABORT + อยู่รุ่นเก่าต่อ + BUG-XXX (freeze R4)** + **atomic update rule ครบ: NEW = active ก็ต่อเมื่อผ่าน LOAD → MIGRATE → SELFCHECK → ADAPTER PROBE ครบ (freeze R3)** + replay policy ผ่านฉาก "เป้าตายระหว่าง freeze" (เป้าหลังอัปเดต = เป้าตามโลกจริง)
- Config migration ทดสอบสำเร็จทั้งเส้นทางปกติและไฟล์เสีย (L1) + fallback สำรอง `.bak` ได้จริง
- Capability Detection: probe 8 ตัวบน Volt จริง + รายงานผลตรงกับที่ Volt อ้าง
- ไม่มี string "key"/"license" ใด ๆ ใน dependency ของระบบ auth (โครงสะอาดตั้งแต่วันแรก)
- Matrix ทั้ง 8 โมดูลผ่านการรีวิวจากคุณแล้ว (deliverable บังคับของเฟสนี้)

### 5.4 เฟส 1 — UI Framework (Void Neon)

**สิ่งที่สร้าง:** Theme Engine | Main Hub (แท็บ + พื้นที่สำหรับค้นหา P1) | Notification | HUD เต็มรูปแบบ (ลากย้าย + FPS + uptime) | ~~เลย์เอาต์มือถือ~~ **[CR-PC-ONLY 1 ต.ค. 2026: ตัดออกจาก product scope — ไม่มี MobileLayout node/ปุ่มลัดมือถือ อุปกรณ์ทัชอย่างเดียวได้เลย์เอาต์ desktop เดิม]** | **Developer Diagnostics เต็มรูปแบบ** (§8.4)

**DoD ฉบับ PC-only (CR-PC-ONLY — แทนข้อ 4–5 เดิมที่ผูกกับทัช/มือถือ):** UI render cost ≤ 0.5 ms/frame ใน test env (Diagnostics) | เปิด-ปิด-เปิด hub 20 รอบ: Resource orphan (รวม 4 ชนิด) ยังคงเป็น 0 | i18n key coverage 100% (test ไล่ทุก key ทั้ง 2 ภาษา ห้ามมี key ตกหล่น/ข้อความค้างภาษาเดิม) | ปุ่ม UI ทั้งหมดมาจาก layout constants มาตรฐาน (TAB_H/ความสูงปุ่ม 44px คงเดิม — เป็นมาตรฐานของ UI ไม่ใช่ gate เฉพาะทัชอีกต่อไป) | **PC-only guard (L1 ถาวร กันถอยหลัง): อุปกรณ์ทัชอย่างเดียว (stub) → ยังได้เลย์เอาต์ desktop เดิมทุกค่า + ไม่มี layer TVMobile + graph ไม่มี MobileLayout** | **L3 checklist บน Volt PC จริง (mouse+keyboard) 10 รายการ: (1) เปิด/ย่อ hub (2) สลับแท็บครบ 8 (3) เปลี่ยนภาษาไทย↔อังกฤษ ป้ายเปลี่ยนสด (4) เปลี่ยน accent (5) ลาก hub ด้วยเมาส์+ปิดเปิดใหม่ตำแหน่งคงเดิม (6) ลาก HUD+เปิด/ปิดแผงย่อ (7) เปิด/ปิด Developer Diagnostics + ดูกราฟ (8) Export Diagnostics (9) รับ toast+ปิดด้วยเมาส์ (10) ปิดสะอาดไม่มี error ค้าง**

### 5.5 เฟส 2 — VoidAim + ESP (งบมากสุด)

**สิ่งที่สร้าง:** VoidAim P0 ทั้งหมด (3 โหมด + parity + Prediction v1 + FOV Circle) + P1: Prediction v2, Smart Target Priority, Auto Switch, Aim Stats | Void ESP P0 ทั้งหมด

**P0 DoD (MUST PASS — ไม่ผ่านเฟสไม่จบ):** ผ่านทุกแถวของ matrix VoidAim + ESP ระดับ P0 (แนบผลทีละแถว) | duplicate lock = 0 ทั้ง suite (generation token assert) | target switch: frame เดียวกัน/ถัดไป + upper-bound บันทึกจาก test env | aim update cost ≤ 0.8 ms/frame ใน L2 test env (§9.1) | EZ Mode ผ่าน L3: ผู้ใช้ใหม่เปิดใช้สำเร็จใน 10 วินาที (checklist + จับเวลาจริง) | stress ฉาก 50 ผู้เล่นจำลอง 2 ชม.: ไม่มี task block เกิน 3 วิ + memory ไม่โต monotonic 15 นาทีสุดท้าย

**P1 DoD (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสนี้ผ่านได้):** Prediction v2 / Smart Target Priority / Auto Switch / Aim Stats ผ่าน matrix ระดับ P1 ของตนเองเท่าที่ทำทัน (แนบผลทีละแถวของที่ทำได้ + ระบุชัดว่าอะไรเลื่อนเป็น v1.1)

### 5.6 เฟส 3 — Macro + Combat

**สิ่งที่สร้าง:** Void Macro P0 (slots/บันทึก/เล่นซ้ำ/soru/timing tuner — *mobile ตัดออก: MC-012 OUT OF SCOPE ตาม CR-PC-ONLY*) | Combat Core P0 ครบ | P1: Visual Editor, Import/Export (ถ้าทัน — ไม่บล็อกเฟส)

**P0 DoD (MUST PASS — ไม่ผ่านเฟสไม่จบ):** action sequence match = 100% ทุกชุดทดสอบ (รวมคอมโบ 50+ ขั้น) | timing: actual execution อยู่ใน tolerance ±1 frame ที่ 60fps เทียบ virtual-time (jitter บันทึกเป็น metric) | ยกเลิกกลางเล่น/ตายกลางเล่น: หยุดสะอาด resource orphan 0 (รวม 4 ชนิด) | L3: บันทึกคอมโบจริง → เล่นซ้ำในแมตช์จริงได้

**P1 DoD (SHOULD PASS — ไม่ผ่าน = ย้าย backlog v1.1 เฟสนี้ผ่านได้):** Visual Editor แก้-ลบ-แทรกขั้นแล้ว replay ผลลัพธ์ตรง matrix | Import/Export: ส่งไฟล์คอมโบให้เพื่อนเปิดได้ (ผูกกับ CLIPBOARD/FILEIO capability — ถ้า capability ไม่มี = เลื่อน v1.1 ไม่ใช่ความล้มเหลว)

### 5.7 เฟส 4 — Race + Fruit + Polish + เปิดตัว v1.0

**สิ่งที่สร้าง:** Race P0 | Fruit P0 + P1 (value table/stock notify/safety) | Movement P0 + P1 (profile) | Server Hop + Teleport | Polish + สำรวจ i18n ครบ | **Stress เต็มรูปแบบ + Capability Matrix บน Volt จริง + Long-run 8 ชม.** | แพ็กเกจเปิดตัว (zip + เอกสาร + คลิปสาธิตสั้น)

**DoD (เกณฑ์เปิดตัว v1.0):** **P0 coverage = 100%** (ทุกแถวของทุก matrix ระดับ P0 ผ่าน มีหลักฐานกำกับ) | stress 2 ชม. ผ่านทุกเกณฑ์ §9 | long-run 8 ชม.: memory ไม่โต monotonic + ไม่มีโมดูลไหนถูก watchdog ปิดถาวร | capability matrix: **Volt จริง** (probe ใหม่ทุก release ตาม §6.3) + ทดสอบ graceful disable ด้วยการบังคับปิด capability จำลอง | regression suite เขียว 100% | คุณ + เพื่อนทดสอบในเกมจริง: ไม่มีบั๊กระดับบล็อก | P1 ที่ยังไม่เสร็จ → ระบุเป็น v1.1 อย่างเปิดเผย (ไม่เก็บเงียบ)

### 5.8 วิธีทำงานแต่ละรอบ (กติกาเดิม + เพิ่มเติม)

1. **ห้ามทำงานเงียบ** — รายงานความคืบหน้าตลอด ภาษาไทยเสมอ
2. **ทดสอบก่อนส่งทุกครั้ง** — ผล L1/L2 แนบทุกรอบ + ทุกบั๊กกลายเป็น test case ถาวร (§11)
3. **Update Log ทุกการเปลี่ยนแปลง** — อะไร/ทำไม/ผลกระทบ/วิธีทดสอบ/สถานะ
4. **คุณคือ QA ตัวจริง** — ทุกเฟสคุณทดสอบในเกมจริงก่อนไปเฟสถัดไป
5. *(ใหม่)* **ตัวเลขทุกตัวมีที่มา** — ทุก metric ที่รายงานต้องระบุได้ว่าวัดจากไหน อย่างไร กี่ครั้ง — ไม่มีตัวเลขลอย ๆ

---

## 6. กลยุทธ์คุณภาพ v2 — Unit / Integration / Live (QA Strategy)

### 6.1 สามชั้นทดสอบ (ตอบจุดรีวิว #6)

เหตุผลของการแยกชั้น: เมื่อเจอบั๊ก ต้องรู้ทันทีว่า **logic พัง / adapter พัง / runtime-executor พัง / หรือเกมเปลี่ยน** — แยกชั้นไว้ล่วงหน้าคือคำตอบของคำถามนี้

| ชั้น | ทดสอบอะไร | รันที่ไหน | เครื่องมือ | ผ่านเมื่อ |
|---|---|---|---|---|
| **L1 — Unit** | ฟังก์ชัน/โมดูลเดี่ยว, pure logic (prediction math, priority score, config migration, exclude matching) | เครื่องเรา อัตโนมัติ | fengari + stub (ต่อยอดชุด v3.x ที่ผ่าน 7–9 หมวดมาแล้ว) + virtual time | ทุก test case ในชุดผ่าน 100% |
| **L2 — Integration** | โมดูล + Game Adapter + Event Bus + Config ทำงานร่วมกัน: ฉากจำลอง "50 ผู้เล่นเดินเข้ามา", "สลับเป้า 100 ครั้ง", "macro 50 ขั้น", "อัปเดตสดกลางล็อกเป้า", "config เสียกลางทาง" | เครื่องเรา อัตโนมัติ | fengari + Roblox stub เต็มรูปแบบ + virtual-time scheduler + pcall spy | ทุกฉากจบโดยไม่มี error + orphan 0 + metric อยู่ในเกณฑ์ |
| **L3 — Live** | ของจริง: Volt จริง + เกมจริง + ผู้เล่นจริง | เครื่องคุณ | Checklist รายเฟส + วิดีโออ้างอิง + Diagnostics export | คุณยืนยัน checklist ผ่านทุกข้อ |

**กฎสำคัญ:** L1/L2 ผ่าน **ไม่ได้แปลว่า** L3 จะผ่าน — ชั้นทดสอบคือตัวกรอง ไม่ใช่หลักฐานสมบูรณ์ ดังนั้นทุกเฟสต้องผ่านครบสามชั้นก่อนส่งมอบถือว่าเสร็จ และบั๊กที่เจอที่ L3 ต้องถูก**จำลองซ้ำใน L2 ให้ได้** (ถ้าทำได้) เพื่อให้มี regression test ถาวรกันซ้ำ — ถ้าจำลองไม่ได้จริง ๆ ให้เก็บเป็น L3 checklist รายข้อแทน

### 6.2 สี่ชุดทดสอบแยกออกจากฉากปกติ

| ชุด | ทำอะไร | ความถี่ |
|---|---|---|
| **Regression Suite** | ทุกบั๊กที่เคยเกิด = test case ถาวรชื่อ `BUG-XXX_*.lua` (§11) | รันทุกรอบส่งมอบ ทุกเฟส ตลอดอายุโปรเจกต์ |
| **Performance Test** | วัด **L2 budget** (§9.1) + เก็บ **L3 baseline** (§9.2) แล้วเทียบกับเฟสก่อน — **L2 budget ห้ามแย่ลงโดยไม่มีเหตุผลที่บันทึกไว้** / L3 เทียบ baseline ของเครื่องเดิม | ทุกรอบส่งมอบ |
| **Stress Test** | ฉากหนัก: ESP 50 ผู้เล่น, สลับเป้าต่อเนื่อง, macro ยาว, เปิดทุกฟีเจอร์พร้อมกัน, hot update กลางการใช้งาน | ปลายทุกเฟส + ก่อนทุก release |
| **Long-run Test** | ทิ้งรัน 8 ชม. ค้างคืน: memory, resource สะสม (Resource Registry 4 ชนิด), watchdog ตอนโต้ตอบน้อย | เฟส 4 ก่อนเปิดตัว + ทุก major release |

### 6.3 Compatibility = Capability Matrix บน Volt (ตอบจุดรีวิว #7 + ขอบเขต freeze R5)

เลิกทำตาราง "Volt = ✅ Solara = ✅ Delta = ✅" แบบ hard-code (แบบ v2.0 เดิม) และตามขอบเขตที่ตัดสินรอบ freeze: **The Voider รองรับและทดสอบบน Volt เท่านั้น** — executors อื่นทั้งหมด = **ไม่รองรับ ไม่ทดสอบ ไม่รับประกัน** (ผู้ใช้ที่เลือกใช้ executor อื่น = ใช้ความเสี่ยงเอง บั๊กประเภท "executor อื่นพัง" ไม่เข้าระบบติดตามของโปรเจกต์) รายงานความสามารถจริงมาจาก **Capability Detection (§3.2) บน Volt ต่อ release** (ไม่เชื่อผลของ release ก่อน เพราะ Volt อัปเดตเวอร์ชันได้ ผลอาจเปลี่ยน):

```text
ตัวอย่างรูปแบบรายงาน (ตัวเลขจริงจะมาจากการทดสอบเฟส 4):

              DRAWING   HOOK   HTTP   FILEIO   INPUT   CLIPBOARD   TASK   CRYPTO
Volt           ✓         ✓      ✓      ✓        ✓        ✓         ✓       ?
```

**พฤติกรรมที่ต้องพิสูจน์ในเฟส 4 (และทุก major release):** (1) ผล probe ตรงกับการใช้งานจริง 100% — probe ว่ามีแต่ใช้แล้วพัง = บั๊กระดับสูง (2) ปิด capability จำลอง (เช่น stub ให้ DRAWING หาย) แล้ว VoidESP ต้องปิดตัวเอง + แจ้งภาษาไทย + ฟีเจอร์อื่นเดินต่อ — **ทดสอบกรณีนี้เป็นชุดทดสอบถาวร** (3) ผลรายงานทั้งหมดแนบไปกับ release notes เป็นภาษาไทย *(ถ้าวันหน้าต้องขยายไปรองรับ executor อื่น = การเปลี่ยนขอบเขต ต้องเสนอ change request แยก ไม่ใช่งานของ v1.0)*

### 6.4 นิยาม "ผ่าน" แบบพิสูจน์ได้ (แทนคำว่า "0 error")

- ทุกแถว matrix มีสถานะ + หลักฐาน (ผลรัน/วิดีโอ/export Diagnostics) กำกับ
- ทุก error ที่เกิดขึ้นเมื่อไหร่ = มี Bug ID + สถานะแก้ + regression test ผ่าน — **ไม่มี error ไร้เจ้าของ**
- ทุก metric (§9) มีค่าล่าสุด + แนวโน้มเทียบเฟสก่อน
- ทุก toggle ใน UI ผูกกับแถว matrix อย่างน้อยหนึ่งแถว (ไม่มีปุ่มหลอก — ตรวจด้วย test ไล่ UI ทุกปุ่ม)

### 6.5 ลำดับความสำคัญคุณภาพ (คงเดิมจาก v2.2)

ถูกต้อง > เสถียร > ปลอดภัย > ประสิทธิภาพ > ใช้งานง่าย > ดูแลรักษาง่าย > ขยายฟีเจอร์ง่าย > ความเร็วพัฒนา

---

## 7. ระบบกระจายและอัปเดตสด v2 — SHA-256 Manifest (Distribution)

### 7.1 Manifest รุ่นใหม่ (ตอบจุดรีวิว #9)

แทนที่การเช็ค "ขนาด + เวอร์ชัน + md5" ด้วย manifest ครบชุด (ฝากไว้ที่ repo ข้างไฟล์ และฝังสำเนาใน loader):

```json
{
  "product": "the-voider",
  "version": "0.3.0",
  "releaseId": "r2026-09-30-01",
  "files": {
    "the-voider.lua": { "sha256": "<hash 64 หลัก>", "size": 123456 },
    "tv.lua":         { "sha256": "<hash 64 หลัก>", "size": 123456 }
  },
  "minLoaderVersion": "0.3.0",
  "channel": "stable"
}
```

- **Version Gate** (ยกจาก v3.1 ที่พิสูจน์แล้ว): ปฏิเสธไฟล์เก่ากว่า manifest ปัจจุบันโดยเด็ดขาด — บทเรียนจาก CDN ค้าง v2.1
- **minLoaderVersion**: ถ้ารุ่นใหม่ต้องการ loader ใหม่กว่าที่ผู้ใช้มี → บอกผู้ใช้ชัดเจนแทนการพังเงียบ ๆ
- **Release ID**: อ้างอิงราย release เดียวทั้ง changelog/bug report/rollback

### 7.2 ความจริงเรื่อง SHA-256 บน executor (วิศวกรรมจริง ไม่ใช่คำสัญญา)

MD5 เดิมเหมาะกับ "ตรวจความเสียหาย" ไม่ใช่ "พิสูจน์ว่าเป็นไฟล์ของเรา" — เปลี่ยนเป็น SHA-256 และตอบตรง ๆ ว่าจะทำอย่างไรบน runtime ที่ไม่มี crypto ให้:

| เงื่อนไข | วิธีตรวจ | สิ่งที่ผู้ใช้เห็น |
|---|---|---|
| Executor มี `CRYPTO` capability (hash ในตัว) | ตรวจ SHA-256 เต็มรูปแบบตอนโหลด/อัปเดต | ข้อความ "ตรวจสอบความถูกต้นฉบับ: เต็มรูปแบบ" |
| ไม่มี crypto และ pure-Lua SHA-256 เร็วพอ *(วัดจริงในเฟส 0)* | ใช้ pure-Lua SHA-256 (benchmark กับไฟล์ขนาดจริง — ถ้า hash จบภายใน budget §9 จึงใช้) | "เต็มรูปแบบ (โหมดซอฟต์แวร์)" |
| ไม่มีและช้าเกิน budget | ตรวจระดับ 2: version + size + header marker ฝังในไฟล์ | "ตรวจระดับพื้นฐาน (version+size)" — **บอกตามจริง ไม่อวดอ้าง** |

**ชั้นที่ได้เสมอไม่ว่ากรณีไหน:** การโหลดทั้งหมดวิ่งผ่าน HTTPS ของ GitHub/jsdelivr ซึ่งปกป้องทั้ง transport และต้นทางอยู่แล้ว — SHA-256 คือชั้นที่สองกันไฟล์เสียหาย/ถูกแปลงกลางทางที่ CDN และกัน "อัปโหลดผิดไฟล์" ของเราเองด้วย

### 7.3 Signed Manifest = P2 (พูดตรง ๆ ไม่ประกาศก่อนพิสูจน์)

ลายเซ็นดิจิทัลแบบ asymmetric ต้องการ RSA/Ed25519 ซึ่งไม่มีใน runtime มาตรฐาน และถ้าใช้ symmetric key ฝังในสคริปต์ = แกะออกได้ทันที (ปลอมความปลอดภัย) จึงจัดเป็น **P2 — ศึกษาต่อหลัง v1.0 stable** พร้อมทางเลือกที่เป็นไปได้จริง (เช่น verify ผ่านหลายช่องทางอิสระ) โดยไม่สัญญาก่อนเวลา

### 7.4 บันไดเวอร์ชัน + โปรโตคอล CDN

- บันไดเวอร์ชัน: `v0.x` ระหว่างพัฒนา → `v1.0` เปิดตัว → `v1.x` patch/ตามเกม → `v2.0` major | ทุก release มี zip + manifest + changelog ภาษาไทย
- **Purge Protocol ทุกครั้ง** (กติกาเดิมที่พิสูจน์แล้วกับ jsdelivr): อัปโหลด → purge → curl ตรวจ 4 URL จริง (เทียบ SHA-256 จากเฟส 0) → ยืนยันกลับว่า "โลกภายนอกเห็นไฟล์ใหม่แล้วจริง"
- **Rollback:** ทุก release เก็บไว้บน repo ถ้ารุ่นใหม่มีปัญหา = manifest ชี้กลับรุ่นก่อนได้ทันที + Version Gate ยอมรับ downgrade เมื่อ manifest ระบุ channel `rollback` อย่างชัดเจน
- **Repo:** แนะนำใหม่ `thevoider/loader` (รอคุณตัดสินใจใน §12)

---

## 8. การออกแบบ UI v2 + Developer Diagnostics (UI Design)

### 8.1 Palette สีหลัก (คงเดิมจาก v1.0)

| บทบาท | ชื่อสี | รหัสสี | ใช้ที่ไหน |
|---|---|---|---|
| พื้นหลังหลัก | ดำหลุมดำ | `#0A0A14` | พื้นหลัง hub / HUD |
| พื้นการ์ด | ดำน้ำเงินเข้ม | `#12121F` | การ์ดฟีเจอร์ / แท็บ |
| เส้นขอบเรือง | ม่วงนีออน | `#7C3AED` | เส้นขอบ 1px รอบการ์ด |
| เน้นหลัก (ไล่สี) | ม่วงไล่แสง | `#A855F7 → #6366F1` | ปุ่มหลัก / toggle เปิด / หัวข้อ |
| เน้นรอง | ฟ้านีออน | `#22D3EE` | ไฮไลต์ / ลิงก์ / สถิติ |
| ข้อความหลัก | ขาวนวล | `#E5E7EB` | ชื่อฟีเจอร์ / ค่าตั้งค่า |
| ข้อความรอง | เทาหม่น | `#9CA3AF` | คำอธิบาย / ค่าที่ปิดอยู่ |
| สถานะเปิด/สำเร็จ | เขียวมรกต | `#34D399` | จุดสถานะ / ยืนยัน |
| สถานะปิด/อันตราย | แดงหลังคา | `#F87171` | ปุ่มปิด / เตือน |

### 8.2 หลักการ Visual (คงเดิม)

- **Glassmorphism แบบเบามือ** — การ์ดโปร่งแสง ~12% + เส้นขอบเรืองม่วง 1px + เงานวล — "ลอยเหนือเกม" โดยไม่บังสายตา
- **Typography** — หัวข้อตัวหนา + ตัวเลขสถิติฟอนต์ mono อ่านสบายที่ 1080p
- **Animation นุ่มแต่ไม่เยอะ** — 0.15 วินาที + hover glow
- **Dark-only โดยตั้งใจ** — ทำธีมเดียวให้สวยสุด + ปรับ accent ได้ (ม่วง/ฟ้า/ชมพู/เขียว)
- **No Silent Degradation ใน UI ด้วย** — ฟีเจอร์ที่ถูกปิดเพราะ capability/probe แสดงเป็นปุ่มสีเทา + ไอคอน 🔒 + คำอธิบายสั้นว่าปิดเพราะอะไร (แตะดูรายละเอียดได้) — ไม่ใช่ซ่อนไปเงียบ ๆ

### 8.3 โครงหน้าจอ (Layout — เพิ่มบรรทัดสถานะ)

```text
┌─────────────────────────────────────────────┐
│  🕳️ THE VOIDER          v0.4   ● แชร์เรดี   │ ← แถบหัว: ลากย้ายได้ + สถานะระบบสด
├────────┬────────────────────────────────────┤
│ 🔍 ค้นหาฟีเจอร์...                          │
├────────┬────────────────────────────────────┤
│ ⭐ Aim  │  🟢 EZ Mode      [ON]             │
│ 👁 ESP  │  ────────────────────────────     │
│ 🎹 Macro│  🔵 Pro Mode                       │
│ ⚔ Combat│  FOV: 120px   [════════○──]      │
│ 🧬 Race │  Priority: [Bounty สูงสุด ▾]      │
│ 🍎 Fruit│  ⌨ Key: [คลิกเพื่อตั้ง]           │
│ 🏃 Move │                                    │
│ ⚙ Setup │  📊 ความแม่นเซสชันนี้: 87%        │
├────────┴────────────────────────────────────┤
│ HUD: FPS 60 | ออนไลน์ 2ชม. | ● Adapter ครบ  │ ← ไดอักนอสติกย่อ: กดดูเต็มได้
└─────────────────────────────────────────────┘
```

- แท็บซ้าย = ระบบ / เนื้อหาขวา = การตั้งค่า | ~~มือถือ: แท็บย่อเป็นไอคอนแถบล่าง ปุ่มเป้าหมาย ≥ 44px + ปุ่มลัดลอยย้ายตำแหน่งได้~~ **[CR-PC-ONLY 1 ต.ค. 2026: โหมดมือถือทั้งหมด OUT OF SCOPE — ออกแบบ/รับรองด้วย mouse+keyboard บน PC เท่านั้น]**
- **ใหม่:** จุดสถานะสดในแถบหัวและ HUD (Adapter Health, watchdog, จำนวน connection) — กดดูรายละเอียดได้ทันที

### 8.4 ⚙️ Developer Diagnostics — แผงลับที่เปิดจากแท็บ Setup (ตอบจุดรีวิว #12)

เปิดด้วยการแตะโลโก้ 5 ครั้ง (หรือคีย์ลัดที่ตั้งได้) แสดงสด ๆ:

| กลุ่ม | รายการ |
|---|---|
| เฟรม | FPS จริง, frame cost รวม, **ต้นทุนต่อโมดูล** (aim/esp/macro/ui แยกกัน, min/avg/max) |
| หน่วยความจำ | ใช้ปัจจุบัน + กราฟย้อนหลัง 15 นาที (ตรวจ monotonic growth ด้วยตาได้เลย) |
| Registry | จำนวน resource ทั้ง 4 ชนิด (Task / Connection / Render / Temp) ที่ลงทะเบียนอยู่สด ๆ (ควรกลับเป็น 0 หลังปิดโมดูล — เห็นด้วยตา) |
| Event Bus | event/sec + คิวค้าง |
| วัตถุ | ESP objects ที่กำลัง render |
| Macro | คิวขั้นตอน + สถานะเล่นซ้ำ |
| ระบบ | Capability Report (8 ตัว), Adapter Health (6 API), เวลา startup, เวลา config load, เวลา hot update ล่าสุด |
| เครื่องมือ | **Export Diagnostics** เป็นข้อความ → ส่งให้เราได้ทันทีเมื่อมีบั๊ก (มี stack trace + ตัวแปรสภาพแวดล้อม) |

แผงนี้คือเครื่องมือที่ทำให้ Performance Budget (§9) ไม่ใช่ตัวเลขบนกระดาษ — ทุก metric วัดได้จากในเกมจริงทุกวัน และเป็นส่วนหนึ่งของ workflow แก้บั๊ก: บั๊กทุกตัวที่คุณรายงานควรแนบ Export Diagnostics มาด้วยเสมอถ้าทำได้

---

## 9. Performance Budget (งบประมาณทรัพยากร)

### 9.1 L2 Performance Budget — มาตรฐานวิศวกรรม (ตอบจุดรีวิว #12 + hardening #5)

ค่าเป้าหมายอ้างอิงจาก **test environment ของเรา** (fengari + stub, สภาพควบคุมได้) — นี่คือ **engineering benchmark (L2)** ใช้ตัดสินเรื่องเดียวเท่านั้น: "โค้ดเราแพงขึ้นหรือถูกลง" **ห้ามนำตัวเลข L2 ไปอ้างว่าเป็น performance ของเครื่องผู้ใช้จริง** (fengari ไม่ใช่ runtime เดียวกับ executor ในเกมจริง) — ความจริงจากเครื่องผู้ใช้ดูแลแยกที่ §9.2:

| ตัวชี้วัด | เป้าหมาย (test env) | วิธีวัด | ระดับเตือน |
|---|---|---|---|
| Frame cost รวมของสคริปต์ | ≤ 2.0 ms/frame | Diagnostics per-frame timer | > 3.0 ms ติดต่อกัน 10 วิ |
| Aim update | ≤ 0.8 ms/frame | per-module timer | > 1.2 ms |
| ESP render (50 วัตถุ) | ≤ 0.5 ms/frame | per-module timer | > 0.8 ms |
| UI render | ≤ 0.5 ms/frame | per-module timer | > 0.8 ms |
| Memory | คงที่ (flat) ใน stress 2 ชม. | sampler ทุก 60 วิ + กราฟ Diagnostics | โต monotonic ต่อเนื่อง 15 นาที |
| Resource orphan หลัง Destroy (task+connection+render+temp) | **0 ทุกครั้ง** | Resource Registry assert (อัตโนมัติ) | > 0 = fail ทันที ไม่ใช่เตือน |
| Event/sec | บันทึกเป็น baseline + เฝ้า spike | bus counter | spike > 3× baseline |
| Startup time (โหลดถึง HUD ขึ้น) | ≤ 3 วิ | timer | > 5 วิ |
| Config load | ≤ 0.2 วิ | timer | > 0.5 วิ |
| Hot update รวม (12 ขั้น + rollback path ถ้าพัง) | ≤ 5 วิ + orphan 0 | protocol timer | > 8 วิ หรือ orphan > 0 |

### 9.2 L3 Performance Baseline — ความจริงจากเครื่องผู้ใช้ (hardening #5)

ตัวเลข L2 ข้างบนพิสูจน์แค่ "เราไม่ทำโค้ดแพงขึ้น" — ไม่ได้พิสูจน์ "เครื่องผู้ใช้ลื่น" ดังนั้นทุกเฟสที่มี L3 ต้องเก็บข้อมูลจริงผ่าน Developer Diagnostics (§8.4):

| ตัวชี้วัด L3 | วิธีเก็บ | ใช้ตัดสินอะไร |
|---|---|---|
| Frame cost (Aim/ESP/UI/รวม) | per-module timer บน executor จริง | เก็บ **median / p95 / max** ต่อรอบทดสอบ — ห้ามรายงานค่าเดียว |
| FPS ก่อนเปิด vs หลังเปิดฟีเจอร์ | จับ baseline 30 วิก่อนเปิด → เทียบ 30 วิหลังเปิด (เครื่องเดิม เซิร์ฟเวอร์เดียวกัน) | ฟีเจอร์ไหนทำ FPS ร่วงเกิน 10% = สัญญาณเตือน กลับไปดู L2 ของโมดูลนั้น |
| Memory ระยะยาว | long-run 8 ชม. (§6.2) | monotonic growth = บั๊ก (เกณฑ์เดียวกับ L2) |

**กติกาของ L3:** ไม่ใช่เกณฑ์ผ่านแบบ hard gate (เครื่องผู้ใช้ต่างกันเกินไปจะเทียบข้ามเครื่องไม่ได้) แต่เป็น **baseline เทียบตัวเอง** — ตัวเลขของเครื่องเดียวกันต้องไม่แย่ลงข้ามเฟสโดยไม่มีเหตุผล และทุกตัวเลขที่รายงานต้องระบุ "เครื่อง/เวอร์ชัน Volt/เซิร์ฟเวอร์/จำนวนรอบวัด" กำกับเสมอ (กฎ "ตัวเลขทุกตัวมีที่มา")

### 9.3 กติกางบประมาณ

1. **Performance Budget ห้ามแย่ลงโดยไม่มีเหตุผลที่บันทึกไว้** — ทุกรอบส่งมอบวัดและเทียบเฟสก่อนหน้า ถ้าตัวชี้วัด L2 ตัวไหนแย่ลงเกิน 10% = **ถือเป็นบั๊กประเภทหนึ่ง** มี BUG ID + ต้องแก้หรืออธิบายได้ว่าทำไม (เช่น ฟีเจอร์ใหม่ที่คาดไว้แล้วว่าจะเพิ่มต้นทุน) ก่อนส่งมอบ — ส่วน L3 ใช้กติกา baseline เทียบตัวเองตาม §9.2
2. ตัวชี้วัดใหม่เพิ่มได้เสมอเมื่อเฟสใหม่มีระบบใหม่ — แต่**ลดตัวชี้วัดออกไม่ได้**นอกจากมีเหตุผลที่คุณอนุมัติ
3. ปรัชญาตัวเลข: สคริปต์ PvP ที่ "ฟีเจอร์ครบแต่กินทรัพยากรจนเฟรมไหล" คือแพ้ในมือผู้ใช้ — budget นี้คือสิ่งที่ทำให้ "ครบ" กับ "ลื่น" อยู่ด้วยกันได้

---

## 10. ความเสี่ยงและแผนรับมือ v2 (Risk Register)

| # | ความเสี่ยง | โอกาส | ผลกระทบ | แผนรับมือ (v2.0) |
|---|---|---|---|---|
| 1 | **Blox Fruits อัปเดตใหญ่** เปลี่ยน remote/โครงสร้าง | สูง (อัปเดตถี่เป็นประจำ) | ฟีเจอร์บางส่วนใช้ไม่ได้ชั่วคราว | **Game Adapter จริงในโครงแล้ว (§3.3)**: แก้จุดเดียว + Adapter Self-Probe จับได้ทันทีว่าอะไรตาย + ฟีเจอร์ที่กระทบปิดตัวเองสวย ๆ + hot update จ่ายแพตช์ในวันเดียว |
| 2 | **Volt เปลี่ยน/ปิดตัว/ตรวจเข้ม** (executor เดียวที่รองรับ) | กลาง | โหลดไม่ได้ชั่วคราวทั้งโปรเจกต์ | **Capability Detection (§3.2)** + graceful degradation + ทดสอบ matrix บน Volt จริงทุก major release (§6.3) + loader 4-URL สำรองโดเมน + ถ้าต้องขยายไป executor อื่น = change request แยกตามขอบเขต freeze |
| 3 | **บั๊ก regression** หลังเพิ่มฟีเจอร์ | กลาง | ใช้งานสะดุด ความเชื่อมั่นลด | Regression suite รันทุกรอบ (§6.2) + ทุกบั๊ก = test case ถาวร + **No undocumented hotfix (§11)** |
| 4 | **Scope Creep** — ฟีเจอร์บานไปจน v1.0 ไม่เสร็จ | กลาง-สูง (เคยเป็นโรคของสคริปต์ PvP ทุกตัว) | เปิดตัวเลื่อน คุณภาพตก | **P0/P1/P2 (§4.2)**: v1.0 ผูกกับ P0 เท่านั้น + P1 เลื่อนได้เสมอโดยไม่ถือว่าล้มเหลว + P2 รอหลัง stable + เจ้าของโปรเจกต์อนุมัติการขยับระดับของฟีเจอร์เท่านั้น |
| 5 | **Config เสียหลังอัปเดตโครงสร้าง** | กลาง | ผู้ใช้เสียค่าที่ตั้งไว้ | **Schema + Migration (§3.7)**: ลูกโซ่ migration + unit test ทุกขั้น + fallback backup `.bak` + ห้ามทิ้ง config ผู้ใช้เด็ดขาด |
| 6 | **โค้ดใหญ่ขึ้นจนดูแลยาก** | กลาง | แก้ช้า บั๊กสะสม | Module isolation ครบ lifecycle + registry ทุกอย่าง + lint "แตะเกมผ่าน adapter เท่านั้น" + เอกสารทุกโมดูล |
| 7 | **CDN cache ค้าง** (จำได้ดีจาก v2.1 ใน jsdelivr) | ต่ำ (มี protocol) | ผู้ใช้ได้ไฟล์เก่า | Version Gate ปฏิเสธไฟล์เก่า + Purge Protocol ทุกครั้ง + rollback ผ่าน manifest (§7.4) |
| 8 | **ความเสี่ยงต่อบัญชีผู้เล่น** | มีเสมอ — ของจริงที่ต้องพูดตรง ๆ | โดนลงโทษในเกม | ตรงไปตรงมา: การใช้สคริปต์ใด ๆ มีความเสี่ยงเสมอ ผู้ใช้ต้องชั่งน้ำหนักเอง บทบาทของเราคือทำให้สคริปต์นิ่ง ไม่ error ไม่ทำอะไรแปลกปลอมเกินฟีเจอร์ PvP มาตรฐาน และไม่กระทบผู้เล่นอื่นเกินกรอบการแข่งขันปกติของเกม |

---

## 11. กฎเหล็กของโปรเจกต์ (Iron Rules)

### กฎ 1 — บั๊กทุกตัวกลายเป็น test case ถาวร *(เก็บจาก v1.0 ตามที่รีวิวยืนยัน)*

บั๊กที่เจอ (จากคุณ จาก test หรือจากผู้ใช้คนอื่นในอนาคต) ต้องมี regression test ถาวรใน suite **ก่อนถือว่า "แก้เสร็จ"** — บั๊กเดิมหวนกลับมาไม่ได้ตลอดอายุโปรเจกต์

### กฎ 2 — No Undocumented Hotfix *(ใหม่ตามรีวิว #14)*

ห้ามแก้บั๊กเฉพาะหน้าแล้วจบ — ทุก fix ต้องบันทึกครบหกช่องก่อนปิด:

```text
BUG-017 | Target switched twice after death (เป้าถูกสลับสองครั้งหลังตาย)
รากปัญหา      : stale target event — event เป้าเก่าค้างอยู่ในคิวตอนเป้าตาย
การแก้        : generation token + cleanup คิวตอนเป้าตาย
Regression    : qa/regression/BUG-017_target_switch_after_death.lua
โมดูลที่เกี่ยว  : VoidAim, TargetService
แก้ในเวอร์ชัน  : v0.4.2
สถานะ         : ✅ ปิดจ๊อบ (regression ผ่าน 20/20 รอบ)
```

### กฎ 3 — ทุก requirement ต้องมีวิธีวัดที่พิสูจน์ได้ *(หลักคิดกลางของ v2.0)*

ห้ามใช้คำว่า "แม่น 100%", "เร็วมาก", "เสถียร" โดยไม่ระบุวิธีวัด — ถ้าเขียน requirement ใหม่แล้วตอบไม่ได้ว่า "วัดที่ชั้นไหน ด้วยอะไร ผ่านที่เท่าไร" = requirement นั้นยังไม่เสร็จ

### กฎ 4 — No Silent Degradation

ทุกครั้งที่ระบบปิดฟีเจอร์เอง (capability หาย, adapter probe ตาย, watchdog ปิดโมดูล, config เสียแล้วใช้ default) ต้อง**แจ้งผู้ใช้เสมอ** พร้อมเหตุผลและทางแก้ — ระบบเงียบคือระบบที่ผู้ใช้เชื่อไม่ได้

### กฎ 5 — Performance Regression = บั๊ก

Performance Budget (L2 §9.1) ห้ามแย่ลงระหว่างเฟสโดยไม่มีเหตุผลที่บันทึกไว้และได้รับอนุมัติจากคุณ — มี BUG ID เหมือนบั๊กทุกประเภท ส่วน L3 baseline (§9.2) เทียบกับตัวเองข้ามเฟสบนเครื่องเดียวกัน

### กฎ 6 — กติกาการทำงานร่วมกัน (เดิม ยืนยันอีกครั้ง)

ห้ามทำงานเงียบ + Update Log ทุกการเปลี่ยนแปลง (อะไร/ทำไม/ผลกระทบ/วิธีทดสอบ/สถานะ) + ตรวจ URL จริงทุกครั้งที่ deploy + ไม่ส่งมอบของที่ทดสอบไม่ผ่าน

---

## 12. ขั้นตอนถัดไปและบันทึกการอนุมัติ (Next Steps)

แผน v2.1 นี้ตอบรีวิว 14 จุด (รอบแรก) + 7 จุด hardening (รอบสอง) + 4 จุดสุดท้ายและขอบเขต Volt-only (รอบสาม freeze) ครบถ้วน โดย**ไม่เพิ่มฟีเจอร์ใหม่แม้แต่รายการเดียว** — และได้รับการอนุมัติพร้อม freeze เรียบร้อยแล้ว (1 ตุลาคม 2026) บันทึกการตัดสินใจทั้งหมด:

### บันทึกการตัดสินใจ (หลัง freeze — ปิดรอบรับรองแล้ว)

| # | คำถาม | การตัดสิน (หลัง freeze) |
|---|---|---|
| 1 | **อนุมัติแผน v2.1 (freeze)?** (รวมสถาปัตยกรรมใหม่ + P0/P1/P2 + rollback/replay/dependency graph + กฎเหล็ก) | ✅ **อนุมัติ + FROZEN** — รีวิวรอบสาม: "แกนสถาปัตยกรรมผ่าน" แก้ 4 จุดสุดท้ายครบแล้วจึง freeze |
| 2 | **การจัดระดับ P0/P1/P2** โดยเฉพาะ 4 ตัวที่ย้ายไป P2 (Combo Simulator, Auto Retaliate, Prediction Learning, Race Timing Profiles)? | ✅ ตามนี้ (อนุมัติทั้งแผนโดยรวม) |
| 3 | **ตั้งชื่อ repo ใหม่?** | ⏳ ค้างตัดสินตอนสร้าง repo จริง — ค่าเริ่มต้น `thevoider/loader` (**ไม่บล็อกเฟส 0**: พัฒนาในเครื่องได้เลย) |
| 4 | **VoidAim 3 โหมด (EZ/Pro/Legend)** ตามที่ออกแบบ? | ✅ ตามนี้ |
| 5 | **ภาษาไทย + อังกฤษ** ใน v1.0? | ✅ 2 ภาษา |
| 6 | **แนวทาง SHA-256** (crypto ถ้ามี / pure-Lua ถ้า benchmark ผ่าน / fallback ตรวจระดับ 2 พร้อมบอกผู้ใช้ตามจริง)? | ✅ ตามแนวทางนี้ |
| 7 | **เริ่มเฟส 0 ทันทีหลังอนุมัติ?** | ✅ เริ่มเลยหลัง freeze (งานแรก: Runtime Layer + Matrix ทั้ง 8 โมดูลให้คุณรีวิว) |
| 8 | **executor เป้าหมาย?** *(เพิ่มรอบ freeze)* | **Volt เท่านั้น** — executors อื่นไม่รองรับ ไม่ทดสอบ ไม่รับประกัน (§6.3) |

### ลำดับถัดไป (หลัง freeze — เฟส 0 เริ่มแล้ว)

1. **เฟส 0 รอบแรก** — ผมสร้าง Runtime Layer ครบ 5 องค์ประกอบ + 1 Bootstrap Preflight (Resource Registry 4 ชนิด) + Dependency Graph + Foundation + Adapter โครงแรก + Loader v2 + **Behavioral Matrix ทั้ง 8 โมดูล** ให้คุณรีวิวก่อนเขียนโค้ดโมดูลจริง (ตามกติกา §4.5)
2. **คุณสร้าง repo** `thevoider/loader` (2 นาที — ผมแนบขั้นตอนทีละคลิก) หรือบอกใช้ repo เดิม
3. **รับไฟล์เฟส 0 → ทดสอบในเกมจริง** กับ Volt รวมถึง hot update จำลอง v0.1→v0.2 ที่เห็น protocol ทำงานครบ 12 ขั้น → แจ้งผล → ไต่เฟส 1 ต่อทันที
4. ทุกเฟสจบ = ของจริงใช้ได้จริง ตัวเลขทุกตัวมีที่มา และทุกบั๊กมีเจ้าของ

### คำมั่นสัญญาของผม (เหมือนเดิมทุกประการ + เพิ่มจาก v2.0)

- **ห้ามทำงานเงียบ** — รายงานทุกขั้นตอนสำคัญเป็นภาษาไทย
- **Update Log ทุกการเปลี่ยนแปลง** — อะไร/ทำไม/ผลกระทบ/วิธีทดสอบ/สถานะ
- **ตรวจ URL จริงทุกครั้งที่ deploy** — ยืนยันว่าโลกภายนอกเห็นไฟล์ใหม่จริงก่อนรายงานเสร็จ
- **ไม่ส่งมอบของที่ทดสอบไม่ผ่าน** — ผล L1/L2 แนบทุกรอบ
- *(ใหม่)* **ตัวเลขทุกตัวมีที่มา + บั๊กทุกตัวมีเจ้าของ** — ไม่มี metric ลอย ๆ และไม่มี hotfix ไร้บันทึก



