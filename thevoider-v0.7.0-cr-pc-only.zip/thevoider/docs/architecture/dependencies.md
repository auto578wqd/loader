# Dependency Graph — The Voider

> **สถานะ:** v1.6 (CR-PC-ONLY — ตัด MobileLayout ออกจาก graph — 1 ตุลาคม 2026) | **อ้างอิงแผน:** §3.10 (hardening #7) — แผน v2.1 🟢 APPROVED / FROZEN + CR-PC-ONLY
>
> ไฟล์นี้คือ **source of truth เดียว** ของลำดับ `Init()` และ `Shutdown/TEARDOWN` ทั้งโปรเจกต์ — แก้ที่ไฟล์นี้ที่เดียว ทั้งสองฝั่งเปลี่ยนตามอัตโนมัติ ห้ามเขียนลำดับ hard-code ในโค้ดโดยไม่ผ่านไฟล์นี้
>
> **กฎการแก้ไฟล์นี้:** ทุกการเพิ่ม/แก้ dependency ต้อง (1) ผ่าน build validation 3 ชั้น (ด้านล่าง) (2) ระบุเหตุผลในบรรทัด changelog ท้ายไฟล์ (3) ไม่ขัดกับแผน freeze v2.1 — ถ้าขัด = change request ต่อเจ้าของโปรเจกต์ก่อน

## 1. หลักการ

- **Init()** เรียง **ตามลำดับ dependency** — ผู้ให้บริการ (provider) มาก่อนผู้ใช้บริการ (consumer) เสมอ
- **Shutdown Manager / TEARDOWN (hot update §3.6 ขั้น 7)** เรียง **ย้อนกลับเป๊ะ ๆ จาก graph เดียวกัน** — ได้มาจากการกลับลำดับของ Init ไม่ใช่ logic แยกอีกชุด
- **สายตาย (dead API)**: Adapter Self-Probe ใช้ข้อมูลจากไฟล์นี้รู้ทันทีว่า API ตัวไหนตายแล้วจะกระทบโมดูลไหนบ้าง (§3.3)

## 2. แผนภาพรวมระดับชั้น (Layer)

```text
L0  Loader              Bootstrap Preflight (รันก่อนโหลด core — §3.2 ข้อ 0)
                        + UpdateCoordinator (Hot Update §3.6 — อยู่นอกระบบที่ถูกสลับ
                        จึงรอดจาก TEARDOWN และเป็นผู้เดียวที่สลับรุ่นได้)
L1  Runtime             CapabilityDetection, ResourceRegistry, ErrorBoundary, Watchdog, ShutdownManager
L2  Foundation          EventBus, ConfigService(+Migration), PresetService, FFlagService,
                        I18nService, KeybindService, DiagnosticsService
L3  Game Adapter        PlayerAdapter, CharacterAdapter, CombatAdapter, CameraAdapter,
                        InputAdapter, WorldAdapter (+ AdapterSelfProbe)
L4  Shared Services     TargetService, PredictionService, CameraService, CombatStateService (hot path §3.5)
L5  Feature Modules     VoidAim, VoidESP, VoidMacro, CombatCore, Race, Fruit, Movement, ServerHop
L6  UI                  ThemeEngine, Hub, HUD, Notification (MobileLayout ตัดออกตาม CR-PC-ONLY)
```

**ลำดับ Init = L0 → L1 → L2 → L3 → L4 → L5 → L6** (ภายในชั้นเดียวกันใช้ลำดับในตาราง §3) | **Shutdown/TEARDOWN = กลับด้านเป๊ะ ๆ: L6 → L0**

## 3. ตาราง Dependency ฉบับเต็ม (v1)

**Ambient deps (ทุกโมดูลใน L2–L6 ขึ้นกับสองตัวนี้โดยปริยาย ไม่ต้องประกาศซ้ำ):** `ResourceRegistry` (จอง/คืนทรัพยากร 4 ชนิด) + `ErrorBoundary` (entry point ทุกตัวรันใต้ boundary) — ตามแผน §3.2

| ชั้น | Node | Provides | Depends on |
|---|---|---|---|
| L0 | BootstrapPreflight | ตรวจ HTTP + CDN ก่อนโหลด core (plain text fail §3.2 ข้อ 0) | *(ภายนอก: HTTP function ของ Volt)* |
| L0 | UpdateCoordinator | Hot Update Protocol 12 ขั้น + Rollback F0–F4 + ATOMIC UPDATE RULE + Rollback Snapshot 7 ช่อง (§3.6) — สร้างโดย loader อยู่นอกระบบที่ถูกสลับ (รอดจาก TEARDOWN โดยออกแบบ) ไม่มี hook ปิดของตัวเอง | *(ภายนอก: loadFn + system handle ของ bundle)* |
| L1 | CapabilityDetection | Capability Report 8 ตัว (DRAWING/HOOK/HTTP/FILEIO/INPUT/CLIPBOARD/TASK/CRYPTO) | — |
| L1 | ResourceRegistry | `Runtime.Spawn` / `Runtime.Connect` / `Runtime.NewRender` / `Runtime.Temp` + orphan assert | — |
| L1 | ErrorBoundary | จับ error รายโมดูล + ตัวนับ error ให้ watchdog | — |
| L1 | Watchdog | heartbeat ตรวจโมดูลตาย/ค้าง + restart 1 ครั้ง + backoff | ErrorBoundary |
| L1 | ShutdownManager | ลำดับปิดจากไฟล์นี้ (Init กลับด้าน) | *(อ่าน graph ทั้งหมด)* |
| L2 | EventBus | publish/subscribe + คิว freeze + replay policy (§3.6) | — |
| L2 | ConfigService | โหลด/บันทึก config + schemaVersion + fallback `.bak` | — |
| L2 | MigrationService | ลูกโซ่ migration ทีละเวอร์ชัน (§3.7) | ConfigService |
| L2 | PresetService | สลับชุดค่า preset | ConfigService |
| L2 | FFlagService | FastFlags | ConfigService |
| L2 | I18nService | ไทย/อังกฤษ + key coverage 100% | ConfigService |
| L2 | KeybindService | คีย์ลัด + `Trigger` path เดียวกับคีย์จริง *(เดิม: "ปุ่มลัดมือถือ" — ถูกตัดตาม CR-PC-ONLY)* | EventBus, I18nService |
| L2 | DiagnosticsService | per-module timer, กราฟ memory, Export Diagnostics (§8.4) | EventBus |
| L3 | PlayerAdapter | local player, สถิติ, team, bounty, crew | *(เกม — ประตูเดียว §3.3)* |
| L3 | CharacterAdapter | humanoid, อวัยวะ, state, VFX | — |
| L3 | CombatAdapter | อาวุธ, สกิล, cooldown, remote, M1 | — |
| L3 | CameraAdapter | กล้อง | — |
| L3 | InputAdapter | คีย์บอร์ด/เมาส์/ทัช | — |
| L3 | WorldAdapter | entities, ระยะ, raycast, server info | — |
| L3 | AdapterSelfProbe | Adapter Health report (ครบ/เสื่อมบางส่วน) | *(อ่าน graph ทั้งหมด)* |
| L4 | TargetService | เป้าปัจจุบัน/รายการเป้า + generation token (กัน duplicate lock) | PlayerAdapter, WorldAdapter |
| L4 | PredictionService | ทำนายตำแหน่ง (ping-based v1 / +velocity v2) | TargetService, WorldAdapter |
| L4 | CameraService | ตำแหน่ง/ทิศ/FOV + ล็อกกล้อง | CameraAdapter |
| L4 | CombatStateService | สตัน/ragdoll/คูลดาวน์ รายผู้เล่น | CharacterAdapter, CombatAdapter |
| L5 | **VoidAim** ⭐ | 3 โหมด EZ/Pro/Legend + Skill/Soru Aimbot | TargetService, PredictionService, CameraService, CombatStateService, KeybindService, InputAdapter |
| L5 | **VoidESP** | ESP 9 ชนิด + Chams(P1) | TargetService, WorldAdapter, CameraAdapter + *(ภายใน: EspRenderer, ObjectPool, EspFilter)* |
| L5 | **VoidMacro** | บันทึก/เล่นซ้ำ + slots + timing tuner | InputAdapter, ConfigService, CombatAdapter, KeybindService + *(ภายใน: MacroRecorder, MacroPlayer, EditorModel, MacroSerializer)* |
| L5 | **CombatCore** | Anti Combo/Stun, Ability Trigger, Block Editor, Combo | CombatStateService, CombatAdapter + *(ภายใน: BountyTracker, AbilitySequencer, BlockEditor)* |
| L5 | **Race** | Auto/Smart V3-V4 + HideEffects | PlayerAdapter, CharacterAdapter, KeybindService + *(ภายใน: RaceDetector, V4Sequencer)* |
| L5 | **Fruit** | Auto Roll/Store, Transform, Stock, Gacha, Awakening | WorldAdapter, PlayerAdapter, CombatAdapter + *(ภายใน: FruitDB, StockWatcher, RollController)* |
| L5 | **Movement** | Air Jump, Super Jump, momentum ทุกชนิด | CharacterAdapter, InputAdapter + *(ภายใน: MovementProfiler, BoostApplier)* |
| L5 | **ServerHop** | Server Hop + Teleport ครบ | WorldAdapter + capability `HTTP` + *(ภายใน: ServerHop, TeleportService)* |
| L6 | ThemeEngine | palette Void Neon (§8.1) | — |
| L6 | Hub | แท็บ 8 โมดูล + ค้นหา(P1) | ConfigService, I18nService, **ทุก Feature Module (L5)** |
| L6 | HUD | FPS/uptime/สถานะ + Diagnostics ย่อ | DiagnosticsService, EventBus |
| L6 | Notification | แจ้งเตือนภาษาไทย (No Silent Degradation) | EventBus, I18nService |

> **[CR-PC-ONLY 1 ต.ค. 2026]** แถว `L6 | MobileLayout` (ปุ่ม ≥ 44px + ปุ่มลัดลอย | deps: KeybindService, Hub) **ถูกตัดออกจาก graph** — เก็บบันทึกไว้ที่นี่เพื่อ traceability เท่านั้น — ผลกระทบ: node 39→38 / edge 55→53 (ตัด MobileLayout→KeybindService + MobileLayout→Hub) — PC/Desktop only บน Volt

**หมายเหตุ:** *(ภายใน: ...)* = internal services ของโมดูลนั้น ไม่ขึ้นทะเบียนใน graph ระดับโปรเจกต์ (ซ่อนอยู่ในไฟล์โมดูล) — ขึ้นทะเบียนเฉพาะเมื่อมีโมดูลอื่นเรียกใช้ข้ามโมดูล จึงเลื่อนขั้นเป็น L4 (Shared Services) ในไฟล์นี้

### 3.1 สถานะการสร้างของ node (อัปเดตรอบ Foundation + Game Adapter)

ตาราง §3 คือ "แผนที่เต็ม" ของระบบ ส่วนโค้ดสร้างทีละส่วนตามเฟส — Shutdown Manager ข้าม node ที่ยังไม่ลงทะเบียน hook อัตโนมัติ ดังนั้น node ที่ยังไม่มีโค้ดไม่ทำให้ระบบพัง:

| Node | สถานะ | ไฟล์จริง |
|---|---|---|
| EventBus | ✅ สร้างแล้ว + L1 | core/foundation/eventbus.lua |
| ConfigService | ✅ สร้างแล้ว + L1 | core/foundation/config.lua |
| MigrationService | ✅ สร้างแล้ว + L1 (ทดสอบลูกโซ่/ย้อนกลับ/round-trip) | core/foundation/migration.lua |
| I18nService | ✅ สร้างแล้ว + L1 (ไทย/อังกฤษ + coverage) | core/foundation/i18n.lua |
| KeybindService | ✅ สร้างแล้ว + L1 (เรียกผ่าน InputAdapter เท่านั้น) | core/foundation/keybind.lua |
| DiagnosticsService | ✅ สร้างแล้ว + L1/L2 (Snapshot + Export ใช้งานได้ §8.4) | core/foundation/diagnostics.lua |
| PlayerAdapter ถึง WorldAdapter | ✅ สร้างครบ 6 node + L1 (self-probe + graceful) | core/adapter/{player,character,combat,camera,input,world}.lua |
| AdapterSelfProbe | ✅ สร้างแล้ว + L1/L2 (health + สายตายผูก graph) | core/adapter/probe.lua |
| UpdateCoordinator | ✅ สร้างแล้ว + L1/L2 (protocol ทุก path + failure injection F0–F4 + snapshot validation + atomic) | core/runtime/update.lua (รวม version/sha256/manifest/bundle/loader_main เป็น loader-domain ใน core/runtime/ ตามแบบ preflight.lua) |
| PresetService | ⏸ เลื่อน — สร้างเมื่อมีผู้ใช้จริง ไม่สร้างล่วงหน้า (เฟส 1 จบโดยไม่ต้องใช้ preset — ผู้ใช้ยังไม่มีโมดูล) | *(ยังไม่มี)* |
| FFlagService | ⏸ เลื่อน — สร้างเมื่อมีโมดูลใช้ flag จริง | *(ยังไม่มี)* |
| L6: ThemeEngine, Hub, HUD, Notification | ✅ สร้างครบ 4 node + L1/L2 (เฟส 1 UI Framework รอบ 7 + CR-PC-ONLY รอบ 8 — DoD §5.4 ฉบับ PC-only ผ่าน: render ≤ 0.5 ms / 20 รอบ orphan 0 / i18n coverage 100% / ปุ่มมาตรฐาน 44px / PC-only guard) — MobileLayout ตัดออกตาม CR-PC-ONLY | core/ui/{_backend,theme,hub,hud,notify,init}.lua (util ภายในชั้น: _backend ตามกฎข้อ 2) |
| L4–L5 ทั้งหมด (Shared Services + 8 โมดูล) | 📋 Behavioral Matrix = **APPROVED BASELINE v1.0** (150 แถว sign-off รอบ 6) — เขียนโค้ดได้เมื่อถึงเฟสของตัวเองตาม roadmap §5.3–5.7 เท่านั้น (ห้ามข้ามเฟส) | *(ยังไม่มี — PENDING contracts คือ implementation prerequisites รวมอยู่ใน matrix)* |

หมายเหตุการออกแบบที่บังคับใช้ตั้งแต่รอบนี้: (1) **ชื่อ owner ใน Resource Registry = ชื่อ node ใน graph พอดี** เพื่อให้ Shutdown ตรวจ orphan ราย node ได้ตรงตัว (2) **util ภายในไม่แยก node** — Service Registry (core/foundation/services.lua), JSON codec (core/foundation/json.lua — ใช้โดย ConfigService เท่านั้น), adapter helper (core/adapter/_common.lua) (3) **KeybindService ต่อ InputAdapter แบบ runtime attachment** (AttachInput หลัง L3 พร้อม) ไม่ใช่ init dependency — จึงไม่ต้องแก้ลำดับชั้น graph (4) **lint "ห้ามแตะเกมนอก adapter"** ติดตั้งแล้วที่ build/tools/lint_adapter.py — มี allowlist ระดับบรรทัดเฉพาะ core/runtime/capability.lua สำหรับ Input capability probe (read-only, จำเป็นก่อน adapter ถูกสร้าง)

## 4. Build Validation 3 ชั้น (รันทุก build — ไม่ผ่าน = ไม่ได้ build)

1. **Missing dependency** — โมดูลประกาศ dependency ที่ไม่มีอยู่จริงในตาราง §3 = บล็อก build ทันที
2. **Circular dependency** — A→B→A (ตรวจทุก path ด้วย topological sort ไม่ผ่าน = วน) = บล็อก build ทันที
3. **Invalid dependency** — ชื่อ service/โมดูลสะกดผิด หรือไม่ได้ขึ้นทะเบียน = บล็อก build ทันที

## 5. กฎสำหรับรอบถัดไป

- Behavioral Matrix = **APPROVED BASELINE v1.0** (sign-off เจ้าของโปรเจกต์รอบ 6 + คำตัดสิน Q1=(ข) Ken เฉพาะ ESP / Q2=(ก) Fruit→CombatAdapter / Q3=(ข) Replay Policy §3.6) — เป็น acceptance source of truth เพียงแหล่งเดียวของ implementation ทุกเฟส แก้ไขหลังจากนี้ผ่าน CR เท่านั้น (§4.5) + PENDING contracts (SetLock/WorldToScreen/GetSkillCooldown/DispatchKey/VFX/write-side/stock/teleport) ปิดด้วย survey จริงต้นเฟสของโมดูลตัวเอง แล้ว freeze เป็น contract note
- L5 code เขียนได้เมื่อถึงเฟสของตัวเองตาม roadmap (เฟส 2 = VoidAim + ESP เปิดได้หลังเฟส 1 ผ่าน P0 DoD) — ห้ามเพิ่ม behavior นอก matrix เงียบ ๆ ห้ามขยับ P1/P2 เป็น P0
- Lint rule "ห้ามแตะเกมนอก adapter" ติดตั้งใน build script ตั้งแต่ build แรก
- **[CR-PC-ONLY 1 ต.ค. 2026]** แพลตฟอร์มรับรอง = **PC/Desktop only บน Volt** — ห้ามเพิ่ม node/edge/พฤติกรรมเฉพาะมือถือกลับเข้ามา (เช่น MobileLayout/ปุ่มลัดมือถือ) โดยไม่เปิด CR ใหม่ — `InputAdapter` (TouchEnabled/OnInput) และ `KeybindService:Trigger/InputInfo` คง API ไว้ (Foundation ผ่าน gate — PC จอสัมผัสใช้ได้) แต่ไม่มีผู้เรียกใน production หลังตัด MobileLayout นอกจากเทส PC-only guard

## 6. Changelog ของไฟล์นี้

| เวอร์ชัน | วันที่ | เหตุผล |
|---|---|---|
| v1 | 1 ตุลาคม 2026 | สร้างครั้งแรกพร้อมเปิดเฟส 0 — โครงตามแผน freeze v2.1 (§3.10, §4.1) |
| v1.1 | 1 ตุลาคม 2026 | แก้ความขัดแย้งลำดับชั้น: เดิม Shared Services(L3) ขึ้นกับ Game Adapter(L4) ซึ่งขัดหลัก "provider มาก่อน consumer" — สลับเป็น L3=Game Adapter, L4=Shared Services (ตรงโครงไม้ §3.1 ของแผน freeze) + เพิ่ม core/runtime/graph.lua (generated โดย build/tools/gen_graph.py, ผ่าน validation 3 ชั้น 38 node / 48 edge) |
| v1.2 | 1 ตุลาคม 2026 | รอบ Foundation + Game Adapter: เพิ่ม §3.1 สถานะการสร้างของ node (สร้างจริง 13 node: Foundation 6 + Adapter 6 + SelfProbe 1 + util ภายใน 3 ไฟล์: services/json/_common) + บันทึกว่า PresetService/FFlagService เลื่อนออกไปจนมีผู้ใช้จริง (ตามคำสั่งเจ้าของโปรเจกต์รอบ Foundation — สร้างเท่าที่ลิสต์ระบุ) + กฎ 4 ข้อ: owner=ชื่อ node, util ไม่แยก node, Keybind→Input เป็น runtime attachment, lint ห้ามแตะเกมนอก adapter |
| v1.3 | 1 ตุลาคม 2026 | รอบ Loader v2 + Update/Rollback: เพิ่ม node UpdateCoordinator (L0) ตามแผน §3.6 — เป็น loader-domain อยู่นอกระบบที่ถูกสลับ จึงไม่มี hook ปิดของตัวเอง (Shutdown ข้ามให้อัตโนมัติ) — โค้ดอยู่ที่ core/runtime/ ร่วมกับ preflight.lua ที่เป็น loader-domain เช่นกัน (ไม่เพิ่มโฟลเดอร์นอกโครง §3.8) + ไฟล์ loader-domain ชุดเดียวกัน: version/sha256/manifest/bundle/loader_main |
| v1.4 | 1 ตุลาคม 2026 | รอบ Behavioral Matrix (รอบ 5): เพิ่ม 7 edge ที่ **ฟีเจอร์ P0 ของ §4.3 บังคับ** พร้อมชุด matrix (`qa/matrices/`) — (1) VoidAim→KeybindService [Aim Key/Mode P0, VA-007] (2) VoidAim→InputAdapter [โหมด hold ตรวจ IsKeyDown ตามแบบ Keybind] (3) VoidESP→CameraAdapter [WorldToScreen — camera.lua ระบุ "ใช้โดย ESP เฟส 2", ES-009] (4) VoidMacro→CombatAdapter [Soru Skill Macro P0 ยิงผ่าน FireSkill, MC-011] (5) VoidMacro→KeybindService [ปุ่มอัด/เล่นซ้ำ P0, MC-001] (6) Race→KeybindService [ActivateRaceV4 P0, RA-007] (7) Fruit→CombatAdapter [remote gate เจ้าของเดียวของระบบ GetRemotes/FireSkill, FR-010 — ทางเลือกแยก RemoteAdapter = ต้องเป็น CR แยก] — ทุก edge เป็นการ**เติมให้ครบตาม scope P0 ที่ freeze ไว้** ไม่ใช่การเพิ่ม requirement ใหม่ (edge เดิมของ L5 ใส่ไว้ตอนสร้างไฟล์ก่อนรู้รายละเอียด matrix) + อัปเดตสถานะ L4–L6 เป็น "matrix ส่งรีวิวแล้ว" |
| v1.5 | 1 ตุลาคม 2026 | เฟส 1 UI Framework รอบ 7: L6 สร้างครบ 5 node (ThemeEngine/Hub/HUD/Notification/MobileLayout) + ผ่าน L1 217/217 + L2 26/26 รวมฉาก `scenario_ui` ใหม่ — **ไม่มี node/edge ใหม่** (5 node นี้ประกาศไว้ใน graph ตั้งแต่ v1 แล้ว จำนวนคงเดิม 39/55) — อัปเดต §3.1 แยกสถานะ L6 (สร้างแล้ว) ออกจาก L4–L5 (รอเฟสของตนตาม roadmap) + §5 ปรับเป็นกฎยุค post-approval (matrix = APPROVED BASELINE v1.0 แก้ผ่าน CR เท่านั้น) |
| v1.6 | 1 ตุลาคม 2026 | **CR-PC-ONLY (เจ้าของอนุมัติ):** ตัด node MobileLayout (L6) + edge 2 เส้น (→KeybindService, →Hub) ออกจาก graph — **39→38 node / 55→53 edge** — แพลตฟอร์มรับรอง = PC/Desktop only บน Volt (Mobile = ไม่รองรับ/ไม่ทดสอบ/ไม่รับประกัน) + แก้คำอธิบาย KeybindService ถอด "ปุ่มลัดมือถือ" + §5 เพิ่มกฎห้ามคืนพฤติกรรมมือถือโดยไม่เปิด CR — สอดคล้อง matrix (MC-012/VA-033 OUT OF SCOPE) + Plan §5.4 DoD ฉบับ PC-only |
