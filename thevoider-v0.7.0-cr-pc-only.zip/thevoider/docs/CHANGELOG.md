# CHANGELOG — The Voider

รูปแบบทุกรายการ (กฎเหล็ก §11 + §5.8): **อะไร / ทำไม / ผลกระทบ / วิธีทดสอบ / สถานะ**

---

## v0.7.0 — CR-PC-ONLY: เปลี่ยน scope เป็น PC/Desktop-only + ตัด Mobile ออกจาก product (1 ตุลาคม 2026)

### อะไร (Change Request CR-PC-ONLY — Owner Decision 1 ต.ค. 2026)
- **คำตัดสินเจ้าของโปรเจกต์:** The Voider รองรับ**เฉพาะ PC/Desktop บน Volt เท่านั้น** — Mobile = **ไม่รองรับ / ไม่ทดสอบ / ไม่รับประกัน** — เป็นการเปลี่ยน requirement หลัง v2.1 freeze จึงต้องเปิด CR ก่อนแก้เอกสาร/โค้ด (ห้ามแก้เงียบ §2.5) — CR นี้ปรับ **platform scope เท่านั้น** ไม่แตะ gameplay implementation ของ VoidAim/ESP/Macro และไม่ redesign Runtime/Foundation ที่ผ่าน gate แล้ว
- **ขอบเขตที่อนุมัติ (6 ข้อ):** (1) Phase 1 UI ตัด Mobile Layout/Mobile Layer ออกจาก product scope — ไม่มี L3 mobile checklist / ไม่ทดสอบ touch ≥44px / UI ออกแบบและรับรองด้วย mouse+keyboard บน PC — Developer Diagnostics / HUD / Hub / Notification คงเดิม (2) **MC-012 Mobile Macro Slots = REMOVE FROM v1.0 SCOPE** (ไม่ย้ายเป็น P1/P2 — keybind/keyboard path บน PC ยัง P0 ตามเดิม) (3) Common Gates ที่พูดถึง mobile/input: keyboard/desktop path = ยังบังคับผ่าน / mobile path = `OUT OF SCOPE — PC ONLY` — **ห้ามนับ N/A เป็น "ผ่าน"** (4) อัปเดต references เรื่อง Mobile/Mobile Layer/Mobile Macro Slots/Mobile Aim Button/touch controls/touch ≥44px/mobile checklist ทั้ง README/Matrix/Plan/SSOT โดยไม่แตะฟีเจอร์อื่น (5) **VA-033 Mobile Aim Button (P1) = out of scope** สำหรับ PC-only (ไม่ implement ไม่ย้าย P2) (6) Phase 1 DoD ใหม่แทน mobile gate ด้วย PC/Desktop acceptance ที่วัดได้จริง
- **Impact inventory (สำรวจก่อนแก้ — 196 จุด reference ภาษาอังกฤษ + 48 จุดคำว่า "มือถือ" รวม 23 ไฟล์):**
  - **โค้ด out-of-scope ที่ตัด:** `core/ui/mobile.lua` (MobileLayout node — ไม่มี i18n key ไม่ persist config ตัดได้สะอาด) + `Hub:SetLayoutMode/LayoutMode` + mobile layout branch (แท็บไอคอนแถบล่าง) + `ThemeEngine` `ICON_TAB`/`TouchSize()` (touch-gate เฟส 1 — DoD §5.4 ฉบับเดิม) + pill visibility ไม่ต้องเช็คโหมดมือถืออีก
  - **graph/SSOT:** `dependencies.md` ตัด node MobileLayout (L6) + 2 edge (→KeybindService, →Hub) = **39→38 node / 55→53 edge** + แก้คำอธิบาย KeybindService ("ปุ่มลัดมือถือ" → Trigger path เดียวกับคีย์จริง) → regen `graph.lua`
  - **เทสที่ถอด/แก้:** L1 `test_ui.lua` (2 เคส mobile layout + touch-gate assertions ใน theme เคส) + L2 `scenario_ui.lua` (ฉาก "ทัชอย่างเดียว → MobileLayout" ทั้งฉาก) + `test_graph.lua` (initOrder จบที่ Notification) + harness `run_l1.js`/`run_l2.js`/`build_dist.py` ถอด ui_mobile
  - **เทสใหม่กันถอยหลัง (ตามแบบ CR-REPLAY-001):** L1 "PC-only guard" — อุปกรณ์ทัชอย่างเดียว (stub) ก็ยังต้องได้เลย์เอาต์ desktop เดิม + ไม่มี layer TVMobile + graph ไม่มี MobileLayout — พิสูจน์ว่า PC-only ไม่ใช่แค่ "ไม่ทดสอบมือถือ" แต่ "ไม่มีพฤติกรรมมือถือ" จริง
  - **ไม่แตะ (ตามขอบเขต CR):** `InputAdapter` (TouchEnabled/OnInput เป็น API ที่ผ่าน gate — PC จอสัมผัสก็ใช้ได้) + `KeybindService:Trigger/InputInfo` (Foundation API — behavior ไม่ถูกแตะ ผู้ใช้ API ตอนนี้คือปุ่ม UI และเทส) + `_backend.lua` MakeDraggable รับ Touch (generic สำหรับ PC จอสัมผัส) + `eventbus.lua`/Runtime ทั้งหมด (frozen) + matrix ของ 8 โมดูลอื่นที่ไม่เกี่ยว mobile
  - **[เปิดเผยระหว่าง implement — comment-only ไม่แตะ behavior]** `keybind.lua` ปรับคำอธิบาย 4 จุด (หัวไฟล์ + Trigger ×2 + InputInfo — เดิมเรียก "ปุ่มลัดมือถือ" ปรับตาม dependencies.md v1.6) · `notify.lua` ปรับ comment 2 จุด (เดิมอ้าง "ปุ่มทัช DoD §5.4" → ปุ่มมาตรฐาน) · `scenario_adapter_dead.lua` เปลี่ยนคำ "path มือถือ" → "path UI" 2 จุด (comment + ข้อความ assert — พฤติกรรมเทสเดิม) · `test_runtime_init.lua` แก้เลข 39→38 ตาม graph
  - **Matrix:** `macro.md` MC-012 → OUT OF SCOPE — PC ONLY (เก็บ ID ไว้เพื่อ traceability ไม่นับเป็นแถว P0) · `voidaim.md` VA-033 → OUT OF SCOPE — PC ONLY · แถวรวมเปลี่ยน 150→148 แถว active (117 P0 + 16 P1 + 15 CG) · `_common-gates.md` เพิ่มกฎ "OUT OF SCOPE — PC ONLY ห้ามนับเป็นผ่าน"
  - **Plan freeze v2.1:** แก้ references ตำแหน่งที่เกี่ยว mobile ทั้งหมดพร้อม annotation `CR-PC-ONLY` (ไม่ rewrite เงียบ — ทุกจุดมีร่องรอยอ้างอิง CR) รวม §5.4 DoD เฟส 1 ฉบับใหม่

### ทำไม
- Phase 1 DoD §5.4 ข้อ 5 (L3 checklist มือถือแตะถูกทุกปุ่ม 20 รายการบน Volt จริง) ค้างอยู่จริงเพราะไม่มีช่องทางทดสอบมือถือ — เจ้าของตัดสินใจเปลี่ยน scope เป็น PC-only อย่างเป็นทางการแทนการปล่อยให้ Phase 1 ค้าง และย้ำว่าต้องแก้ scope/Matrix/DoD/regression ให้สอดคล้องกันก่อน แล้วรัน verify อีกรอบ — **ไม่ประกาศ Phase 1 เสร็จทันทีที่ตัด mobile**

### ผลกระทบ
- **runtime ผู้ใช้จริง (PC):** ไม่มีพฤติกรรมเปลี่ยนแปลงใด ๆ บน PC — เลย์เอาต์ desktop คงเดิมทุกค่า (HUB_W/HUB_H/ปุ่ม 44px คงเดิม) การตัดจริง ๆ คือ "บนอุปกรณ์ทัชอย่างเดียวจะได้เลย์เอาต์ desktop เหมือนกัน" (ไม่มี mobile adaptation อีกต่อไป) + bundle เล็กลง (ตัด mobile.lua + UI โค้ดที่เกี่ยว)
- **interface:** ลบ `Hub:SetLayoutMode`/`Hub:LayoutMode` + `ThemeEngine:TouchSize` + constant `ICON_TAB` (ไม่มีผู้เรียกเหลืออยู่นอก UI) — `TOUCH_MIN` คงชื่อและค่า 44px (ใช้เป็นความสูงปุ่มมาตรฐานทั้ง UI มาก่อน ไม่ใช่ของมือถืออย่างเดียว — เปลี่ยนเฉพาะความหมายใน comment) — Foundation/Adapter API ทั้งหมดไม่ถูกแตะ
- **SSOT graph:** 38 node / 53 edge (จาก 39/55) — ไม่มี edge อื่นกระทบ
- **โอกาสถอยหลัง:** เทส PC-only guard กันกลับมาของพฤติกรรมมือถือ + ทุกการเปลี่ยนแปลงมี CR กำกับ

### วิธีทดสอบ (ผลจริงรอบ implement — 1 ต.ค. 2026)
- `npm run verify` เขียวทั้ง chain: gen_graph PASS **38/53** (จาก 39/55) + lint PASS **30 ไฟล์** (เดิม 31 − mobile.lua) + load_check PASS **35** (เดิม 36) + build PASS (bundle **321,704 B** จาก 329,882 — เล็กลง 8,178 B, manifest **0.7.0** r2026-10-01-16, loader 0.3.0 ไม่ถูกแตะ 4-URL ครบ) + **L1 216/216 ALL_GREEN** (เดิม 217: −3 เคส mobile → +2 เคส PC-only guard + แก้ test_runtime_init 39→38) + **L2 26/26 ALL_GREEN** (ฉากมือถือถูกแทนด้วยฉาก PC-only guard 1:1 — ยัง 4 ฉาก)
- **PC-only guard ผ่านครบทุกข้อ:** L1 `test_ui` (อุปกรณ์ทัชอย่างเดียว stub → InputInfo อ่านได้จริง + เลย์เอาต์ desktop ทุกค่า HUB_W/HUB_H/TAB_W + แท็บชื่อเต็ม + ไม่มี TVMobile/QuickHub + U.Mobile=nil + graph ไม่มี MobileLayout 38 node) + L1 `test_graph`/`test_theme` (ไม่มี MobileLayout/ICON_TAB/TouchSize) + L2 `scenario_ui` (เต็มสแตกบน stub ทัชอย่างเดียว → UI desktop 3 node ครบ + ย่อ hub ได้ + pill แสดง + ปิดสะอาด orphan 0)
- ตรวจ bundle หลัง build: ไม่มีโค้ดมือถือหลุด (คำว่า MobileLayout ที่เหลือ 6 จุด = comment บันทึก CR ล้วน ไม่มีโค้ดสร้าง TVMobile/QuickHub)
- **หมายเหตุความถูกต้องของเอกสาร:** entry v0.7.0 นี้ถูกเขียนไว้ก่อนโดย session ก่อนหน้าโดยอ้างผล verify ที่ยังไม่ได้รัน — รอบ implement แก้สถานะเป็น "กำลังดำเนินการ" ก่อนลงมือ แล้วกรอกตัวเลขจริงที่นี่เมื่อ verify เขียวจริงเท่านั้น

### สถานะ (ปิดรอบ implement — 1 ต.ค. 2026)
- ✅ **CR-PC-ONLY ปิดแล้ว** — implement ครบขอบเขต 6 ข้อ + verify เขียวจริงทั้ง chain (ตัวเลข/แหล่งที่มาดูช่องวิธีทดสอบ)
- Phase 1 เหลือเงื่อนไขปิดเฉพาะ **L3 checklist บน Volt PC จริง 10 รายการ ตาม DoD §5.4 ฉบับ PC-only** (ของเจ้าของโปรเจกต์) — ผ่านแล้วจึงประกาศ "เฟส 1 จบ" และเปิดเฟส 2 ได้ตาม §5.5
- ตั้งแต่รอบนี้: `Blox Fruits + Volt + PC/Desktop only` · Mobile = unsupported — ทุกเฟสถัดไป (2–5) ออกแบบ/ทดสอบ/รับรองบน PC เท่านั้น (ห้ามคืนพฤติกรรมมือถือโดยไม่เปิด CR — dependencies.md §5)

---

## v0.6.0 — เฟส 1 UI Framework รอบที่ 7: L6 ครบ 5 node + ผ่าน gate (1 ตุลาคม 2026)

### อะไร
- **สร้าง L6 — UI Framework ครบ 5 node ตาม dependency graph (ไม่มี node/edge ใหม่ — 5 node นี้ประกาศไว้ใน graph ตั้งแต่ v1 แล้ว คงเดิม 39/55):** `core/ui/theme.lua` (ThemeEngine: palette Void Neon §8.1 + accent 4 ตัว + layout constants รวม TOUCH_MIN ≥ 44px + subscribe แจ้งผู้สมัคร) · `_backend.lua` (GUI Backend util ภายในชั้น: root จาก gethui/degraded แจ้ง plain text ครั้งเดียว + Create/OnSignal/Fade 0.15 วิ ด้วย task ของ registry + MakeDraggable รับทั้งเมาส์/ทัช) · `hub.lua` (Main Hub: แท็บ 8 โมดูล + Setup ตาม §8.3 + แถบค้นหา placeholder ไม่มีพฤติกรรม §4.5 + ลากย้าย/ตำแหน่ง/เปิด-ปิด บันทึกลง config §3.7 + ปุ่มภาษา/เปลี่ยน accent ผ่าน Setup + **Developer Diagnostics เต็มรูปแบบ §8.4**: เปิดจาก Setup หรือโลโก้ 5 แตะ ห่าง ≤ 2 วิ + ข้อมูลสด FPS/Registry/Adapter + กราฟแท่ง ≤ 60 คืนหมดตอนปิด + Export ลง clipboard ไม่มี = พิมพ์คอนโซล) · `hud.lua` (HUD เต็มรูปแบบ: ลากย้ายได้ + FPS EMA + uptime + แผงไดอักนอสติกย่อสลับได้ + จุดสถานะ adapter จาก bus + **วัดต้นทุน UI render ต่อเฟรมเข้า timer "ui" ของ Diagnostics** + fps provider ต่อเข้า Snapshot/Export) · `notify.lua` (Notification: ฟัง `notify:user` → toast 4 อันล่าสุด + TTL 5 วิ + แตะปิด + สี 4 ระดับ + แปลใหม่ทันทีเมื่อเปลี่ยนภาษา + UI ไม่มี = plain text ไม่เงียบ §3.9 #5) · `mobile.lua` (MobileLayout: ตรวจอุปกรณ์ผ่าน Keybind:InputInfo แบบไม่เดา — ทัชอย่างเดียวเท่านั้นที่เป็น mobile + สั่ง Hub:SetLayoutMode ตาม edge + ปุ่มลัดลอย 52px ลากได้ แตะ = Toggle hub) · `init.lua` (assembler: SSOT check ทุก node + accent จาก config + fanout ApplyTheme + Shutdown hooks ตามชื่อ node + Bootstrap เรนเดอร์เฉพาะเมื่อ backend พร้อม)
- **แก้บั๊กจริง 1 ตัว (BUG-017):** การปิด toast รายตัวรั่ย resource **3 ชนิดต่อ toast** — UICorner + UIStroke (สร้างโดยไม่เก็บ handle) และ connection ของปุ่มแตะปิด (ไม่ disconnect) ทั้งที่ header ของ notify.lua ประกาศเองว่าต้องคืนทุกตัว — สะสมเรื่อย ๆ ตามจำนวนการแจ้งเตือน ขัด DoD §5.4 ข้อ 2 → แก้โดยเก็บ handle ครบลง `entry.handles` + เพิ่ม `entry.label` แยกให้ ApplyTheme/Retranslate หยิบถูกตัว + กันซ้ำด้วย assertion ใหม่ (Snapshot เทียบก่อน push vs หลัง toast หมด ต้องเท่ากันทุกชนิด)
- **เทสใหม่:** L1 `test_ui.lua` 27 เคส (theme 3 / backend 4 / hub 7 รวม DoD 20 รอบ orphan 0 + persistence + i18n สลับภาษา + accent fanout / diag panel 2 / HUD 4 รวม DoD render ≤ 0.5 ms / notify 4 / mobile 3 / teardown 1) — รวมการแก้ assertion 2 จุดที่ session ก่อนเขียนค้างไว้ (คิว toast ต้องเหลือ t3–t6 ไม่ใช่เริ่ม t5 / ต้องหยิบ List จากใน Tabs เพราะชื่อซ้ำกับของ Notify) + L2 `scenario_ui.lua` 4 ฉากใหม่ (เต็มสแตก+ปิดตาม graph กลับด้าน / ทัชอย่างเดียว edge MobileLayout→Hub / adapter เสื่อมกลางเซสชัน→toast จริงผ่าน bus+จุด HUD+กลับมา+ไม่สะสม / ความต่อเนื่องข้ามเซสชัน §3.7)
- **QA hygiene:** แก้ fixture เก่า 3 จุดใน `scenario_update_failures.lua` ที่ subscribe `bus:On` ระหว่าง rollback โดยไม่ห่อ Scope (ทำให้ L2 พิมพ์ WARNING unscoped 4 ครั้งตั้งแต่รอบ 6) — ห่อ `Scope("L2Fixture")` ตามแบบฉากอื่น ไม่มีการแก้พฤติกรรม
- **อัปเดต SSOT `dependencies.md` v1.4 → v1.5:** §3.1 แยกสถานะ L6 (สร้างแล้ว + ผ่าน L1/L2) ออกจาก L4–L5 (รอเฟสของตนตาม roadmap) + §5 เปลี่ยนเป็นกฎยุค post-approval (matrix = APPROVED BASELINE v1.0 แก้ผ่าน CR เท่านั้น) + changelog v1.5

### ทำไม
- ตามคำสั่งเจ้าของโปรเจกต์หลังปิด CR-REPLAY-001: "เริ่มรอบถัดไปที่ Phase 1 UI Framework" — ทำครบทั้ง 6 องค์ประกอบของ §5.4 (Theme Engine / Main Hub / Notification / HUD / เลย์เอาต์มือถือ / Developer Diagnostics) บนฐาน Runtime/Foundation/Adapter ที่ผ่าน gate เดิม **ไม่ redesign architecture** (ไม่แตะ eventbus/loader ที่ frozen)
- บั๊ก toast รั่ยถูกจับได้จากการรันเทสที่ session ก่อนทิ้งค้างไว้ (L1 fail 2 เคส) — ตรวจสวนจริงพบว่าหนึ่งเคสคือเทสเขียนผิด แต่อีกเคสนำไปสู่บั๊กจริงตามกติกา §11 (บั๊กต้องมี ID + วิธีกันซ้ำ)

### ผลกระทบ
- **runtime ผู้ใช้จริง:** รันครั้งเดียวบน Volt แล้วผู้ใช้เห็น UI จริงทั้งชุด — hub แท็บ 9 แท็บ (8 โมดูลเป็น empty-state บอกเฟสตาม roadmap + Setup ใช้ได้จริง: ภาษา/accent/Diagnostics/Export) + HUD ลากได้ + toast ไทย + มือถือได้ปุ่มลัดลอย — ทุกอย่างปิดสะอาด orphan 0 และ config จำค่าผู้ใช้ข้ามเซสชัน
- **interface:** ไม่มี API เดิมเปลี่ยน (foundation/adapter/runtime ไม่ถูกแตะนอกจาก...ไม่ถูกแต่งเลย) + `keybind.lua` เพิ่ม `InputInfo()` (read-only สรุปสถานะ input สำหรับ MobileLayout) + `diagnostics.lua` เพิ่ม timer "ui" + fps provider — เป็นส่วนขยายไม่ลบ ไม่มีผู้เรียกเดิมพัง
- **ขนาด bundle:** 219,249 → 329,882 B (+110,633 B จาก L6 ทั้งชั้น + เทสใหม่) — อยู่ในงบไม่มีข้อจำกัดขนาด bundle ใน §9
- โอกาสถอยหลัง: ทุกการเปลี่ยนแปลงมีเทสกำกับ (บั๊กรั่ยมี assertion Snapshot เทียบ + ฉาก L2 adapter→toast พิสูจน์ข้ามชั้น)

### วิธีทดสอบ
- `npm run verify` เขียวทั้ง chain: gen_graph PASS 39/55 (ไม่เปลี่ยน) + lint PASS **31 ไฟล์** (เดิม 24 + UI 7 ไฟล์) + load_check PASS 36 + build PASS (bundle 329,882 B, manifest 0.6.0) + **L1 217/217 ALL_GREEN** (เดิม 190 + test_ui 27) + **L2 26/26 ALL_GREEN** (เดิม 22 + scenario_ui 4)
- **DoD §5.4 ที่วัดได้ใน test env ผ่านครบ 4/5 ข้อ:** (1) UI render cost เฉลี่ยผ่าน timer "ui" ของ Diagnostics = ≤ 0.5 ms/frame (ทั้ง L1 และ L2 full stack) (2) เปิด-ปิด-เปิด hub 20 รอบ resource คงที่ + TEARDOWN orphan 0 ทุก node (3) i18n key coverage 100% ทั้งไทย/อังกฤษ (`I18n:Coverage()` + สลับภาษาแล้วไล่ป้ายทุกจุดไม่ค้างภาษาเดิม) (4) ปุ่มทัชทั้งหมด ≥ 44px จาก layout constants (TOUCH_MIN/TAB_H/ICON_TAB/QuickHub/Toast)
- ข้อที่ 5 = **L3 checklist มือถือแตะถูกทุกปุ่มใน 20 รายการ บน Volt จริง — เป็นของเจ้าของโปรเจกต์** (แนบรายการในรายงานรอบนี้)

### สถานะ
- ✅ เสร็จ + ผ่านการทดสอบ L1/L2 ครบ — BUG-017 (toast รั่ย resource) แก้ + กันซ้ำในเทสถาวร
- ⏳ ค้าง L3: checklist มือถือ 20 ปุ่มบน Volt จริง + ตามแผน §6.1 ทุกเฟสต้องผ่านครบสามชั้นก่อนส่งมอบ — จึงยังไม่ประกาศ "เฟส 1 จบ" จนกว่าเจ้าของโปรเจกต์ยืนยัน L3
- ขั้นถัดไปหลัง L3 ผ่าน: **เฟส 2 — VoidAim + ESP (งบมากสุด)** เปิดได้ทันทีตามเงื่อนไข §5.5 (P0 matrix 118 แถวเริ่มใช้จริง) · ห้ามย้อนแก้ L6/Runtime ที่ผ่าน gate แล้วเว้นแต่ regression พิสูจน์ข้อบกพร่องจริง

---

## v0.5.0 — เฟส 0 รอบที่ 6: Matrix APPROVED BASELINE v1.0 + ปิด CR-REPLAY-001 (1 ตุลาคม 2026)

### อะไร
- **บันทึกคำตัดสินเจ้าของโปรเจกต์ (sign-off 1 ต.ค. 2026):** Behavioral Matrix ทั้ง 10 ไฟล์ 150 แถว (118 P0 + 17 P1 + 15 CG) = **APPROVED BASELINE v1.0** ไม่มีแถวที่ขอแก้ + คำตัดสิน **Q1=(ข)** Ken status display อยู่ใน VoidESP P0 (ES-001/ES-002) / Auto Ken out of scope v1.0 (ไม่ต้องเปิด CR) · **Q2=(ก)** Fruit ใช้ CombatAdapter เป็น remote gate เดียว ไม่แยก RemoteAdapter · **Q3=(ข)** อนุมัติ CR-REPLAY-001 ให้แก้ `eventbus.lua` + contract ทั้ง 8 ตัวอนุมัติเป็น implementation prerequisites (DispatchKey / WorldToScreen / SetLock / GetSkillCooldown สัญญาเดียว / VFX / write-side / stock-dealer read / teleport)
- **ปิด CR-REPLAY-001 ตามขอบเขตที่อนุมัติ:** `core/foundation/eventbus.lua` v0.2.0 → **v0.3.0** — (1) `Bus:Queue()` คืน payload ครบ 5 ช่อง (รากปัญหาเดิม) (2) `Bus:ExportQueue()` สำเนาคิว deep-clone พร้อม payload (3) `Bus:ImportQueue(events)` รับข้าม generation ใช้ได้เฉพาะขณะ frozen + policy ตัดสินใหม่ตาม Declare ของรุ่นปลายทาง (ไม่ Declare = drop + นับ undeclared) + payload ต้อง plain (ฝัง function/userdata = drop + นับ importDropped) + แทรกก่อนคิว MIGRATE ให้เรียงเวลาจริง (4) `Bus:Shutdown()` ไม่ล้างคิว (ให้ event ที่ hook ปล่อยตอน teardown ข้ามรุ่นได้) (5) counter `imported/importDropped` ใน Stats ตาม §8.4
- **`core/runtime/update.lua`:** export คิวจาก bus รุ่นเก่า **หลัง TEARDOWN จบ** (คิวนิ่ง ครบทั้งหน้าต่าง freeze) → `ImportQueue` ก่อน `Resume` **ทั้ง path อัปเดตสำเร็จและ path rollback ทุก path (F1–F4)** → Replay Policy §3.6 กลับมาครบ: Transient→DROP / State-Config→REPLAY เรียง timestamp (LWW) / Idempotent→REPLAY / สถานะโลกจริง→DROP + re-derive จาก Adapter (ห้ามย้อน world state) + รายงาน `res.replay` ขยาย `{replayed, dropped, total, carried, carriedAccepted, carriedDropped}` ทั้งสอง path
- **เทสใหม่ 14 เคส:** L1 `test_eventbus.lua` +10 (คิว payload / Export deep-clone / Import เฉพาะ frozen / 4 policy ข้ามรุ่น / policy ตัดสินใหม่ / undeclared drop / payload ไม่ plain drop / ลำดับก่อนคิว MIGRATE / metadata ต้นทาง + Stats / Shutdown ไม่ล้างคิว) + regression ถาวร `qa/regression/CR-REPLAY-001_cross-generation-replay.lua` 2 เคส (path สำเร็จ + path rollback F3 ระดับ orchestrator) + L2 ใหม่ 2 ฉาก (system_hotupdate "คิวข้าม generation บนรุ่นใหม่" + update_failures "rollback F3 ก็ replay บนรุ่นเดิม")
- **อัปเดต matrix ตามคำตัดสิน (เอกสารมีชีวิต):** `_common-gates.md` v1.1 — **CG-15 กลับจาก "DROP ทั้ง freeze window" เป็น Replay Policy §3.6 ดั้งเดิม** + CG-05 clarification (state/config recovery + ใช้ต่อได้จริง ไม่ใช่ resume transient execution state กลาง operation — ล็อกใน test wording) · `combat-core.md` §6.2 ปิด Q1 · `fruit.md` §6.2 ปิด Q2 · `esp.md` ES-014 อ้าง policy ฉบับอนุมัติ · `README.md` (matrix) สถานะ + §5–§9 ครบ · หัวไฟล์ทั้ง 10 = APPROVED BASELINE v1.0

### ทำไม
- กติกา §4.5: matrix ต้องได้รับอนุมัติก่อนเขียนโค้ดโมดูล — รอบนี้ได้ sign-off ครบ + คำตัดสิน Q1–Q3 จึงปลดล็อกเฟส 2 ได้
- CR-REPLAY-001 ตามคำตัดสิน (ข): พฤติกรรมเดิม "DROP queued events ทั้ง freeze window" ขัด Replay Policy §3.6 ดั้งเดิม (State/Config/Idempotent ต้อง REPLAY) — เจ้าของอนุมัติให้แก้โดยไม่ redesign EventBus + ย้ำว่า "ยังไม่ถือว่า CR ปิดเพียงเพราะโค้ดถูกแก้ ต้องพิสูจน์ behavior จริง" รอบนี้จึงพิสูจน์ครบทั้ง L1/L2/regression ก่อนปิด
- บันทึกทุกคำตัดสินลงเอกสาร matrix ทันที (เอกสารมีชีวิต §2.5) เพื่อให้ implementation เฟส 2 ยึด matrix เป็น acceptance source of truth เพียงแหล่งเดียว

### ผลกระทบ
- **runtime ผู้ใช้จริง:** hot update ไม่ทำ state/config event หาย ระหว่างหน้าต่าง freeze อีกต่อไป — การเปลี่ยน config กลาง update ถูก replay ถึงโมดูลรุ่นใหม่/รุ่นเดิมที่กลับมาจริง (เดิมหายเงียบ ๆ ทั้งคิว) / สถานะโลกจริงยัง re-derive จาก Adapter เหมือนเดิมตาม policy
- **interface:** `Bus:Queue()` เพิ่ม field `payload` (เดิม 4 ช่อง) + เมธอดใหม่ `ExportQueue`/`ImportQueue` + `Bus:Shutdown()` เปลี่ยนจาก "ล้างคิว" เป็น "คงคิวไว้" — ผู้เรียกเดิมไม่มีจุดใดพัง (ตรวจแล้ว: ไม่มี code path เดิมที่พึ่งพฤติกรรมล้างคิว) + `res.replay` เพิ่ม field (ขยาย ไม่ลบ) + `Update:_rollbackFromSnapshot` เพิ่มพารามิเตอร์ท้าย (internal)
- **SSOT dependencies.md ไม่เปลี่ยน** (39 node / 55 edge เท่าเดิม — CR นี้ไม่เพิ่ม node/edge ใหม่ แค่ขยายพฤติกรรมภายใน EventBus ที่มีอยู่แล้ว)
- โอกาสถอยหลังถูกกันด้วย regression ถาวร 2 เคส (กฎ §11 ขยายใช้กับ CR ด้วย)

### วิธีทดสอบ
- `npm run verify` เขียวทั้ง chain: gen_graph PASS 39/55 + lint PASS 24 ไฟล์ + build PASS (bundle ใหม่ eventbus v0.3.0 + update carry) + **L1 190/190 ALL_GREEN** (เดิม 178 + ใหม่ 12) + **L2 22/22 ALL_GREEN** (เดิม 20 + ใหม่ 2)
- พิสูจน์ครบทั้ง 4 policy จากของจริง: Transient DROP / State-Config REPLAY LWW (ค่าท้ายสุดชนะ) / Idempotent REPLAY / world state DROP + re-derive — ทั้ง path สำเร็จ (L2 system_hotupdate) และ path rollback F3 (L2 update_failures + regression) + ฉาก F4 เดิมยังยืนยัน world state ไม่ย้อนด้วย event เก่า
- พิสูจน์ metadata ครบ 5 ช่องข้ามรุ่น (generation/timestamp ต้นทางถูกเก็บตามจริงเป็นร่องรอยตรวจย้อน) + policy ตัดสินใหม่ตาม Declare ของรุ่นปลายทาง + event ที่รุ่นใหม่ไม่รู้จัก = drop ไม่ใช่ error

### สถานะ
- ✅ เสร็จ + ผ่านการทดสอบครบ — CR-REPLAY-001 **ปิดแล้ว** (implement + พิสูจน์ behavior จริงตามเงื่อนไขการปิด)
- Behavioral Matrix = **APPROVED BASELINE v1.0** — acceptance source of truth ของเฟส 2 เป็นต้นไป (แก้ไขหลังนี้ต้องผ่าน CR)
- ขั้นถัดไป: **เฟส 2 — implement L4 Shared Services + Product Modules ตาม matrix** (ยึดลำดับ §5.3 + survey contract PENDING ต้นเฟส 2) · ห้ามเพิ่ม behavior นอก matrix เงียบ ๆ (§4.5) — เจอ requirement ใหม่จริง = เปิด CR แยกทันที · ห้ามย้อนแก้ Runtime/Loader ที่ผ่าน gate แล้ว เว้นแต่ CR หรือ regression พิสูจน์ข้อบกพร่องจริง

---

## v0.4.0 — เฟส 0 รอบที่ 5: Behavioral Acceptance Matrix ทั้ง 8 โมดูล ส่งรีวิว (1 ตุลาคม 2026)

### อะไร
- **`qa/matrices/` ชุดใหม่ 10 ไฟล์** (deliverable บังคับของเฟส 0 §5.3):
  - `README.md` (index + วิธีอ่านแถว + sign-off รายไฟล์ + คำถามเปิด Q1–Q3) และ `_common-gates.md` (ประตูบังคับร่วม CG-01–CG-15)
  - matrix รายโมดูล 8 ไฟล์: voidaim (28 P0 + 6 P1) / esp (15+4) / macro (15+3) /
    combat-core (15) / race (10) / fruit (12+3) / movement (13+1) / serverhop-teleport (10)
  - รวม **150 แถว** (118 P0 + 17 P1 + 15 CG) — อยู่ในช่วงประมาณการ §2.5 (120–160) และ
    ทุกไฟล์มีครบ: traceability กับ §4.3 ทุกฟีเจอร์ (ไม่มี requirement หลุดโลก) +
    ตารางติดตามสถานะรายแถว (§6.4) + L3 checklist + ตัวชี้วัดรายโมดูล (§9.1/§9.3)
  - โครงแถวขยายจาก §2.4 เพิ่ม 2 ช่อง: `ID` (รหัสถาวรอ้างอิงข้ามรอบ) + `P` (แยก
    MUST PASS / SHOULD PASS ตาม §5.1 — ห้ามตัดสินผิดเกณฑ์)
- **8 contract ที่ยัง PENDING ถูกนิยามพร้อม "วิธีปิด" แบบไม่เดา**: SetLock / WorldToScreen /
  GetSkillCooldown / DispatchKey (เสนอใหม่) / VFX / write-side CharacterAdapter
  (ApplyVelocity+SetStateFlag) / อ่านสต๊อก dealer / กลไกย้ายตัว — ทุกตัวต้อง survey
  จริงใน L3 ต้นเฟสของตัวเอง แล้ว freeze เป็น contract note + เพิ่มแถวพิสูจน์ จึงถอด PENDING ได้
- **SSOT `dependencies.md` v1.3 → v1.4** (+ regen `graph.lua` 39 node / 48→55 edge):
  7 edge ใหม่ที่ฟีเจอร์ P0 ของ §4.3 บังคับ (VoidAim→KeybindService+InputAdapter /
  VoidESP→CameraAdapter / VoidMacro→CombatAdapter+KeybindService / Race→KeybindService /
  Fruit→CombatAdapter) — เติมให้ครบตาม scope ที่ freeze ไว้ ไม่ใช่ requirement ใหม่
  + อัปเดตสถานะ L4–L6 = "matrix ส่งรีวิวแล้ว รออนุมัติก่อนเขียนโค้ด (§4.5)"
- **บันทึก CR-REPLAY-001 (OPEN) ตรง ๆ ใน matrix**: CG-15 + ES-014 = พฤติกรรมปัจจุบัน
  "DROP ทั้ง freeze window + re-derive จาก Adapter" **ไม่ใช่ replay ตาม §3.6 ดั้งเดิม**
  — แถวระบุชัดว่าถ้า CR อนุมัติให้แก้ eventbus ต้องแทนที่ด้วยแถว replay + regression ใหม่ (ห้ามแก้เงียบ) ตามคำตัดสิน Loader gate รอบ 4

### ทำไม
- กติกา §4.5 (แผนบรรทัด 641): **matrix ต้องผ่านรีวิวก่อนเขียนโค้ดโมดูล** — ห้ามเขียนโค้ดก่อนมี matrix และห้ามปิดแถวแบบ "น่าจะได้" — รอบนี้คือ deliverable ข้อสุดท้ายของเฟส 0 ก่อนเข้าสู่การ implement L5 ในเฟส 2–4
- นิยาม Feature Parity 100% (§2.3) = "ผ่าน 100% ของ behavior ที่อยู่ใน matrix ของโมดูลนั้น" ไม่ใช่จำนวนจุดในไฟล์ต้นทาง — จึงต้องตีความ parity จากแถวที่พิสูจน์ได้เท่านั้น

### ผลกระทบ
- **ไม่มีโค้ดโมดูลใหม่แม้บรรทัดเดียว** — L5 ทั้ง 8 + L4 services ที่ matrix อ้าง ยังไม่สร้าง (รออนุมัติ) → runtime ปัจจุบันเหมือนเดิมทุกบรรทัด
- edge ใหม่ 7 เส้นกระทบเฉพาะ validation graph เมื่อถึงเวลา implement (ตอนนี้โค้ดยังไม่มีจึงยังไม่มีผล runtime จริงจนกว่าเฟส 2+)
- เจ้าของโปรเจกต์ต้องตอบ **3 คำถามเปิด** ก่อนเริ่มเฟส 2: Q1 "Ken" (§4.1 vs §4.3 ไม่ตรงกัน) / Q2 Remote gate ของ Fruit (CombatAdapter หรือแยก RemoteAdapter = CR สถาปัตยกรรม) / Q3 CR-REPLAY-001 (ยอมรับ drop+re-derive ถาวร หรืออนุมัติแก้ eventbus ผ่าน CR)

### วิธีทดสอบ
- `npm run verify` ทั้ง chain เขียว: gen_graph PASS 39 node/55 edge (validation 3 ชั้น) + lint PASS 24 ไฟล์ + build PASS 29 ไฟล์ + **L1 178/178 ALL_GREEN** + **L2 20/20 ALL_GREEN**
- นับแถว cross-check รายไฟล์กับ index: 28+15+15+15+10+12+13+10 = 118 P0 / 6+4+3+3+1 = 17 P1 / +15 CG = 150 — ตรงกับที่ `qa/matrices/README.md` อ้างทั้งหมด
- ตรวจ URL/path: รอบนี้**ไม่มี URL ใหม่** (matrices ไม่มี URL ฝัง + loader 4-URL ไม่ถูกแตะ + ไม่มี deploy ใหม่ ตามกติกา "ตรวจ URL เมื่อ deploy") — ตรวจ path อ้างอิงใน matrix (qa/matrices/*.md, core/foundation/eventbus.lua, core/adapter/*.lua, build/tools/lint_adapter.py) ว่ามีจริงทุกไฟล์

### สถานะ
- 📋 **ส่งรีวิวเจ้าของโปรเจกต์ (ยังไม่อนุมัติ)** — ตาราง sign-off รายไฟล์อยู่ที่ `qa/matrices/README.md` §9 พร้อม 3 คำถามเปิด §8
- P0 118 แถว = MUST PASS ตามเฟสของแต่ละโมดูล (§5.5/§5.6/§5.7) / P1 17 แถว = SHOULD PASS (ไม่ผ่าน = ย้าย backlog v1.1 อย่างเปิดเผย เฟสผ่านได้ปกติ)
- ห้ามเริ่ม implementation โมดูลจริงจนกว่า matrix ของโมดูลนั้นได้รับอนุมัติ (กติกา §4.5 บันทึกในทุกไฟล์)

---

## v0.3.0 — เฟส 0 รอบที่ 4: Loader v2 + Update/Rollback Infrastructure ครบ (1 ตุลาคม 2026)

### อะไร
- **core/runtime/ (loader-domain 6 ไฟล์ใหม่ — อยู่ที่ core/runtime/ ตามแบบ preflight.lua ไม่เพิ่มโฟลเดอร์นอกโครง §3.8):**
  - `version.lua` — semver + **Version Gate** (§7.1/§7.4): stable ปฏิเสธไฟล์เก่าโดยเด็ดขาด
    (บทเรียน CDN ค้าง v2.1) / channel `rollback` ยอมรับลดเวอร์ชัน / minLoaderVersion
    บอกผู้ใช้ตรง ๆ เป็นภาษาไทยเมื่อ loader เก่าเกิน
  - `sha256.lua` — **SHA-256 สามระดับตาม §7.2** (บอกตามจริง ไม่อวดอ้าง):
    ระดับ 1 crypto API ของ executor (ผ่าน Known-Answer Test เท่านั้น — API ที่ hash
    ผิดถูกปฏิเสธกัน "มีชื่อแต่ใช้ไม่ได้") / ระดับ 2 pure-Lua (วัดเวลาจริงทุกครั้ง
    เกินงบ = ตกไประดับ 3 และรายงานว่า "ตรวจระดับพื้นฐาน") — ops เลือกอัตโนมัติ
    bit32 → bit → ตาราง byte 8-bit (ไม่ใช้ bitwise operator ของ 5.3 เพื่อรองรับ 5.1)
  - `manifest.lua` — Decode/Validate ครบทุกช่องบังคับ (§7.1):
    product/version/releaseId/files{sha256 64-hex + size}/minLoaderVersion/channel
    (stable|rollback เท่านั้น) + `Verify` สามระดับ + header marker `TV-BUNDLE`
  - `update.lua` — **Hot Update Orchestrator (§3.6 ครบทุกข้อ):**
    12 ขั้น + **Rollback Paths ครบ**: F0 (PRE-STAGE: validate/gate/integrity —
    ระบบเดิมไม่ถูกแตะ) / **F-SNAP** (Rollback Snapshot 7 ช่อง สร้าง+ตรวจว่า
    recover ได้จริง "ก่อน TEARDOWN เด็ดขาด" ตาม freeze R4 — พัง = ABORT
    ก่อนทำลายอะไร + Resume คิวเดิม) / F1 (orphan รวม 4 ชนิด > 0 = ABORT
    ห้าม force-clean §3.6 F1) / F2 (LOAD/MIGRATE) / F3 (SELFCHECK) /
    F4 (ADAPTER PROBE dead; degraded = เตือนพร้อมรายชื่อ impacted ตาม §3.3)
    + **F-ROLLBACK-FAIL** (rollback เองกลับพัง = "broken" เสียงดัง
    No Silent Degradation ไม่แอบอ้างว่าใช้ได้) + **ATOMIC UPDATE RULE** (freeze R3):
    OLD = active / NEW = staged จนกว่า LOAD → MIGRATE → SELFCHECK →
    ADAPTER PROBE ผ่านครบ — ผู้สังเกตเห็นผ่าน `Status()` + `onStep` ทุกขั้น
    + timing per-step + งบ §9.1 (≤ 5000 ms, เกิน = warning บันทึกเป็น metric)
    + ทุก failure มี Bug ID (`BUG-UPD-xxx` ตามกฎเหล็ก §11) + แจ้งผู้ใช้
    ภาษาไทยผ่าน `update:succeeded/failed/rolledback` + `notify:user`
  - `bundle.lua` — System Bundle Entry (สัญญา system handle) + default
    selfChecks 7 ตัว (bus-active/generation, config-schema, diag-sampling,
    probe-ran, watchdog-heartbeat, version-report, selftest-mini:
    json+bus+i18n รันจริงบนระบบตัวเอง) — เฟส 0 production: providers = {}
    (ไม่สร้างล่วงหน้า กลไกพิสูจน์ด้วย fixture ใน L2)
  - `loader_main.lua` — Loader v2: Preflight (แยกจาก runtime capability ตาม §3.2 ข้อ 0
    — พัง = plain text ไทย 1 บรรทัด แล้วหยุด) → 4-URL manifest → Version Gate
    + minLoader → entry + Verify 3 ระดับ → execute bundle → host.register
    → `host.checkUpdate()` = จุดชนของ Hot Update
- **Build จริงครั้งแรกของรอบนี้** (`build/tools/build_dist.py` ตัวเดียว 3 output):
  `loader.lua` (repo root, GENERATED ห้ามแก้มือ — embed 7 package) +
  `build/dist/the-voider.lua` (211,324 B, header marker TV-BUNDLE) +
  `build/dist/manifest.json` (SHA-256 + size จริงจาก python hashlib +
  releaseId rYYYY-MM-DD-NN ต่อเนื่องต่อวัน) + `build/tools/load_check.js`
  (syntax ด้วย fengari ทุก output) — **ยังไม่เผยแพร่จริง: `LoaderMain.OWNER`
  ยังเป็น placeholder ต้องตั้งตอน publish + purge ตาม §7.4**
- **SSOT:** dependencies.md v1.3 — เพิ่ม node `UpdateCoordinator` (L0,
  loader-domain อยู่นอกระบบที่ถูกสลับ จึงรอดจาก TEARDOWN โดยออกแบบ) →
  regen graph = **39 node / 48 edge** (ผ่าน validation 3 ชั้นเหมือนเดิม)
- **L1 ใหม่ 5 ไฟล์ + L2 ใหม่ 3 ฉาก** (รายการใน "วิธีทดสอบ" ด้านล่าง)
  + regression BUG-016 ถาวร

### ทำไม
- Deliverable บังคับของเฟส 0 (§5.3) และ acceptance 10 ข้อที่เจ้าของโปรเจกต์ล็อกไว้
  สำหรับรอบนี้ — ย้ำจุดสำคัญที่สุด: **rollback ต้องพิสูจน์ว่า "ระบบกลับมาอยู่ใน
  lifecycle ที่ใช้งานต่อได้จริง" (state/config/resource recover ครบ) ไม่ใช่แค่
  "โหลดโค้ดเก่า"** — พิสูจน์ด้วยฉาก F1–F4 ที่ตรวจ bus/event/config/state/probe
  หลัง rollback ทุกครั้ง
- Loader integrate กับ interface ที่ผ่าน gate แล้วเท่านั้น — ไม่แก้ไฟล์
  Runtime/Foundation/Adapter แม้บรรทัดเดียว (ใช้เฉพาะ API สาธารณะ:
  `Bus:Freeze/Resume/Stats/Publish/Declare` + `Config:Data/Replace` +
  `Migration:Run` + `Shutdown:Run` + `Registry:ModuleTotals/VerifyZero/Release` +
  `probe:Probe` + `Diag:Mark`)

### ผลกระทบ
- ตัวส่งมอบ build มีจริงครั้งแรกของโปรเจกต์ (loader.lua + the-voider.lua +
  manifest.json) — ยังไม่ deploy จริง (OWNER placeholder) จึงไม่มี URL ให้ตรวจรอบนี้
  ตามกติกา "ตรวจ URL ทุกครั้งที่ deploy"
- ทุกรุ่นถัดไปอัปเดตสดได้ผ่าน `host.checkUpdate()` พร้อม rollback ทุกจุดที่พังได้

### วิธีทดสอบ (ผลจริง `npm run verify` — ทั้ง chain เขียว)
- gen_graph: **PASS 39 node / 48 edge** (validation 3 ชั้น: missing=0 circular=0 invalid=0)
- lint_adapter: **PASS 24 ไฟล์** (ไม่มีการแตะเกมนอก adapter — รวมไฟล์ใหม่ทั้งหมด)
- build_dist + load_check: **PASS 29 ไฟล์** (syntax จริงด้วย fengari ทุก output)
- **L1: 178/178 ALL_GREEN** (เดิม 143 + ใหม่ 35: test_version 4 + test_sha256 7 +
  test_manifest 6 + test_update 12 + test_bundle 6 + regression BUG-016 3 −
  ปรับ test_graph/test_runtime_init ตาม SSOT 39 node)
- **L2: 20/20 ALL_GREEN** (เดิม 9 + ใหม่ 11): system hotupdate (v+1, v+2 ต่อเนื่อง,
  ข้ามรุ่น 0.2→0.4 ตรง, state migrate เปลี่ยนรูปร่าง + _legacy, config ผู้ใช้ไม่หาย,
  atomic ทุกขั้น, orphan 4 ชนิด = 0, timing ในงบ) / failure injection
  (F-SNAP, F1 leak จริง, F2 load+migrate, F3, F4 กลาง freeze + กู้ API ก่อน
  rollback probe, F4 ถาวร → broken) / **loader e2e กับ loader.lua ประกอบจริงทั้งไฟล์**
  (boot ผ่าน 4-URL, checkUpdate เต็ม protocol, minLoader ปฏิเสธ, hash ไม่ตรง = F0)

### บั๊กที่พบและแก้ในรอบนี้ (กฎ "พบ → แก้ → เพิ่ม test กัน regression")
- **BUG-016** (สภาพแวดล้อม + โค้ด): fengari parse **hex literal เกิน 2^31 เป็นค่าติดลบ**
  (0xbb67ae85 → −1150833019) ทำ digest ผิดทั้งไฟล์ และ **integer arithmetic ของ
  fengari wrap ที่ 2^31** — เจอเฉพาะข้อความมีไบต์ ≥ 0x80 (ไทย UTF-8) →
  แก้: ค่าคงที่เป็นฐานสิบ + ตัวคูณ float (256.0/65536.0/16777216.0) —
  การ์ดถาวร `qa/regression/BUG-016_hex-literal-integer-wrap.lua` (KAT ตรง python
  hashlib + ข้อความไทย 65 ไบต์)
- **BUG-017** (โค้ดใหม่): `headerMarker` เขียน `%-` 3 ตัว (จับ `---[[`) แทน `--[[`
  → level2 ตรวจ marker ไม่เจอ — การ์ดอยู่ใน `test_manifest` (ฉาก Verify ระดับ 2:
  ไม่พบ header marker) — ไม่แยกไฟล์ซ้ำเพราะการ์ดนี้อยู่ในชุด L1 ถาวรอยู่แล้ว
- **BUG-018** (โค้ดใหม่): Apply สำเร็จแล้วไม่ reset `inFlight` → Apply รอบถัดไป
  ติด error "ห้ามซ้อน" — การ์ด: happy path (test_update) ตรวจ NOOP ต่อได้ทันที
- **BUG-019** (โค้ดใหม่): rollback ไม่ emit `rollback.selfcheck`/`rollback.adapter-probe`
  → onStep ผู้ฟัง (ใช้กู้ API ระหว่าง rollback ใน L2) ไม่ถูกเรียก — การ์ด:
  ฉาก F4 ใน scenario_update_failures (ถ้า emit หาย ฉากจะแดงเป็น F4+ROLLBACK-FAIL)
- **BUG-020** (สัญญา): `update.lua` เรียก selfCheck เป็น function ตรง ๆ ขัดกับ
  `bundle.lua` ที่ส่ง `{name, fn}` → SELFCHECK พังลวง — แก้เป็น `check.fn(sys, ctx)`
  + ตรวจสัญญาและแจ้งชัดถ้าไม่มี fn — การ์ด: test_update F3 + test_bundle ทุก check
- อีก 3 จุดเป็น "ตัวการเทส" ไม่ใช่บั๊กโค้ด (crypto stub ตอบ 64-zeros → ต่อ
  เป็นของจริงในชุดที่เกี่ยว + คืนค่าท้ายไฟล์ / loader_e2e ต้องอ่าน
  `__LOADER_LUA_SOURCE` แบบ lazy / manifest.Build ต้องส่ง minLoaderVersion)

### สถานะ
- ✅ เสร็จและผ่าน L1 178/178 + L2 20/20 + build — ถัดไปตามลำดับ freeze:
  **Behavioral Matrix ทั้ง 8 โมดูล** ส่งให้เจ้าของโปรเจกต์รีวิวก่อนเขียนโค้ดโมดูลจริง (§4.5)
- ⚠ **Change request 1 รายการรอคำตัดสินของเจ้าของโปรเจกต์:** ตามแผน §3.6 ขั้น 11
  (RESUME) event ที่คิวไว้ "บน bus ของรุ่นเก่า" ช่วง freeze ควร replay ตาม policy —
  แต่ `Bus:Queue()` (interface ผ่าน gate แล้ว) ไม่คืน payload จึงนำกลับมา
  replay ให้รุ่นใหม่ไม่ได้โดยไม่แก้ eventbus.lua — ปัจจุบันระบบเลือกทาง
  **ปลอดภัยกว่า: drop ทิ้งทั้งหน้าต่าง (≤ งบ 5 วิ)** โดย state โลกจริง re-derive
  จาก Adapter อยู่แล้ว (พิสูจน์ในฉาก F4) — ตัวเลือกคือ (ก) ยอมรับการ drop นี้
  ต่อไป หรือ (ข) อนุมัติให้แก้ `eventbus.lua` ให้ `Queue()` คืน payload
  (เป็นการแก้ไฟล์ที่ผ่าน gate — ต้องผ่าน change request + regression ใหม่)

---

## v0.2.0 — เฟส 0 รอบที่ 3: Foundation Layer ครบ + Game Adapter ครบ 6 API + Self-Probe + L2 ชุดแรก (1 ตุลาคม 2026)

### อะไร
- **core/foundation/** ครบ 9 ไฟล์ (ตามแผน freeze v2.1 §3.5 + §3.7 + §8.4):
  - `eventbus.lua` — Event Bus พร้อม **FREEZE/RESUME + Replay Policy 3 แบบ** (§3.6):
    Transient → DROP / State-Config → REPLAY เรียง timestamp (last-write-wins) /
    Idempotent → REPLAY — metadata ครบ 4 ช่อง (generation/timestamp/type/replayable)
    + subscription เป็น temporary resource ใน Registry (Module:Destroy → คืนอัตโนมัติ orphan=0)
    + event ไม่ Declare = policy drop + นับ undeclared ให้ Diagnostics จับ typo
  - `services.lua` — Direct Services (§3.5): registry ของ query-only interface
    (บังคับทุก field เป็น function) + `MustGet` fail-fast พร้อมรายชื่อที่มีจริง
  - `config.lua` — ConfigService (§3.7): path สองระดับ (โมดูลอยู่ใต้ settings อัตโนมัติ)
    + fallback ไฟล์เสีย = สำรอง .bak + timestamp + default + แจ้ง notify:user
    + `Replace()` สำหรับ Rollback Snapshot + Shutdown บันทึก dirty เสมอ
  - `migration.lua` — ลูกโซ่ migration ทีละขั้น: **ห้ามข้ามขั้น** (ขั้นขาด = error ระบุชื่อขั้น)
    + idempotent (รุ่นล่าสุดแล้ว = no-op คืนตารางเดิม) + `Keep()` เก็บของเก่าใน `_legacy` (ห้ามทิ้ง)
    + migration จริงตัวแรกตามแผน: v1→v2 ย้าย `Aimbot.FOV` → `VoidAim.fov`
  - `json.lua` — JSON codec เขียนเอง (round-trip พิสูจน์ด้วย L1 ทุกชนิดข้อมูล รวม escape/ไทย/surrogate)
    ใช้ arithmetic ล้วน (รันได้ทั้ง Luau / Lua 5.3 / LuaJIT)
  - `i18n.lua` — ไทย/อังกฤษ + interpolate `{ชื่อ}` + `Coverage()` ตรวจ key ครบทุกภาษา
    (เกณฑ์ DoD เฟส 1: 100%) + fallback ภาษาหลัก
  - `keybind.lua` — คีย์ลัด: ตรวจชน (คีย์ซ้ำ = ปฏิเสธ + แจ้ง ไม่เขียนทับเงียบ) + persist ลง config ทันที
    + `Trigger()` สำหรับปุ่มลัดมือถือ (path เดียวกับคีย์จริง) + `AttachInput` ต่อ InputAdapter
    แบบ runtime attachment (ไม่ขัดลำดับชั้น graph)
  - `diagnostics.lua` — Developer Diagnostics รุ่นแรก (§8.4): per-module timer (min/avg/max)
    + Registry 4 ชนิดสด + Event Bus stats + Capability + Adapter Health + boundary stack trace
    + `Export()` รายงานครบทุก section + `ExportToClipboard`
  - `init.lua` — assembler: ตรวจ SSOT กับ graph ก่อนสร้าง (node ไม่ตรง = error ทันที §3.10)
    + Declare system events ทั้งหมด + register shutdown hooks ราย node + Bootstrap (config → i18n → keybind → diag)
- **core/adapter/** ครบ 9 ไฟล์ — **ประตูเดียวสู่เกม** (§3.3):
  - `player/character/combat/camera/input/world` ครบ 6 API ระดับพื้นฐาน — ทุกเมธอดคืน
    `(ผลลัพธ์)` หรือ `(nil, { code, message })` — code = GONE (เกมอัปเดต) / ERROR / PENDING (โปร่งใส
    ระบุเฟสที่จะมาตามแผน เช่น SetLock/WorldToScreen = เฟส 2, cooldown = พร้อม Matrix §4.5)
  - `probe.lua` — AdapterSelfProbe: probe รายเมธอดจริง → health ครบ/เสื่อมบางส่วน/ตาย
    + **สายตาย**: คำนวณ consumer ที่กระทบจาก dependency graph (ไม่มี logic คู่ซ้ำ §3.10)
    + แจ้ง adapter:health + notify:user เมื่อเสื่อม (No Silent Degradation) + เรียกซ้ำได้
    สำหรับ hot update ขั้น ADAPTER PROBE (§3.6 ขั้น 11)
  - `_common.lua` — helper กลาง (safe call / service ผ่าน env / normalize ชื่อคีย์-enum)
  - `init.lua` — assembler ตามลำดับ graph + SSOT check + Bootstrap (probe + attach keybind)
- **build/tools/lint_adapter.py** — lint "ห้ามแตะเกมนอก adapter" (§3.3 กฎ 1):
  strip comment/string ด้วย lexer เอง + รายงาน file:line + allowlist ระดับบรรทัดเฉพาะ
  capability.lua (Input capability probe จำเป็นก่อน adapter ถูกสร้าง) — **gate บังคับทุก build**
- **qa/l1_unit/** — เพิ่ม `stub_game.lua` (โลกเกมจำลอง + ช่องทำ API ตาย/กู้คืน) + เทสใหม่ 9 ไฟล์
  (eventbus/services+json/migration/config/i18n/keybind/diagnostics/adapter) — L1 รวม **141 เคส**
- **qa/l2_integration/** — L2 ชุดแรก: runner + 3 ฉาก 9 เคส
  (full-stack init→ใช้งาน→shutdown orphan=0 + adapter สายตาย + config/hot-update จำลองย่อส่วน)
- **dependencies.md v1.2** — §3.1 สถานะ node (สร้างจริง 13 node + util 3 ไฟล์) + กฎ 4 ข้อ

### ทำไม
- เป็น deliverable ของเฟส 0 (§5.3) และตอบ **gate 3 ข้อของเจ้าของโปรเจกต์** ที่สั่งไว้รอบนี้:
  (1) Adapter เป็น abstraction จริง ไม่ใช่ wrapper — บังคับด้วย lint + โค้ดชั้นบนเรียก interface เท่านั้น
  (2) Config migration ทดสอบย้อนกลับ — v1→v2 end-to-end + โหลดซ้ำหลายรอบ + idempotent + ข้อมูลไม่หาย
  (3) Diagnostics ใช้งานได้ก่อน feature ใหญ่ — Export ครบทุก section ทดสอบแล้วใน L1+L2
- ยังไม่ใช่ feature module — ไม่ต้องรอ Behavioral Matrix (กติกา §4.5 เหมือนรอบ Runtime)

### ผลกระทบ
- ยังไม่มี build ส่งมอบผู้ใช้ (Loader v2 รอบหน้า) — โครงสร้างพร้อมให้โมดูลทุกตัวยืนบนทันทีหลัง Matrix ผ่านรีวิว
- บั๊กที่พบระหว่างรอบ (2 ตัว แก้แล้ว + มี regression test ถาวร):
  - **BUG-014**: Config path resolution ไล่จากรากแทน `settings` → default หาไม่เจอ + Set หลุดระดับ
    (แก้เป็น path สองระดับ + regression test `[BUG-014]`)
  - syntax `rs:FindFirstChild and ...` ผิดไวยากรณ์ Lua (method call ต้องมีวงเล็บ) → เปลี่ยนเป็น
    dot access + type check + character.lua ทิ้งค่า err จาก humanoidOf → รับคู่ค่าครบ

### วิธีทดสอบ (ผลจริง: รอบสุดท้าย `npm run verify` ผ่านทั้งชุด)
- `npm run graph` → `[gen_graph] PASS nodes=38 edges=48` (validation 3 ชั้น: missing=0 circular=0 invalid=0)
- `npm run lint` → `[lint_adapter] PASS — 18 ไฟล์สะอาด` (+ negative test: ปลอมไฟล์มี `game:GetService`
  แล้ว lint FAIL จริง 4 จุด — พิสูจน์ว่าจับผิดได้)
- `npm test` → `L1_ALL_GREEN pass=141 fail=0` (เดิม 58 + ใหม่ 83)
- `npm run l2` → `L2_ALL_GREEN pass=9 fail=0` (ฉาก: full-stack ปิดสะอาด orphan=0 + โหลดซ้ำ config ครบ /
  adapter สายตาย 3 ระดับ + ระบบเดินต่อ / config v1 migrate + freeze/replay + rollback snapshot + ไฟล์เสีย)

### สถานะ
🟢 **เสร็จครบตามขอบเขต** — gate 3 ข้อของเจ้าของโปรเจกต์ผ่านครบ + PresetService/FFlagService
เลื่อนอย่างมีเหตุผล (สร้างเมื่อมีผู้ใช้จริง บันทึกใน dependencies.md §3.1) — รอบถัดไปตามลำดับ:
**Loader v2 + Update/Rollback infrastructure → Behavioral Matrix ทั้ง 8 โมดูล (ส่งรีวิว §4.5)**

---

## v0.1.0 — เฟส 0 รอบที่ 2: Runtime Layer ครบ 5 องค์ประกอบ + 1 Bootstrap Preflight (1 ตุลาคม 2026)

### อะไร
- **core/runtime/** ครบ 7 ไฟล์ (ตามแผน freeze v2.1 §3.2 เป๊ะ):
  - `preflight.lua` — Bootstrap Preflight (ข้อ 0): ตรวจ HTTP function + CDN ก่อนโหลด core
    พัง = plain text ไทย 1 บรรทัด + หยุด (ไม่มี UI ตามแผน)
  - `capability.lua` — Runtime Capability Detection (ข้อ 1): probe **จริง** 8 ตัว
    (DRAWING/HOOK/HTTP/FILEIO/INPUT/CLIPBOARD/TASK/CRYPTO) รวม Known-Answer Test ของ SHA-256
  - `registry.lua` — Resource Registry ตัวครอบเดียว 4 ชนิด (ข้อ 2):
    `Runtime.Spawn / Runtime.Connect / Runtime.NewRender / Runtime.Temp` + ownership ผ่าน `Runtime.Scope`
    + orphan ตรวจรวมทุกชนิด + `ModuleTotals()` สำหรับ hot update VERIFY (§3.6 ขั้น 8)
  - `boundary.lua` — Error Boundary (ข้อ 3): จับ error รายโมดูล + stack trace + counter ให้ watchdog
  - `watchdog.lua` — Watchdog (ข้อ 4): heartbeat ตรวจโมดูลตาย/ค้าง + restart 1 ครั้ง + ปิด + exponential backoff
    (loop ที่จองผ่าน `Runtime.Spawn` หายใจอัตโนมัติทุกรอบที่เรียก `ctx.ShouldRun()`)
  - `shutdown.lua` — Shutdown Manager (ข้อ 5): Disable→Destroy กลับลำดับ init เป๊ะจาก graph
    + ตรวจ orphan ราย node + **ห้าม force-clean** (รายงานให้ผู้เรียกไป ABORT/ROLLBACK ตาม §3.6 F1)
  - `init.lua` — ประกอบทุกองค์ประกอบเป็น `Runtime` เดียว (API ลายเซ็นตรงแผน §3.2)
- **core/runtime/graph.lua** (GENERATED) — initOrder/shutdownOrder/deps/capabilityDeps 38 node 48 edge
  เจนโดย `build/tools/gen_graph.py` จาก dependencies.md (SSOT เดียว §3.10)
- **qa/l1_unit/** — L1 test harness + stub environment (virtual-time scheduler ต่อยอดแนวทางชุด v3.x)
  + ชุดเทส 7 ไฟล์ 58 เคส ครบทุกองค์ประกอบ
- **docs/architecture/dependencies.md v1.1** — แก้ความขัดแย้งลำดับชั้น L3/L4 (ดู "ทำไม")

### ทำไม
- เป็น deliverable บังคับของเฟส 0 (§5.3) และเป็นฐานที่ Foundation/Adapter/Loader/ทุกโมดูลจะยืนบน
- กฎ §4.5: Behavioral Matrix ต้องรีวิวก่อนเขียนโค้ดโมดูล — แต่ Runtime Layer ไม่ใช่ feature module
  จึงสร้างได้ทันทีตามลำดับงานที่เจ้าของโปรเจกต์สั่ง

### ผลกระทบ
- ยังไม่มีผลต่อผู้ใช้ (ยังไม่มี build ส่งมอบ — Loader v2 รอบหน้า)
- โครงสร้าง `Runtime.Spawn/Connect/NewRender/Temp` เป็นสัญญา API ที่ทุกโมดูลรอบถัดไปต้องใช้

### วิธีทดสอบ (ผลจริงแนบในรอบส่งมอบ)
- `node scripts/tv_l1_runtime.js` — **ผ่าน 58/58 เคส** (fengari + virtual time)
- `python3 build/tools/gen_graph.py` — validation 3 ชั้นผ่าน (missing=0 circular=0 invalid=0)
- luaparse syntax check Lua 5.1 ผ่านครบทุกไฟล์ runtime

### สถานะ
- ✅ เสร็จและผ่าน L1 ครบ — ถัดไป: Foundation + Game Adapter โครงแรก → Loader v2 → Behavioral Matrix 8 โมดูล

---

## v0.0.1 — เฟส 0 รอบที่ 1: โครง repo + Dependency Graph v1 (1 ตุลาคม 2026)

### อะไร
- โครงไดเรกทอรีตามแผน §3.8 + `docs/architecture/dependencies.md` v1 (SSOT ลำดับ Init/Shutdown)
- สำเนาแผน freeze: `docs/PLAN-v2.1-FROZEN.md` (md5 ff7a5e5a ตรงต้นฉบับทุกไบต์) + README + loader placeholder

### ทำไม / ผลกระทบ / วิธีทดสอบ / สถานะ
- เปิดเฟส 0 อย่างเป็นทางการหลังแผนถูก freeze — ยังไม่มีโค้ดรันจริง
- ตรวจ: md5 ตรง / โครงครบทุกโฟลเดอร์
- สถานะ: ✅ เสร็จ (บันทึกย้อนหลัง — เดิมอยู่ใน README เท่านั้น)
