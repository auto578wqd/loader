# 🕳️ THE VOIDER

Blox Fruits PvP Script — ฉบับของเรา 100% (ไม่มี key ตั้งแต่ไลน์แรก)

| ข้อมูล | รายละเอียด |
|---|---|
| สถานะ | 🖥️ **เฟส 1 — UI Framework รอบที่ 8: CR-PC-ONLY ปิดแล้ว** — เปลี่ยน scope เป็น **PC/Desktop only บน Volt** (Mobile = ไม่รองรับ/ไม่ทดสอบ/ไม่รับประกัน) — ตัด MobileLayout ออกจาก product (graph 38/53) + MC-012/VA-033 = OUT OF SCOPE + DoD §5.4 ฉบับ PC-only + PC-only guard test ถาวร — **L1 216/216 + L2 26/26** — เหลือ L3 (checklist PC 10 รายการบน Volt จริง) ก่อนเปิดเฟส 2 |
| เวอร์ชันปัจจุบัน | `0.7.0` (ดู `VERSION` + `docs/CHANGELOG.md`) |
| แผนหลัก | `docs/PLAN-v2.1-FROZEN.md` — 🟢 **APPROVED / FROZEN v2.1** (ห้ามแก้แผนอีก) |
| Executor เป้าหมาย | **Volt เท่านั้น + PC/Desktop only** (CR-PC-ONLY 1 ต.ค. 2026) — executors อื่น/มือถือไม่รองรับ ไม่ทดสอบ ไม่รับประกัน (§6.3 + `_common-gates.md` §3.1) |
| Source of truth ลำดับระบบ | `docs/architecture/dependencies.md` → generate เป็น `core/runtime/graph.lua` โดย `build/tools/gen_graph.py` |
| ตัวส่งมอบ build | `loader.lua` (repo root, GENERATED) + `build/dist/the-voider.lua` + `build/dist/manifest.json` โดย `build/tools/build_dist.py` |

## โครงสร้าง (ตามแผน §3.8)

```text
thevoider/
├── loader.lua              ← ✅ สร้างจริงแล้ว (GENERATED — ห้ามแก้มือ): Preflight + 4-URL
│                              + Version Gate + Manifest + execute bundle + host
├── VERSION                 ← เวอร์ชันปัจจุบันของ repo
├── core/
│   ├── runtime/            ← ✅ ครบแล้ว: preflight / capability / registry / boundary /
│   │                          watchdog / shutdown / graph(GENERATED) / init
│   │                          + loader-domain: version / sha256 / manifest / update
│   │                            (Hot Update orchestrator) / bundle (entry) / loader_main
│   ├── foundation/         ← ✅ ครบแล้ว: eventbus / services / config / migration / json /
│   │                          i18n / keybind / diagnostics / init
│   ├── adapter/            ← ✅ ครบแล้ว: _common / player / character / combat / camera /
│   │                          input / world / probe(SelfProbe) / init — ประตูเดียวสู่เกม
│   ├── modules/            ← ยังไม่มี — เขียนเมื่อถึงเฟสของตนตาม roadmap (เฟส 2 = VoidAim+ESP)
│   └── ui/                 ← ✅ เฟส 1 ครบ (PC-only): _backend(util) / theme / hub / hud /
│                              notify / init(assembler + SSOT check) — mobile.lua ตัดตาม CR-PC-ONLY
├── build/
│   ├── config.json         ← minLoaderVersion / channel / entryFile ของ manifest
│   ├── dist/               ← the-voider.lua (bundle จริง) + manifest.json (SHA-256 จริง)
│   └── tools/              ← gen_graph.py + lint_adapter.py + build_dist.py
│                              (ประกอบ bundle+manifest+loader รวม 3  output รอบเดียว)
│                              + load_check.js (syntax ด้วย fengari)
├── qa/
│   ├── matrices/           ← ✅ APPROVED BASELINE v1.0 + CR-PC-ONLY: 8 โมดูล + common gates
│   │                          + index = **148 แถว active** (117 P0 + 16 P1 + 15 CG — MC-012/VA-033
│   │                          OUT OF SCOPE เก็บ ID เพื่อ traceability ห้ามนับเป็น "ผ่าน")
│   ├── l1_unit/            ← ✅ harness + stub_env(UI) + stub_game + เทส 216 เคส (รวม PC-only guard)
│   ├── l2_integration/     ← ✅ ฉาก 7 ชุด 26 เคส (full stack / adapter dead / config
│   │                          hotupdate / system hotupdate / failure injection / loader e2e
│   │                          / **ui — UI×Adapter×Bus×Config×i18n×Teardown**)
│   └── regression/         ← ✅ BUG-014 / 015 / 016 + CR-REPLAY-001 (ข้าม generation)
└── docs/
    ├── PLAN-v2.1-FROZEN.md ← แผนหลักฉบับ freeze
    ├── CHANGELOG.md        ← บันทึกทุกการเปลี่ยนแปลง (อะไร/ทำไม/ผลกระทบ/วิธีทดสอบ/สถานะ)
    └── architecture/dependencies.md ← Dependency Graph (SSOT) v1.6 (38 node / 53 edge — CR-PC-ONLY)
```

## กติกาเหล็กของ repo นี้ (§11)

1. บั๊กทุกตัวกลายเป็น regression test ถาวร (`qa/regression/BUG-XXX_*.lua`) ก่อนถือว่าแก้เสร็จ
2. **No Undocumented Hotfix** — ทุก fix บันทึกครบ 6 ช่อง (BUG ID / รากปัญหา / การแก้ / Regression / โมดูลที่เกี่ยว / เวอร์ชัน)
3. ทุก requirement ต้องมีวิธีวัดที่พิสูจน์ได้ (ชั้น L1/L2/L3 + tolerance)
4. **No Silent Degradation** — ปิดฟีเจอร์เพราะ capability/probe ต้องแจ้งผู้ใช้เสมอ
5. Performance Budget ห้ามแย่ลงโดยไม่มีเหตุผลที่บันทึกไว้ (§9)
6. ห้ามทำงานเงียบ + Update Log ทุกการเปลี่ยนแปลง + ตรวจ URL จริงทุกครั้งที่ deploy

## ลำดับการทำงานเฟส 0 (§5.3)

1. ✅ โครง repo + Dependency Graph v1 (1 ตุลาคม 2026)
2. ✅ **Runtime Layer ครบ 5 องค์ประกอบ + 1 Bootstrap Preflight + Resource Registry 4 ชนิด + graph.lua (generated) + L1 harness — ผ่าน 58/58** (1 ตุลาคม 2026)
3. ✅ **Foundation (Event Bus + Direct Services + Config/Migration + i18n + Keybind + Diagnostics) + Game Adapter ครบ 6 API + Self-Probe + lint ห้ามแตะเกมนอก adapter + L2 integration ชุดแรก — ผ่าน L1 141/141 + L2 9/9** (1 ตุลาคม 2026 — gate 3 ข้อของเจ้าของโปรเจกต์ครบ)
4. ✅ **Loader v2 + Update/Rollback infrastructure — manifest §7.1 + SHA-256 3 ระดับ §7.2 + Hot Update protocol 12 ขั้น + Rollback F0–F4 + ATOMIC + snapshot 7 ช่อง + build จริง (loader.lua/bundle/manifest) — ผ่าน L1 178/178 + L2 20/20** (1 ตุลาคม 2026)
5. ✅ **Behavioral Matrix ทั้ง 8 โมดูล + common gates — 150 แถว (118 P0 + 17 P1 + 15 CG) + SSOT v1.4 (graph 39/55)** (1 ตุลาคม 2026 — ส่งรีวิว)
6. ✅ **Owner sign-off ครบชุด = APPROVED BASELINE v1.0 + ปิด CR-REPLAY-001 (ตัวเลือก ข)** — Q1=(ข) Ken เฉพาะ ESP / Q2=(ก) Fruit→CombatAdapter / Q3=(ข) แก้ eventbus ตาม CR: replay ข้าม generation ตาม §3.6 คืนครบทั้ง path สำเร็จ+rollback + regression ถาวร — **ผ่าน L1 190/190 + L2 22/22** (1 ตุลาคม 2026) — พร้อมเริ่มเฟส 2: implement ตาม matrix
7. ✅ **เฟส 1 UI Framework รอบ 7: L6 ครบ 5 node + BUG-017 แก้ + ผ่าน L1 217/217 + L2 26/26** (1 ตุลาคม 2026)
8. ✅ **CR-PC-ONLY (รอบ 8): PC/Desktop only บน Volt — ตัด MobileLayout/MC-012/VA-033 + DoD §5.4 ฉบับ PC-only + PC-only guard + Matrix 148 แถว active + SSOT v1.6 (38/53) — ผ่าน L1 216/216 + L2 26/26** (1 ตุลาคม 2026)

## วิธีรันชุดทดสอบ (verify รวมทุกชั้น)

```bash
cd /home/z/my-project/thevoider
npm run verify    # graph validation 3 ชั้น + lint adapter + build จริง + L1 (216 เคส) + L2 (26 ฉาก)
# แยกรายชั้น: npm run graph | npm run lint | npm test | npm run l2
```

ผลที่ต้องเห็น: `[gen_graph] PASS` + `[lint_adapter] PASS` + `L1_ALL_GREEN` + `L2_ALL_GREEN`

## สถาปัตยกรรม Runtime Layer ในหนึ่งบรรทัด (§3.2)

`Bootstrap Preflight (loader) → Capability probe จริง 8 ตัว → ทุกทรัพยากรผ่าน Registry 4 ชนิด
→ error โดนจับรายโมดูลที่ Boundary → โมดูลเงียบโดน Watchdog restart 1 ครั้งแล้วปิด
→ ปิดทั้งระบบตาม Dependency Graph กลับด้าน — orphan = 0 ตรวจรวมทุกชนิดเสมอ`

## สถาปัตยกรรม Foundation + Game Adapter ในหนึ่งบรรทัด (§3.5 + §3.3 + §3.7)

`Event Bus (freeze/replay ตาม policy) สำหรับ lifecycle/config/notify — Direct Services สำหรับ hot path
→ Config + migration ลูกโซ่ (ห้ามข้ามขั้น + ห้ามทิ้ง + .bak เมื่อเสีย) + i18n ไทย/อังกฤษ + keybind ผ่าน InputAdapter
→ Game Adapter 6 API คือประตูเดียวสู่เกม (lint บังคับ) + Self-Probe รายงานสายตายตาม graph
→ Diagnostics Export พร้อมใช้ก่อนฟีเจอร์หลัก (Registry 4 ชนิดสด / bus / adapter health / stack trace)`
