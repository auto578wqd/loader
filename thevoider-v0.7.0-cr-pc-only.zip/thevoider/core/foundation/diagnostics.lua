-- ============================================================================
-- The Voider — core/foundation/diagnostics.lua
-- Developer Diagnostics — รุ่นแรก (แผน freeze v2.1 §8.4 + §5.3)
--
--   เกณฑ์ของรอบนี้ (เจ้าของโปรเจกต์กำหนด): "Diagnostics ต้องใช้งานได้ก่อน
--   feature ใหญ่" — เมื่อฟีเจอร์หลักเริ่มมีปัญหา ต้องเห็นหลักฐานจาก runtime
--   ทันที แทนการเดาว่าเป็น adapter / resource / scheduler / config
--
--   สิ่งที่ดูได้แล้วรุ่นนี้ (ตามตาราง §8.4):
--     Registry   จำนวน resource ทั้ง 4 ชนิด สด ๆ (task/connection/render/temp)
--     Event Bus  subscribers / events/sec / คิวค้าง / undeclared
--     Services   จำนวน Direct Service ที่ลงทะเบียน
--     Keybind    actions / listeners / input ต่อแล้วหรือยัง
--     ระบบ       Capability Report (8 ตัว), Adapter Health (6 API),
--                เวลา startup / config load / hot update ล่าสุด, boundary errors
--     หน่วยความจำ gcinfo (ถ้าสภาพแวดล้อมมี) — กราฟย้อนหลังผ่าน Sample()
--     เฟรม       Begin/End(name) — ต้นทุนต่อโมดูล min/avg/max (โมดูลเรียกเอง)
--     เครื่องมือ  Export() → ข้อความรายงานครบ + stack trace ล่าสุด
--
--   ที่ยังมาในเฟสถัดไป: กราฟ memory 15 นาทีแบบวาดจริง + FPS จาก render loop
--   (เฟส 1 UI) + ESP objects / Macro queue (เฟส 2-3 เมื่อโมดูลมีจริง)
-- ============================================================================

local Diag = {}
Diag.__index = Diag

Diag.VERSION = "0.2.0"

Diag.MAX_SAMPLES = 180 -- 15 นาที ณ ช่วง sample 5 วินาที

function Diag.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    time = ctx.time or os.time,
    bus = ctx.bus,               -- Event Bus (อ่าน Stats)
    registry = ctx.registry,     -- Resource Registry (นับ 4 ชนิดสด)
    boundary = ctx.boundary,     -- Error Boundary (records + counters)
    capability = ctx.capability, -- CapabilityDetection (Report)
    services = ctx.services,     -- Service Registry (Stats)
    keybind = ctx.keybind,       -- KeybindService (Stats)
    i18n = nil,                  -- ต่อภายหลังผ่าน SetI18n (labels ตอน Export)
    fpsProvider = ctx.fpsProvider, -- optional: function() → FPS (มาในเฟส 1)
    samples = {},                -- ring buffer ย้อนหลัง
    timers = {},                 -- [name] = { count, total, min, max, openAt }
    marks = {},                  -- [name] = ค่าล่าสุด (startupMs ฯลฯ)
    adapterHealth = nil,         -- รายงานล่าสุดจาก AdapterSelfProbe
    startedAt = nil,
  }, Diag)
  return self
end

--- ต่อ i18n หลังพร้อม (labels ของ Export)
function Diag:SetI18n(i18n)
  self.i18n = i18n
  return self
end

--- ต่อ keybind/service หลังพร้อม (สร้างพร้อมกันทั้งชุดใน foundation init)
function Diag:SetSources(services, keybind)
  self.services = services
  self.keybind = keybind
  return self
end

--- ต่อ FPS provider (เฟส 1 UI §8.4 "FPS จริง" — HUD วัดจาก frame task
--- แล้วต่อเข้ามาให้ Snapshot/Export เห็นค่า) — additive รุ่นนี้
function Diag:SetFpsProvider(fn)
  if fn ~= nil and type(fn) ~= "function" then
    error("Diag:SetFpsProvider(fn): fn ต้องเป็น function หรือ nil", 2)
  end
  self.fpsProvider = fn
  return self
end

--- อนุกรม sample ย้อนหลัง (สำเนา) — กราฟ memory 15 นาที §8.4
--- (เฟส 1 UI นำไปวาดจริงในแผง Diagnostics เต็มรูปแบบ)
function Diag:MemorySeries()
  local out = {}
  for i, s in ipairs(self.samples) do
    out[i] = {
      at = s.at,
      memoryKb = s.memoryKb,
      registry = s.registry,
      busQueued = s.busQueued,
      busPerSec = s.busPerSec,
    }
  end
  return out
end

function Diag:SetAdapterHealth(report)
  self.adapterHealth = report
  return self
end

-- ---- per-module frame timer (§8.4 "ต้นทุนต่อโมดูล") ---------------------------

--- เริ่มจับเวลาชื่อโมดูล — คู่กับ End(name) เสมอ (โมดูลเรียกใน Update(dt) ของตัวเอง)
function Diag:Begin(name)
  local t = self.timers[name]
  if not t then
    t = { count = 0, total = 0, min = math.huge, max = 0, openAt = nil }
    self.timers[name] = t
  end
  t.openAt = self.clock()
end

--- จบจับเวลา — คืน ms ของรอบนี้
function Diag:End(name)
  local t = self.timers[name]
  if not t or not t.openAt then
    return nil
  end
  local ms = (self.clock() - t.openAt) * 1000
  t.openAt = nil
  t.count = t.count + 1
  t.total = t.total + ms
  if ms < t.min then t.min = ms end
  if ms > t.max then t.max = ms end
  return ms
end

-- ---- ตัวชี้วัดเหตุการณ์ -----------------------------------------------------------

--- บันทึก metric จุดเหตุการณ์: startupMs / configLoadMs / hotUpdateMs / ...
function Diag:Mark(name, value)
  self.marks[name] = value
  return self
end

function Diag:MarkStartup(ms)
  self.startedAt = self.time()
  return self:Mark("startupMs", ms)
end

-- ---- sampling (ย้อนหลัง / กราฟ memory รอบหน้า) ----------------------------------

--- เก็บภาพสถานะ 1 ชุดลง ring buffer (เรียกเป็นระยะจาก heartbeat ของระบบ)
function Diag:Sample()
  local snap = self:Collect()
  table.insert(self.samples, {
    at = snap.time,
    memoryKb = snap.memoryKb,
    registry = snap.registry,
    busQueued = snap.bus.queued,
    busPerSec = snap.bus.perSec,
  })
  if #self.samples > Diag.MAX_SAMPLES then
    table.remove(self.samples, 1)
  end
  return #self.samples
end

--- รวบรวมสถานะปัจจุบันทุก section (ใช้ทั้ง Sample / Snapshot / Export)
function Diag:Collect()
  local memoryKb
  if type(gcinfo) == "function" then
    memoryKb = gcinfo()
  elseif type(collectgarbage) == "function" then
    local ok, v = pcall(collectgarbage, "count")
    if ok and type(v) == "number" then memoryKb = v end
  end

  local registryCounts = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 }
  if self.registry then
    registryCounts = self.registry:Snapshot()
  end

  local busStats = { subscribers = 0, perSec = 0, queued = 0, published = 0 }
  if self.bus then
    busStats = self.bus:Stats()
  end

  local serviceStats = { count = 0 }
  if self.services then
    serviceStats = self.services:Stats()
  end

  local keybindStats = { actions = 0, listeners = 0, inputAttached = false }
  if self.keybind then
    keybindStats = self.keybind:Stats()
  end

  local boundaryCounters = {}
  local boundaryRecords = {}
  if self.boundary then
    boundaryCounters = self.boundary:Counters()
    boundaryRecords = self.boundary:Records()
  end

  local fps
  if type(self.fpsProvider) == "function" then
    local ok, v = pcall(self.fpsProvider)
    if ok and type(v) == "number" then fps = v end
  end

  return {
    time = self.time(),
    memoryKb = memoryKb,
    fps = fps,
    registry = registryCounts,
    bus = busStats,
    services = serviceStats,
    keybind = keybindStats,
    boundaryCounters = boundaryCounters,
    boundaryErrorTotal = #boundaryRecords,
    capability = self.capability and self.capability:Report() or nil,
    adapterHealth = self.adapterHealth,
    marks = self.marks,
    timers = self.timers,
    uptimeSec = self.startedAt and (self.time() - self.startedAt) or 0,
  }
end

--- สำเนาสถานะปัจจุบัน (ใช้ตรวจค่าจากโค้ด/เทส)
function Diag:Snapshot()
  return self:Collect()
end

--- จำนวน sample ที่เก็บไว้ (ตรวจว่า sampling เดินจริง)
function Diag:SampleCount()
  return #self.samples
end

-- ---- export (เครื่องมือหลักของ §8.4) ----------------------------------------------

local function fmtMs(v)
  if v == nil then return "-" end
  return ("%.2f ms"):format(v)
end

local function fmtKb(v)
  if v == nil then return "-" end
  return ("%.0f KB"):format(v)
end

--- รายงานทั้งหมดเป็นข้อความ — ส่งให้ทีมได้ทันทีเมื่อมีบั๊ก
--- (พร้อม stack trace ล่าสุดจาก Error Boundary)
function Diag:Export()
  local s = self:Collect()
  local lines = {}
  local function add(fmt, ...)
    lines[#lines + 1] = fmt:format(...)
  end
  local function label(key, fallback)
    if self.i18n then
      return self.i18n:T(key)
    end
    return fallback
  end

  add("===== The Voider — Diagnostics Export =====")
  add("เวลา: %s | uptime: %ds | version: %s", tostring(s.time), s.uptimeSec, Diag.VERSION)

  -- Registry
  add("-- Registry (ทั้ง 4 ชนิด — ควรกลับเป็น 0 หลังปิดโมดูล)")
  add("   task=%d connection=%d render=%d temp=%d (total=%d)",
    s.registry.tasks, s.registry.connections, s.registry.renders, s.registry.temps, s.registry.total)

  -- Event Bus
  add("-- Event Bus")
  add("   subscribers=%d events/sec=%d คิวค้าง=%d (frozen=%s) published=%s undeclared=%d subscriberErrors=%d",
    s.bus.subscribers, s.bus.perSec, s.bus.queued, tostring(s.bus.frozen), tostring(s.bus.published), s.bus.undeclared, s.bus.subscriberErrors)

  -- Services
  add("-- Direct Services: %d รายการ", s.services.count)

  -- Keybind
  add("-- Keybind: actions=%d listeners=%d input=%s",
    s.keybind.actions, s.keybind.listeners, s.keybind.inputAttached and "attached" or "ยังไม่ต่อ")

  -- เฟรม / หน่วยความจำ
  add("-- เฟรม/หน่วยความจำ")
  add("   memory=%s fps=%s", fmtKb(s.memoryKb), s.fps and ("%.0f"):format(s.fps) or "n/a (เฟส 1)")
  local timerNames = {}
  for name in pairs(s.timers) do
    timerNames[#timerNames + 1] = name
  end
  table.sort(timerNames)
  if #timerNames > 0 then
    for _, name in ipairs(timerNames) do
      local t = s.timers[name]
      if t.count > 0 then
        add("   [%s] n=%d min=%s avg=%s max=%s", name, t.count,
          fmtMs(t.min), fmtMs(t.total / t.count), fmtMs(t.max))
      end
    end
  else
    add("   (ยังไม่มีโมดูลลงทะเบียนจับเวลา)")
  end

  -- ระบบ
  add("-- ระบบ")
  add("   startup=%s configLoad=%s hotUpdate=%s",
    fmtMs(s.marks.startupMs), fmtMs(s.marks.configLoadMs), fmtMs(s.marks.hotUpdateMs))
  if s.capability then
    local parts = {}
    local names = {}
    for n in pairs(s.capability) do names[#names + 1] = n end
    table.sort(names)
    for _, n in ipairs(names) do
      parts[#parts + 1] = ("%s=%s"):format(n, s.capability[n].supported and "Y" or "N")
    end
    add("   capability: %s", table.concat(parts, " "))
  else
    add("   capability: (ยังไม่ probe)")
  end
  if s.adapterHealth then
    add("   adapter: %s", s.adapterHealth.summary or "(ไม่มีสรุป)")
    local apiNames = {}
    for n in pairs(s.adapterHealth.adapters or {}) do
      apiNames[#apiNames + 1] = n
    end
    table.sort(apiNames)
    for _, n in ipairs(apiNames) do
      local a = s.adapterHealth.adapters[n]
      add("     - %s: %s%s", n, a.status, a.deadMethods and #a.deadMethods > 0
        and (" (ตาย: %s)"):format(table.concat(a.deadMethods, ",")) or "")
    end
  else
    add("   adapter: (ยังไม่ probe)")
  end

  -- Error Boundary
  add("-- Error Boundary: errors ล่าสุด %d รายการ", s.boundaryErrorTotal)
  local counters = {}
  for owner in pairs(s.boundaryCounters) do
    counters[#counters + 1] = owner
  end
  table.sort(counters)
  for _, owner in ipairs(counters) do
    add("   [%s] %d ครั้ง", owner, s.boundaryCounters[owner])
  end
  if self.boundary then
    local recs = self.boundary:Records()
    for i = math.max(1, #recs - 4), #recs do
      local r = recs[i]
      if r then
        add("   • %s: %s", tostring(r.owner), tostring(r.err))
      end
    end
  end

  add("===== จบรายงาน — แนบไฟล์นี้กับรายงานบั๊กเสมอ =====")
  return table.concat(lines, "\n")
end

--- Export + คัดลอกลง clipboard ถ้าสภาพแวดล้อมมี (คืนข้อความเสมอ)
function Diag:ExportToClipboard()
  local text = self:Export()
  local setClip = rawget(_G, "setclipboard")
  if type(setClip) == "function" then
    pcall(setClip, text)
    return text, true
  end
  return text, false
end

--- ปิด node (TEARDOWN) — ล้าง ring buffer (resource ทั้งหมดของ Diag อยู่ใน memory เท่านั้น)
function Diag:Shutdown()
  self.samples = {}
  return true
end

return Diag
