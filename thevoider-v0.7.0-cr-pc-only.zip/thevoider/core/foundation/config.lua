-- ============================================================================
-- The Voider — core/foundation/config.lua
-- Config Service (แผน freeze v2.1 §3.7) — config ของผู้ใช้คือของมีค่า
--
--   โครงสร้างทุกไฟล์: { schemaVersion, profile = {...}, settings = {...} }
--   พื้นที่เก็บ: FILEIO ของ executor ถ้ามี (thevoider/config.json)
--               ไม่มี = หน่วยความจำ (สถานะเดียวกับ "ไม่ persist" — ต้องแจ้งผู้ใช้)
--
--   Fallback เมื่อไฟล์เสีย (§3.7): parse ไม่ผ่าน / migrate ไม่ผ่าน
--     → สำรองไฟล์เก่าเป็น .bak พร้อม timestamp → โหลด default
--     → แจ้งผู้ใช้ผ่าน Event Bus ("notify:user") + เปิดโหลด .bak คืนได้ (ListBackups)
--
--   เหตุการณ์ที่ประกาศ (Declare ตอน Init):
--     config:changed  (replay)     — Set() เปลี่ยนค่า { path, value }
--     config:replaced (replay)     — Replace() ทั้งก้อน (hot update/rollback)
--     config:loaded   (idempotent) — โหลด/เริ่มระบบเสร็จ { source }
--     config:saved    (idempotent) — Save() สำเร็จ { at }
--     notify:user     (idempotent) — ข้อความถึงผู้ใช้ { level, key, params }
--
--   migration จริงตัวแรก (§3.7): v1→v2 ย้าย settings.Aimbot.FOV →
--   settings.VoidAim.fov + เก็บค่าเก่าไว้ใน _legacy (ห้ามทิ้ง)
-- ============================================================================

local P = __TV_PACKAGES
local JsonLib = P.json

local Config = {}
Config.__index = Config

Config.VERSION = "0.2.0"

Config.CURRENT_SCHEMA_VERSION = 2

Config.FILE_PREFIX = "thevoider/config"

-- ---- default ---------------------------------------------------------------

function Config.Default()
  return {
    schemaVersion = Config.CURRENT_SCHEMA_VERSION,
    profile = {
      name = "หลัก",
      createdAt = os.time(),
      updatedAt = os.time(),
    },
    settings = {
      VoidAim = { mode = "EZ", fov = 120 }, -- โครงตาม §3.7 (โมดูลจริงมาเฟส 2)
      i18n = { lang = "th" },
      Keybinds = {},
    },
  }
end

-- ---- helpers ----------------------------------------------------------------

local function deepClone(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for k, val in pairs(v) do
    out[k] = deepClone(val)
  end
  return out
end

local function splitPath(path)
  local parts = {}
  for seg in string.gmatch(path, "[^.]+") do
    parts[#parts + 1] = seg
  end
  if #parts == 0 then
    error(("Config: path %q ว่าง"):format(tostring(path)), 3)
  end
  return parts
end

-- path สองระดับตามโครง §3.7:
--   "schemaVersion" / "profile.*" / "settings.*" / "_legacy" → ระดับบนสุดของ config
--   "VoidAim.fov" / "i18n.lang" / "Keybinds.toggle"       → อยู่ใต้ cfg.settings เสมอ
-- (โมดูลไม่ต้องเขียน "settings." นำหน้า — แต่โครงไฟล์ยังตรงแผน §3.7)
local RESERVED_TOP = {
  schemaVersion = true,
  profile = true,
  settings = true,
  _legacy = true,
}

local function resolveForGet(cfg, path)
  local parts = splitPath(path)
  if RESERVED_TOP[parts[1]] then
    return cfg, parts
  end
  return (type(cfg.settings) == "table") and cfg.settings or {}, parts
end

local function resolveForSet(cfg, path)
  local parts = splitPath(path)
  if RESERVED_TOP[parts[1]] then
    return cfg, parts
  end
  if type(cfg.settings) ~= "table" then
    cfg.settings = {}
  end
  return cfg.settings, parts
end

-- ---- constructors ------------------------------------------------------------

-- storage แบบไฟล์ executor (FILEIO)
local function fileStorage(path)
  local readFileFn = rawget(_G, "readfile")
  local writeFileFn = rawget(_G, "writefile")
  local isFileFn = rawget(_G, "isfile")
  return {
    kind = "file",
    path = path,
    exists = function() return isFileFn and isFileFn(path) or false end,
    read = function()
      if not readFileFn then return nil, "ไม่มี readfile" end
      local ok, content = pcall(readFileFn, path)
      if not ok then return nil, tostring(content) end
      return content
    end,
    write = function(content)
      if not writeFileFn then return false, "ไม่มี writefile" end
      local ok, err = pcall(writeFileFn, path, content)
      if not ok then return false, tostring(err) end
      return true
    end,
  }
end

-- storage แบบหน่วยความจำ (ทดสอบ / executor ไม่มี FILEIO)
local function memoryStorage()
  local mem = {}
  return {
    kind = "memory",
    exists = function() return mem.data ~= nil end,
    read = function()
      if mem.data == nil then return nil, "ยังไม่เคยเขียน" end
      return mem.data
    end,
    write = function(content)
      mem.data = content
      return true
    end,
  }
end

function Config.new(ctx)
  ctx = ctx or {}
  local storage
  if ctx.storage then
    storage = ctx.storage
  elseif rawget(_G, "readfile") and rawget(_G, "writefile") and rawget(_G, "isfile") then
    storage = fileStorage(ctx.path or (Config.FILE_PREFIX .. ".json"))
  else
    storage = memoryStorage()
  end
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    time = ctx.time or os.time,
    bus = ctx.bus,                 -- Event Bus (ส่ง config:changed / notify:user)
    migration = ctx.migration,     -- Migration Service
    storage = storage,
    cfg = nil,                     -- ตาราง config ปัจจุบัน (แก้หลัง Load)
    status = "not-loaded",         -- not-loaded | default | file | migrated | corrupted | migration-failed
    loadInfo = nil,                -- รายละเอียดรอบโหลดล่าสุด
    dirty = false,
    backups = {},                  -- รายการ .bak ที่สร้าง [{ name, at }]
  }, Config)
  self:_registerMigrations()
  return self
end

-- ---- migration จริงตัวแรก (§3.7: Aimbot.FOV → VoidAim.fov) -------------------

function Config:_registerMigrations()
  local m = self.migration
  if not m then return end
  -- v1 → v2: ย้ายชื่อชั่วคราวระหว่างพัฒนา "Aimbot.FOV" → "VoidAim.fov"
  m:Register(1, function(cfg)
    cfg.settings = cfg.settings or {}
    cfg.settings.VoidAim = cfg.settings.VoidAim or {}
    local old = cfg.settings.Aimbot
    if type(old) == "table" and old.FOV ~= nil then
      -- ห้ามเขียนทับค่าใหม่ถ้ามีอยู่แล้ว (last config wins)
      if cfg.settings.VoidAim.fov == nil then
        cfg.settings.VoidAim.fov = old.FOV
      end
      -- ห้ามทิ้ง (§3.7): เก็บของเก่าไว้ใน _legacy เสมอ
      self.migration.Keep(cfg, "settings.Aimbot", old)
    end
    cfg.settings.Aimbot = nil
    return cfg
  end)
end

-- ---- internal ----------------------------------------------------------------

function Config:_notify(level, key, params)
  if self.bus then
    self.bus:Publish("notify:user", { level = level, key = key, params = params or {} })
  end
end

function Config:_backupCorrupt(content, why)
  -- สำรองไฟล์เสียเป็น .bak พร้อม timestamp ก่อนทำอย่างอื่น (§3.7)
  local name = ("%s.corrupt-%d.bak"):format(self.storage.path or "memory", self.time())
  table.insert(self.backups, { name = name, at = self.time(), reason = tostring(why), kind = "corrupt" })
  if #self.backups > 10 then
    table.remove(self.backups, 1)
  end
  -- หมายเหตุ: storage แบบไฟล์จริงเขียน .bak ผ่าน writefile ถ้ามี
  local writeFileFn = rawget(_G, "writefile")
  if self.storage.kind == "file" and writeFileFn and type(content) == "string" then
    pcall(writeFileFn, name, content)
  end
end

-- ---- API หลัก ------------------------------------------------------------------

--- โหลด config — ลำดับ: ไฟล์ (→ decode → migrate) → default เมื่อเสีย
--- คืน { status, migratedFrom?, error? } — ไม่มีทาง error ยกเละ (ทุก path ได้ config ใช้ได้)
function Config:Load()
  -- อ่านไฟล์
  local content, readErr = self.storage.read()
  if content == nil then
    self.cfg = Config.Default()
    self.status = "default"
    self.loadInfo = { status = self.status, reason = tostring(readErr) }
    self:_notify("info", "notify.config.default", {})
    return self.loadInfo
  end

  -- decode
  local ok, decoded = pcall(JsonLib.decode, content)
  if not ok or type(decoded) ~= "table" then
    self:_backupCorrupt(content, decoded)
    self.cfg = Config.Default()
    self.status = "corrupted"
    self.loadInfo = { status = self.status, error = tostring(decoded) }
    self:_notify("warn", "notify.config.corrupted", { backup = self.backups[#self.backups] and self.backups[#self.backups].name or "" })
    return self.loadInfo
  end

  -- migrate สู่รุ่นปัจจุบัน (ห้ามข้ามขั้น — ขั้นขาด = error = fallback)
  local migratedFrom
  if self.migration and type(decoded.schemaVersion) == "number"
      and decoded.schemaVersion < Config.CURRENT_SCHEMA_VERSION then
    local okM, migrated = pcall(self.migration.Run, self.migration, decoded, Config.CURRENT_SCHEMA_VERSION)
    if not okM then
      self:_backupCorrupt(content, migrated)
      self.cfg = Config.Default()
      self.status = "migration-failed"
      self.loadInfo = { status = self.status, error = tostring(migrated) }
      self:_notify("warn", "notify.config.migration_failed", {})
      return self.loadInfo
    end
    decoded = migrated
    migratedFrom = true
  end

  -- เติม field ที่หาย (default merge แบบตื้น: เฉพาะระดับบน + settings รายโมดูล)
  decoded.profile = decoded.profile or Config.Default().profile
  decoded.settings = decoded.settings or {}
  self.cfg = decoded
  self.status = migratedFrom and "migrated" or "file"
  self.loadInfo = { status = self.status, migratedFrom = migratedFrom }
  self:_notify("info", "notify.config.loaded", { source = self.status })
  if self.bus then
    self.bus:Publish("config:loaded", { source = self.status })
  end
  return self.loadInfo
end

--- บันทึก config ลง storage — คืน (true) หรือ (false, err)
function Config:Save()
  if not self.cfg then
    return false, "ยังไม่ได้ Load()"
  end
  self.cfg.profile.updatedAt = self.time()
  local okEnc, encoded = pcall(JsonLib.encode, self.cfg)
  if not okEnc then
    return false, ("เข้ารหัสไม่ผ่าน: %s"):format(tostring(encoded))
  end
  local okW, errW = self.storage.write(encoded)
  if not okW then
    return false, ("เขียนไฟล์ไม่ผ่าน: %s"):format(tostring(errW))
  end
  self.dirty = false
  if self.bus then
    self.bus:Publish("config:saved", { at = self.time() })
  end
  return true
end

--- อ่านค่าตาม path — คืน (value) หรือ (nil) — path ระดับโมดูล (เช่น "VoidAim.fov")
--- อยู่ใต้ settings อัตโนมัติ ส่วนระดับบนสุด (schemaVersion/profile/...) อ่านตรง
function Config:Get(path)
  if not self.cfg then
    error("Config:Get: ยังไม่ได้ Load()", 2)
  end
  local cur, parts = resolveForGet(self.cfg, path)
  for _, seg in ipairs(parts) do
    if type(cur) ~= "table" then return nil end
    cur = cur[seg]
  end
  return cur
end

--- ตั้งค่า + ประกาศ config:changed — opts.save = true → Save ทันที
function Config:Set(path, value, opts)
  if not self.cfg then
    error("Config:Set: ยังไม่ได้ Load()", 2)
  end
  local cur, parts = resolveForSet(self.cfg, path)
  for i = 1, #parts - 1 do
    local seg = parts[i]
    if type(cur[seg]) ~= "table" then
      cur[seg] = {}
    end
    cur = cur[seg]
  end
  cur[parts[#parts]] = value
  self.dirty = true
  if self.bus then
    self.bus:Publish("config:changed", { path = path, value = value })
  end
  if opts and opts.save then
    return self:Save()
  end
  return true
end

--- สำเนา config ทั้งก้อน (สำหรับ Rollback Snapshot configState §3.6)
function Config:Data()
  if not self.cfg then return nil end
  return deepClone(self.cfg)
end

--- แทนที่ config ทั้งก้อน (hot update MIGRATE สำเร็จ / rollback กลับรุ่นเก่า)
--- cfg ต้องเป็น table ที่ schemaVersion = ปัจจุบันแล้ว
function Config:Replace(cfg)
  if type(cfg) ~= "table" then
    error("Config:Replace(cfg): cfg ต้องเป็น table", 2)
  end
  if cfg.schemaVersion ~= Config.CURRENT_SCHEMA_VERSION then
    error(("Config:Replace: schemaVersion ต้องเป็น %d (ได้ %s) — migrate ก่อน")
      :format(Config.CURRENT_SCHEMA_VERSION, tostring(cfg.schemaVersion)), 2)
  end
  self.cfg = deepClone(cfg)
  self.dirty = true
  if self.bus then
    self.bus:Publish("config:replaced", {})
  end
  return true
end

--- สถานะการ persist — Diagnostics แสดงเตือนเมื่อ "ไม่ persist"
function Config:StorageKind()
  return self.storage.kind
end

--- รายการ backup ที่สร้างไว้ (แท็บ Setup จะให้โหลดคืน — เฟส 1)
function Config:ListBackups()
  local out = {}
  for _, b in ipairs(self.backups) do
    table.insert(out, { name = b.name, at = b.at, reason = b.reason })
  end
  return out
end

--- ปิด node (TEARDOWN) — Save ถ้า dirty และ persist ได้ (พยายามเก็บของผู้ใช้เสมอ)
function Config:Shutdown()
  if self.dirty then
    local ok, err = pcall(self.Save, self)
    if not ok then
      self:_notify("warn", "notify.config.save_failed", { error = tostring(err) })
    end
  end
  return true
end

return Config
