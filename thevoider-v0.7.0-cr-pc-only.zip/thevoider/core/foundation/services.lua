-- ============================================================================
-- The Voider — core/foundation/services.lua
-- Service Registry — Direct Services (แผน freeze v2.1 §3.5)
--
--   hot path (target query, prediction, camera state, combat state, คำนวณ
--   per-frame) เรียกตรงผ่าน service interface — ไม่ผ่าน event
--
--   กฎคู่ของ Services (§3.5):
--     (1) Service = สำหรับ "query" ที่ตอบเร็ว ไม่มี side effect แฝง
--         → Define() บังคับว่าทุก field ต้องเป็น function เท่านั้น
--     (2) ถ้าการทำงานนั้นเปลี่ยน state ที่โมดูลอื่นสนใจ → ต้องประกาศผ่าน
--         Event Bus เสมอ (service ไม่แจ้งเอง = ใครก็ไม่พลาด event)
--
--   ผู้ใช้จริง: L4 Shared Services (TargetService, PredictionService,
--   CameraService, CombatStateService) จะ Define ที่นี่ในเฟสถัด ๆ ไป
-- ============================================================================

local Services = {}
Services.__index = Services

Services.VERSION = "0.2.0"

function Services.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    services = {},  -- [name] = interface table (function เท่านั้น)
    order = {},     -- ชื่อตามลำดับ Define (แสดงใน Diagnostics สม่ำเสมอ)
    history = {},   -- บันทึกการ Define/Replace (audit ตอน hot update)
  }, Services)
  return self
end

--- ลงทะเบียน service — iface ต้องเป็น table ที่ทุก field เป็น function
--- opts.replace = true → อนุญาตแทนที่ของเดิม (ใช้ตอน hot update รุ่นใหม่)
function Services:Define(name, iface, opts)
  opts = opts or {}
  if type(name) ~= "string" or #name == 0 then
    error("Services:Define(name, iface): name ต้องเป็น string ไม่ว่าง", 2)
  end
  if type(iface) ~= "table" then
    error(("Services:Define(%s): iface ต้องเป็น table"):format(name), 2)
  end
  for k, v in pairs(iface) do
    if type(v) ~= "function" then
      error(("Services:Define(%s): field '%s' ต้องเป็น function — service เป็น query-only (§3.5 กฎ 1)")
        :format(name, tostring(k)), 2)
    end
  end
  local existed = self.services[name] ~= nil
  if existed and not opts.replace then
    error(("Services:Define(%s): ชื่อนี้มีอยู่แล้ว — ใช้ opts.replace = true เพื่อแทนที่ (hot update)")
      :format(name), 2)
  end
  if not existed then
    table.insert(self.order, name)
  end
  self.services[name] = iface
  table.insert(self.history, {
    op = existed and "replace" or "define",
    name = name,
    at = os.clock(),
  })
  if #self.history > 100 then
    table.remove(self.history, 1)
  end
  return self
end

--- ถอน service (TEARDOWN ของผู้ให้บริการ)
function Services:Undefine(name)
  if self.services[name] == nil then
    return false
  end
  self.services[name] = nil
  for i, n in ipairs(self.order) do
    if n == name then
      table.remove(self.order, i)
      break
    end
  end
  table.insert(self.history, { op = "undefine", name = name, at = os.clock() })
  return true
end

--- ดึง service — คืน iface หรือ nil (hot path ต้องไม่ error — เช็ค nil เอง)
function Services:Get(name)
  return self.services[name]
end

--- ดึง service แบบบังคับ — ไม่มี = error ชัดเจนพร้อมรายชื่อที่มีจริง
--- (ใช้ตอน Init ของโมดูลเพื่อ fail-fast ตาม dependency graph)
function Services:MustGet(name)
  local svc = self.services[name]
  if not svc then
    local avail = #self.order > 0 and table.concat(self.order, ", ") or "(ไม่มีเลย)"
    error(("Services:MustGet(%s): service นี้ยังไม่ถูก Define — ที่มีอยู่: %s"):format(name, avail), 2)
  end
  return svc
end

--- รายชื่อ service ทั้งหมดเรียงตามลำดับ Define
function Services:List()
  local out = {}
  for i, n in ipairs(self.order) do
    out[i] = n
  end
  return out
end

--- สถิติ (Diagnostics §8.4)
function Services:Stats()
  return { count = #self.order }
end

return Services
