-- ============================================================================
-- The Voider — core/foundation/keybind.lua
-- Keybind Service (แผน freeze v2.1 §5.3) — คีย์ลัด + `Trigger` path เดียวกับคีย์จริง
-- [CR-PC-ONLY 1 ต.ค. 2026] เดิมระบุ "ปุ่มลัดมือถือ" — ปรับคำตาม dependencies.md v1.6
--
--   Bind(action, key)      ผูกคีย์ → action (ตรวจชนก่อนเสมอ + บันทึกลง config)
--   Unbind(action)         ปลดผูก
--   OnAction(action, fn)   สมัครฟัง action (subscription ผ่าน Resource Registry —
--                          orphan=0 อัตโนมัติเมื่อ module Destroy §3.4)
--   Trigger(action)        จำลองการกด (ปุ่ม UI ใช้ API เดียวกับคีย์จริง)
--   AttachInput(adapter)   ต่อกับ InputAdapter — เรียกหลัง adapter พร้อม
--                          (KeybindService อยู่ L2, InputAdapter อยู่ L3 ตาม graph
--                          — จึงต่อกันที่ runtime ไม่ใช่ตอน init ตาม SSOT §3.10)
--
--   เหตุการณ์: keybind:changed (replay) { action, key } — keybind เป็น state
--   ของผู้ใช้ → replay ระหว่าง hot update (§3.6)
-- ============================================================================

local Keybind = {}
Keybind.__index = Keybind

Keybind.VERSION = "0.2.0"

Keybind.CONFIG_PATH = "Keybinds"

function Keybind.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    bus = ctx.bus,
    config = ctx.config,       -- ConfigService (บันทึก/โหลด Keybinds)
    registry = ctx.registry,   -- Resource Registry (optional — subscription เป็น temp)
    boundary = ctx.boundary,   -- Error Boundary (optional)
    hostOwner = ctx.owner or "KeybindService",
    input = nil,               -- InputAdapter (AttachInput ภายหลัง)
    _inputSub = nil,           -- handle ของ OnInput
    keyToAction = {},          -- [keyCode] = action
    actionToKey = {},          -- [action] = keyCode
    listeners = {},            -- [action] = { {fn, owner, handle?} ... }
  }, Keybind)
  return self
end

-- ---- internal ----------------------------------------------------------------

function Keybind:_offListener(action, item)
  local list = self.listeners[action]
  if not list then return end
  for i, x in ipairs(list) do
    if x == item then
      table.remove(list, i)
      return true
    end
  end
  return false
end

function Keybind:_persist(action, key)
  if not self.config then return end
  if key then
    self.config:Set(("%s.%s"):format(Keybind.CONFIG_PATH, action), key, { save = true })
  else
    self.config:Set(("%s.%s"):format(Keybind.CONFIG_PATH, action), nil, { save = true })
  end
end

function Keybind:_dispatch(action)
  local list = self.listeners[action]
  if not list or #list == 0 then return 0 end
  local targets = {}
  for _, x in ipairs(list) do
    targets[#targets + 1] = x
  end
  local n = 0
  for _, x in ipairs(targets) do
    n = n + 1
    if self.boundary then
      self.boundary:Guard(x.owner, function()
        x.fn(action)
      end)
    else
      pcall(x.fn, action)
    end
  end
  return n
end

-- ---- attach input (หลัง InputAdapter พร้อม — L3) ------------------------------

--- ต่อกับ InputAdapter — ฟัง input แบบ "กดลง" เพื่อ trigger action
--- (hold ตรวจผ่าน IsKeyDown ของ adapter เอง)
function Keybind:AttachInput(inputAdapter)
  if self.input then
    error("Keybind:AttachInput: ต่อ InputAdapter แล้ว (ห้ามต่อซ้ำ)", 2)
  end
  if not inputAdapter or type(inputAdapter.OnInput) ~= "function" then
    error("Keybind:AttachInput(inputAdapter): ต้องเป็น InputAdapter (มี OnInput)", 2)
  end
  self.input = inputAdapter
  -- subscription ของตัว KeybindService เอง — จองใน Scope ชื่อ node
  -- เพื่อให้ connection ตกเป็น resource ของ "KeybindService" ตาม graph
  -- (Shutdown ตรวจ orphan ราย node ได้ตรงตัว §3.10)
  local attach = function()
    self._inputSub = inputAdapter:OnInput(function(input)
      if input and input.state == "down" and input.key then
        local action = self.keyToAction[input.key]
        if action then
          self:_dispatch(action)
        end
      end
    end)
  end
  if self.registry then
    self.registry:Scope(self.hostOwner, attach)
  else
    attach()
  end
  return self
end

-- ---- binding -------------------------------------------------------------------

--- ผูกคีย์ → action — คืน (true) หรือ (false, { conflictedWith = action })
--- คีย์ที่ถูกใช้แล้ว = ปฏิเสธ (ไม่เขียนทับเงียบ ๆ) + แจ้งเตือนผู้ใช้
function Keybind:Bind(action, key)
  if type(action) ~= "string" or #action == 0 then
    error("Keybind:Bind(action, key): action ต้องเป็น string ไม่ว่าง", 2)
  end
  if type(key) ~= "string" or #key == 0 then
    error(("Keybind:Bind(%s, key): key ต้องเป็น string ไม่ว่าง (เช่น \"LeftControl\")"):format(action), 2)
  end
  local owner = self.keyToAction[key]
  if owner and owner ~= action then
    if self.bus then
      self.bus:Publish("notify:user", {
        level = "warn",
        key = "notify.keybind.conflict",
        params = { key = key, action = owner },
      })
    end
    return false, { conflictedWith = owner }
  end
  -- ถ้า action นี้ผูกคีย์อื่นอยู่ → ปลดคีย์เก่าก่อน (action ย้ายคีย์ได้)
  local oldKey = self.actionToKey[action]
  if oldKey and oldKey ~= key then
    self.keyToAction[oldKey] = nil
  end
  self.keyToAction[key] = action
  self.actionToKey[action] = key
  self:_persist(action, key)
  if self.bus then
    self.bus:Publish("keybind:changed", { action = action, key = key })
  end
  return true
end

--- ปลดผูก action
function Keybind:Unbind(action)
  local key = self.actionToKey[action]
  if not key then
    return false
  end
  self.keyToAction[key] = nil
  self.actionToKey[action] = nil
  self:_persist(action, nil)
  if self.bus then
    self.bus:Publish("keybind:changed", { action = action, key = nil })
  end
  return true
end

--- คีย์ปัจจุบันของ action
function Keybind:KeyOf(action)
  return self.actionToKey[action]
end

--- action ทั้งหมด (เรียง — ให้ UI วาดรายการ)
function Keybind:Actions()
  local out = {}
  for action in pairs(self.actionToKey) do
    out[#out + 1] = action
  end
  table.sort(out)
  return out
end

--- โหลด binding ทั้งหมดจาก config (เรียกครั้งเดียวตอน bootstrap หลัง Config:Load)
function Keybind:LoadFromConfig()
  if not self.config then return 0 end
  local bindings = self.config:Get(Keybind.CONFIG_PATH)
  if type(bindings) ~= "table" then return 0 end
  local n = 0
  for action, key in pairs(bindings) do
    if type(action) == "string" and type(key) == "string" then
      local existing = self.keyToAction[key]
      if existing and existing ~= action then
        -- ข้อมูลเก่าชนกันเอง — เอารายการแรกตามลำดับ sort (deterministic)
        -- แล้วรายงาน ไม่เงียบ (§3.9 ข้อ 5)
        if action < existing then
          self.keyToAction[existing] = nil
        else
          key = nil
        end
      end
      if key then
        self.keyToAction[key] = action
        self.actionToKey[action] = key
        n = n + 1
      end
    end
  end
  if n > 0 and self.bus then
    self.bus:Publish("notify:user", {
      level = "info",
      key = "notify.keybind.restored",
      params = { count = n },
    })
  end
  return n
end

-- ---- listener --------------------------------------------------------------------

--- สมัครฟัง action — คืน handle ที่ Release ได้ (ผ่าน registry ถ้ามี — orphan=0)
function Keybind:OnAction(action, fn)
  if type(fn) ~= "function" then
    error(("Keybind:OnAction(%s, fn): fn ต้องเป็น function"):format(tostring(action)), 2)
  end
  local owner
  if self.registry then
    owner = self.registry:Owner() or self.hostOwner
  else
    owner = self.hostOwner
  end
  local item = { fn = fn, owner = owner }
  self.listeners[action] = self.listeners[action] or {}
  table.insert(self.listeners[action], item)
  if self.registry then
    local h = self.registry:Temp(item, function()
      self:_offListener(action, item)
    end)
    item.handle = h
    return h
  end
  item.Release = function()
    self:_offListener(action, item)
  end
  return item
end

--- จำลองการกด action (ปุ่ม UI ใช้ — path เดียวกับคีย์จริง)
function Keybind:Trigger(action)
  return self:_dispatch(action)
end

--- สถานะ (Diagnostics)
function Keybind:Stats()
  local actions = 0
  for _ in pairs(self.actionToKey) do
    actions = actions + 1
  end
  local listeners = 0
  for _, list in pairs(self.listeners) do
    listeners = listeners + #list
  end
  return {
    actions = actions,
    listeners = listeners,
    inputAttached = self.input ~= nil,
  }
end

--- ข้อมูลอินพุตปัจจุบัน (query-only) — KeybindService เป็น L2 เดียวที่ถือ
--- InputAdapter แบบ runtime attachment (§3.10) — [CR-PC-ONLY 1 ต.ค. 2026]
--- เดิมมี MobileLayout เป็นผู้เรียก (ตรวจอุปกรณ์ทัชอย่างเดียว) ตัดออกจาก
--- scope แล้ว — API นี้คงไว้ (Foundation ผ่าน gate + PC จอสัมผัสยังใช้ได้)
--- ปัจจุบันผู้เรียก = เทส PC-only guard (qa/l1_unit/test_ui.lua) เท่านั้น
--- คืน { attached, touchEnabled, keyboardEnabled } — ค่าที่หาไม่ได้ = nil
--- (ผู้ใช้ต้อง fallback เอง — ไม่เดาเงียบ ๆ)
function Keybind:InputInfo()
  local info = {
    attached = self.input ~= nil,
    touchEnabled = nil,
    keyboardEnabled = nil,
  }
  if self.input then
    local okT, touch = pcall(function() return self.input:TouchEnabled() end)
    if okT and touch ~= nil then info.touchEnabled = touch == true end
    local okK, kb = pcall(function() return self.input:KeyboardEnabled() end)
    if okK and kb ~= nil then info.keyboardEnabled = kb == true end
  end
  return info
end

--- ปิด node (TEARDOWN) — ถอด subscription ของ input + ล้าง listener
--- (handles ใน registry เป็น no-op หลังจากนี้)
function Keybind:Shutdown()
  if self._inputSub and self._inputSub.Release then
    pcall(function() self._inputSub:Release() end)
    self._inputSub = nil
  end
  self.listeners = {}
  self.input = nil
  return true
end

return Keybind
