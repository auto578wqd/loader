-- ============================================================================
-- The Voider — core/foundation/migration.lua
-- Migration Service — ลูกโซ่ migration ทีละเวอร์ชัน (แผน freeze v2.1 §3.7)
--
--   migrations[1] = v1→v2, migrations[2] = v2→v3, ...
--   โหลด config เก่าเข้ามาแล้วไล่รันทีละขั้นจนถึงเวอร์ชันปัจจุบัน — ห้ามข้ามขั้น
--
--   หลักการ "config ของผู้ใช้คือของมีค่า — ห้ามทิ้ง" (§3.7):
--     key เก่าที่เลิกใช้ ต้องเก็บค่าไว้ใน cfg._legacy[oldPath] ด้วย Migration.Keep()
--     เพื่อให้กู้คืน/ตรวจสอบย้อนหลังได้เสมอ
--
--   คุณสมบัติที่การใช้งานจริงต้องได้ (และมี L1 พิสูจน์):
--     - ลูกโซ่หลายขั้น v1→v2→v3 รันเรียงถูกต้อง ห้ามข้ามขั้น (ขั้นขาด = error ชัด)
--     - idempotent: Run() ซ้ำกับ config ที่เป็นรุ่นล่าสุดแล้ว = no-op เป๊ะ ๆ
--     - ข้อมูลสำคัญไม่หาย: ค่าที่เปลี่ยนชื่อ key ต้องยังอยู่ + เก็บ legacy ครบ
-- ============================================================================

local Migration = {}
Migration.__index = Migration

Migration.VERSION = "0.2.0"

function Migration.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    steps = {},       -- [fromV] = fn(cfg) → cfg
    clock = ctx.clock or os.clock,
    lastRun = nil,    -- รายงานรอบล่าสุด { from, to, steps = {fromV...}, ms }
  }, Migration)
  return self
end

--- ลงทะเบียนขั้น migration: จาก schemaVersion = fromV เป็น fromV + 1
--- fn(cfg) แก้/ย้าย/เติม field แล้วคืน cfg (แก้ in-place หรือคืนตารางใหม่ก็ได้)
function Migration:Register(fromV, fn)
  if type(fromV) ~= "number" or fromV < 1 or math.floor(fromV) ~= fromV then
    error("Migration:Register(fromV, fn): fromV ต้องเป็นจำนวนเต็มบวก", 2)
  end
  if type(fn) ~= "function" then
    error(("Migration:Register(%d, fn): fn ต้องเป็น function"):format(fromV), 2)
  end
  if self.steps[fromV] then
    error(("Migration:Register(%d): ขั้นนี้ลงทะเบียนซ้ำ (v%d→v%d มีแล้ว)"):format(fromV, fromV, fromV + 1), 2)
  end
  self.steps[fromV] = fn
  return self
end

--- เวอร์ชันสูงสุดที่ migrate ไปได้จากขั้นที่ลงทะเบียนครบ (target ของ Run)
function Migration:Latest()
  -- หา fromV สูงสุด แล้ว +1 — ถ้าไม่มีขั้นเลย = 1 (ยังไม่มี migration)
  local maxFrom = 0
  for fromV in pairs(self.steps) do
    if fromV > maxFrom then maxFrom = fromV end
  end
  return maxFrom + 1
end

--- รายการขั้นที่ลงทะเบียน (เรียง) — ใช้ตรวจว่าลูกโซ่ต่อเนื่อง
function Migration:Steps()
  local out = {}
  local froms = {}
  for fromV in pairs(self.steps) do
    table.insert(froms, fromV)
  end
  table.sort(froms)
  for _, fromV in ipairs(froms) do
    table.insert(out, ("v%d→v%d"):format(fromV, fromV + 1))
  end
  return out
end

--- helper สำหรับ step: เก็บค่า key เก่าไว้ใน cfg._legacy[oldPath] (ห้ามทิ้ง §3.7)
function Migration.Keep(cfg, oldPath, value)
  if value == nil then return cfg end
  cfg._legacy = cfg._legacy or {}
  cfg._legacy[oldPath] = value
  return cfg
end

--- รันลูกโซ่ migration จาก cfg.schemaVersion จนถึง targetV (default = Latest)
--- - ห้ามข้ามขั้น: ขั้นไหนไม่ได้ลงทะเบียน = error ทันที (พร้อมระบุขั้นที่ขาด)
--- - idempotent: schemaVersion >= target แล้ว = คืน cfg เดิมไม่แตะ
--- - cfg.schemaVersion ไม่ใช่ตัวเลข = error (ไฟล์เสีย — ผู้เรียกจัด fallback)
--- คืน: cfg รุ่นใหม่ (ตารางเดิมถ้า no-op)
function Migration:Run(cfg, targetV)
  if type(cfg) ~= "table" then
    error("Migration:Run(cfg): cfg ต้องเป็น table", 2)
  end
  targetV = targetV or self:Latest()
  local from = cfg.schemaVersion
  if type(from) ~= "number" then
    error(("Migration:Run: cfg.schemaVersion ไม่ใช่ตัวเลข (ได้ %s) — config เสีย")
      :format(tostring(from)), 2)
  end
  if from >= targetV then
    self.lastRun = { from = from, to = from, steps = {}, noop = true, ms = 0 }
    return cfg
  end

  local t0 = self.clock()
  local ran = {}
  local v = from
  while v < targetV do
    local step = self.steps[v]
    if not step then
      error(("Migration:Run: ขั้น v%d→v%d ไม่ได้ลงทะเบียน — ห้ามข้ามขั้น (§3.7) ลงทะเบียนก่อน: %s")
        :format(v, v + 1, table.concat(self:Steps(), ", ")), 2)
    end
    local ok, result = pcall(step, cfg)
    if not ok then
      error(("Migration:Run: ขั้น v%d→v%d พัง: %s"):format(v, v + 1, tostring(result)), 2)
    end
    cfg = result or cfg
    if type(cfg) ~= "table" then
      error(("Migration:Run: ขั้น v%d→v%d คืนค่าไม่ใช่ table"):format(v, v + 1), 2)
    end
    cfg.schemaVersion = v + 1
    table.insert(ran, v)
    v = v + 1
  end
  self.lastRun = {
    from = from, to = targetV, steps = ran, noop = false,
    ms = (self.clock() - t0) * 1000,
  }
  return cfg
end

--- รายงานรอบล่าสุด (Diagnostics ตรวจเวลา migration ต่อขั้น)
function Migration:LastRun()
  return self.lastRun
end

return Migration
