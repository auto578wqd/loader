-- ============================================================================
-- The Voider — core/foundation/init.lua
-- Foundation Layer assembler (แผน freeze v2.1 §3.5 + §3.7 + §8.4 + §3.10)
--
-- ประกอบ L2 ทั้งหมดตามลำดับ dependency graph:
--   EventBus → ConfigService → MigrationService → I18nService
--   → KeybindService → DiagnosticsService
--   (+ ServiceRegistry เป็น infrastructure ไม่แยก node ใน graph)
--
-- SSOT enforcement (§3.10): ตอนสร้างตรวจว่าชื่อ node ที่ layer นี้ดูแล
-- อยู่ใน Graph.initOrder ครบทุกตัว — ชื่อไม่ตรง = error ทันที
-- (กันไฟล์ graph กับโค้ดคลาดเคลื่อนกันแบบเงียบ ๆ)
--
-- ใช้งาน:
--   local F = FoundationLib.new({ runtime = R })
--   F:Bootstrap()          -- โหลด config + ภาษา + keybind + Diagnostics เริ่มทำงาน
--   F.Bus / F.Config / F.Migration / F.I18n / F.Keybind / F.Diag / F.Services
--   -- ปิดระบบทั้งหมดผ่าน R.ShutdownAll() (hook ของแต่ละ node ลงทะเบียนแล้ว)
-- ============================================================================

local P = __TV_PACKAGES
local ServicesLib = P.services
local BusLib = P.eventbus
local ConfigLib = P.config
local MigrationLib = P.migration
local I18nLib = P.i18n
local KeybindLib = P.keybind
local DiagLib = P.diagnostics

local FoundationLib = {}
FoundationLib.version = "0.2.0"

-- ชื่อ node ตาม dependency graph (ต้องตรง dependencies.md §3 พอดี — SSOT §3.10)
FoundationLib.NODES = {
  "EventBus",
  "ConfigService",
  "MigrationService",
  "I18nService",
  "KeybindService",
  "DiagnosticsService",
}

-- เหตุการณ์ระดับระบบทั้งหมด (Declare ครั้งเดียวที่นี่ — โมดูลเพิ่มของตัวเองภายหลังได้)
-- policy ตาม Replay Policy §3.6: config/keybind/i18n = state → replay,
-- notify/loaded/saved/ready = idempotent → replay ได้ปลอดภัย
FoundationLib.SYSTEM_EVENTS = {
  { "config:changed",  "replay" },
  { "config:replaced", "replay" },
  { "config:loaded",   "idempotent" },
  { "config:saved",    "idempotent" },
  { "i18n:changed",    "replay" },
  { "keybind:changed", "replay" },
  { "adapter:health",  "replay" },
  { "system:ready",    "idempotent" },
  { "notify:user",     "idempotent" },
  { "module:state",    "idempotent" },
}

function FoundationLib.new(ctx)
  ctx = ctx or {}
  local R = ctx.runtime
  if not R or not R.Registry or not R.Boundary or not R.Graph or not R.Shutdown then
    error("FoundationLib.new({ runtime = R }): ต้องส่ง Runtime ครบ (Registry/Boundary/Graph/Shutdown)", 2)
  end

  -- ---- SSOT check: node ของ foundation ต้องอยู่ใน graph ครบ ----------------
  local inGraph = {}
  for _, n in ipairs(R.Graph.initOrder) do
    inGraph[n] = true
  end
  for _, n in ipairs(FoundationLib.NODES) do
    if not inGraph[n] then
      error(("Foundation: node %q ไม่อยู่ใน dependency graph (dependencies.md) — "
        .. "โค้ดกับ SSOT คลาดเคลื่อน แก้ที่ dependencies.md ก่อน (§3.10)"):format(n), 2)
    end
  end

  local F = {}
  F.version = FoundationLib.version
  F.runtime = R

  -- ---- สร้างตามลำดับ (provider ก่อน consumer ตาม graph) ---------------------
  F.Services = ServicesLib.new()

  F.Bus = BusLib.new({
    registry = R.Registry,
    boundary = R.Boundary,
    owner = "EventBus",
  })

  F.Migration = MigrationLib.new({})

  F.Config = ConfigLib.new({
    bus = F.Bus,
    migration = F.Migration,
  })

  F.I18n = I18nLib.new({ bus = F.Bus })

  F.Keybind = KeybindLib.new({
    bus = F.Bus,
    config = F.Config,
    registry = R.Registry,
    boundary = R.Boundary,
    owner = "KeybindService",
  })

  F.Diag = DiagLib.new({
    bus = F.Bus,
    registry = R.Registry,
    boundary = R.Boundary,
    capability = R.Capability,
  })
  F.Diag:SetSources(F.Services, F.Keybind)
  F.Diag:SetI18n(F.I18n)

  -- ---- Declare ระบบ events --------------------------------------------------
  for _, ev in ipairs(FoundationLib.SYSTEM_EVENTS) do
    F.Bus:Declare(ev[1], ev[2])
  end

  -- ---- Direct Services ที่ foundation ให้เอง (query-only §3.5) ---------------
  -- โมดูลเรียกตรงผ่าน context ที่ได้รับตอน Init — ไม่ผ่าน bus (hot path เช่นแปลข้อความ)
  F.Services:Define("I18n", {
    T = function(key, params) return F.I18n:T(key, params) end,
    Lang = function() return F.I18n:Lang() end,
  })
  F.Services:Define("Config", {
    Get = function(path) return F.Config:Get(path) end,
    StorageKind = function() return F.Config:StorageKind() end,
  })
  F.Services:Define("Diagnostics", {
    Snapshot = function() return F.Diag:Snapshot() end,
    Export = function() return F.Diag:Export() end,
    -- เฟส 1 UI (§8.4 เครื่องมือ Export): คัดลอกลง clipboard ถ้ามี
    ExportToClipboard = function() return F.Diag:ExportToClipboard() end,
    -- เฟส 1 UI (§8.4 กราฟ memory 15 นาที): อนุกรม sample ย้อนหลัง
    MemorySeries = function() return F.Diag:MemorySeries() end,
  })

  -- ---- Shutdown hooks ตาม node (TEARDOWN = Init กลับด้าน §3.10) ---------------
  R.Shutdown:Register("EventBus", {
    Destroy = function()
      F.Bus:Shutdown()
    end,
  })
  R.Shutdown:Register("ConfigService", {
    -- เก็บของผู้ใช้เสมอ: Save ถ้า dirty (§3.7)
    Destroy = function()
      F.Config:Shutdown()
    end,
  })
  R.Shutdown:Register("KeybindService", {
    Destroy = function()
      F.Keybind:Shutdown()
    end,
  })
  R.Shutdown:Register("DiagnosticsService", {
    Destroy = function()
      F.Diag:Shutdown()
    end,
  })
  -- MigrationService / I18nService: ไม่ถือ resource ภายนอก — ไม่ลงทะเบียน hook
  -- (Shutdown Manager ข้าม node ไม่มี hook อัตโนมัติ)

  -- ---- Bootstrap ---------------------------------------------------------------

  function F:Bootstrap()
    local t0 = os.clock()
    -- 1) config ก่อนทุกอย่าง (ภาษา + keybind อยู่ในนั้น)
    local tc = os.clock()
    local loadInfo = F.Config:Load()
    F.Diag:Mark("configLoadMs", (os.clock() - tc) * 1000)

    -- 2) ภาษาจาก config
    local lang = F.Config:Get("i18n.lang")
    if lang and F.I18n:Has(lang) then
      F.I18n:Set(lang)
    end

    -- 3) keybind จาก config (ยังไม่ attach input — รอ adapter พร้อม L3)
    F.Keybind:LoadFromConfig()

    -- 4) เริ่ม Diagnostics + sample แรก
    F.Diag:MarkStartup((os.clock() - t0) * 1000)
    F.Diag:Sample()
    F.Bus:Publish("system:ready", {
      version = F.version,
      configSource = loadInfo.status,
    })
    return F
  end

  return F
end

return FoundationLib
