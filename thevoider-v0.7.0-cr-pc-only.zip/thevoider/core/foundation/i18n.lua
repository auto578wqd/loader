-- ============================================================================
-- The Voider — core/foundation/i18n.lua
-- I18n Service (แผน freeze v2.1 §5.3 — ไทย/อังกฤษ + key coverage 100%)
--
--   T(key, params)     แปล key → ข้อความภาษาปัจจุบัน + interpolate {ชื่อ}
--   Set(lang)          สลับภาษา + ประกาศ "i18n:changed" (UI ฟังเพื่อ render ใหม่)
--   AddTable(lang, t)  โมดูล/UI เติมคำศัพท์ภายหลัง (เฟส 1+)
--   Coverage()         ตรวจ key ครบทุกภาษาไหม — เกณฑ์ DoD เฟส 1: 100% ห้ามตกหล่น
--
--   fallback: ภาษาปัจจุบัน → ภาษาหลัก (th) → คืน key เปล่า (เห็นชัดว่าหาย —
--   ไม่เงียบ §3.9 ข้อ 5) + Coverage() จับได้ทันที
-- ============================================================================

local I18n = {}
I18n.__index = I18n

I18n.VERSION = "0.2.0"

I18n.DEFAULT_LANG = "th"
I18n.LANGS = { "th", "en" }

-- คำศัพท์ของ Foundation + Adapter (รอบนี้) — โมดูลเติมเองผ่าน AddTable ภายหลัง
local BASE = {
  -- การแจ้งเตือน config (§3.7)
  ["notify.config.default"] = {
    th = "เริ่มต้นด้วยค่าตั้งต้น (ยังไม่มีไฟล์ config)",
    en = "Starting with default settings (no config file yet)",
  },
  ["notify.config.corrupted"] = {
    th = "ไฟล์ config เสีย — สำรองเป็น {backup} แล้ว ใช้ค่าตั้งต้นชั่วคราว",
    en = "Config file corrupted — backed up as {backup}, using defaults for now",
  },
  ["notify.config.migration_failed"] = {
    th = "ย้าย config ข้ามเวอร์ชันไม่สำเร็จ — สำรองไฟล์เก่าแล้ว ใช้ค่าตั้งต้น",
    en = "Config migration failed — old file backed up, using defaults",
  },
  ["notify.config.loaded"] = {
    th = "โหลด config สำเร็จ ({source})",
    en = "Config loaded ({source})",
  },
  ["notify.config.save_failed"] = {
    th = "บันทึก config ไม่สำเร็จ: {error}",
    en = "Failed to save config: {error}",
  },
  -- การแจ้งเตือน adapter (§3.3 กฎ 3)
  ["notify.adapter.degraded"] = {
    th = "Adapter {name} เสื่อมบางส่วน — ฟีเจอร์ที่เกี่ยวข้องปิดตัวเองชั่วคราว รออัปเดต The Voider",
    en = "Adapter {name} partially degraded — related features disabled until The Voider update",
  },
  ["notify.adapter.dead"] = {
    th = "Adapter {name} ใช้ไม่ได้ ({reason}) — รออัปเดต The Voider",
    en = "Adapter {name} unavailable ({reason}) — waiting for The Voider update",
  },
  -- keybind
  ["notify.keybind.conflict"] = {
    th = "คีย์ {key} ถูกใช้โดย \"{action}\" อยู่แล้ว — ปลดผูกเดิมก่อนจึงจะใช้ซ้ำได้",
    en = "Key {key} is already bound to \"{action}\" — unbind it first",
  },
  ["notify.keybind.restored"] = {
    th = "โหลดคีย์ลัด {count} รายการจาก config",
    en = "Restored {count} keybindings from config",
  },
  -- ชื่อ adapter (แสดงใน Diagnostics §8.4)
  ["adapter.player"] = { th = "ผู้เล่น", en = "Player" },
  ["adapter.character"] = { th = "ตัวละคร", en = "Character" },
  ["adapter.combat"] = { th = "ต่อสู้", en = "Combat" },
  ["adapter.camera"] = { th = "กล้อง", en = "Camera" },
  ["adapter.input"] = { th = "อินพุต", en = "Input" },
  ["adapter.world"] = { th = "โลก", en = "World" },
  -- สถานะระบบ (Diagnostics §8.4)
  ["diag.status.ok"] = { th = "ครบ", en = "OK" },
  ["diag.status.degraded"] = { th = "เสื่อมบางส่วน", en = "Degraded" },
  ["diag.status.dead"] = { th = "ตาย", en = "Dead" },
}

function I18n.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    bus = ctx.bus,
    lang = ctx.lang or I18n.DEFAULT_LANG,
    tables = {},   -- [lang] = { [key] = string }
  }, I18n)
  for _, lang in ipairs(I18n.LANGS) do
    self.tables[lang] = {}
  end
  -- ใส่คำศัพท์พื้นฐาน
  for key, entry in pairs(BASE) do
    for lang, text in pairs(entry) do
      self.tables[lang][key] = text
    end
  end
  return self
end

--- เติมคำศัพท์ (โมดูล/UI เรียกตอน Init ของตัวเอง — key ซ้ำ = เขียนทับของเดิม
--- เพราะโมดูลเป็นเจ้าของ key ของตัวเอง)
function I18n:AddTable(lang, t)
  if type(lang) ~= "string" then
    error("I18n:AddTable(lang, t): lang ต้องเป็น string", 2)
  end
  if type(t) ~= "table" then
    error(("I18n:AddTable(%s, t): t ต้องเป็น table { [key] = ข้อความ }"):format(lang), 2)
  end
  self.tables[lang] = self.tables[lang] or {}
  for k, v in pairs(t) do
    if type(v) ~= "string" then
      error(("I18n:AddTable(%s): key %s ต้องมีค่าเป็น string"):format(lang, tostring(k)), 2)
    end
    self.tables[lang][k] = v
  end
  return self
end

--- ภาษาปัจจุบัน
function I18n:Lang()
  return self.lang
end

--- มีภาษานี้หรือไม่ (ใช้ตรวจค่าจาก config ก่อน Set)
function I18n:Has(lang)
  return self.tables[lang] ~= nil
end

--- ภาษาที่มี
function I18n:Available()
  local out = {}
  for lang in pairs(self.tables) do
    out[#out + 1] = lang
  end
  table.sort(out)
  return out
end

--- สลับภาษา + ประกาศให้ UI render ใหม่
function I18n:Set(lang)
  if not self.tables[lang] then
    error(("I18n:Set(%s): ไม่มีภาษานี้ (มี: %s)"):format(tostring(lang), table.concat(self:Available(), ", ")), 2)
  end
  self.lang = lang
  if self.bus then
    self.bus:Publish("i18n:changed", { lang = lang })
  end
  return self
end

local function interpolate(text, params)
  if not params then return text end
  return (text:gsub("{(%w+)}", function(name)
    local v = params[name]
    if v == nil then return "{" .. name .. "}" end
    return tostring(v)
  end))
end

--- แปล key → ข้อความ (fallback: ภาษาปัจจุบัน → th → key เปล่า)
function I18n:T(key, params)
  local cur = self.tables[self.lang]
  local def = self.tables[I18n.DEFAULT_LANG]
  local text = (cur and cur[key]) or (def and def[key]) or key
  return interpolate(text, params)
end

--- แปลแบบระบุภาษา (ใช้น้อย — เช่น Export Diagnostics อยากได้สองภาษา)
function I18n:TIn(lang, key, params)
  local t = self.tables[lang]
  local def = self.tables[I18n.DEFAULT_LANG]
  local text = (t and t[key]) or (def and def[key]) or key
  return interpolate(text, params)
end

--- ตรวจความครอบคลุมของ key ทุกภาษา (DoD เฟส 1: 100%)
--- คืน { total = จำนวน key รวม, [lang] = { missing = n, keys = { ... } } }
function I18n:Coverage()
  -- union ของ key ทุกภาษา
  local union = {}
  local total = 0
  for _, lang in ipairs(self:Available()) do
    for k in pairs(self.tables[lang]) do
      if not union[k] then
        union[k] = true
        total = total + 1
      end
    end
  end
  local out = { total = total, complete = true }
  for _, lang in ipairs(self:Available()) do
    local missing = {}
    for k in pairs(union) do
      if self.tables[lang][k] == nil then
        missing[#missing + 1] = k
      end
    end
    table.sort(missing)
    out[lang] = { missing = #missing, keys = missing }
    if #missing > 0 then
      out.complete = false
    end
  end
  return out
end

return I18n
