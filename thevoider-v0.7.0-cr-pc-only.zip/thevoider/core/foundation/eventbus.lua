-- ============================================================================
-- The Voider — core/foundation/eventbus.lua
-- Event Bus (แผน freeze v2.1 §3.5 — ช่องทางสื่อสารความถี่ต่ำ-กลาง)
--
--   ใช้สำหรับ: Lifecycle (โมดูลเปิด/ปิด/พัง) / Notification / Config change /
--   Cross-module signal ทั่วไป (เป้าตาย, กำลังสลับเซิร์ฟเวอร์)
--   ส่วน hot path (per-frame query) ต้องเรียก Direct Service (services.lua) เท่านั้น
--
--   + §3.6 FREEZE/RESUME (hot update ขั้น 4/9):
--       Freeze()  → event ใหม่เข้าคิวพร้อม metadata 5 ช่อง
--                   (generation, timestamp, type, replayable, payload)
--       Resume()  → replay ตาม Replay Policy:
--         "drop"       Transient (เหตุการณ์เก่า เกิดแล้วเกิดเลย) → ทิ้งทั้งหมด
--                      โมดูลรุ่นใหม่ re-derive สถานะจาก Game Adapter เอง
--         "replay"     State/Config (สถานะที่ยังมีผล) → replay เรียง timestamp
--                      (ลำดับเดิม = last-write-wins โดยธรรมชาติ)
--         "idempotent" ทำซ้ำได้ผลเดิม → replay ปลอดภัย
--
--   + CR-REPLAY-001 (อนุมัติโดยเจ้าของโปรเจกต์ 1 ตุลาคม 2026 — ตัวเลือก ข):
--       คิวระหว่าง freeze ต้องข้าม generation ได้ตาม §3.6 ดั้งเดิม:
--         ExportQueue() → สำเนาคิวทั้งหมดพร้อม payload (deep clone) —
--           orchestrator (update.lua) เรียกจาก bus รุ่นเก่าก่อน TEARDOWN
--         ImportQueue(events) → รับเข้าคิวของ bus รุ่นปลายทาง (ต้อง frozen)
--           โดย policy ถูกตัดสินใหม่ตาม Declare ของรุ่นปลายทาง แล้ว replay
--           ตอน Resume — Transient DROP / State-Config REPLAY (LWW) /
--           Idempotent REPLAY / สถานะโลกจริง DROP + re-derive จาก Adapter
--
--   ความปลอดภัย:
--     - subscriber callback รันภายใต้ Error Boundary ของ "เจ้าของ subscription"
--       (พังเองไม่ลามไปคนอื่น §3.2 ข้อ 3)
--     - subscription = temporary resource ใน Resource Registry (ผ่าน Runtime.Temp)
--       → Module:Destroy() คืนของครบ orphan=0 อัตโนมัติ (§3.4)
--     - event ที่ยังไม่ Declare = policy "drop" (safe default) + นับ undeclared
--       ให้ Diagnostics เห็น (จับ typo ของชื่อ event)
-- ============================================================================

local Bus = {}
Bus.__index = Bus

Bus.POLICIES = { drop = true, replay = true, idempotent = true }

Bus.VERSION = "0.3.0"

-- deep clone ค่าที่ serialize ได้ (payload ของ event ต้องเป็น plain table เท่านั้น)
local function deepClone(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for k, val in pairs(v) do
    out[k] = deepClone(val)
  end
  return out
end

-- ตรวจว่า payload "replay ได้" จริง: ห้าม function/userdata/thread ฝังอยู่
-- (ข้าม generation = ต้องไม่ผูกอะไรที่มีชีวิตของรุ่นเก่าติดมาด้วย)
local function replayablePayload(p)
  if p == nil then return true end
  if type(p) ~= "table" then return true end -- string/number/boolean ใช้ได้
  for k, v in pairs(p) do
    if type(k) ~= "string" and type(k) ~= "number" then return false end
    local tv = type(v)
    if tv == "function" or tv == "userdata" or tv == "thread" then return false end
    if tv == "table" and not replayablePayload(v) then return false end
  end
  return true
end

function Bus.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    registry = ctx.registry,   -- Resource Registry (ไม่มี = โหมด standalone เช่น L1)
    boundary = ctx.boundary,   -- Error Boundary (ไม่มี = pcall ธรรมดา)
    hostOwner = ctx.owner or "EventBus", -- ชื่อ node ตาม dependency graph
    declared = {},   -- [evtType] = policy
    subs = {},       -- [evtType] = { {type, fn, owner, handle?} ... } (เรียงสมัคร)
    frozen = false,
    generation = 0,
    pendingGeneration = nil,
    queue = {},      -- event ค้างระหว่าง freeze (เรียงเวลา)
    stats = {
      published = 0, dispatched = 0, queued = 0, droppedOnResume = 0,
      undeclared = 0, subscriberErrors = 0,
      imported = 0,     -- CR-REPLAY-001: event ที่รับข้าม generation (ImportQueue)
      importDropped = 0, -- CR-REPLAY-001: event ข้าม generation ที่ถูกทิ้ง (payload ไม่ replay ได้)
    },
    _pubTimes = {},  -- timestamp ของ publish ล่าสุด (นับ events/sec)
  }, Bus)
  return self
end

--- ประกาศชนิด event + นโยบาย replay (ควร Declare ตอน init ก่อน Publish ครั้งแรก)
-- policy: "drop" | "replay" | "idempotent" — event ที่ไม่เคย Declare = "drop"
function Bus:Declare(evtType, policy)
  if type(evtType) ~= "string" or #evtType == 0 then
    error("Bus:Declare(evtType, policy): evtType ต้องเป็น string ไม่ว่าง", 2)
  end
  if not Bus.POLICIES[policy] then
    error(("Bus:Declare(%s): policy ต้องเป็น drop|replay|idempotent (ได้ %s)")
      :format(tostring(evtType), tostring(policy)), 2)
  end
  self.declared[evtType] = policy
  return self
end

--- ถอดการประกาศ (ใช้ตอน TEARDOWN ของผู้ประกาศ)
function Bus:Undeclare(evtType)
  self.declared[evtType] = nil
  return self
end

function Bus:Policy(evtType)
  return self.declared[evtType]
end

-- ---- subscription ----------------------------------------------------------

function Bus:_off(sub)
  local list = self.subs[sub.type]
  if not list then return end
  for i, s in ipairs(list) do
    if s == sub then
      table.remove(list, i)
      return true
    end
  end
  return false
end

--- สมัครรับ event — คืน handle ที่ Release() ได้ (และถ้ามี registry
--- จะถูกนับเป็น temporary resource ของ owner ปัจจุบันจนกว่าจะคืน — orphan ตรวจได้)
function Bus:On(evtType, fn)
  if type(fn) ~= "function" then
    error(("Bus:On(%s, fn): fn ต้องเป็น function"):format(tostring(evtType)), 2)
  end
  local owner
  if self.registry then
    owner = self.registry:Owner() or self.hostOwner
  else
    owner = self.hostOwner
  end
  local sub = { type = evtType, fn = fn, owner = owner }
  self.subs[evtType] = self.subs[evtType] or {}
  table.insert(self.subs[evtType], sub)

  if self.registry then
    -- §3.4: subscription เป็นทรัพยากรของโมดูลผู้สมัคร — Release ตาม owner อัตโนมัติ
    local h = self.registry:Temp(sub, function()
      self:_off(sub)
    end)
    sub.handle = h
    return h
  end
  -- โหมดไม่มี registry: handle เบา ๆ ที่ Off เองได้
  sub.Release = function() self:_off(sub) end
  sub.Off = sub.Release
  return sub
end

-- ---- publish ---------------------------------------------------------------

--- ส่ง event (payload ตารางธรรมดาเท่านั้น — ห้ามผูก userdata เพราะต้อง replay ได้)
-- คืน: จำนวน subscriber ที่รับ (หรือ 0 + "QUEUED" เมื่ออยู่ในช่วง freeze)
function Bus:Publish(evtType, payload)
  local policy = self.declared[evtType]
  if not policy then
    policy = "drop"
    self.stats.undeclared = self.stats.undeclared + 1
  end
  local evt = {
    generation = self.generation,
    timestamp = self.clock(),
    type = evtType,
    replayable = policy,
    payload = payload,
  }

  local pt = self._pubTimes
  table.insert(pt, evt.timestamp)
  if #pt > 256 then table.remove(pt, 1) end
  self.stats.published = self.stats.published + 1

  if self.frozen then
    table.insert(self.queue, evt)
    self.stats.queued = self.stats.queued + 1
    return 0, "QUEUED"
  end
  return self:_dispatch(evt)
end

function Bus:_dispatch(evt)
  local list = self.subs[evt.type]
  if not list or #list == 0 then return 0 end
  -- snapshot รายชื่อก่อนเดิน (subscriber อาจ Off ตัวเองกลาง dispatch)
  local targets = {}
  for _, s in ipairs(list) do
    table.insert(targets, s)
  end
  local n = 0
  for _, s in ipairs(targets) do
    n = n + 1
    local ok
    if self.boundary then
      -- error ของ subscriber = ของเจ้าของ subscription (ไม่ลามไป publisher)
      ok = self.boundary:Guard(s.owner, function()
        s.fn(evt.payload, evt)
      end)
    else
      ok = pcall(function()
        s.fn(evt.payload, evt)
      end)
    end
    if not ok then
      self.stats.subscriberErrors = self.stats.subscriberErrors + 1
    end
  end
  self.stats.dispatched = self.stats.dispatched + n
  return n
end

-- ---- freeze / resume (hot update §3.6 ขั้น 4 / 9) ---------------------------

--- หยุด dispatch — event ใหม่เข้าคิวพร้อม metadata
--- generation ที่ส่งมา = เลขรุ่นใหม่ของระบบ (จะใช้ตอน Resume)
function Bus:Freeze(generation)
  self.frozen = true
  self.pendingGeneration = generation or (self.generation + 1)
  return self
end

--- เปิด dispatch ใหม่ + เล่น event ในคิวตาม Replay Policy
--- คืน { replayed, dropped, total }
function Bus:Resume(generation)
  self.generation = generation or self.pendingGeneration or (self.generation + 1)
  self.pendingGeneration = nil
  self.frozen = false
  local q = self.queue
  self.queue = {}
  local replayed, dropped = 0, 0
  -- คิวเรียง timestamp อยู่แล้ว (insert เรียง) → replay = last-write-wins ตามลำดับเวลาจริง
  for _, evt in ipairs(q) do
    if evt.replayable == "drop" then
      dropped = dropped + 1
    else
      replayed = replayed + 1
      self:_dispatch(evt)
    end
  end
  self.stats.droppedOnResume = self.stats.droppedOnResume + dropped
  return { replayed = replayed, dropped = dropped, total = #q }
end

--- ล้างคิวทิ้งทั้งหมดโดยไม่ replay — ใช้เมื่อผู้ใช้งาน bus โดยตรงต้องการทิ้งคิว
--- อย่างชัดเจนเอง (หลัง CR-REPLAY-001: orchestrator ของ update ใช้
--- Export/Import + Resume แทน — replay ตาม policy ทั้งสอง path สำเร็จ/ย้อนรุ่น)
function Bus:DropQueue()
  local n = #self.queue
  self.queue = {}
  self.frozen = false
  self.stats.droppedOnResume = self.stats.droppedOnResume + n
  return n
end

--- สำเนาคิวปัจจุบัน (Diagnostics / ตรวจ state ระหว่าง hot update)
--- CR-REPLAY-001: คืนครบ 5 ช่องรวม payload (เดิมไม่คืน payload จึง replay
--- ข้าม generation ไม่ได้ — รากปัญหาของ CR) — payload เป็นอ้างอิงตารางจริง
--- ของคิว: ใช้อ่าน/ตรวจเท่านั้น ห้ามแก้ (จะแก้ = ใช้ ExportQueue ที่ clone ให้)
function Bus:Queue()
  local out = {}
  for i, evt in ipairs(self.queue) do
    out[i] = {
      generation = evt.generation,
      timestamp = evt.timestamp,
      type = evt.type,
      replayable = evt.replayable,
      payload = evt.payload,
    }
  end
  return out
end

--- CR-REPLAY-001 (§3.6 ตามคำตัดสินเจ้าของ 1 ตุลาคม 2026): ส่งออกคิวทั้งหมด
--- พร้อม payload แบบ deep clone เพื่อข้าม generation — orchestrator
--- (update.lua) เรียกจาก bus รุ่นเก่าหลัง TEARDOWN เสร็จ (คิวนิ่งแล้ว) แล้ว
--- Import เข้า bus ของระบบปลายทาง (รุ่นใหม่ หรือรุ่นเดิมกรณี rollback)
--- ไม่ล้างคิวเดิม (bus รุ่นเก่าจะตายตาม TEARDOWN อยู่แล้ว)
function Bus:ExportQueue()
  local out = {}
  for i, evt in ipairs(self.queue) do
    out[i] = {
      generation = evt.generation,
      timestamp = evt.timestamp,
      type = evt.type,
      replayable = evt.replayable,
      payload = deepClone(evt.payload),
    }
  end
  return out
end

--- CR-REPLAY-001: รับ event ที่ export จาก bus รุ่นอื่นเข้าคิวของ bus นี้
--- กฎสำคัญ:
---   - ใช้ได้เฉพาะขณะ frozen — event ถูก replay ตาม policy ตอน Resume เท่านั้น
---   - policy ตัดสินใหม่ตาม Declare ของ "bus ปลายทาง" (รุ่นปลายทางเป็นเจ้าของ
---     คำตอบ): ชนิดที่รุ่นนี้ไม่ Declare = drop (safe default เหมือน Publish)
---     + นับ undeclared ให้ Diagnostics เห็น
---   - payload ต้อง replay ได้ (plain — ห้าม function/userdata/thread):
---     ไม่ใช่ = drop + นับ importDropped (ห้ามผูกของมีชีวิตข้ามรุ่น)
---   - event ที่รับเข้ามาถูกแทรก "ก่อน" คิวเดิมของ bus นี้ (เกิดก่อน event
---     ที่เกิดระหว่าง MIGRATE) → replay เรียงเวลาจริงทั้งคิว last-write-wins
---   - generation/timestamp เก็บค่าอนุมมัยของ event ต้นทางไว้ตามจริง
--- คืน { accepted, dropped, total }
function Bus:ImportQueue(events)
  if not self.frozen then
    error("Bus:ImportQueue(events): ใช้ได้เฉพาะขณะ frozen — event จะถูก "
      .. "replay ตาม policy ตอน Resume เท่านั้น (CR-REPLAY-001 §3.6)", 2)
  end
  if events == nil then events = {} end
  if type(events) ~= "table" then
    error("Bus:ImportQueue(events): events ต้องเป็น table จาก ExportQueue", 2)
  end
  local accepted, dropped = 0, 0
  local imported = {}
  for _, src in ipairs(events) do
    if type(src) ~= "table" or type(src.type) ~= "string" or #src.type == 0 then
      dropped = dropped + 1
    elseif not replayablePayload(src.payload) then
      dropped = dropped + 1
      self.stats.importDropped = self.stats.importDropped + 1
    else
      local policy = self.declared[src.type]
      if not policy then
        policy = "drop"
        self.stats.undeclared = self.stats.undeclared + 1
      end
      if policy == "drop" then
        dropped = dropped + 1
      else
        accepted = accepted + 1
        imported[#imported + 1] = {
          generation = src.generation,
          timestamp = src.timestamp,
          type = src.type,
          replayable = policy,
          payload = src.payload,
        }
      end
    end
  end
  if #imported > 0 then
    -- แทรกข้างหน้าคิวเดิม: event ข้าม generation เกิดก่อน (timestamp เก่ากว่า)
    local merged = {}
    for _, e in ipairs(imported) do merged[#merged + 1] = e end
    for _, e in ipairs(self.queue) do merged[#merged + 1] = e end
    self.queue = merged
    self.stats.imported = self.stats.imported + accepted
  end
  return { accepted = accepted, dropped = dropped, total = #events }
end

-- ---- สถิติ (DiagnosticsService §8.4) ----------------------------------------

function Bus:Stats()
  local now = self.clock()
  local cutoff = now - 1.0
  local perSec = 0
  for i = #self._pubTimes, 1, -1 do
    if self._pubTimes[i] >= cutoff then
      perSec = perSec + 1
    else
      break
    end
  end
  local subscribers = 0
  for _, list in pairs(self.subs) do
    subscribers = subscribers + #list
  end
  local declaredCount = 0
  for _ in pairs(self.declared) do
    declaredCount = declaredCount + 1
  end
  return {
    subscribers = subscribers,
    declared = declaredCount,
    published = self.stats.published,
    dispatched = self.stats.dispatched,
    queued = #self.queue,
    frozen = self.frozen,
    generation = self.generation,
    perSec = perSec,
    undeclared = self.stats.undeclared,
    subscriberErrors = self.stats.subscriberErrors,
    droppedOnResume = self.stats.droppedOnResume,
    imported = self.stats.imported,       -- CR-REPLAY-001
    importDropped = self.stats.importDropped, -- CR-REPLAY-001
  }
end

--- ปิด event bus ทั้งตัว (TEARDOWN ของ node "EventBus") — ถอด subscriber ทุกตัว
--- (subscription handles ใน registry จะกลายเป็น no-op เพราะ _off หาไม่เจอแล้ว)
--- CR-REPLAY-001: "ไม่ล้างคิว" — event ที่ค้างในคิวต้องรอดพ้น Shutdown ของ
--- bus รุ่นเก่า เพื่อให้ orchestrator ExportQueue ข้าม generation ไป replay ตาม
--- policy ได้ (Idempotent เช่น config:saved ที่ hook ปล่อยตอนถอดระบบก็ต้อง replay)
--- bus ที่ Shutdown แล้วไม่มี subscriber — replay ภายหลังเป็น no-op ปลอดภัย
function Bus:Shutdown()
  self.subs = {}
  self.frozen = false
  return true
end

return Bus
