-- ============================================================================
-- The Voider — core/foundation/json.lua
-- JSON codec ขนาดเล็กเขียนเอง (ใช้กับ ConfigService §3.7)
--
--   เหตุผลที่เขียนเอง: ต้องคุมพฤติกรรม encode/decode 100% (round-trip ตรงเป๊ะ
--   ทดสอบด้วย L1) และต้องรันได้ทั้งบน Volt และในชุดทดสอบ (fengari) โดยไม่
--   พึ่ง HttpService ของเกม (ผ่าน Game Adapter เท่านั้น — แต่ config โหลดก่อน
--   adapter พร้อม จึงต้องไม่ depend ต่อกัน §3.10)
--
--   รองรับ: null / boolean / number / string / array / object (ซ้อนกี่ชั้นก็ได้)
--   ปฏิเสธ: function / userdata / thread / key ที่ไม่ใช่ string / table ผสม
--           array+object คลุมเครือ / NaN / Inf — ทั้งหมด error พร้อม path
--           (config เสียต้อง "รู้ตัว" ตั้งแต่ตอน encode — ไม่ใช่เงียบ ๆ §3.9 ข้อ 5)
--
--   สัญญา round-trip: Decode(Encode(t)) == t (deep equal) สำหรับข้อมูลธรรมดา
--   ทุกชนิดที่รองรับ — มี L1 พิสูจน์ทุกชนิด
-- ============================================================================

local Json = {}

Json.VERSION = "0.2.0"

local INF = math.huge

-- ---- encode ---------------------------------------------------------------

local function encodeString(s, out)
  table.insert(out, "\"")
  -- escape ตัวที่ JSON บังคับ + ควบคุมอื่น ๆ (เขียนเป็น \u00XX เพื่อไฟล์สะอาด)
  local buf = {}
  for i = 1, #s do
    local c = s:sub(i, i)
    local b = s:byte(i)
    if c == "\"" then buf[#buf + 1] = "\\\""
    elseif c == "\\" then buf[#buf + 1] = "\\\\"
    elseif c == "\n" then buf[#buf + 1] = "\\n"
    elseif c == "\r" then buf[#buf + 1] = "\\r"
    elseif c == "\t" then buf[#buf + 1] = "\\t"
    elseif b < 32 then
      buf[#buf + 1] = ("\\u%04x"):format(b)
    else
      buf[#buf + 1] = c
    end
  end
  table.insert(out, table.concat(buf))
  table.insert(out, "\"")
end

local function encodeValue(v, out, path)
  local t = type(v)
  if v == nil then
    table.insert(out, "null")
  elseif t == "boolean" then
    table.insert(out, v and "true" or "false")
  elseif t == "number" then
    if v ~= v or v == INF or v == -INF then
      error(("Json.encode: เลข %s ที่ path %s เก็บไม่ได้ (NaN/Inf ต้องเป็น string แทน)")
        :format(tostring(v), path), 0)
    end
    -- จำนวนเต็มพิมพ์ไม่มี .0 (อ่านกลับได้ค่าเดิมเป๊ะด้วย tonumber)
    if math.floor(v) == v and math.abs(v) < 1e15 then
      table.insert(out, ("%d"):format(v))
    else
      table.insert(out, tostring(v))
    end
  elseif t == "string" then
    encodeString(v, out)
  elseif t == "table" then
    -- แยก array / object / ผสมคลุมเครือ
    local n = #v
    local hasOther = false
    for k in pairs(v) do
      if type(k) ~= "number" or k < 1 or k > n or math.floor(k) ~= k then
        hasOther = true
        break
      end
    end
    if n > 0 and hasOther then
      error(("Json.encode: table ที่ path %s ผสม array + key อื่น — แยกให้ชัดก่อนเก็บ"):format(path), 0)
    end
    if n > 0 then
      table.insert(out, "[")
      for i = 1, n do
        if i > 1 then table.insert(out, ",") end
        encodeValue(v[i], out, ("%s[%d]"):format(path, i))
      end
      table.insert(out, "]")
    else
      table.insert(out, "{")
      local first = true
      -- เรียง key เพื่อ output เสถียร (diff ได้ / md5 ตรงกัน)
      local keys = {}
      for k in pairs(v) do
        if type(k) ~= "string" then
          error(("Json.encode: key ที่ path %s ไม่ใช่ string (ได้ %s) — ห้ามใช้ key ตัวเลข/boolean ใน object")
            :format(path, type(k)), 0)
        end
        keys[#keys + 1] = k
      end
      table.sort(keys)
      for _, k in ipairs(keys) do
        if v[k] ~= nil then -- nil = ไม่เขียน (เหมือนไม่มี)
          if not first then table.insert(out, ",") end
          first = false
          encodeString(k, out)
          table.insert(out, ":")
          encodeValue(v[k], out, path == "" and k or (path .. "." .. k))
        end
      end
      table.insert(out, "}")
    end
  else
    error(("Json.encode: ค่าชนิด %s ที่ path %s เก็บใน config ไม่ได้ (อนุญาตเฉพาะข้อมูลธรรมดา)")
      :format(t, path), 0)
  end
end

--- ตาราง → สตริง JSON (key เรียงเสถียร)
function Json.encode(v)
  local out = {}
  encodeValue(v, out, "")
  return table.concat(out)
end

-- ---- decode ----------------------------------------------------------------

local Decoder = {}
Decoder.__index = Decoder

function Decoder.new(s)
  return setmetatable({ s = s, i = 1, depth = 0 }, Decoder)
end

function Decoder:err(msg)
  -- บอกตำแหน่ง + ตัวอักษรรอบข้าง เพื่อแก้ไฟล์ config มือได้ง่าย
  local around = self.s:sub(math.max(1, self.i - 12), self.i + 12)
  error(("Json.decode: %s (ที่ตำแหน่ง %d, ใกล้ ๆ: %q)"):format(msg, self.i, around), 0)
end

function Decoder:peek()
  return self.s:sub(self.i, self.i)
end

function Decoder:skipWs()
  while self.i <= #self.s do
    local c = self.s:sub(self.i, self.i)
    if c == " " or c == "\t" or c == "\n" or c == "\r" then
      self.i = self.i + 1
    else
      break
    end
  end
end

function Decoder:expect(c)
  if self:peek() ~= c then
    self:err(("คาดหวัง '%s'"):format(c))
  end
  self.i = self.i + 1
end

local function utf8Encode(cp)
  -- \uXXXX → UTF-8 (รองรับ surrogate pair จาก caller)
  -- ใช้ arithmetic ล้วน (ไม่ใช้ bitwise operator) เพื่อรันได้ทุกสภาพแวดล้อม:
  -- Luau / Lua 5.3 / Lua 5.1 + LuaJIT — ค่า bit ของเราไม่ซ้อนกันจึงใช้ + แทน | ได้เป๊ะ
  if cp < 0x80 then
    return string.char(cp)
  elseif cp < 0x800 then
    return string.char(0xC0 + math.floor(cp / 64), 0x80 + (cp % 64))
  elseif cp < 0x10000 then
    return string.char(
      0xE0 + math.floor(cp / 4096),
      0x80 + (math.floor(cp / 64) % 64),
      0x80 + (cp % 64)
    )
  else
    return string.char(
      0xF0 + math.floor(cp / 262144),
      0x80 + (math.floor(cp / 4096) % 64),
      0x80 + (math.floor(cp / 64) % 64),
      0x80 + (cp % 64)
    )
  end
end

function Decoder:decodeString()
  self:expect("\"")
  local buf = {}
  while true do
    local c = self:peek()
    if c == "" then
      self:err("string ไม่ปิด (ไม่มีเครื่องหมาย \")")
    elseif c == "\"" then
      self.i = self.i + 1
      return table.concat(buf)
    elseif c == "\\" then
      self.i = self.i + 1
      local e = self:peek()
      if e == "\"" then buf[#buf + 1] = "\""
      elseif e == "\\" then buf[#buf + 1] = "\\"
      elseif e == "/" then buf[#buf + 1] = "/"
      elseif e == "b" then buf[#buf + 1] = "\b"
      elseif e == "f" then buf[#buf + 1] = "\f"
      elseif e == "n" then buf[#buf + 1] = "\n"
      elseif e == "r" then buf[#buf + 1] = "\r"
      elseif e == "t" then buf[#buf + 1] = "\t"
      elseif e == "u" then
        local hex = self.s:sub(self.i + 1, self.i + 4)
        if not hex:match("^%x%x%x%x$") then
          self:err("\\u ต้องตามด้วยเลขฐานสิบหก 4 ตัว")
        end
        self.i = self.i + 4
        local cp = tonumber(hex, 16)
        -- surrogate pair (D800-DBFF ตามด้วย DC00-DFFF)
        if cp >= 0xD800 and cp <= 0xDBFF then
          if self.s:sub(self.i + 1, self.i + 2) ~= "\\u" then
            self:err("surrogate ไม่ครบคู่")
          end
          local hex2 = self.s:sub(self.i + 3, self.i + 6)
          if not hex2:match("^%x%x%x%x$") then
            self:err("\\u ที่สองต้องเป็นเลขฐานสิบหก 4 ตัว")
          end
          local low = tonumber(hex2, 16)
          if low < 0xDC00 or low > 0xDFFF then
            self:err("surrogate คู่ที่สองไม่ถูกต้อง")
          end
          self.i = self.i + 6
          cp = 0x10000 + ((cp - 0xD800) * 1024) + (low - 0xDC00)
        elseif cp >= 0xDC00 and cp <= 0xDFFF then
          self:err("surrogate ตัวเดียวไม่ใช้ได้")
        end
        buf[#buf + 1] = utf8Encode(cp)
      else
        self:err(("escape ไม่รู้จัก: \\%s"):format(e))
      end
      self.i = self.i + 1
    else
      buf[#buf + 1] = c
      self.i = self.i + 1
    end
  end
end

function Decoder:decodeNumber()
  local start = self.i
  local s = self.s
  -- ตัวเลข JSON: -?(0|[1-9]\d*)(\.\d+)?([eE][+-]?\d+)?
  if s:sub(self.i, self.i) == "-" then self.i = self.i + 1 end
  local digits = s:match("^%d+", self.i)
  if not digits then self:err("ตัวเลขไม่ถูกต้อง") end
  if digits:len() > 1 and digits:sub(1, 1) == "0" then
    self:err("ตัวเลขขึ้นต้น 0 ตามด้วยตัวเลขไม่ได้ (ตามสเปค JSON)")
  end
  self.i = self.i + #digits
  if s:sub(self.i, self.i) == "." then
    self.i = self.i + 1
    local frac = s:match("^%d+", self.i)
    if not frac then self:err("ทศนิยมไม่มีตัวเลขหลังจุด") end
    self.i = self.i + #frac
  end
  local c = s:sub(self.i, self.i)
  if c == "e" or c == "E" then
    self.i = self.i + 1
    c = s:sub(self.i, self.i)
    if c == "+" or c == "-" then self.i = self.i + 1 end
    local exp = s:match("^%d+", self.i)
    if not exp then self:err("เลขชี้กำลังไม่มีตัวเลข") end
    self.i = self.i + #exp
  end
  local num = tonumber(s:sub(start, self.i - 1))
  if not num then self:err("ตัวเลขกลายเป็น nil หลังแปลง") end
  return num
end

Decoder.MAX_DEPTH = 64

function Decoder:decodeValue()
  self.depth = self.depth + 1
  if self.depth > Decoder.MAX_DEPTH then
    self:err("ซ้อนลึกเกิน 64 ชั้น — config ผิดปกติ")
  end
  self:skipWs()
  local c = self:peek()
  local v
  if c == "{" then
    self.i = self.i + 1
    local obj = {}
    self:skipWs()
    if self:peek() == "}" then
      self.i = self.i + 1
      v = obj
    else
      while true do
        self:skipWs()
        local k = self:decodeString()
        self:skipWs()
        self:expect(":")
        obj[k] = self:decodeValue()
        self:skipWs()
        local sep = self:peek()
        if sep == "," then
          self.i = self.i + 1
        elseif sep == "}" then
          self.i = self.i + 1
          break
        else
          self:err("คาดหวัง ',' หรือ '}' ใน object")
        end
      end
    end
    v = obj
  elseif c == "[" then
    self.i = self.i + 1
    local arr = {}
    self:skipWs()
    if self:peek() == "]" then
      self.i = self.i + 1
      v = arr
    else
      while true do
        arr[#arr + 1] = self:decodeValue()
        self:skipWs()
        local sep = self:peek()
        if sep == "," then
          self.i = self.i + 1
        elseif sep == "]" then
          self.i = self.i + 1
          break
        else
          self:err("คาดหวัง ',' หรือ ']' ใน array")
        end
      end
    end
    v = arr
  elseif c == "\"" then
    v = self:decodeString()
  elseif self.s:sub(self.i, self.i + 3) == "true" then
    self.i = self.i + 4
    v = true
  elseif self.s:sub(self.i, self.i + 4) == "false" then
    self.i = self.i + 5
    v = false
  elseif self.s:sub(self.i, self.i + 3) == "null" then
    self.i = self.i + 4
    v = nil
  elseif c == "-" or c:match("%d") then
    v = self:decodeNumber()
  else
    self:err(("ไม่รู้จักค่าที่ขึ้นต้นด้วย %q"):format(c))
  end
  self.depth = self.depth - 1
  return v
end

--- สตริง JSON → ตาราง (error พร้อมตำแหน่ง — ให้ ConfigService ทำ fallback ต่อ)
function Json.decode(s)
  if type(s) ~= "string" then
    error("Json.decode(s): s ต้องเป็น string", 2)
  end
  local d = Decoder.new(s)
  d:skipWs()
  if d:peek() == "" then
    error("Json.decode: สตริงว่าง", 2)
  end
  local v = d:decodeValue()
  d:skipWs()
  if d.i <= #d.s then
    d:err("มีขยะหลังค่า JSON จบ")
  end
  return v
end

return Json
