-- ============================================================================
-- The Voider — core/runtime/version.lua (loader-domain: 4-URL + Version Gate §7.1)
--
-- เวอร์ชัน/การเปรียบเทียบ/กติกา version gate — ใช้ทั้งใน loader (ก่อนโหลด core)
-- และใน Hot Update orchestrator (ตรวจ PRE-STAGE ขั้น version gate §3.6)
--
--   รูปแบบเวอร์ชัน: "MAJOR.MINOR.PATCH" (อาจมี "v" นำหน้า) — เช่น "0.3.0"
--   ไม่รองรับ pre-release (-beta ฯลฯ) ในเฟส 0 — ปฏิเสธชัด ๆ ไม่เดา
--
--   กติกา gate (§7.1 + §7.4):
--     - ไฟล์เก่ากว่า manifest ปัจจุบัน = ปฏิเสธโดยเด็ดขาด (บทเรียน CDN ค้าง v2.1)
--     - channel "stable"  = อัปเกรดอย่างเดียว ห้ามลดเวอร์ชัน
--     - channel "rollback" = ยอมรับการลดเวอร์ชัน (เมื่อรุ่นใหม่มีปัญหา ชี้กลับรุ่นก่อน)
--     - minLoaderVersion   = ถ้ารุ่นใหม่ต้องการ loader ใหม่กว่าที่ผู้ใช้มี
--                            → บอกผู้ใช้ชัดเจน ไม่พังเงียบ ๆ
--
-- ไฟล์นี้ self-contained (ไม่ require อะไร) — build ฝังลง loader.lua ได้ทันที
-- ============================================================================

local Version = {}

Version.VERSION = "0.3.0"

--- parse("0.3.0") → {major=0, minor=3, patch=0} หรือ (nil, err)
function Version.parse(s)
  if type(s) ~= "string" then
    return nil, ("version ต้องเป็น string (ได้ %s)"):format(tostring(s))
  end
  local t = s:match("^v?(%d+)%.(%d+)%.(%d+)%s*$")
  if not t then
    local m = s:match("^v?(%d+)%.(%d+)%.(%d+)%-")
    if m then
      return nil, ("เวอร์ชัน %q มี pre-release — ยังไม่รองรับในเฟส 0 (ใช้ x.y.z เท่านั้น)"):format(s)
    end
    return nil, ("เวอร์ชัน %q ไม่ใช่รูปแบบ MAJOR.MINOR.PATCH"):format(s)
  end
  local a, b, c = s:match("^v?(%d+)%.(%d+)%.(%d+)%s*$")
  return { major = tonumber(a), minor = tonumber(b), patch = tonumber(c) }
end

--- คืน string จาก table เวอร์ชัน (ใช้ในข้อความรายงาน)
function Version.stringify(v)
  if type(v) == "string" then return v end
  if type(v) == "table" then
    return ("%d.%d.%d"):format(v.major or 0, v.minor or 0, v.patch or 0)
  end
  return tostring(v)
end

--- compare("0.3.0", "0.4.0") → -1 | 0 | 1  — ตัวใดไม่ parse ได้ = error ชัด (ไม่เดา)
function Version.compare(a, b)
  local va, ea = Version.parse(a)
  if not va then error(("Version.compare: a ผิดรูปแบบ (%s)"):format(tostring(ea)), 2) end
  local vb, eb = Version.parse(b)
  if not vb then error(("Version.compare: b ผิดรูปแบบ (%s)"):format(tostring(eb)), 2) end
  if va.major ~= vb.major then return va.major < vb.major and -1 or 1 end
  if va.minor ~= vb.minor then return va.minor < vb.minor and -1 or 1 end
  if va.patch ~= vb.patch then return va.patch < vb.patch and -1 or 1 end
  return 0
end

function Version.eq(a, b) return Version.compare(a, b) == 0 end
function Version.lt(a, b) return Version.compare(a, b) < 0 end
function Version.gt(a, b) return Version.compare(a, b) > 0 end

--- ตรวจ minLoaderVersion — คืน (ok, message)
--- ok=false = loader ผู้ใช้เก่าเกินไปสำหรับ manifest นี้ → message เป็นภาษาไทยชัดเจน
function Version.checkMinLoader(manifestMin, loaderVersion)
  if manifestMin == nil or manifestMin == "" then
    return true, nil
  end
  local ok, err = pcall(Version.compare, manifestMin, loaderVersion)
  if not ok then
    return false, ("manifest ระบุ minLoaderVersion ผิดรูปแบบ (%s): %s"):format(
      tostring(manifestMin), tostring(err))
  end
  if Version.gt(manifestMin, loaderVersion) then
    return false, ("รุ่นใหม่นี้ต้องการ loader v%s ขึ้นไป แต่ตัวคุณเป็น v%s — "
      .. "กรุณารัน loader ล่าสุดจากแหล่งที่เผยแพร่ (The Voider รองรับ Volt เท่านั้น)")
      :format(Version.stringify(manifestMin), Version.stringify(loaderVersion))
  end
  return true, nil
end

--- คำตัดสินของ version gate — ใช้ทั้ง loader ตอน DETECT และ updater ตอน PRE-STAGE
--- opts = { manifestVersion, activeVersion (nil = ยังไม่มีระบบเดิม เช่น boot ครั้งแรก),
---           channel = manifest.channel ("stable"|"rollback") }
--- คืน decision: "update" | "noop" | "reject-downgrade"
---   + detail เป็นภาษาไทย (ไปแสดงผู้ใช้/บันทึก log)
function Version.gate(opts)
  opts = opts or {}
  local mv = opts.manifestVersion
  local av = opts.activeVersion
  local channel = opts.channel or "stable"

  -- ยังไม่มีระบบเดิม (boot ครั้งแรก) = รับได้ทุกกรณีที่ manifest สมเหตุสมผล
  if not av then
    return "update", "boot ครั้งแรก — ติดตั้งรุ่น " .. Version.stringify(mv)
  end

  local cmp = Version.compare(mv, av)
  if cmp > 0 then
    return "update", ("พบรุ่นใหม่: %s → %s"):format(Version.stringify(av), Version.stringify(mv))
  end
  if cmp == 0 then
    return "noop", ("รุ่นล่าสุดแล้ว (%s)"):format(Version.stringify(mv))
  end

  -- รุ่นเก่ากว่า — ดู channel
  if channel == "rollback" then
    return "update", ("manifest ชี้กลับรุ่นก่อน (channel=rollback): %s → %s")
      :format(Version.stringify(av), Version.stringify(mv))
  end
  return "reject-downgrade", ("ปฏิเสธไฟล์เก่า: manifest เป็น v%s แต่ระบบกำลังรัน v%s "
    .. "(channel=%s ไม่อนุญาตการลดเวอร์ชัน — Version Gate §7.1)")
    :format(Version.stringify(mv), Version.stringify(av), tostring(channel))
end

return Version
