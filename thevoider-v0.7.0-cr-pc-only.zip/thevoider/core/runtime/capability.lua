-- ============================================================================
-- The Voider — core/runtime/capability.lua
-- Runtime Capability Detection (แผน freeze v2.1 §3.2 ข้อ 1)
--
-- ตอน startup ระบบ "ทดสอบจริง" (เรียกใช้แล้วดูผล ไม่ใช่แค่เช็คว่ามีชื่อ function
-- เพราะบาง executor มีชื่อแต่พัง) ว่า runtime ปัจจุบันทำอะไรได้ 8 อย่าง:
--   DRAWING / HOOK / HTTP / FILEIO / INPUT / CLIPBOARD / TASK / CRYPTO
--
-- ผลเก็บเป็น Capability Report → Developer Diagnostics (§8.4)
-- ทุกฟีเจอร์ต้องเช็ค capability ก่อนเปิด — ไม่ hard-code ตาม executor (§6.3)
-- ผลอ้างอิงของโปรเจกต์เก็บจาก Volt เท่านั้น + probe ใหม่ทุก release
--
-- หมายเหตุ: กรณี "ไม่มี HTTP เลยจน loader โหลดไม่ได้" = หน้าที่ของ
-- Bootstrap Preflight (§3.2 ข้อ 0) ก่อนโหลด core — สองระดับไม่ปนกัน
-- ============================================================================

local Capability = {}
Capability.__index = Capability

Capability.NAMES = { "DRAWING", "HOOK", "HTTP", "FILEIO", "INPUT", "CLIPBOARD", "TASK", "CRYPTO" }

-- Known-Answer Test ของ SHA-256 (ใช้ตรวจว่า crypto API ใช้ได้จริง ไม่ใช่แค่มีชื่อ)
-- sha256("TheVoider-KAT") = a0c4fa5d... (ตรวจสอบก่อนฝังด้วย python3 hashlib)
Capability.KAT_INPUT = "TheVoider-KAT"
Capability.KAT_DIGEST = "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee"

function Capability.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    env = ctx.env or _G, -- tests แทนด้วย stub environment ได้
    httpProbeUrl = ctx.httpProbeUrl or "https://raw.githubusercontent.com/",
    report = nil,
  }, Capability)
  return self
end

-- ค้นหาค่าจาก env โดยมี getgenv เป็นทางเลือก (executor บางตัวเก็บ global ที่นั่น)
local function resolve(env, key)
  local v = env[key]
  if v ~= nil then return v end
  local gg = env.getgenv or (type(_G.getgenv) == "function" and _G.getgenv)
  if type(gg) == "function" then
    local ok, res = pcall(gg)
    if ok and type(res) == "table" then
      return res[key]
    end
  end
  return nil
end

-- ---------------------------------------------------------------------------
-- probes: ทุกตัวคืน (supported: boolean, detail: string) — ห้าม panic เด็ดขาด
-- ---------------------------------------------------------------------------

local function probeDrawing(env)
  local Drawing = resolve(env, "Drawing")
  if not (type(Drawing) == "table" and type(Drawing.new) == "function") then
    return false, "ไม่มี Drawing library"
  end
  local ok, err = pcall(function()
    local line = Drawing.new("Line")
    line.Visible = true
    line.Thickness = 1
    line:Remove()
  end)
  if ok then
    return true, "Drawing.new สร้าง/ตั้ง props/Remove ได้จริง"
  end
  return false, "Drawing.new มีชื่อแต่ใช้งานพัง: " .. tostring(err)
end

local function probeHook(env)
  local hookfunction = resolve(env, "hookfunction")
  if type(hookfunction) == "function" then
    -- ทดสอบจริง: hook ต้อง "มีผล" ต่อการเรียกฟังก์ชัน (ไม่ใช่แค่เรียกผ่าน)
    -- ใช้ global เพื่อให้ hookfunction ของ runtime จริงและ stub แทนค่าได้ทั้งคู่
    local ok, res = pcall(function()
      __TV_HOOK_PROBE_BASE = function(a) return a * 2 end
      hookfunction(__TV_HOOK_PROBE_BASE, function(a) return (a * 2) + 100 end)
      local r = __TV_HOOK_PROBE_BASE(1)
      __TV_HOOK_PROBE_BASE = nil
      return r
    end)
    if ok and res == 102 then
      return true, "hookfunction ทดสอบจริงผ่าน (hook มีผลต่อการเรียก)"
    end
    if ok then
      __TV_HOOK_PROBE_BASE = nil
      return false, "hookfunction มีชื่อแต่ hook ไม่มีผลจริง (ได้ " .. tostring(res) .. " ไม่ใช่ 102)"
    end
    __TV_HOOK_PROBE_BASE = nil
    return false, "hookfunction เรียกแล้ว error: " .. tostring(res)
  end
  local hookmeta = resolve(env, "hookmetamethod")
  if type(hookmeta) == "function" then
    local ok2, res2 = pcall(function()
      local t = setmetatable({}, { __index = function(_, k) return k .. "!" end })
      hookmeta(t, "__index", function(_, k) return k .. "?" end)
      return t.foo
    end)
    if ok2 and res2 == "foo?" then
      return true, "hookmetamethod ทดสอบจริงผ่าน"
    end
    return false, "hookmetamethod มีชื่อแต่ใช้ไม่ได้: " .. tostring(res2)
  end
  return false, "ไม่มี hookfunction/hookmetamethod"
end

local function probeHttp(env, probeUrl)
  local list = {}
  local http_request = resolve(env, "http_request")
  if type(http_request) == "function" then table.insert(list, { "http_request", http_request }) end
  local syn = resolve(env, "syn")
  if type(syn) == "table" and type(syn.request) == "function" then table.insert(list, { "syn.request", syn.request }) end
  local request = resolve(env, "request")
  if type(request) == "function" then table.insert(list, { "request", request }) end
  local http_get = resolve(env, "http_get")
  if type(http_get) == "function" then table.insert(list, { "http_get", http_get }) end
  local httpget = resolve(env, "httpget")
  if type(httpget) == "function" then table.insert(list, { "httpget", httpget }) end

  if #list == 0 then
    return false, "ไม่มี HTTP API ที่รู้จักเลย"
  end
  local names = {}
  for _, c in ipairs(list) do table.insert(names, c[1]) end

  for _, cand in ipairs(list) do
    local name, fn = cand[1], cand[2]
    local ok, res
    if name == "http_get" or name == "httpget" then
      ok, res = pcall(fn, probeUrl)
    else
      ok, res = pcall(fn, { Url = probeUrl, Method = "GET", Timeout = 8 })
    end
    if ok then
      if type(res) == "table" then
        local code = res.StatusCode or res.Status or res.code
        if res.Success == true or (type(code) == "number" and code >= 200 and code <= 299) then
          return true, name .. " เรียกจริงผ่าน (ตอบ " .. tostring(code or "Success") .. ")"
        end
      elseif type(res) == "string" and #res > 0 then
        return true, name .. " เรียกจริงผ่าน (body " .. tostring(#res) .. "B)"
      end
    end
  end
  return false, "มี HTTP API (" .. table.concat(names, ", ") .. ") แต่เรียกจริงไม่สำเร็จ"
end

local function probeFileio(env)
  local writefile = resolve(env, "writefile")
  local readfile = resolve(env, "readfile")
  local delfile = resolve(env, "delfile")
  if not (type(writefile) == "function" and type(readfile) == "function") then
    return false, "ไม่มี writefile/readfile"
  end
  local path = "thevoider_probe.tmp"
  local ok, err = pcall(function()
    writefile(path, "ok")
    local content = readfile(path)
    assert(content == "ok", "อ่านกลับไม่ตรงกับที่เขียน (ได้ " .. tostring(content) .. ")")
    if type(delfile) == "function" then
      delfile(path)
    end
  end)
  if ok then
    local extra = type(delfile) == "function" and "" or " (ไม่มี delfile — ลบไฟล์ไม่ได้แต่บันทึก/อ่านใช้ได้)"
    return true, "เขียน-อ่าน round-trip ได้จริง" .. extra
  end
  return false, "file round-trip พัง: " .. tostring(err)
end

local function probeInput(env)
  local game = resolve(env, "game")
  if not (type(game) == "table" or type(game) == "userdata") then
    return false, "ไม่มี game object"
  end
  local ok, uis = pcall(function()
    return game:GetService("UserInputService")
  end)
  if not ok or type(uis) ~= "table" then
    return false, "เข้าถึง UserInputService ไม่ได้: " .. tostring(uis)
  end
  local ok2, err = pcall(function()
    -- อ่าน property จริง + connect/disconnect จริง (แล้วถอดทันที — ไม่ทิ้ง connection)
    local _ = uis.KeyboardEnabled
    local _m = uis.MouseEnabled
    local conn = uis.InputBegan:Connect(function() end)
    conn:Disconnect()
  end)
  if ok2 then
    return true, "UserInputService: อ่าน property + InputBegan connect/disconnect ได้จริง"
  end
  return false, "UserInputService มีชื่อแต่ใช้งานพัง: " .. tostring(err)
end

local function probeClipboard(env)
  local set = resolve(env, "setclipboard")
  local get = resolve(env, "getclipboard")
  if type(set) ~= "function" then
    return false, "ไม่มี setclipboard"
  end
  if type(get) ~= "function" then
    -- มีแค่ set: ไม่ยอมเขียนทับคลิปบอร์ดผู้ใช้ตอน startup เพื่อพิสูจน์ชื่อ
    return true, "มี setclipboard (ตรวจชื่ออย่างเดียว — ไม่ยุ่งคลิปบอร์ดผู้ใช้ตอน probe)"
  end
  -- มีทั้งคู่: ทดสอบจริงแบบกู้คืนค่าเดิมเสมอ (คลิปบอร์ดของผู้ใช้ต้องไม่ถูกทำลาย)
  local okBackup, backup = pcall(get)
  local payload = "TheVoider-clipboard-probe"
  local okSet, err = pcall(set, payload)
  if not okSet then
    return false, "setclipboard เรียกพัง: " .. tostring(err)
  end
  local _, back = pcall(get)
  if okBackup then pcall(set, backup) end -- คืนคลิปบอร์ดเดิมเสมอ
  if back == payload then
    return true, "set+get round-trip ผ่านจริง (คืนคลิปบอร์ดเดิมแล้ว)"
  end
  return true, "set เรียกได้ แต่ get ไม่ตรง (ใช้ได้ทาง export อย่างเดียว)"
end

local function probeTask(env)
  local task = resolve(env, "task")
  if type(task) ~= "table" then
    return false, "ไม่มี task library"
  end
  local ok, err = pcall(function()
    assert(type(task.spawn) == "function", "ไม่มี task.spawn")
    assert(type(task.wait) == "function", "ไม่มี task.wait")
    local ran = false
    task.spawn(function() ran = true end)
    assert(ran, "task.spawn รันฟังก์ชันจริงไม่ได้")
  end)
  if ok then
    return true, "task.spawn รันฟังก์ชันได้จริง + task.wait มีครบ"
  end
  return false, "task library พัง: " .. tostring(err)
end

local function probeCrypto(env)
  local forms = {}
  local crypto = resolve(env, "crypto")
  if type(crypto) == "table" and type(crypto.hash) == "function" then
    table.insert(forms, { "crypto.hash(algo, s)", function(s) return crypto.hash("sha256", s) end })
    table.insert(forms, { "crypto.hash(s, algo)", function(s) return crypto.hash(s, "sha256") end })
  end
  local syn = resolve(env, "syn")
  if type(syn) == "table" and type(syn.crypt) == "table" and type(syn.crypt.hash) == "function" then
    table.insert(forms, { "syn.crypt.hash(algo, s)", function(s) return syn.crypt.hash("sha256", s) end })
    table.insert(forms, { "syn.crypt.hash(s, algo)", function(s) return syn.crypt.hash(s, "sha256") end })
  end
  if #forms == 0 then
    return false, "ไม่มี crypto API ที่รู้จัก (hot update จะใช้การตรวจระดับ 2: version+size+marker)"
  end
  for _, f in ipairs(forms) do
    local name, fn = f[1], f[2]
    local ok, digest = pcall(fn, Capability.KAT_INPUT)
    if ok and type(digest) == "string" and #digest == 64 then
      if digest:lower() == Capability.KAT_DIGEST then
        return true, name .. " ผ่าน Known-Answer Test (SHA-256 ถูกต้องจริง)"
      end
      return false, name .. " ตอบ 64-hex แต่ digest ไม่ตรง KAT — ใช้ SHA-256 จริงไม่ได้ (ตรวจระดับ 2 แทน)"
    end
  end
  return false, "crypto API มีชื่อแต่เรียกใช้จริงไม่ได้ (ตรวจระดับ 2 แทน)"
end

-- ---------------------------------------------------------------------------
-- API
-- ---------------------------------------------------------------------------

--- รัน probe ทั้ง 8 — คืน Capability Report { [name] = {supported, detail} }
function Capability:Probe()
  local env = self.env
  local probes = {
    DRAWING = function() return probeDrawing(env) end,
    HOOK = function() return probeHook(env) end,
    HTTP = function() return probeHttp(env, self.httpProbeUrl) end,
    FILEIO = function() return probeFileio(env) end,
    INPUT = function() return probeInput(env) end,
    CLIPBOARD = function() return probeClipboard(env) end,
    TASK = function() return probeTask(env) end,
    CRYPTO = function() return probeCrypto(env) end,
  }
  local report = {}
  for _, name in ipairs(Capability.NAMES) do
    local ok, supported, detail = pcall(probes[name])
    if not ok then
      supported, detail = false, "probe รันเองพัง (ไม่ลาม): " .. tostring(supported)
    end
    report[name] = { supported = supported == true, detail = tostring(detail) }
  end
  self.report = report
  return report
end

--- ฟีเจอร์ต้องเช็คก่อนเปิดเสมอ — คืน (supported, detail)
function Capability:Has(name)
  if not self.report then
    self:Probe()
  end
  local r = self.report[name]
  if r == nil then
    return false, "ไม่รู้จัก capability ชื่อ " .. tostring(name)
  end
  return r.supported == true, r.detail
end

function Capability:Report()
  if not self.report then
    self:Probe()
  end
  return self.report
end

--- สรุปบรรทัดละชิ้นสำหรับ Developer Diagnostics (§8.4) + release notes
function Capability:Summary()
  local lines = {}
  for _, n in ipairs(Capability.NAMES) do
    local r = self:Report()[n]
    table.insert(lines, ("%s = %s (%s)"):format(n, r.supported and "SUPPORTED" or "OFF", r.detail))
  end
  return lines
end

return Capability
