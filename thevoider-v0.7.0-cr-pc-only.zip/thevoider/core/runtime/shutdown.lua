-- ============================================================================
-- The Voider — core/runtime/shutdown.lua
-- Shutdown Manager (แผน freeze v2.1 §3.2 ข้อ 5 + §3.10 hardening #7)
--
-- ลำดับปิดที่ถูกต้องเสมอ: ลำดับของโมดูลมาจาก Dependency Graph (graph.lua)
-- ซึ่งเป็น source of truth เดียวกับลำดับ Init() แต่ "กลับด้านเป๊ะ ๆ"
-- (ไม่ใช่ logic แยกอีกชุด — แก้ graph ที่เดียว ทั้งสองฝั่งเปลี่ยนตามอัตโนมัติ)
--
-- ใช้ 3 ที่: hot update TEARDOWN (§3.6 ขั้น 7) / unload ปกติ / ปุ่ม "ปิดสคริปต์" จาก UI
--
-- หลักเหล็กของรอบนี้ (§3.6 F1): Shutdown "ห้าม force-clean"
-- - หน้าที่ของ Shutdown = เรียก hook Disable/Destroy ตามลำดับ + ตรวจนับ orphan + รายงาน
-- - โมดูลเป็นคนคืนทรัพยากรของตัวเองใน Destroy (§3.4) — ค้างเกิน 0 = รายงานให้ผู้เรียก
--   ไป ABORT/ROLLBACK (hot update) — เลิกวิธี force-clean แล้วไปต่อถาวร
-- ============================================================================

local Shutdown = {}
Shutdown.__index = Shutdown

function Shutdown.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    boundary = nil,
    registry = nil,
    order = {},       -- init order (ชื่อ node ตาม graph.lua)
    hooks = {},       -- [name] = { Disable = fn?, Destroy = fn? }
    lastReport = nil,
  }, Shutdown)
  return self
end

function Shutdown:SetBoundary(b) self.boundary = b end
function Shutdown:SetRegistry(r) self.registry = r end

--- ตั้งลำดับจาก graph (initOrder) — Shutdown จะเรียงกลับด้านเอง
function Shutdown:Configure(initOrder)
  self.order = {}
  for _, n in ipairs(initOrder) do
    table.insert(self.order, n)
  end
  return self
end

--- ลงทะเบียน hook ปิดของ node (ใครมี lifecycle ครบจึงมี hook — node ที่ยังไม่มีโค้ดข้ามได้)
function Shutdown:Register(name, hooks)
  self.hooks[name] = hooks or {}
  return self
end

function Shutdown:Unregister(name)
  self.hooks[name] = nil
end

function Shutdown:_callHook(name, hookName, fn)
  if self.boundary then
    return (self.boundary:Guard(name, fn))
  end
  return (pcall(fn))
end

function Shutdown:_orphanNames()
  local out = {}
  if not (self.registry and self.lastReport) then return out end
  for _, row in ipairs(self.lastReport.rows) do
    if not row.ok then
      for _, desc in ipairs(self.registry:List(row.name)) do
        table.insert(out, desc)
      end
    end
  end
  return out
end

--- รันการปิดทั้งระบบ:
--   pass 1: Disable ทุก node (กลับลำดับ init)
--   pass 2: Destroy ทุก node (กลับลำดับ init) + ตรวจ orphan ต่อ node
-- คืน report = { rows, orphans, ok, order }
-- opts.assertZero = true (debug build) → orphan > 0 = error ทันที (assert อัตโนมัติ §3.4)
function Shutdown:Run(opts)
  opts = opts or {}
  local report = { rows = {}, orphans = 0, ok = true, order = {} }

  -- pass 1: Disable ทั้งหมด (กลับลำดับ)
  for i = #self.order, 1, -1 do
    local name = self.order[i]
    table.insert(report.order, name)
    local hooks = self.hooks[name]
    if hooks and type(hooks.Disable) == "function" then
      self:_callHook(name, "Disable", hooks.Disable)
    end
  end

  -- pass 2: Destroy ทั้งหมด (กลับลำดับ) + ตรวจ orphan ราย node
  for i = #self.order, 1, -1 do
    local name = self.order[i]
    local hooks = self.hooks[name]
    if hooks then
      if type(hooks.Destroy) == "function" then
        self:_callHook(name, "Destroy", hooks.Destroy)
      end
      local snap = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 }
      if self.registry then
        snap = self.registry:Snapshot(name)
      end
      local row = { name = name, orphan = snap, ok = snap.total == 0 }
      table.insert(report.rows, row)
      report.orphans = report.orphans + snap.total
      if snap.total > 0 then
        report.ok = false
      end
    end
  end

  self.lastReport = report

  if opts.assertZero and report.orphans > 0 then
    error(("[The Voider][Shutdown] ORPHAN > 0 หลัง TEARDOWN (ห้าม force-clean — ต้อง ABORT/ROLLBACK): %s")
      :format(table.concat(self:_orphanNames(), ", ")), 0)
  end

  return report
end

return Shutdown
