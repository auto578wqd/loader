-- ============================================================================
-- The Voider — core/runtime/manifest.lua (loader-domain §7.1 + §7.2)
--
-- Manifest รุ่นใหม่ครบชุด (แทน "ขนาด+เวอร์ชัน+md5" ของระบบเก่า):
--
--   {
--     "product": "the-voider",
--     "version": "0.3.0",
--     "releaseId": "r2026-10-01-01",
--     "files": { "the-voider.lua": { "sha256": "<64 hex>", "size": 123456 } },
--     "minLoaderVersion": "0.3.0",
--     "channel": "stable"
--   }
--
--   + Manifest.Verify: ตรวจความถูกต้นฉบับของ source 3 ระดับ (§7.2)
--     "crypto-api" → "software" (วัดเวลาจริง เกินงบ = ตกไประดับถัดไป)
--     → "level2" (version+size+header marker) — บอกตามจริงทุกครั้ง ไม่อวดอ้าง
--
-- dependency: ต้องมี JSON codec — รับผ่าน ctx.json หรือ __TV_PACKAGES.json
--   (ใน L1/L2) หรือ __TV_EMBED.json (ใน loader.lua ที่ build ประกอบแล้ว)
--   ไม่พบ = error ชัด ๆ ทันที (ไม่เดา)
-- ============================================================================

-- หา dependency จาก 3 แหล่ง (test packages → embedded loader → ไม่มี = error)
local function _pkg(name)
  local g = rawget(_G, "__TV_PACKAGES")
  if g and g[name] then return g[name] end
  local e = rawget(_G, "__TV_EMBED")
  if e and e[name] then return e[name] end
  return nil
end

local Version = _pkg("version")
local Sha256 = _pkg("sha256")

local Manifest = {}

Manifest.VERSION = "0.3.0"

Manifest.PRODUCT = "the-voider"
Manifest.CHANNELS = { stable = true, rollback = true }

-- ---- decode + validate ------------------------------------------------------

--- decode JSON string → (m, err) — ผ่าน Validate ให้เสร็จในตัว (decode อย่างเดียวไม่มีใช้)
function Manifest.Decode(jsonStr, ctx)
  ctx = ctx or {}
  local Json = ctx.json or _pkg("json")
  if not Json then
    return nil, "Manifest.Decode: หา JSON codec ไม่ได้ (ctx.json / __TV_PACKAGES.json / __TV_EMBED.json)"
  end
  if type(jsonStr) ~= "string" or #jsonStr == 0 then
    return nil, "manifest ว่างหรือไม่ใช่ string"
  end
  local ok, m = pcall(Json.decode, jsonStr)
  if not ok then
    return nil, ("manifest parse ไม่ผ่าน (JSON): " .. tostring(m))
  end
  if type(m) ~= "table" then
    return nil, "manifest ต้องเป็น JSON object"
  end
  local verr = Manifest.Validate(m, { product = ctx.product })
  if #verr > 0 then
    return nil, "manifest ไม่ผ่านการตรวจ: " .. table.concat(verr, "; ")
  end
  return m
end

--- ตรวจโครง manifest ครบทุกช่องบังคับ (§7.1) — คืนรายการข้อผิดพลาด (ว่าง = ผ่าน)
function Manifest.Validate(m, opts)
  opts = opts or {}
  local wantProduct = opts.product or Manifest.PRODUCT
  local errs = {}

  if type(m) ~= "table" then
    return { "manifest ต้องเป็น table" }
  end

  if m.product ~= wantProduct then
    errs[#errs + 1] = ("product ต้องเป็น %q (ได้ %s)"):format(
      wantProduct, tostring(m.product))
  end

  if Version then
    local pv, perr = Version.parse(m.version)
    if not pv then
      errs[#errs + 1] = ("version ผิดรูปแบบ: %s"):format(tostring(perr))
    end
    local mlv, mlerr
    if m.minLoaderVersion ~= nil and m.minLoaderVersion ~= "" then
      mlv, mlerr = Version.parse(m.minLoaderVersion)
      if not mlv then
        errs[#errs + 1] = ("minLoaderVersion ผิดรูปแบบ: %s"):format(tostring(mlerr))
      end
    else
      errs[#errs + 1] = "minLoaderVersion ขาดหาย (บังคับมีทุก manifest §7.1)"
    end
  else
    if type(m.version) ~= "string" or #m.version == 0 then
      errs[#errs + 1] = "version ต้องเป็น string ไม่ว่าง"
    end
  end

  if type(m.releaseId) ~= "string" or #m.releaseId == 0 then
    errs[#errs + 1] = "releaseId ต้องเป็น string ไม่ว่าง (อ้างราย release เดียว §7.1)"
  end

  if type(m.files) ~= "table" then
    errs[#errs + 1] = "files ต้องเป็น table { [ชื่อไฟล์] = { sha256, size } }"
  else
    local count = 0
    for fname, entry in pairs(m.files) do
      count = count + 1
      if type(fname) ~= "string" or #fname == 0 then
        errs[#errs + 1] = "ชื่อไฟล์ใน files ต้องเป็น string ไม่ว่าง"
      end
      if type(entry) ~= "table" then
        errs[#errs + 1] = ("files[%s]: ต้องเป็น table"):format(tostring(fname))
      else
        if type(entry.sha256) ~= "string"
          or #entry.sha256 ~= 64
          or entry.sha256:match("^[%x]+$") == nil then
          errs[#errs + 1] = ("files[%s].sha256 ต้องเป็น 64 ตัวเลขฐานสิบหก"):format(tostring(fname))
        end
        if type(entry.size) ~= "number"
          or math.floor(entry.size) ~= entry.size
          or entry.size <= 0 then
          errs[#errs + 1] = ("files[%s].size ต้องเป็นจำนวนเต็มบวก"):format(tostring(fname))
        end
      end
    end
    if count == 0 then
      errs[#errs + 1] = "files ว่าง — ต้องมีอย่างน้อย 1 ไฟล์"
    end
  end

  if not Manifest.CHANNELS[m.channel] then
    errs[#errs + 1] = ("channel ต้องเป็น stable|rollback เท่านั้น (ได้ %s)"):format(tostring(m.channel))
  end

  return errs
end

--- สร้าง manifest ใน memory (ใช้ในเทส/สร้างจริงใน build/tools/gen_manifest.py ฝั่ง python)
function Manifest.Build(fields)
  local m = {
    product = fields.product or Manifest.PRODUCT,
    version = fields.version,
    releaseId = fields.releaseId,
    files = fields.files or {},
    minLoaderVersion = fields.minLoaderVersion,
    channel = fields.channel or "stable",
  }
  local errs = Manifest.Validate(m, { product = fields.product })
  if #errs > 0 then
    return nil, "Manifest.Build: " .. table.concat(errs, "; ")
  end
  return m
end

-- ---- Verify: ความถูกต้นฉบับ 3 ระดับ (§7.2) -----------------------------------

-- หา version+releaseId จาก header marker ของ bundle (level 2 ใช้)
-- รูปแบบ marker (build_bundle.py เขียนให้ทุกครั้ง):
--   --[[ TV-BUNDLE version=0.3.0 releaseId=r... ]]
local function headerMarker(source)
  if type(source) ~= "string" then return nil end
  local ver = source:match("%-%-%[%[%s*TV%-BUNDLE%s+version=([%d%.]+)")
  local rid = source:match("releaseId=([%w%-_]+)")
  return ver, rid
end

Manifest.headerMarker = headerMarker

--- ตรวจ source ตรงกับรายการ files[entryName] ของ manifest
--- opts = { clock, softwareBudgetMs (default 1000), env (crypto probe ใช้ — default _G) }
--- คืน { ok, mode, detail, ms, expectedSize, gotSize }
---   mode: "crypto-api" | "software" | "level2"
---   (เลือกให้เองอัตโนมัติตาม §7.2 — รายงานเป็นภาษาไทยตรงไปตรงมา)
function Manifest.Verify(source, entryName, m, opts)
  opts = opts or {}
  local clock = opts.clock or os.clock
  local budgetMs = opts.softwareBudgetMs or 1000
  local entry = (type(m) == "table" and type(m.files) == "table") and m.files[entryName] or nil

  local out = {
    ok = false, mode = nil, detail = nil, ms = 0,
    expectedSize = entry and entry.size or nil,
    gotSize = type(source) == "string" and #source or nil,
  }
  if not entry then
    out.detail = ("manifest ไม่มีไฟล์ชื่อ %q"):format(tostring(entryName))
    return out
  end
  if type(source) ~= "string" or #source == 0 then
    out.detail = "source ว่างหรือไม่ใช่ string"
    return out
  end

  local expected = entry.sha256:lower()

  -- ระดับ 1: crypto API ของ executor (ถ้ามีและผ่าน KAT)
  if Sha256 then
    local hex, apiName = Sha256.cryptoHex(opts.env or _G, source)
    if hex then
      out.mode = "crypto-api"
      out.ms = 0
      if hex == expected then
        out.ok = true
        out.detail = ("ตรวจสอบความถูกต้นฉบับ: เต็มรูปแบบ (SHA-256 ผ่าน %s)"):format(apiName)
      else
        out.detail = ("SHA-256 ไม่ตรง (ผ่าน %s) — ไฟล์เสียหาย/ถูกแปลงกลางทาง"):format(apiName)
      end
      return out
    end
  end

  -- ระดับ 2: pure-Lua SHA-256 — วัดเวลาจริง เกินงบ = ตกไประดับ 3
  if Sha256 then
    local t0 = clock()
    local okH, got = pcall(Sha256.hex, source)
    local ms = (clock() - t0) * 1000
    if okH and ms <= budgetMs then
      out.mode = "software"
      out.ms = ms
      got = got:lower()
      if got == expected then
        out.ok = true
        out.detail = ("ตรวจสอบความถูกต้นฉบับ: เต็มรูปแบบ (โหมดซอฟต์แวร์, %.1f ms)"):format(ms)
      else
        out.detail = "SHA-256 ไม่ตรง (โหมดซอฟต์แวร์) — ไฟล์เสียหาย/ถูกแปลงกลางทาง"
      end
      return out
    end
    -- ช้าเกินงบ (หรือพัง) → ไประดับ 3 พร้อมบอกตามจริง
  end

  -- ระดับ 3: version + size + header marker
  out.mode = "level2"
  if #source ~= entry.size then
    out.detail = ("ตรวจระดับพื้นฐาน (version+size): ขนาดไม่ตรง (อยากได้ %d ได้ %d)")
      :format(entry.size, #source)
    return out
  end
  local ver = headerMarker(source)
  if not ver then
    out.detail = "ตรวจระดับพื้นฐาน (version+size): ไม่พบ header marker ของ bundle"
    return out
  end
  if Version and Version.parse(ver) and m.version and not Version.eq(ver, m.version) then
    out.detail = ("ตรวจระดับพื้นฐาน (version+size): marker v%s ไม่ตรง manifest v%s")
      :format(ver, tostring(m.version))
    return out
  end
  if not Version and tostring(ver) ~= tostring(m.version) then
    out.detail = ("ตรวจระดับพื้นฐาน (version+size): marker v%s ไม่ตรง manifest v%s")
      :format(tostring(ver), tostring(m.version))
  end

  out.ok = true
  out.detail = ("ตรวจระดับพื้นฐาน (version+size) — ระบบนี้ไม่มี crypto API และ "
    .. "SHA-256 โหมดซอฟต์แวร์ไม่จบในงบเวลา จึงตรวจได้เท่าระดับนี้ (บอกตามจริง §7.2)")
  return out
end

return Manifest
