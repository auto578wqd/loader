-- ============================================================================
-- The Voider — core/runtime/watchdog.lua
-- Watchdog (แผน freeze v2.1 §3.2 ข้อ 4)
--
-- โมดูลทุกตัวต้อง "รายงานหายใจ" ตามรอบที่ตนประกาศ (เช่น โมดูล per-frame = ทุกวินาที)
-- - loop task ที่จองผ่าน Runtime.Spawn หายใจอัตโนมัติทุกครั้งที่เรียก ctx.ShouldRun()
-- - โมดูล event-driven เรียก Runtime.Beat(owner) เองใน handler
--
-- โมดูลเงียบเกิน threshold → พยายาม restart 1 ครั้ง → ยังเงียบ = ปิด + แจ้งผู้ใช้
-- กัน infinite restart ด้วย exponential backoff (รอบที่พังซ้ำ threshold แรมเป็น 2 เท่า)
-- ============================================================================

local Watchdog = {}
Watchdog.__index = Watchdog

function Watchdog.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    checkInterval = ctx.checkInterval or 0.25, -- รอบเช็คของ monitor เอง
    stallFactor = ctx.stallFactor or 3,        -- เงียบเกิน period x นี้ = นับเป็น stall
    maxRestarts = ctx.maxRestarts or 1,        -- restart ได้ 1 ครั้ง (แผน §3.2 ข้อ 4)
    maxBackoff = ctx.maxBackoff or 32,         -- เพดาน backoff (2^n)
    registry = nil,
    boundary = nil,
    entries = {},     -- [owner] = entry ที่กำลังเฝ้า
    history = {},     -- [owner] = ตัวคูณ backoff สะสม (กัน register-พัง-register วนไม่รู้จบ)
    monitorHandle = nil,
    running = false,
  }, Watchdog)
  return self
end

function Watchdog:SetRegistry(r) self.registry = r end
function Watchdog:SetBoundary(b) self.boundary = b end

--- ลงทะเบียนโมดูลเพื่อเฝ้าหายใจ
-- opts = { period, stallFactor, maxRestarts, onRestart=function(owner, n), onDisable=function(owner, reason, entry) }
function Watchdog:Register(owner, opts)
  opts = opts or {}
  local mult = self.history[owner] or 1
  self.entries[owner] = {
    owner = owner,
    period = opts.period or 1,
    stallFactor = opts.stallFactor or self.stallFactor,
    maxRestarts = opts.maxRestarts or self.maxRestarts,
    onRestart = opts.onRestart,
    onDisable = opts.onDisable,
    lastBeat = self.clock(),
    restartCount = 0,
  }
  return self.entries[owner]
end

--- รายงานหายใจ 1 ครั้ง (เรียกจาก Runtime.Spawn อัตโนมัติ หรือโมดูลเรียกเอง)
function Watchdog:Beat(owner)
  local e = self.entries[owner]
  if e then
    e.lastBeat = self.clock()
  end
end

function Watchdog:Unregister(owner)
  self.entries[owner] = nil
end

function Watchdog:Entry(owner)
  return self.entries[owner]
end

--- threshold ปัจจุบันของ entry = period x stallFactor x backoff สะสม x 2^restartCount
function Watchdog:_threshold(e)
  local mult = self.history[e.owner] or 1
  return e.period * e.stallFactor * mult * (2 ^ e.restartCount)
end

function Watchdog:_runGuarded(fn)
  if self.boundary then
    return self.boundary:Guard("Runtime.Watchdog", fn)
  end
  local ok, err = pcall(fn)
  return ok, err
end

--- ปิดโมดูล + จำ backoff + แจ้งผู้ฟัง (No Silent Degradation — onDisable ต้องแจ้งผู้ใช้)
function Watchdog:_disable(e, reason)
  self.entries[e.owner] = nil
  self.history[e.owner] = math.min((self.history[e.owner] or 1) * 2, self.maxBackoff)
  local entry = e
  self:_runGuarded(function()
    if entry.onDisable then
      entry.onDisable(entry.owner, reason, entry)
    end
  end)
end

--- เช็คทุก entry 1 รอบ (เรียกโดย monitor loop)
function Watchdog:_check(now)
  for owner, e in pairs(self.entries) do
    local elapsed = now - e.lastBeat
    if elapsed > self:_threshold(e) then
      if e.restartCount < e.maxRestarts then
        -- พยายาม restart 1 ครั้งก่อน (แผน: restart หนึ่งครั้ง → ยังเงียบ = ปิด)
        e.restartCount = e.restartCount + 1
        e.lastBeat = now
        local entry = e
        local ok = self:_runGuarded(function()
          if entry.onRestart then
            entry.onRestart(entry.owner, entry.restartCount)
          end
        end)
        if not ok then
          -- restart callback พังเอง = รีสตาร์ทไม่ได้จริง → ไปทางปิดทันที (ไม่ลาม)
          self:_disable(e, "restart-failed")
        end
      else
        self:_disable(e, "stalled-after-restart")
      end
    end
  end
end

--- เริ่ม monitor loop (จองผ่าน registry = โมดูลของ Runtime เอง owner="Runtime.Watchdog")
function Watchdog:Start()
  if self.running or not self.registry then
    return self
  end
  self.running = true
  local wd = self
  local reg = self.registry
  self.monitorHandle = reg:Scope("Runtime.Watchdog", function()
    return reg:Spawn("WatchdogMonitor", function(ctx)
      while ctx.ShouldRun() do
        wd:_check(wd.clock())
        reg.task.wait(wd.checkInterval)
      end
    end)
  end)
  return self
end

--- หยุด monitor + คืนทรัพยากรของตัวเอง (orphan = 0 เช่นกัน)
function Watchdog:Stop()
  self.running = false
  if self.monitorHandle then
    self.monitorHandle.Release()
    self.monitorHandle = nil
  end
end

return Watchdog
