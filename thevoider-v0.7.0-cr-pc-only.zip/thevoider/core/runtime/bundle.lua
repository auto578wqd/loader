-- ============================================================================
-- The Voider — core/runtime/bundle.lua
-- System Bundle Entry — จุดเข้าเดียวของ "the-voider.lua" ที่ build ประกอบ
-- (แผน freeze v2.1 §3.8: ตัวส่งมอบจริงคือไฟล์เดียว ประกอบโดย build)
--
-- เมื่อ loader รัน bundle (loadstring → exec) → execFn() เรียก Bundle.Entry:
--   สร้าง Runtime → Foundation → Adapter ตาม dependency graph → Bootstrap
--   → อ่าน __TV_BUNDLE_RUN (source+manifest ที่ loader เก็บไว้ก่อน execute)
--   → host:register({system, source, manifest}) ให้ update orchestrator จัดการ
--
-- สัญญา system handle (สิ่งที่ update.lua ต้องการ — ทั้งหมดคือ interface
-- สาธารณะเดิมของ Runtime/Foundation/Adapter ไม่มีการแตะภายใน):
--   {
--     version, releaseId,
--     runtime, foundation, adapter,
--     bus, config, migration, shutdown, registry, boundary, watchdog, diag,
--     probe,           -- AdapterSelfProbe object: :Probe() / :LastReport()
--     providers,        -- ลำดับ { {name, Serialize(sys), Apply(sys, oldState)} }
--     selfChecks,       -- ลำดับ { {name, fn(sys, ctx) → (ok, detail)} }
--   }
--
-- state providers (moduleStates ของ Rollback Snapshot §3.6):
--   เฟส 0 ยังไม่มี feature module → production bundle ส่ง providers = {}
--   (ไม่สร้างล่วงหน้า — กลไกถูกพิสูจน์ด้วย fixture ใน L2 เท่านั้น)
--   โมดูลจริงจะมาหลัง Behavioral Matrix ผ่านรีวิว (กติกา §4.5)
--
-- SELFCHECK ชุดย่อยของแต่ละระบบ (§3.6 ขั้น 12: watchdog heartbeat + version
-- report + L1 self-test ชุดย่อ) ติดตั้งเป็น default — release ใดจะเพิ่ม
-- check ของตัวเองก็ได้ (selfChecks ใน spec ต่อท้าย)
-- ============================================================================

local P = __TV_PACKAGES
local RuntimeLib = P.init
local FoundationLib = P.foundation
local AdapterLib = P.adapter
local UiLib = P.ui
local JsonLib = P.json

local Bundle = {}

Bundle.VERSION = "0.3.0"

-- ---- default selfChecks (ติดตั้งทุกระบบ) -------------------------------------

local function defaultSelfChecks(sys, spec)
  local ConfigLib = P.config
  local checks = {}

  checks[#checks + 1] = {
    name = "bus-active",
    fn = function(s)
      local stats = s.bus:Stats()
      if stats.frozen then return false, "bus ยัง frozen อยู่ (RESUME ไม่สำเร็จ?)" end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "bus-generation",
    fn = function(s, ctx)
      if not ctx or not ctx.generation then return true, "ไม่มี generation เป้าหมาย — ข้าม" end
      local gen = s.bus:Stats().generation
      if gen ~= ctx.generation then
        return false, ("generation ไม่ตรง (อยากได้ %d ได้ %d)"):format(ctx.generation, gen)
      end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "config-schema",
    fn = function(s)
      local v = s.config:Get("schemaVersion")
      local want = ConfigLib and ConfigLib.CURRENT_SCHEMA_VERSION or 2
      if v ~= want then
        return false, ("schemaVersion = %s ไม่ตรงปัจจุบัน (%s)"):format(tostring(v), tostring(want))
      end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "diag-sampling",
    fn = function(s)
      local n = s.diag:SampleCount()
      if not n or n < 1 then return false, "Diagnostics ยังไม่ sampling เลย" end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "probe-ran",
    fn = function(s)
      local r = s.probe:LastReport()
      if not r then return false, "Adapter Self-Probe ยังไม่เคยรัน" end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "watchdog-heartbeat",
    fn = function(s, ctx)
      -- ทุก entry ที่ลงทะเบียนต้องหายใจใหม่พอ (เฟส 0 มักไม่มี entry = ผ่านตามจริง)
      local now = os.clock()
      for owner, e in pairs(s.watchdog.entries or {}) do
        local threshold = (e.period or 1) * (e.stallFactor or 3)
        if now - (e.lastBeat or 0) > threshold then
          return false, ("watchdog: %s เงียบเกิน threshold"):format(tostring(owner))
        end
      end
      return true, nil
    end,
  }

  checks[#checks + 1] = {
    name = "version-report",
    fn = function(s, ctx)
      if ctx and ctx.manifest and ctx.manifest.version then
        if s.version ~= ctx.manifest.version then
          return false, ("version ของระบบ (%s) ไม่ตรง manifest (%s)")
            :format(s.version, ctx.manifest.version)
        end
      end
      return true, s.version
    end,
  }

  checks[#checks + 1] = {
    name = "selftest-mini",
    fn = function(s)
      -- L1 self-test ชุดย่อ 3 ข้อ (จริง รันบนระบบตัวเอง):
      local enc = JsonLib.encode({ ok = 1, list = { 2, 3 } })
      local dec = JsonLib.decode(enc)
      if dec.ok ~= 1 or dec.list[2] ~= 3 then
        return false, "json roundtrip ไม่ผ่าน"
      end
      local hit = {}
      s.runtime.Scope("SelfTestMini", function()
        s.bus:On("selftest:ping", function(p) hit[#hit + 1] = p end)
      end)
      s.bus:Declare("selftest:ping", "idempotent")
      s.bus:Publish("selftest:ping", { n = 1 })
      if #hit ~= 1 then
        return false, "bus pub/sub ไม่ผ่าน"
      end
      local t = s.foundation.Services:MustGet("I18n").T("notify.adapter.dead", { name = "probe" })
      if type(t) ~= "string" or #t == 0 then
        return false, "i18n แปลไม่ได้"
      end
      return true, "json+bus+i18n ผ่าน"
    end,
  }

  return checks
end

-- ---- Build ---------------------------------------------------------------------

-- spec = {
--   version, releaseId,        [บังคับ]
--   runtime = {...},           -- ส่งต่อให้ RuntimeLib.new (clock/task/drawing/instance/debug)
--   env = {...},               -- ส่งต่อให้ AdapterLib (nil = เกมจริงตาม adapter เดิม)
--   guiRoot = <instance>,      -- ส่งต่อให้ UI (nil = gethui ของ executor / ไม่มี = graceful)
--   providers = {...},         -- state providers เพิ่มเติม (production เฟส 0 = {})
--   selfChecks = {...},        -- เพิ่มหลัง default
--   onAssembly = fn(sys),      -- hook หลังประกอบ+boot เสร็จ (ใช้ใน fixture เท่านั้น)
--   boot = true|false,         -- false = ไม่ boot (ส่งต่อให้ผู้เรียกเรียก sys:boot() เอง)
-- }
function Bundle.Build(spec)
  spec = spec or {}
  if type(spec.version) ~= "string" or #spec.version == 0 then
    error("Bundle.Build: spec.version ต้องเป็น string ไม่ว่าง", 2)
  end
  if type(spec.releaseId) ~= "string" or #spec.releaseId == 0 then
    error("Bundle.Build: spec.releaseId ต้องเป็น string ไม่ว่าง", 2)
  end

  local sys = {}

  -- 1) Runtime (L1) ตามลำดับ graph — Bootstrap ภายใน
  local R = RuntimeLib.new(spec.runtime or {})
  R:Bootstrap()
  sys.runtime = R

  -- 2) Foundation (L2)
  local F = FoundationLib.new({ runtime = R })
  F:Bootstrap()
  sys.foundation = F

  -- 3) Game Adapter (L3) — ประตูเดียวสู่เกม (§3.3)
  local A = AdapterLib.new({
    runtime = R,
    foundation = F,
    env = spec.env,
  })
  A:Bootstrap()
  sys.adapter = A

  -- 3.5) UI (L6 เฟส 1) — หลัง adapter ตามลำดับ graph (L4/L5 ยังไม่มี
  --      ในเฟสนี้ตาม roadmap §5.2; พอมีจริงจะแทรกตามลำดับ initOrder)
  local Ui = UiLib.new({
    runtime = R,
    foundation = F,
    version = spec.version,
    guiRoot = spec.guiRoot,
    clock = (spec.runtime or {}).clock,
    env = spec.env,
  })
  Ui:Bootstrap()
  sys.ui = Ui

  -- 4) ส่วนประกอบของ update domain (handle ตามสัญญา)
  sys.version = spec.version
  sys.releaseId = spec.releaseId
  sys.bus = F.Bus
  sys.config = F.Config
  sys.migration = F.Migration
  sys.shutdown = R.Shutdown
  sys.registry = R.Registry
  sys.boundary = R.Boundary
  sys.watchdog = R.Watchdog
  sys.diag = F.Diag
  sys.probe = A.SelfProbe

  -- 5) state providers (เฟส 0 production = ไม่มี; ตัวเพิ่มจาก spec ต่อท้าย)
  sys.providers = {}
  for _, pr in ipairs(spec.providers or {}) do
    if type(pr) ~= "table" or type(pr.name) ~= "string"
      or type(pr.Serialize) ~= "function" or type(pr.Apply) ~= "function" then
      error(("Bundle.Build: provider %s ไม่ครบสัญญา (name/Serialize/Apply)"):format(tostring(pr and pr.name)), 2)
    end
    sys.providers[#sys.providers + 1] = pr
  end

  -- 6) selfChecks = default + ของ spec
  sys.selfChecks = defaultSelfChecks(sys, spec)
  for _, c in ipairs(spec.selfChecks or {}) do
    if type(c) ~= "table" or type(c.name) ~= "string" or type(c.fn) ~= "function" then
      error(("Bundle.Build: selfCheck %s ไม่ครบสัญญา (name/fn)"):format(tostring(c and c.name)), 2)
    end
    sys.selfChecks[#sys.selfChecks + 1] = c
  end

  -- 7) hook ของ fixture (หลังประกอบ+boot เสร็จ)
  if type(spec.onAssembly) == "function" then
    spec.onAssembly(sys)
  end

  return sys
end

-- ---- Entry: จุดที่ loader เรียกตอน execute bundle ------------------------------

-- host (สร้างโดย loader_main) ต้องมี host.register(record)
-- loader ตั้ง _G.__TV_BUNDLE_RUN = { source, manifest } ก่อน execute
function Bundle.Entry(host, spec)
  local sys = Bundle.Build(spec)

  local run = rawget(_G, "__TV_BUNDLE_RUN")
  if host and type(host.register) == "function" then
    host.register({
      system = sys,
      source = run and run.source or nil,
      manifest = run and run.manifest or nil,
    })
  end
  return sys
end

return Bundle
