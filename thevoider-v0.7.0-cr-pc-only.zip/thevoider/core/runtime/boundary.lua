-- ============================================================================
-- The Voider — core/runtime/boundary.lua
-- Error Boundary (แผน freeze v2.1 §3.2 ข้อ 3)
--
-- entry point ทุกตัวของโมดูลรันภายใต้ boundary:
--   - error ถูกจับ (ลามไม่ได้ — ระบบที่เหลือเดินต่อ)
--   - นับ error ต่อโมดูล (ให้ watchdog ใช้ตัดสิน)
--   - บันทึก log พร้อม stack trace (DiagnosticsService ดึงไปแสดง/export รอบหน้า)
--   - แจ้ง subscriber (ModuleManager/Notification รอบหน้า) = "ปิดเฉพาะโมดูลนั้น + แจ้งผู้ใช้"
--
-- นโยบาย "ปิดโมดูลไหน" อยู่ที่ผู้ฟัง (ModuleManager ของ Foundation รอบถัดไป)
-- Boundary เองเป็นเครื่องจับ-นับ-แจ้ง ให้บริสุทธิ์ต่อทุกโมดูล
-- ============================================================================

local Boundary = {}
Boundary.__index = Boundary

local unpack = table.unpack or unpack

function Boundary.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    debug = ctx.debug or false,
    counters = {},   -- [owner] = จำนวน error สะสม
    records = {},    -- log ล่าสุด (ring buffer)
    listeners = {},  -- รายการ callback(owner, record)
    maxRecords = ctx.maxRecords or 200,
  }, Boundary)
  return self
end

--- ลงทะเบียนผู้ฟัง error — คืนรหัสตำแหน่ง (ใช้ถอดภายหลังได้)
function Boundary:On(cb)
  table.insert(self.listeners, cb)
  return #self.listeners
end

function Boundary:Off(index)
  self.listeners[index] = nil
end

--- ตัวนับ error รายโมดูล (watchdog ใช้ตัดสิน + §5.1: error counter ต้องชน session log 100%)
function Boundary:Count(owner)
  return self.counters[owner] or 0
end

function Boundary:Counters()
  return self.counters
end

--- log ล่าสุด (Diagnostics อ่านไป export)
function Boundary:Records()
  return self.records
end

function Boundary:Reset(owner)
  if owner then
    self.counters[owner] = 0
  else
    self.counters = {}
  end
end

--- บันทึก error 1 ครั้ง + แจ้งผู้ฟังทุกตน (ผู้ฟังพังเองไม่มีทางลามมาที่ boundary)
function Boundary:_record(owner, err)
  local stack = tostring(err)
  if debug and debug.traceback then
    stack = debug.traceback(tostring(err), 2)
  end
  self.counters[owner] = (self.counters[owner] or 0) + 1
  local rec = {
    owner = owner,
    err = tostring(err),
    stack = stack,
    time = self.clock(),
    count = self.counters[owner],
  }
  table.insert(self.records, rec)
  if #self.records > self.maxRecords then
    table.remove(self.records, 1)
  end
  for _, cb in ipairs(self.listeners) do
    local okCb, cbErr = pcall(cb, owner, rec)
    if not okCb and self.debug then
      print(("[The Voider][ErrorBoundary] listener error: %s"):format(tostring(cbErr)))
    end
  end
  return rec
end

--- รัน fn ภายใต้ boundary — คืน (true, ผลลัพธ์...) หรือ (false, record)
function Boundary:Guard(owner, fn, ...)
  local results = { pcall(fn, ...) }
  local ok = table.remove(results, 1)
  if ok then
    return true, unpack(results)
  end
  local rec = self:_record(owner, results[1])
  return false, rec
end

return Boundary
