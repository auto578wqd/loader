-- ============================================================================
-- The Voider — core/runtime/init.lua
-- Runtime Layer assembler (แผน freeze v2.1 §3.2) — ประกอบ 5 องค์ประกอบเป็น Runtime เดียว
--
-- ลำดับโหลด (build/runner รับประกัน): registry → boundary → watchdog → shutdown
-- → capability → preflight → graph → init (ไฟล์นี้)
--
-- ใช้งาน:
--   local RuntimeLib = __TV_PACKAGES.init
--   local R = RuntimeLib.new({ clock = ..., task = task })
--   R:Bootstrap()            -- probe capability + เปิด watchdog monitor + อ่าน graph
--   R.Spawn(...) R.Connect(...) R.NewRender(...) R.Temp(...)   -- ลายเซ็นตามแผน §3.2
--   R.ShutdownAll()          -- ปิดตาม graph + คืนทุกอย่าง (orphan ต้อง 0)
-- ============================================================================

local P = __TV_PACKAGES
local Registry = P.registry
local Boundary = P.boundary
local Watchdog = P.watchdog
local ShutdownManager = P.shutdown
local Capability = P.capability
local Preflight = P.preflight
local Graph = P.graph

local RuntimeLib = {}

RuntimeLib.version = "0.1.0"

-- loader ใช้ก่อนโหลด core (§3.2 ข้อ 0) — build จะ embed preflight ลง loader.lua
RuntimeLib.Preflight = Preflight

function RuntimeLib.new(ctx)
  ctx = ctx or {}

  local boundary = Boundary.new(ctx)
  local registry = Registry.new(ctx)
  local watchdog = Watchdog.new(ctx)
  local shutdown = ShutdownManager.new(ctx)
  local capability = Capability.new(ctx)

  -- เชื่อมองค์ประกอบเข้าหากัน (registry → boundary/watchdog, watchdog → registry/boundary)
  registry:SetBoundary(boundary)
  registry:SetWatchdog(watchdog)
  watchdog:SetRegistry(registry)
  watchdog:SetBoundary(boundary)
  shutdown:SetBoundary(boundary)
  shutdown:SetRegistry(registry)

  local R = {}

  R.version = RuntimeLib.version
  R.ctx = ctx
  R.Graph = Graph
  R.Registry = registry
  R.Boundary = boundary
  R.Watchdog = watchdog
  R.Shutdown = shutdown
  R.Capability = capability

  -- ---- API ตามแผน §3.2 (ลายเซ็นตรงเป๊ะ) ------------------------------

  R.Spawn = function(name, fn)
    return registry:Spawn(name, fn)
  end
  R.Connect = function(signal, fn)
    return registry:Connect(signal, fn)
  end
  R.NewRender = function(kind, props)
    return registry:NewRender(kind, props)
  end
  R.Temp = function(obj, disposer)
    return registry:Temp(obj, disposer)
  end

  -- ---- ความเป็นเจ้าของ / หายใจ ------------------------------------------

  R.Scope = function(owner, fn)
    return registry:Scope(owner, fn)
  end
  R.Owner = function()
    return registry:Owner()
  end
  R.Beat = function(owner)
    watchdog:Beat(owner)
  end

  -- ---- ตรวจนับ / คืนทรัพยากร / ตรวจ orphan ------------------------------

  R.Snapshot = function(owner)
    return registry:Snapshot(owner)
  end
  R.List = function(owner)
    return registry:List(owner)
  end
  R.Release = function(owner)
    return registry:Release(owner)
  end
  R.ReleaseAll = function()
    return registry:Release(nil)
  end
  R.VerifyZero = function(owner)
    return registry:VerifyZero(owner)
  end
  -- ใช้ตอน hot update VERIFY (§3.6 ขั้น 8) — นับเฉพาะของโมดูล (ไม่รวม Runtime.*)
  R.ModuleTotals = function()
    return registry:ModuleTotals()
  end

  -- ---- lifecycle ของ Runtime ทั้งชุด -------------------------------------

  -- เรียกครั้งเดียวหลังสร้าง: probe capability 8 ตัว + เปิด watchdog monitor
  -- + ตั้งลำดับ shutdown จาก Dependency Graph (SSOT เดียว §3.10)
  R.Bootstrap = function()
    capability:Probe()
    watchdog:Start()
    if Graph and Graph.initOrder then
      shutdown:Configure(Graph.initOrder)
    end
    return R
  end

  -- ปิดทุกอย่างตามลำดับ graph: hook ของโมดูล (Disable→Destroy กลับลำดับ init)
  -- แล้วปิด runtime เองเป็นท้ายสุด + คืนทรัพยากรทุกชิ้น — จบแล้ว orphan ต้องเท่ากับ 0
  R.ShutdownAll = function(opts)
    local report = shutdown:Run(opts)
    watchdog:Stop()
    registry:Release(nil)
    return report
  end

  return R
end

return RuntimeLib
