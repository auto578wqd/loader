-- ============================================================================
-- The Voider — core/runtime/loader_main.lua (Loader v2 — แผน §3.2 ข้อ 0 + §7)
--
-- จุดเข้าเดียวที่ผู้ใช้รัน (repo root loader.lua = ไฟล์นี้ + package ที่ฝัง
-- ประกอบโดย build/tools/build_dist.py):
--
--   1. Bootstrap Preflight (§3.2 ข้อ 0 — แยกจาก runtime capability ชัดเจน):
--      หา HTTP function จริง → ตรวจ CDN — พัง = plain text ไทย 1 บรรทัด แล้วหยุด
--      (ยังไม่โหลด core = ไม่มี UI ให้เปิด จึงห้ามสัญญา UI ตรงนี้)
--   2. ดึง manifest.json (4-URL fallback) → Version Gate + minLoaderVersion
--   3. ดึง the-voider.lua → ตรวจความถูกต้นฉบับ 3 ระดับ (§7.2 — บอกตามจริง)
--   4. execute bundle → host.register → Update orchestrator ถือ active ต่อ
--   5. เปิดใช้ host.checkUpdate() = ตัวจุดชนของ Hot Update Protocol (§3.6)
--      (เฟส 0 ยังไม่มี UI — เรียกได้จาก console/Diagnostics; อนาคตปุ่มใน Hub)
--
-- executor: Volt เท่านั้น (แผน freeze v2.1) — ข้อความทุกอันเป็นภาษาไทย
--
-- URL: ตั้ง OWNER ให้ถูกตอนเผยแพร่จริง — ถ้ายังเป็น placeholder loader จะเตือน
-- ชัดเจนตอนรัน (รอบนี้ยังไม่มี deployment จึงไม่มี URL จริงให้ตรวจ)
-- ============================================================================

local function _pkg(name)
  local g = rawget(_G, "__TV_PACKAGES")
  if g and g[name] then return g[name] end
  local e = rawget(_G, "__TV_EMBED")
  if e and e[name] then return e[name] end
  return nil
end

local Preflight = _pkg("preflight")
local Version = _pkg("version")
local Manifest = _pkg("manifest")
local Update = _pkg("update")

local LoaderMain = {}

LoaderMain.VERSION = "0.3.0"        -- เวอร์ชัน loader ตัวเอง
LoaderMain.PRODUCT = "the-voider"
LoaderMain.ENTRY_FILE = "the-voider.lua"
LoaderMain.MANIFEST_FILE = "manifest.json"

-- เผยแพร่จริง: แก้ OWNER เป็น GitHub user/org ของโปรเจกต์ (บันทึกใน CHANGELOG)
LoaderMain.OWNER = "OWNER-PLACEHOLDER"
LoaderMain.REPO = "thevoider"

LoaderMain.BASES = {
  "https://raw.githubusercontent.com/OWNER/thevoider/main",
  "https://cdn.jsdelivr.net/gh/OWNER/thevoider@main",
  "https://raw.githack.com/OWNER/thevoider/main",
  "https://github.com/OWNER/thevoider/raw/main",
}

--- รายการ URL เต็ม (แทน OWNER จริง) — ใช้ต่อ path ที่ต้องการ
function LoaderMain.urls()
  local out = {}
  for _, base in ipairs(LoaderMain.BASES) do
    local b = base:gsub("OWNER", LoaderMain.OWNER)
    out[#out + 1] = b
  end
  return out
end

-- ---- HTTP fetch (คืน body จริง — ต่างจาก preflight ที่ตรวจแค่ ok) ----------

local function respondOnce(name, fn, url, timeout)
  if name == "http_get" or name == "httpget" then
    local ok, body = pcall(fn, url)
    if not ok then return { ok = false, status = "error:" .. tostring(body), body = nil } end
    if type(body) == "string" and #body > 0 then
      return { ok = true, status = "200", body = body, url = url }
    end
    return { ok = false, status = "empty", body = nil }
  end
  -- รูปแบบ table-request (http_request / syn.request / request)
  local req = { Url = url, Method = "GET" }
  if timeout then req.Timeout = timeout end
  local ok, res = pcall(fn, req)
  if not ok then return { ok = false, status = "error:" .. tostring(res), body = nil } end
  if type(res) == "table" then
    local body = res.Body
    local code = res.StatusCode or res.Status or res.code
    local okCode = (res.Success == true)
      or (type(code) == "number" and code >= 200 and code <= 299)
    if okCode and type(body) == "string" and #body > 0 then
      return { ok = true, status = tostring(code or "ok"), body = body, url = url }
    end
    return { ok = false, status = tostring(code or "no-body"), body = nil }
  elseif type(res) == "string" and #res > 0 then
    return { ok = true, status = "200", body = res, url = url }
  end
  return { ok = false, status = "no-response", body = nil }
end

-- ---- default loadFn (Luau: loadstring / Lua 5.3: load) ----------------------

local function defaultLoadFn(source, chunkName)
  local ls = rawget(_G, "loadstring") or rawget(_G, "load")
  if type(ls) ~= "function" then
    return nil, "environment นี้ไม่มี loadstring/load — โหลด bundle ไม่ได้"
  end
  return ls(source, chunkName)
end

-- ---- constructor --------------------------------------------------------------

-- opts (ทั้งหมด optional — ใช้แทนค่า default ได้ สะดวกใน L2):
--   env, httpFn, httpName, urls, loadFn, logger, clock, onStep,
--   softwareBudgetMs, budgetMs, timeout
function LoaderMain.new(opts)
  opts = opts or {}
  local self = setmetatable({}, { __index = LoaderMain })
  self.env = opts.env or _G
  self.logger = opts.logger or function(level, msg)
    local w = level == "error" and (type(warn) == "function" and warn or print)
      or print
    w(("[The Voider][Loader][%s] %s"):format(level, msg))
  end
  self.httpFn = opts.httpFn
  self.httpName = opts.httpName
  self.urls = opts.urls or LoaderMain.urls()
  self.loadFn = opts.loadFn or defaultLoadFn
  self.clock = opts.clock or os.clock
  self.timeout = opts.timeout or 8
  self.softwareBudgetMs = opts.softwareBudgetMs or 1000
  self.updateBudgetMs = opts.budgetMs or 5000
  self.onStep = opts.onStep

  self.updater = nil
  self.host = nil
  self.booted = nil
  return self
end

-- ---- ขั้น 1: Bootstrap Preflight (plain text — §3.2 ข้อ 0) -------------------

function LoaderMain:preflight()
  -- ตรวจด้วย URL ของ manifest จริง (base เปล่าตอบ 404 บน CDN จริง —
  -- ใช้ path ที่จะถูกดึงจริงจึงวัดความเข้าถึงได้ตรง)
  local mfUrls = {}
  for _, b in ipairs(self.urls) do
    mfUrls[#mfUrls + 1] = b .. "/" .. LoaderMain.MANIFEST_FILE
  end
  local result = Preflight.Run({
    env = self.env,
    urls = mfUrls,
    httpFn = self.httpFn,
    httpName = self.httpName,
    timeout = self.timeout,
    log = function(msg) self.logger("error", msg) end,
  })
  return result
end

-- ---- ขั้น 2-3: ดึง manifest/entry จาก 4-URL -----------------------------------

function LoaderMain:fetch(url)
  local name, fn
  if self.httpFn then
    name = self.httpName or "(custom)"
    fn = self.httpFn
  else
    name, fn = Preflight.FindHTTP(self.env)
  end
  if not name then
    return { ok = false, status = "no-http" }
  end
  return respondOnce(name, fn, url, self.timeout)
end

--- ลองทุก URL จนกว่าจะได้ manifest ที่ผ่านการตรวจ — คืน (m, tried[])
function LoaderMain:fetchManifest()
  local tried = {}
  for _, base in ipairs(self.urls) do
    local url = base .. "/" .. LoaderMain.MANIFEST_FILE
    local res = self:fetch(url)
    tried[#tried + 1] = ("%s → %s"):format(url, res.ok and "ok" or res.status)
    if res.ok then
      local m, err = Manifest.Decode(res.body, {})
      if m then
        return m, tried
      end
      tried[#tried] = tried[#tried] .. " (manifest เสีย: " .. tostring(err) .. ")"
    end
  end
  return nil, tried
end

--- ดึง entry file ตาม manifest + ตรวจความถูกต้นฉบับ 3 ระดับ
function LoaderMain:fetchEntry(m)
  local tried = {}
  for _, base in ipairs(self.urls) do
    local url = base .. "/" .. LoaderMain.ENTRY_FILE
    local res = self:fetch(url)
    if res.ok then
      local verify = Manifest.Verify(res.body, LoaderMain.ENTRY_FILE, m, {
        clock = self.clock,
        softwareBudgetMs = self.softwareBudgetMs,
        env = self.env,
      })
      if verify.ok then
        return res.body, verify, tried
      end
      tried[#tried + 1] = ("%s → %s"):format(url, verify.detail)
    else
      tried[#tried + 1] = ("%s → %s"):format(url, res.status)
    end
  end
  return nil, nil, tried
end

-- ---- host + updater wiring ----------------------------------------------------

function LoaderMain:_ensureHost()
  if self.host then return end
  local loader = self
  self.host = {
    loaderVersion = LoaderMain.VERSION,
    register = function(record)
      loader.updater:Attach(record)
      loader.logger("info", ("ระบบ v%s พร้อมใช้งาน (releaseId %s)")
        :format(record.system.version, tostring(record.system.releaseId)))
    end,
    checkUpdate = function()
      return loader:checkUpdate()
    end,
    log = function(level, msg) loader.logger(level, msg) end,
  }
  self.updater = Update.new({
    loadFn = self.loadFn,
    clock = self.clock,
    logger = self.logger,
    onStep = self.onStep,
    budgetMs = self.updateBudgetMs,
    softwareBudgetMs = self.softwareBudgetMs,
    loaderVersion = LoaderMain.VERSION,
    env = self.env,
  })
end

-- ---- ขั้น 4-5: boot ทั้ง flow ---------------------------------------------------

function LoaderMain:boot()
  if self.booted then
    return self.booted
  end

  if LoaderMain.OWNER == "OWNER-PLACEHOLDER" then
    self.logger("warn", "loader ยังไม่ได้ตั้ง OWNER ของ repo (ยังไม่เผยแพร่จริง) — "
      .. "แก้ LoaderMain.OWNER ตอน publish แล้ว purge CDN ทุกครั้ง (§7.4)")
  end

  -- 1) Preflight: HTTP + CDN (พัง = หยุดทันที — plain text ไทยจาก preflight เอง)
  local pre = self:preflight()
  if not pre.ok then
    self.booted = { ok = false, stage = "preflight", message = pre.message }
    return self.booted
  end

  -- 2) manifest + Version Gate
  local m, tried = self:fetchManifest()
  if not m then
    self.booted = {
      ok = false,
      stage = "manifest",
      message = ("ดึง manifest ไม่ได้จากทุก URL:\n  %s"):format(table.concat(tried, "\n  ")),
    }
    self.logger("error", self.booted.message)
    return self.booted
  end

  local okMin, msgMin = Version.checkMinLoader(m.minLoaderVersion, LoaderMain.VERSION)
  if not okMin then
    self.booted = { ok = false, stage = "min-loader", message = msgMin }
    self.logger("error", msgMin)
    return self.booted
  end

  -- 3) entry + integrity (บอกระดับตรวจตามจริง §7.2)
  local source, verify, etried = self:fetchEntry(m)
  if not source then
    self.booted = {
      ok = false,
      stage = "entry",
      message = ("ดึง/ตรวจ %s ไม่ผ่าน:\n  %s"):format(
        LoaderMain.ENTRY_FILE, table.concat(etried, "\n  ")),
    }
    self.logger("error", self.booted.message)
    return self.booted
  end
  self.logger("info", verify.detail)

  -- 4) execute bundle (ตั้ง host + BUNDLE_RUN ก่อนเสมอ)
  self:_ensureHost()
  local run = rawget(_G, "__TV_BUNDLE_RUN")
  rawset(_G, "__TV_BUNDLE_RUN", { source = source, manifest = m })
  local prevHost = rawget(_G, "__TV_HOST")
  rawset(_G, "__TV_HOST", self.host)

  local execFn, err = self.loadFn(source, "@" .. LoaderMain.ENTRY_FILE .. ":" .. m.version)
  local sys
  if execFn then
    local okRun, r = pcall(execFn)
    if okRun then sys = r end
    err = okRun and nil or r
  end
  rawset(_G, "__TV_BUNDLE_RUN", run)
  rawset(_G, "__TV_HOST", prevHost)

  if not sys then
    self.booted = {
      ok = false,
      stage = "execute",
      message = ("รัน bundle v%s ไม่สำเร็จ: %s"):format(m.version, tostring(err)),
    }
    self.logger("error", self.booted.message)
    return self.booted
  end

  self.booted = {
    ok = true, stage = "done", system = sys, manifest = m,
    version = m.version, verify = verify,
  }
  self.logger("info", ("โหลดสำเร็จ v%s (releaseId %s, channel %s)")
    :format(m.version, tostring(m.releaseId), tostring(m.channel)))
  return self.booted
end

-- ---- Hot Update: จุดชนของ protocol (§3.6) --------------------------------------

function LoaderMain:checkUpdate()
  if not self.updater or not self.updater.active then
    return { ok = false, path = "NO-BOOT", detail = "ยังไม่ได้ boot — ไม่มีระบบเดิมให้อัปเดต" }
  end
  local active = self.updater:Active()

  local m, tried = self:fetchManifest()
  if not m then
    return { ok = false, path = "F0", detail = ("ดึง manifest ไม่ได้:\n  %s")
      :format(table.concat(tried, "\n  ")) }
  end

  local decision, detail = Version.gate({
    manifestVersion = m.version,
    activeVersion = active.version,
    channel = m.channel,
  })

  if decision == "noop" then
    return { ok = true, path = "NOOP", detail = detail }
  end
  if decision ~= "update" then
    self.logger("warn", detail)
    return { ok = false, path = "F0", detail = detail }
  end

  self.logger("info", detail)

  local okMin, msgMin = Version.checkMinLoader(m.minLoaderVersion, LoaderMain.VERSION)
  if not okMin then
    return { ok = false, path = "F0", detail = msgMin }
  end

  local source, verify, etried = self:fetchEntry(m)
  if not source then
    return { ok = false, path = "F0", detail = ("ดึง/ตรวจ entry ไม่ผ่าน:\n  %s")
      :format(table.concat(etried, "\n  ")) }
  end
  self.logger("info", verify.detail)

  local res = self.updater:Apply(source, m, { entryName = LoaderMain.ENTRY_FILE })
  self.logger(res.ok and "info" or "error", res.detail)
  return res
end

function LoaderMain:Status()
  return {
    loaderVersion = LoaderMain.VERSION,
    booted = self.booted and self.booted.ok or false,
    stage = self.booted and self.booted.stage or nil,
    update = self.updater and self.updater:Status() or nil,
  }
end

return LoaderMain
