-- ============================================================================
-- The Voider — core/runtime/update.lua
-- Hot Update Orchestrator (แผน freeze v2.1 §3.6 + R3/R4 + §7.2)
--
-- เจ้าของ protocol ทั้งหมด — อยู่นอกระบบที่ถูกสลับ (loader-domain) จึงรอด
-- จาก TEARDOWN และเป็นคนเดียวที่สลับรุ่นได้:
--
--   การ map กับ 12 ขั้นของแผน §3.6 (ขั้น 1-2 PUBLISH/DETECT อยู่ฝั่งเรา/loader):
--     3  PRE-STAGE   = pre-stage     (validate manifest + version gate + integrity)
--     4  FREEZE      = freeze
--     5  DRAIN       = drain
--     6  SNAPSHOT    = snapshot      (+ ROLLBACK SNAPSHOT 7 ช่อง)
--     7  TEARDOWN    = teardown      (ตาม dependency graph กลับด้าน §3.10)
--     8  VERIFY      = verify        (orphan รวม 4 ชนิด = 0 ไม่ใช่ = ABORT)
--     9  LOAD        = load
--     10 MIGRATE     = migrate       (config ผ่าน Migration chain + state providers)
--     11 RESUME      = resume        (replay ตาม policy: คิวที่ข้าม generation
--                                    มาจาก bus รุ่นเก่า + คิวที่เกิดระหว่าง
--                                    MIGRATE บน bus รุ่นใหม่ — CR-REPLAY-001)
--     12 SELFCHECK   = selfcheck     (+ REPORT)
--     +  ATOMIC RULE (freeze R3) เพิ่มขั้นท้าย: adapter-probe → commit
--
--   ROLLBACK PATHS:
--     F0      PRE-STAGE พัง (validate/gate/integrity) → ยกเลิก ระบบเดิมเดินต่อ
--     F-SNAP  snapshot สร้าง/ตรวจไม่ผ่าน (R4: ตรวจ recover ได้ก่อน TEARDOWN
--             เด็ดขาด) → ABORT ก่อนทำลายอะไร + Resume คิวเดิม
--     F1      VERIFY: orphan > 0                    → ROLLBACK + BUG
--     F2      LOAD หรือ MIGRATE พัง                  → ROLLBACK + BUG
--     F3      SELFCHECK พัง                          → ROLLBACK + BUG
--     F4      ADAPTER PROBE: dead                   → ROLLBACK + BUG
--             (degraded = เดินต่อ + เตือน — ปิดเฉพาะโมดูลที่กระทบตาม §3.3
--              เฟส 0 ยังไม่มีโมดูล จึงเป็นการเตือนพร้อมรายชื่อ impacted)
--     F-ROLLBACK-FAIL  rollback เองกลับพัง → "broken" + แจ้งเสียงดัง (ห้ามเงียบ)
--
--   ATOMIC UPDATE RULE (freeze R3): OLD = active / NEW = staged —
--     ระบบรุ่นใหม่ไม่ได้เป็น active จนกว่า LOAD → MIGRATE → SELFCHECK →
--     ADAPTER PROBE ผ่านครบ (ดู self.active/self.staged ระหว่างดำเนินการ)
--
--   สัญญาของ "system handle" (สร้างโดย core/runtime/bundle.lua):
--     { version, releaseId, runtime R, foundation F, adapter A,
--       bus, config, migration, shutdown, registry, boundary, watchdog,
--       diag, probe (fn → Adapter Health report), providers (ลำดับ),
--       selfChecks (ลำดับ) } — ทั้งหมดเป็น interface สาธารณะเดิมของ
--     Runtime/Foundation/Adapter ไม่มีการแตะภายในหรือแก้ไฟล์เหล่านั้นเลย
--
-- ใช้เฉพาะ interface สาธารณะเดิม (ไม่แก้ไฟล์ที่ผ่าน gate แล้วแม้บรรทัดเดียว
-- — ยกเว้น CR-REPLAY-001 ที่เจ้าของอนุมัติ 1 ต.ค. 2026 ให้เพิ่ม
--   Bus:ExportQueue/ImportQueue ใน eventbus.lua):
--   Bus:Freeze/Resume/Stats/Publish/Declare · Bus:ExportQueue/ImportQueue
--   (CR-REPLAY-001) · Config:Data/Replace ·
--   Migration:Run · Shutdown:Run · Registry:ModuleTotals/VerifyZero/Release ·
--   Watchdog:Stop · probe:Probe · Diag:Mark
-- ============================================================================

local function _pkg(name)
  local g = rawget(_G, "__TV_PACKAGES")
  if g and g[name] then return g[name] end
  local e = rawget(_G, "__TV_EMBED")
  if e and e[name] then return e[name] end
  return nil
end

local Version = _pkg("version")
local Manifest = _pkg("manifest")

local Update = {}

Update.VERSION = "0.3.0"

-- ---- helpers (ภายใน) ---------------------------------------------------------

local function deepClone(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for k, val in pairs(v) do
    out[deepClone(k)] = deepClone(val)
  end
  return out
end

--- เดินตาราง: คืน (ok, ที่พบเจ้าแรก) — ใช้ได้กับ key+value พร้อมกัน
local function walkPlain(t, path)
  path = path or "root"
  if type(t) ~= "table" then
    if type(t) == "function" or type(t) == "userdata" or type(t) == "thread" then
      return false, ("%s เป็น %s (ห้าม — ต้อง serialize ได้)"):format(path, type(t))
    end
    return true, nil
  end
  for k, v in pairs(t) do
    if type(k) ~= "string" and type(k) ~= "number" then
      return false, ("%s.[%s] key ชนิด %s"):format(path, tostring(k), type(k))
    end
    local ok, why = walkPlain(v, ("%s.%s"):format(path, tostring(k)))
    if not ok then return false, why end
  end
  return true, nil
end

local function sumKinds(rows)
  local t = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0, owners = {} }
  for _, row in ipairs(rows) do
    local o = row.orphan
    if o then
      t.tasks = t.tasks + (o.tasks or 0)
      t.connections = t.connections + (o.connections or 0)
      t.renders = t.renders + (o.renders or 0)
      t.temps = t.temps + (o.temps or 0)
      t.total = t.total + (o.total or 0)
      if o.total and o.total > 0 then
        t.owners[#t.owners + 1] = ("%s (%d ชิ้น)"):format(row.name, o.total)
      end
    end
  end
  return t
end

-- ---- constructor ---------------------------------------------------------------

-- ctx = {
--   loadFn   = function(source, chunkName) -> (execFn, err)   [บังคับ]
--              execFn() จะสร้าง system handle ของรุ่นนั้น (bundle entry)
--   clock    = function() → วินาที (จับเวลา per-step) default os.clock
--   time     = function() → timestamp (ใส่ใน snapshot) default os.time
--   logger   = function(level, msg) — default print
--   onStep   = function(step, info) — จุดสังเกตทุกขั้น (ใช้ในเทสพิสูจน์ atomic)
--   budgetMs = ตัวเลข — งบเวลารวม (default 5000 ตาม §9.1)
--   softwareBudgetMs = งบ hash โหมดซอฟต์แวร์ (default 1000, ส่งต่อให้ Manifest.Verify)
--   loaderVersion = เวอร์ชัน loader ปัจจุบัน (ตรวจ minLoaderVersion อีกชั้น)
--   env      = environment สำหรับ crypto probe (default _G)
-- }
function Update.new(ctx)
  ctx = ctx or {}
  if type(ctx.loadFn) ~= "function" then
    error("Update.new({ loadFn = ... }): ต้องส่ง loadFn(source, chunkName) → (execFn, err)", 2)
  end

  local self = setmetatable({}, { __index = Update })
  self.loadFn = ctx.loadFn
  self.clock = ctx.clock or os.clock
  self.time = ctx.time or os.time
  self.logger = ctx.logger or function(level, msg)
    print(("[The Voider][Update][%s] %s"):format(level, msg))
  end
  self.onStep = ctx.onStep
  self.budgetMs = ctx.budgetMs or 5000
  self.softwareBudgetMs = ctx.softwareBudgetMs or 1000
  self.loaderVersion = ctx.loaderVersion
  self.env = ctx.env or _G

  self.active = nil        -- { system, source, manifest, version, releaseId }
  self.staged = nil        -- { source, manifest, version, releaseId } (ระหว่าง protocol)
  self.rollbackTarget = nil
  self.inFlight = false
  self.broken = nil        -- { message, path, bugId } — rollback ก็พัง
  self.lastResult = nil
  self.lastSnapshot = nil
  self._bugSeq = 0
  return self
end

-- ---- รายงานสถานะ (ใช้ตรวจ atomic + Diagnostics) -------------------------------

function Update:Active()
  if not self.active then return nil end
  return {
    version = self.active.version,
    releaseId = self.active.releaseId,
    system = self.active.system,
  }
end

function Update:Staged()
  if not self.staged then return nil end
  return { version = self.staged.version, releaseId = self.staged.releaseId }
end

function Update:RollbackTarget()
  if not self.rollbackTarget then return nil end
  return { version = self.rollbackTarget.version, releaseId = self.rollbackTarget.releaseId }
end

function Update:Status()
  return {
    active = self:Active() and self:Active().version or nil,
    staged = self:Staged() and self:Staged().version or nil,
    rollbackTarget = self:RollbackTarget() and self:RollbackTarget().version or nil,
    inFlight = self.inFlight,
    broken = self.broken and self.broken.message or nil,
    lastResult = self.lastResult and self.lastResult.path or nil,
  }
end

function Update:LastResult()
  return self.lastResult
end

-- ---- bug id (§11: ไม่มี error ที่ไม่มี Bug ID) --------------------------------

function Update:_nextBugId()
  self._bugSeq = self._bugSeq + 1
  return ("BUG-UPD-%03d"):format(self._bugSeq)
end

-- ---- step bookkeeping ---------------------------------------------------------

local STEP_ORDER = {
  "pre-stage", "freeze", "drain", "snapshot", "snapshot-validate",
  "teardown", "verify", "load", "migrate", "resume", "selfcheck",
  "adapter-probe", "commit",
  "rollback.load", "rollback.migrate", "rollback.resume",
  "rollback.selfcheck", "rollback.adapter-probe", "rollback.commit",
}

function Update:_emit(step, info)
  info = info or {}
  info.step = step
  if self.onStep then
    local ok, err = pcall(self.onStep, step, info)
    if not ok then
      self.logger("warn", ("onStep hook พัง (ขั้น %s): %s"):format(step, tostring(err)))
    end
  end
  return info
end

-- ---- Attach: ระบบที่ boot แล้วมารายงานตัวเป็น active -------------------------

Update.EVENTS = {
  { "update:succeeded", "idempotent" },
  { "update:failed",    "idempotent" },
  { "update:rolledback","idempotent" },
}

function Update:Attach(record)
  record = record or {}
  if self.inFlight then
    error("Update:Attach: กำลังอัปเดตอยู่ (in-flight) — ห้ามเปลี่ยน active กลาง protocol", 2)
  end
  local sys = record.system
  if type(sys) ~= "table"
    or not sys.bus or not sys.config or not sys.migration
    or not sys.shutdown or not sys.registry or not sys.probe then
    error("Update:Attach: system handle ไม่ครบสัญญา (bus/config/migration/shutdown/registry/probe)", 2)
  end
  if type(sys.version) ~= "string" or type(sys.releaseId) ~= "string" then
    error("Update:Attach: system ต้องมี version+releaseId เป็น string", 2)
  end

  -- ประกาศ event ของ update domain บน bus ของระบบนี้ (Declare สาธารณะ —
  -- ไม่แก้ foundation/init.lua) — ตัวที่ไม่ Declare จะถูกนับเป็น undeclared
  for _, ev in ipairs(Update.EVENTS) do
    if sys.bus:Policy(ev[1]) == nil then
      sys.bus:Declare(ev[1], ev[2])
    end
  end

  self.active = {
    system = sys,
    source = record.source,
    manifest = record.manifest,
    version = sys.version,
    releaseId = sys.releaseId,
  }
  self.broken = nil
  return self
end

-- ---- ผลลัพธ์มาตรฐาน -----------------------------------------------------------

function Update:_result(path, opts)
  opts = opts or {}
  local r = {
    ok = opts.ok or false,
    path = path,
    bugId = opts.bugId,
    detail = opts.detail,
    from = opts.from or (self.active and {
      version = self.active.version, releaseId = self.active.releaseId,
    } or nil),
    to = opts.to or (self.staged and {
      version = self.staged.version, releaseId = self.staged.releaseId,
    } or nil),
    rolledBack = opts.rolledBack or false,
    broken = opts.broken or false,
    orphans = opts.orphans,
    replay = opts.replay,
    integrity = opts.integrity,
    snapshot = opts.snapshot,
    warnings = opts.warnings or {},
    timing = opts.timing,
    system = self.active and self.active.system or nil,
  }
  self.lastResult = r
  return r
end

local function finishTiming(self, steps, t0)
  local totalMs = (self.clock() - t0) * 1000
  local overBudget = totalMs > self.budgetMs
  return {
    totalMs = totalMs,
    budgetMs = self.budgetMs,
    overBudget = overBudget,
    steps = steps,
  }, totalMs
end

-- ---- SNAPSHOT: สร้าง + ตรวจ (R4 — ก่อน TEARDOWN เด็ดขาด) ---------------------

function Update:_makeSnapshot()
  local sys = self.active.system
  local snap = {
    version = self.active.version,
    releaseId = self.active.releaseId,
    bundle = self.active.source,
    manifest = deepClone(self.active.manifest),
    moduleStates = {},
    configState = deepClone(sys.config:Data()),
    timestamp = self.time(),
  }
  if snap.configState == nil then
    return nil, "config:Data() คืน nil — จับ snapshot ไม่ได้"
  end
  for _, provider in ipairs(sys.providers or {}) do
    local ok, state = pcall(provider.Serialize, sys)
    if not ok then
      return nil, ("provider %s:Serialize พัง: %s"):format(provider.name, tostring(state))
    end
    local plain, why = walkPlain(state, ("moduleStates.%s"):format(provider.name))
    if not plain then
      return nil, ("provider %s:Serialize คืนค่า serialize ไม่ได้ (%s)"):format(provider.name, why)
    end
    snap.moduleStates[provider.name] = deepClone(state)
  end
  return snap
end

function Update:_validateSnapshot(snap)
  if type(snap) ~= "table" then
    return false, "snapshot ไม่ใช่ table"
  end
  -- ครบ 7 ช่อง (R4) — ตรวจชนิดเข้ม
  if type(snap.version) ~= "string" or #snap.version == 0 then
    return false, "ช่อง version ไม่ใช่ string ที่ไม่ว่าง"
  end
  if type(snap.releaseId) ~= "string" or #snap.releaseId == 0 then
    return false, "ช่อง releaseId ไม่ใช่ string ที่ไม่ว่าง"
  end
  if type(snap.bundle) ~= "string" or #snap.bundle == 0 then
    return false, "ช่อง bundle (โค้ดรุ่นเดิม) ว่าง — โหลดกลับไม่ได้"
  end
  if type(snap.manifest) ~= "table" then
    return false, "ช่อง manifest ไม่ใช่ table"
  end
  if type(snap.moduleStates) ~= "table" then
    return false, "ช่อง moduleStates ไม่ใช่ table"
  end
  if type(snap.configState) ~= "table" then
    return false, "ช่อง configState ไม่ใช่ table"
  end
  if type(snap.timestamp) ~= "number" then
    return false, "ช่อง timestamp ไม่ใช่ number"
  end
  -- ความสอดคล้องภายใน
  if snap.manifest.version ~= nil and snap.manifest.version ~= snap.version then
    return false, ("manifest ใน snapshot เป็น v%s แต่ version เป็น v%s ไม่ตรงกัน")
      :format(tostring(snap.manifest.version), tostring(snap.version))
  end
  if type(snap.configState.schemaVersion) ~= "number" then
    return false, "configState.schemaVersion ไม่ใช่ number"
  end
  -- state ทุกชุดต้อง serialize ได้ (ห้าม function/userdata)
  local plain, why = walkPlain(snap.moduleStates, "moduleStates")
  if not plain then return false, why end
  plain, why = walkPlain(snap.configState, "configState")
  if not plain then return false, why end
  -- recover ได้จริง: โค้ดรุ่นเดิมต้อง compile ผ่าน (ยังไม่ execute —
  -- การ compile ไม่มีผลข้างเคียง)
  local execFn, err = self.loadFn(snap.bundle, "@rollback:" .. tostring(snap.version))
  if not execFn then
    return false, ("โค้ดรุ่นเดิม compile ไม่ผ่าน — recover ไม่ได้: %s"):format(tostring(err))
  end
  return true, nil
end

-- ---- bootstrap ระบบจาก source (ใช้ทั้ง LOAD ปกติและ rollback) ----------------

-- คืน (sys, err) — execFn() ต้องคืน system handle (สัญญาของ bundle entry)
function Update:_execSource(source, chunkName)
  local execFn, err = self.loadFn(source, chunkName)
  if not execFn then
    return nil, ("compile ไม่ผ่าน: %s"):format(tostring(err))
  end
  local ok, sys = pcall(execFn)
  if not ok then
    return nil, ("รัน bundle พัง: %s"):format(tostring(sys))
  end
  if type(sys) ~= "table" or not sys.bus then
    return nil, "bundle ไม่คืน system handle ตามสัญญา"
  end
  return sys
end

-- MIGRATE ระบบเป้าหมายด้วย snapshot ของระบบเก่า (ใช้ทั้ง update และ rollback)
-- คืน (ok, err)
function Update:_migrateSystem(sys, snap)
  -- 1) config: ผ่าน Migration chain ของระบบใหม่เอง → Replace
  local cfg = deepClone(snap.configState)
  local ok, err = pcall(sys.migration.Run, sys.migration, cfg)
  if not ok then
    return false, ("Migration:Run พัง (MIGRATE): %s"):format(tostring(err))
  end
  if type(cfg.schemaVersion) ~= "number" then
    return false, "MIGRATE: config หลัง migration ไม่มี schemaVersion"
  end
  ok, err = pcall(sys.config.Replace, sys.config, cfg)
  if not ok then
    return false, ("Config:Replace พัง (MIGRATE): %s"):format(tostring(err))
  end
  -- 2) state providers ทุกตัว: รับ oldState ของตัวเอง (nil = รุ่นนี้เพิ่มมาใหม่
  --    provider เริ่มจากศูนย์เองตามสัญญา §3.4 MigrateState)
  for _, provider in ipairs(sys.providers or {}) do
    local oldState = snap.moduleStates[provider.name]
    ok, err = pcall(provider.Apply, sys, oldState)
    if not ok then
      return false, ("provider %s:Apply พัง (MIGRATE): %s"):format(provider.name, tostring(err))
    end
  end
  return true, nil
end

-- SELFCHECK: รัน checks ทั้งชุดของระบบเป้าหมาย — คืน (ok, ชื่อ+detail ที่พัง)
-- selfChecks = ลำดับ { name = string, fn = function(sys, ctx) → (ok, detail) } (สัญญาเดียวกับ bundle.lua)
function Update:_selfCheckSystem(sys, purpose, newGen, m)
  for _, check in ipairs(sys.selfChecks or {}) do
    if type(check) ~= "table" or type(check.fn) ~= "function" then
      return false, ("selfCheck %s ไม่ครบสัญญา (ต้องมี fn)"):format(tostring(check and check.name))
    end
    local ok, detail = check.fn(sys, {
      generation = newGen,
      manifest = m,
      purpose = purpose,
    })
    if not ok then
      return false, ("%s: %s"):format(check.name, tostring(detail))
    end
  end
  return true, nil
end

-- ==============================================================================
-- :Apply — protocol หลัก
--
-- newSource = โค้ดรุ่นใหม่ (string)
-- m         = manifest รุ่นใหม่ (table ที่ผ่าน Manifest.Validate แล้ว)
-- opts      = { entryName (default "the-voider.lua"), drainFns = {fn...} }
-- คืน result (ดูรูปทรงด้านบน) — ทุก path มี bugId ยกเว้น OK/NOOP (§11)
-- ==============================================================================

function Update:Apply(newSource, m, opts)
  opts = opts or {}
  local entryName = opts.entryName or "the-voider.lua"

  if self.inFlight then
    error("Update:Apply: มี protocol กำลังเดินอยู่ — ห้ามซ้อน", 2)
  end
  if not self.active then
    error("Update:Apply: ยังไม่มีระบบเดิม — ใช้ loader บูตก่อนแล้ว Attach", 2)
  end

  self.inFlight = true
  local steps = {}
  local t0 = self.clock()
  local warnings = {}

  local function markMs(name, st)
    steps[name] = (self.clock() - st) * 1000
  end

  -- ผลลัพธ์ของ integrity ระดับไหน (รายงานตามจริง §7.2)
  local integrity = nil

  -- ---------------------------------------------------------------- F0 ----
  local st = self.clock()
  self:_emit("pre-stage", { manifestVersion = m and m.version or nil })

  if type(m) ~= "table" then
    self.inFlight = false
    return self:_result("F0", {
      bugId = self:_nextBugId(),
      detail = "manifest ไม่ใช่ table (PRE-STAGE ไม่ผ่าน)",
      timing = finishTiming(self, steps, t0),
    })
  end

  local errs = Manifest and Manifest.Validate(m, {}) or {}
  if #errs > 0 then
    self.inFlight = false
    return self:_result("F0", {
      bugId = self:_nextBugId(),
      detail = "manifest ไม่ผ่านการตรวจ (PRE-STAGE): " .. table.concat(errs, "; "),
      timing = finishTiming(self, steps, t0),
    })
  end

  local gateDecision, gateDetail
  if Version then
    gateDecision, gateDetail = Version.gate({
      manifestVersion = m.version,
      activeVersion = self.active.version,
      channel = m.channel,
    })
  else
    gateDecision = (m.version ~= self.active.version) and "update" or "noop"
    gateDetail = gateDecision
  end

  if gateDecision == "noop" then
    self.inFlight = false
    self:_emit("pre-stage.noop", { detail = gateDetail })
    return self:_result("NOOP", {
      ok = true,
      detail = gateDetail,
      to = { version = m.version, releaseId = m.releaseId },
      timing = finishTiming(self, steps, t0),
    })
  end

  if gateDecision == "reject-downgrade" then
    self.inFlight = false
    return self:_result("F0", {
      bugId = self:_nextBugId(),
      detail = gateDetail .. " (PRE-STAGE: version gate ปฏิเสธ)",
      to = { version = m.version, releaseId = m.releaseId },
      timing = finishTiming(self, steps, t0),
    })
  end

  -- minLoaderVersion (ป้องกันอีกชั้น — loader เองก็ตรวจก่อน fetch)
  if Version and self.loaderVersion and m.minLoaderVersion then
    local okMin, msgMin = Version.checkMinLoader(m.minLoaderVersion, self.loaderVersion)
    if not okMin then
      self.inFlight = false
      return self:_result("F0", {
        bugId = self:_nextBugId(),
        detail = msgMin .. " (PRE-STAGE: minLoaderVersion ไม่ผ่าน)",
        to = { version = m.version, releaseId = m.releaseId },
        timing = finishTiming(self, steps, t0),
      })
    end
  end

  if type(newSource) ~= "string" or #newSource == 0 then
    self.inFlight = false
    return self:_result("F0", {
      bugId = self:_nextBugId(),
      detail = "source รุ่นใหม่ว่าง (PRE-STAGE)",
      to = { version = m.version, releaseId = m.releaseId },
      timing = finishTiming(self, steps, t0),
    })
  end

  integrity = Manifest and Manifest.Verify(newSource, entryName, m, {
    clock = self.clock,
    softwareBudgetMs = self.softwareBudgetMs,
    env = self.env,
  }) or nil
  markMs("pre-stage", st)
  self:_emit("pre-stage.done", { integrity = integrity and integrity.mode })

  if not integrity or not integrity.ok then
    self.inFlight = false
    return self:_result("F0", {
      bugId = self:_nextBugId(),
      detail = (integrity and integrity.detail or "ตรวจความถูกต้นฉบับไม่ได้")
        .. " (PRE-STAGE: integrity ไม่ผ่าน — ระบบเดิมไม่ถูกแตะ)",
      to = { version = m.version, releaseId = m.releaseId },
      integrity = integrity,
      timing = finishTiming(self, steps, t0),
    })
  end

  -- ตรงจุดนี้เท่านั้นที่ระบบเดิมเริ่มถูกแตะ (FREEZE) — F0 ไม่แตะอะไรเลย
  self.staged = {
    source = newSource, manifest = deepClone(m),
    version = m.version, releaseId = m.releaseId,
  }

  -- ------------------------------------------------------------- FREEZE ----
  st = self.clock()
  local oldSys = self.active.system
  local oldStats = oldSys.bus:Stats()
  local newGen = (oldStats.generation or 0) + 1
  oldSys.bus:Freeze(newGen)
  markMs("freeze", st)
  self:_emit("freeze", { generation = newGen, queuedBefore = oldStats.queued })

  -- -------------------------------------------------------------- DRAIN ----
  st = self.clock()
  for _, fn in ipairs(opts.drainFns or {}) do
    local ok, err = pcall(fn)
    if not ok then
      self.logger("warn", ("drain hook พัง (ข้าม): %s"):format(tostring(err)))
    end
  end
  markMs("drain", st)
  self:_emit("drain", { hooks = #(opts.drainFns or {}) })

  -- ------------------------------------------------------------ SNAPSHOT ----
  st = self.clock()
  self:_emit("snapshot")
  local snap, snapErr = self:_makeSnapshot()
  markMs("snapshot", st)

  -- ----------------------------------------------------- SNAPSHOT-VALIDATE --
  -- R4: สร้างเสร็จ + ตรวจว่า recover ได้จริง "ก่อน TEARDOWN เด็ดขาด"
  st = self.clock()
  local snapOk, snapWhy
  if snap then
    snapOk, snapWhy = self:_validateSnapshot(snap)
  else
    snapOk, snapWhy = false, (snapErr or "สร้าง snapshot ไม่ได้ (serializer พัง/ขาดช่อง)")
  end
  markMs("snapshot-validate", st)

  if not snapOk then
    -- ยังไม่มีอะไวถูกทำลาย — ถอน freeze + replay คิวเดิม + อยู่รุ่นเก่าต่อ
    snapWhy = snapWhy or (snapErr or "สร้าง snapshot ไม่ได้")
    oldSys.bus:Resume()
    self.staged = nil
    self.inFlight = false
    self.lastSnapshot = nil
    local res = self:_result("F-SNAP", {
      bugId = self:_nextBugId(),
      detail = ("Rollback Snapshot ไม่ผ่านการตรวจ: %s — ABORT ก่อน TEARDOWN "
        .. "(ระบบเดิมเดินต่อ ไม่มีอะไรถูกทำลาย §3.6 R4)"):format(snapWhy),
      to = { version = m.version, releaseId = m.releaseId },
      integrity = integrity,
      snapshot = nil,
      timing = finishTiming(self, steps, t0),
    })
    self.logger("error", res.detail)
    return res
  end

  self.lastSnapshot = snap
  self:_emit("snapshot.validate.done", { fields = 7, version = snap.version })

  -- ------------------------------------------------------------ TEARDOWN ----
  st = self.clock()
  self:_emit("teardown")
  local tdReport = oldSys.shutdown:Run({ assertZero = false })
  markMs("teardown", st)

  -- CR-REPLAY-001 (§3.6 ตามคำตัดสินเจ้าของ 1 ต.ค. 2026 — ตัวเลือก ข):
  -- คิวของ bus รุ่นเก่าที่ค้างตลอดหน้าต่าง freeze (FREEZE → DRAIN → SNAPSHOT →
  -- TEARDOWN รวม event ที่ hook ปล่อยออกมาตอนถอดระบบ) ต้องข้าม generation ไป
  -- replay ตาม policy บนระบบปลายทาง — เดิมทิ้งทั้งคิวเงียบ ๆ ขัด §3.6
  -- export หลัง TEARDOWN เสร็จ (คิวนิ่งแล้ว) — path สำเร็จนำไป import ที่ RESUME
  -- / path ย้อนรุ่นนำไป import ที่ rollback.resume
  local carried = oldSys.bus:ExportQueue()
  self:_emit("carry-export", { carried = #carried })

  -- -------------------------------------------------------------- VERIFY ----
  -- orphan รวม 4 ชนิด = 0 ไม่ใช่ = ABORT + ROLLBACK (ห้าม force-clean §3.6)
  st = self.clock()
  local orphans = sumKinds(tdReport.rows)
  if tdReport.orphans == 0 then
    -- คืนส่วนที่ runtime เป็นเจ้าของเอง (หลังพิสูจน์ว่าโมดูลคืนครบแล้ว —
    -- ต่างจาก force-clean: ตรงนี้ cleanup หลัง orphans=0 เท่านั้น)
    if oldSys.watchdog and oldSys.watchdog.Stop then
      pcall(oldSys.watchdog.Stop, oldSys.watchdog)
    end
    oldSys.registry:Release(nil)
  end
  markMs("verify", st)
  self:_emit("verify", { orphans = orphans.total })

  if tdReport.orphans > 0 then
    orphans.owners = orphans.owners or {}
    local res = self:_rollbackFromSnapshot("F1", ("VERIFY ไม่ผ่าน: orphan รวม %d ชิ้น "
      .. "(tasks=%d connections=%d renders=%d temps=%d) เจ้าของที่ค้าง: %s — "
      .. "ห้าม force-clean แล้วไปต่อ (§3.6 F1)")
      :format(tdReport.orphans, orphans.tasks, orphans.connections,
        orphans.renders, orphans.temps,
        #orphans.owners > 0 and table.concat(orphans.owners, ", ") or "(ไม่มีรายงาน)"),
      snap, integrity, steps, t0, warnings, orphans, carried)
    return res
  end

  -- ---------------------------------------------------------------- LOAD ----
  st = self.clock()
  local sysNew, loadErr = self:_execSource(newSource, "@" .. entryName .. ":" .. tostring(m.version))
  self:_emit("load", { system = sysNew }) -- จุดเข้าถึกระบบที่ staged (เทส/Diagnostics)
  markMs("load", st)

  if sysNew then
    -- ระบบใหม่ถูกสร้างแล้ว — กันหน้า: freeze bus ของรุ่นใหม่ทันที ให้เหตุการณ์
    -- ที่เกิดจาก MIGRATE เข้าคิว แล้ว replay ตอน RESUME (ใกล้เคียง §3.6
    -- มากที่สุดโดยไม่แก้ไฟล์ที่ผ่าน gate)
    sysNew.bus:Freeze(newGen)
  end

  -- -------------------------------------------------------------- MIGRATE --
  if sysNew then
    st = self.clock()
    self:_emit("migrate")
    local okM, errM = self:_migrateSystem(sysNew, snap)
    markMs("migrate", st)

    if not okM then
      local res = self:_rollbackFromSnapshot("F2", errM .. " (LOAD/MIGRATE)", snap, integrity, steps, t0, warnings, nil, carried)
      return res
    end
  else
    local res = self:_rollbackFromSnapshot("F2", loadErr .. " (LOAD)", snap, integrity, steps, t0, warnings, nil, carried)
    return res
  end

  -- -------------------------------------------------------------- RESUME --
  st = self.clock()
  -- CR-REPLAY-001: คิวจาก bus รุ่นเก่าถูก import เข้า bus รุ่นใหม่ (frozen อยู่)
  -- policy ตัดสินใหม่ตาม Declare ของรุ่นใหม่ แล้ว replay รวมกับคิวที่เกิด
  -- ระหว่าง MIGRATE — เรียงเวลาจริงทั้งคิว (last-write-wins)
  local carry = sysNew.bus:ImportQueue(carried)
  local replay = sysNew.bus:Resume(newGen)
  local replayReport = {
    replayed = replay.replayed,
    dropped = replay.dropped + carry.dropped,
    total = replay.total + carry.dropped,
    carried = carry.total,
    carriedAccepted = carry.accepted,
    carriedDropped = carry.dropped,
  }
  markMs("resume", st)
  self:_emit("resume", {
    replayed = replayReport.replayed, dropped = replayReport.dropped,
    total = replayReport.total, carried = replayReport.carried,
  })

  -- ----------------------------------------------------------- SELFCHECK --
  st = self.clock()
  self:_emit("selfcheck")
  local scOk, scWhy = self:_selfCheckSystem(sysNew, "update", newGen, m)
  markMs("selfcheck", st)
  if not scOk then
    local res = self:_rollbackFromSnapshot("F3", ("SELFCHECK ไม่ผ่าน: %s"):format(scWhy),
      snap, integrity, steps, t0, warnings, nil, carried)
    return res
  end

  -- -------------------------------------------------------- ADAPTER PROBE --
  st = self.clock()
  self:_emit("adapter-probe")
  local probeReport = sysNew.probe:Probe()
  markMs("adapter-probe", st)

  if probeReport.status == "dead" then
    local res = self:_rollbackFromSnapshot("F4", ("ADAPTER PROBE ไม่ผ่าน: %s — %s")
      :format(probeReport.summary, "adapter ตายหลัง migrate = รุ่นใหม่ไม่น่าไว้ใจ กลับรุ่นเดิม (§3.6 F4)"),
      snap, integrity, steps, t0, warnings, nil, carried)
    return res
  elseif probeReport.status == "degraded" then
    warnings[#warnings + 1] = ("Adapter เสื่อมหลังอัปเดต: %s — ปิดเฉพาะโมดูลที่กระทบตามกฎ §3.3 "
      .. "(เฟส 0 ยังไม่มีโมดูล จึงเป็นการเตือนพร้อมรายชื่อ impacted)")
      :format(probeReport.summary)
  end

  -- --------------------------------------------------------------- COMMIT --
  -- ATOMIC UPDATE RULE (R3): ตรงนี้เท่านั้นที่ NEW กลายเป็น active
  st = self.clock()
  self.rollbackTarget = {
    source = self.active.source,
    manifest = self.active.manifest,
    version = self.active.version,
    releaseId = self.active.releaseId,
  }
  self.active = {
    system = sysNew, source = newSource, manifest = deepClone(m),
    version = m.version, releaseId = m.releaseId,
  }
  self.staged = nil
  self.inFlight = false
  markMs("commit", st)
  self:_emit("commit", { system = sysNew }) -- หลังสลับ — ผู้สังเกตเห็น NEW เป็น active แล้ว

  local timing, totalMs = finishTiming(self, steps, t0)
  if timing.overBudget then
    warnings[#warnings + 1] = ("เวลารวม %.1f ms เกินงบ %d ms (§9.1) — บันทึกเป็น metric")
      :format(totalMs, self.budgetMs)
  end

  -- metrics เข้า Diagnostics ของระบบใหม่ (§8.4)
  pcall(sysNew.diag.Mark, sysNew.diag, "hotUpdateMs", totalMs)

  local res = self:_result("OK", {
    ok = true,
    detail = ("อัปเดตสำเร็จ v%s → v%s (ใช้เวลา %.1f ms, orphan 0, replay %d/%d"
      .. " รวมข้าม generation %d ตัว)")
      :format(self.rollbackTarget.version, m.version, totalMs,
        replayReport.replayed, replayReport.total, replayReport.carried),
    to = { version = m.version, releaseId = m.releaseId },
    rolledBack = false,
    orphans = orphans,
    replay = replayReport,
    integrity = integrity,
    snapshot = snap,
    warnings = warnings,
    timing = timing,
  })

  -- REPORT (ขั้น 12 ของแผน): แจ้งผู้ใช้เป็นภาษาไทยผ่าน bus ของระบบที่ active
  sysNew.bus:Publish("update:succeeded", {
    from = res.from, to = res.to, totalMs = totalMs, replay = res.replay,
  })
  sysNew.bus:Publish("notify:user", {
    level = "info",
    key = "notify.update.succeeded",
    params = { from = res.from.version, to = res.to.version, ms = ("%.0f"):format(totalMs) },
  })
  self.logger("info", res.detail)
  return res
end

-- ==============================================================================
-- rollback จาก snapshot — ใช้ร่วมทุก path F1–F4
-- พิสูจน์ว่า "กลับรุ่นเดิม + ใช้งานได้จริง" ไม่ใช่แค่ "โหลดโค้ดเก่า":
--   LOAD รุ่นเดิม → freeze → MIGRATE state/config เดิม → RESUME →
--   SELFCHECK → ADAPTER PROBE → COMMIT (รุ่นเดิมกลับมาเป็น active)
-- ==============================================================================

function Update:_rollbackFromSnapshot(path, reason, snap, integrity, steps, t0, warnings, orphans, carried)
  warnings = warnings or {}
  carried = carried or {} -- CR-REPLAY-001: คิวที่ export จาก bus รุ่นเก่าก่อน TEARDOWN

  -- เวอร์ชันที่ "ตั้งใจไป" (รายงานใน result.to ของทุก path ที่ rollback)
  local attempt = self.staged and {
    version = self.staged.version, releaseId = self.staged.releaseId,
  } or nil

  -- ยังไม่มี snapshot ที่เชื่อถือได้ = ไม่มีทางกลับ (ห้ามเงียบ)
  if not snap then
    self.inFlight = false
    self.broken = { message = reason, path = path }
    local res = self:_result(path .. "+NO-SNAPSHOT", {
      bugId = self:_nextBugId(),
      detail = reason .. " — และไม่มี snapshot ให้กลับ (ระบบอยู่ในสถานะ broken)",
      broken = true,
      to = attempt,
      integrity = integrity,
      warnings = warnings,
      timing = finishTiming(self, steps, t0),
    })
    self.logger("error", res.detail)
    return res
  end

  local function rbFail(rpath, rdetail)
    self.inFlight = false
    self.broken = { message = rdetail, path = path }
    self.staged = nil
    local res = self:_result(path .. "+ROLLBACK-FAIL", {
      bugId = self:_nextBugId(),
      detail = ("%s → แล้ว rollback เองกลับพัง (%s): %s — ระบบอยู่ในสถานะ broken "
        .. "ห้ามแอบอ้างว่าใช้ได้ (No Silent Degradation)")
        :format(reason, rpath, rdetail),
      broken = true,
      rolledBack = false,
      to = attempt,
      integrity = integrity,
      warnings = warnings,
      timing = finishTiming(self, steps, t0),
    })
    self.logger("error", res.detail)
    return res
  end

  -- rollback.load
  local st = self.clock()
  local sysOld, err = self:_execSource(snap.bundle, "@rollback:" .. tostring(snap.version))
  local loadMs = (self.clock() - st) * 1000
  steps["rollback.load"] = loadMs
  self:_emit("rollback.load", { system = sysOld }) -- จุดเข้าถึงระบบที่กำลังกู้คืน
  if not sysOld then
    return rbFail("rollback.load", err)
  end
  sysOld.bus:Freeze() -- generation ใหม่ของรอบ rollback = generation เดิม + 1 (ค่า default)

  -- rollback.migrate
  st = self.clock()
  self:_emit("rollback.migrate")
  local okM, errM = self:_migrateSystem(sysOld, snap)
  steps["rollback.migrate"] = (self.clock() - st) * 1000
  if not okM then
    return rbFail("rollback.migrate", errM)
  end

  -- rollback.resume
  st = self.clock()
  -- CR-REPLAY-001: event ที่ค้างในหน้าต่าง freeze ของ bus รุ่นเก่า (รวมที่
  -- เกิดระหว่าง TEARDOWN) ถูกส่งข้าม generation มาที่รุ่นเดิมที่กลับมา —
  -- replay ตาม policy ของรุ่นนี้เอง (Transient DROP / State-Config REPLAY
  -- LWW / Idempotent REPLAY — สถานะโลกจริง DROP + re-derive จาก Adapter)
  local carry = sysOld.bus:ImportQueue(carried)
  local replay = sysOld.bus:Resume()
  local replayReport = {
    replayed = replay.replayed,
    dropped = replay.dropped + carry.dropped,
    total = replay.total + carry.dropped,
    carried = carry.total,
    carriedAccepted = carry.accepted,
    carriedDropped = carry.dropped,
  }
  steps["rollback.resume"] = (self.clock() - st) * 1000
  self:_emit("rollback.resume", {
    replayed = replayReport.replayed, dropped = replayReport.dropped,
    carried = replayReport.carried,
  })

  -- rollback.selfcheck
  st = self.clock()
  self:_emit("rollback.selfcheck")
  local scOk, scWhy = self:_selfCheckSystem(sysOld, "rollback", nil, snap.manifest)
  steps["rollback.selfcheck"] = (self.clock() - st) * 1000
  if not scOk then
    return rbFail("rollback.selfcheck", scWhy)
  end

  -- rollback.adapter-probe
  st = self.clock()
  self:_emit("rollback.adapter-probe")
  local probeReport = sysOld.probe:Probe()
  steps["rollback.adapter-probe"] = (self.clock() - st) * 1000
  if probeReport.status == "dead" then
    return rbFail("rollback.adapter-probe", ("รุ่นเดิมก็เห็น adapter ตายเหมือนกัน: %s "
      .. "(ถ้าเกมเปลี่ยนจริง การกลับรุ่นไม่ช่วย — ต้องแจ้งเป็น BUG แล้ววิเคราะห์ต่อ)")
      :format(probeReport.summary))
  elseif probeReport.status == "degraded" then
    warnings[#warnings + 1] = ("หลัง rollback พบ Adapter เสื่อม: %s"):format(probeReport.summary)
  end

  -- rollback.commit — รุ่นเดิมกลับมาเป็น active อีกครั้ง
  st = self.clock()
  self:_emit("rollback.commit")
  self.active = {
    system = sysOld, source = snap.bundle, manifest = snap.manifest,
    version = snap.version, releaseId = snap.releaseId,
  }
  self.staged = nil
  self.inFlight = false
  steps["rollback.commit"] = (self.clock() - st) * 1000

  -- bus ของระบบที่ rollback มาเป็น bus ใหม่ — ต้อง Declare event ของ update domain
  -- ก่อน publish (มิฉะนั้นเป็น undeclared และถูก drop เงียบ ๆ)
  for _, ev in ipairs(Update.EVENTS) do
    if sysOld.bus:Policy(ev[1]) == nil then
      sysOld.bus:Declare(ev[1], ev[2])
    end
  end

  local timing, totalMs = finishTiming(self, steps, t0)
  if timing.overBudget then
    warnings[#warnings + 1] = ("เวลารวม %.1f ms เกินงบ %d ms (§9.1)")
      :format(totalMs, self.budgetMs)
  end

  pcall(sysOld.diag.Mark, sysOld.diag, "hotUpdateMs", totalMs)

  local res = self:_result(path, {
    bugId = self:_nextBugId(),
    detail = ("%s — ROLLBACK สำเร็จ: กลับรุ่น v%s + state/config กลับคืน "
      .. "+ SELFCHECK/PROBE ผ่าน (ใช้งานต่อได้จริง %.1f ms)")
      :format(reason, snap.version, totalMs),
    rolledBack = true,
    to = attempt,
    orphans = orphans,
    replay = replayReport,
    integrity = integrity,
    snapshot = snap,
    warnings = warnings,
    timing = timing,
  })

  sysOld.bus:Publish("update:rolledback", {
    path = path, bugId = res.bugId, from = res.from, back = res.to, totalMs = totalMs,
  })
  sysOld.bus:Publish("notify:user", {
    level = "warn",
    key = "notify.update.rolledback",
    params = { path = path, bugId = res.bugId, version = snap.version },
  })
  self.logger("warn", res.detail)
  return res
end

return Update
