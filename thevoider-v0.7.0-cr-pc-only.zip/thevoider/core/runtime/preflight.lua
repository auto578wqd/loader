-- ============================================================================
-- The Voider — core/runtime/preflight.lua
-- Bootstrap Preflight (แผน freeze v2.1 §3.2 ข้อ 0, hardening #6)
--
-- รัน "ใน loader ก่อนโหลด core" ตรวจเฉพาะ prerequisite ที่ loader เองต้องใช้:
--   1) มี HTTP request function จริงหรือไม่ (ชื่อไหนก็ตามที่ executor รองรับ)
--   2) เข้าถึง GitHub/CDN ได้หรือไม่
--
-- พัง = แจ้ง plain text ผ่านคอนโซลของ executor (ข้อความไทยชัดเจน 1 บรรทัด)
-- แล้วหยุดทำงานทันที — ไม่มี UI ใด ๆ เพราะ core ยังไม่ถูกโหลด
-- (แยกชัดจาก Runtime Capability = หลัง core = Notification UI + graceful disable)
--
-- หมายเหตุ build: loader.lua ส่งมอบจริง embed ไฟล์นี้ (core ยังไม่ถูกโหลด
-- จึง require จากไฟล์อื่นไม่ได้) — build script คัดลอก/ฝังให้อัตโนมัติทุกรอบ
-- ============================================================================

local Preflight = {}

-- ชื่อ HTTP API ที่ค้ำเลือก (เรียงตามควา่นิยม) — Volt ใช้ http_request
Preflight.HTTP_CANDIDATES = {
  "http_request", -- มาตรฐาน executor รุ่นใหม่ (Volt)
  "syn.request",  -- มาตรฐานเก่า
  "request",
  "http_get",     -- GET-only (คืน body เป็น string)
  "httpget",
}

Preflight.MSG_NO_HTTP =
  "[The Voider] รันสคริปต์ไม่ได้: ไม่พบระบบเชื่อมต่ออินเทอร์เน็ต (HTTP) — The Voider รองรับการใช้งานบน Volt เท่านั้น"

Preflight.MSG_CDN_FAIL =
  "[The Voider] รันสคริปต์ไม่ได้: เข้าถึงเซิร์ฟเวอร์อัปเดต (GitHub/CDN) ไม่สำเร็จ — กรุณาตรวจอินเทอร์เน็ตแล้วรันใหม่ (The Voider รองรับ Volt เท่านั้น)"

--- ค้นหา HTTP function จาก environment — คืน (name, fn) หรือ (nil, nil)
function Preflight.FindHTTP(env)
  env = env or _G
  for _, name in ipairs(Preflight.HTTP_CANDIDATES) do
    if name == "syn.request" then
      if type(env.syn) == "table" and type(env.syn.request) == "function" then
        return name, env.syn.request
      end
    else
      local v = env[name]
      if type(v) == "function" then
        return name, v
      end
    end
  end
  return nil, nil
end

-- ปรับผลตอบของ HTTP API หลายรูปแบบให้เป็นมาตรฐานเดียว {ok, status}
local function normalize(res)
  if type(res) == "table" then
    if res.Success == true then return { ok = true, status = "Success=true" } end
    local code = res.StatusCode or res.Status or res.code
    if type(code) == "number" then
      if code >= 200 and code <= 299 then
        return { ok = true, status = tostring(code) }
      end
      return { ok = false, status = tostring(code) }
    end
    if type(res.Body) == "string" and #res.Body > 0 then
      return { ok = true, status = "body:" .. tostring(#res.Body) .. "B" }
    end
  elseif type(res) == "string" then
    if #res > 0 then return { ok = true, status = "body:" .. tostring(#res) .. "B" } end
  end
  return { ok = false, status = "no-response" }
end

-- สร้าง requester ที่คุมรูปแบบการเรียกตามชื่อ API (table-request vs GET-only)
local function makeRequester(name, fn, timeout)
  if name == "http_get" or name == "httpget" then
    return function(url)
      local ok, body = pcall(fn, url)
      if not ok then return { ok = false, status = "error:" .. tostring(body) } end
      return normalize(body)
    end
  end
  return function(url)
    local req = { Url = url, Method = "GET" }
    if timeout then req.Timeout = timeout end
    local ok, res = pcall(fn, req)
    if not ok then return { ok = false, status = "error:" .. tostring(res) } end
    return normalize(res)
  end
end

--- ตรวจ 2 ขั้น: HTTP function + CDN เข้าถึงได้
--- opts = { env=table, urls={...}, log=function, httpFn=function, httpName=string, timeout=number }
--- คืน result = { ok, stage, httpName, httpFn, url, message, lastStatus }
---   stage: "http_function" | "cdn" | "done"
function Preflight.Run(opts)
  opts = opts or {}
  local env = opts.env or _G
  local timeout = opts.timeout or 8

  local function log(msg)
    if opts.log then
      opts.log(msg)
    else
      local w = type(warn) == "function" and warn or print
      w(msg)
    end
  end

  local result = { ok = false, stage = nil, httpName = nil, httpFn = nil, url = nil, message = nil }

  -- ขั้น 1: หา HTTP function จริง
  local name, fn
  if opts.httpFn then
    name, fn = opts.httpName or "(custom)", opts.httpFn
  else
    name, fn = Preflight.FindHTTP(env)
  end
  if not name then
    result.stage = "http_function"
    result.message = Preflight.MSG_NO_HTTP
    log(result.message) -- plain text 1 บรรทัด แล้วหยุด (loader เรียก return เอง)
    return result
  end
  result.httpName = name
  result.httpFn = fn

  -- ขั้น 2: CDN/GitHub เข้าถึงได้อย่างน้อย 1 URL (fallback ตามลำดับ)
  local request = makeRequester(name, fn, timeout)
  local urls = opts.urls or {}
  local lastStatus = nil
  for _, url in ipairs(urls) do
    local res = request(url)
    if res.ok then
      result.ok = true
      result.stage = "done"
      result.url = url
      return result
    end
    lastStatus = res.status
  end

  result.stage = "cdn"
  result.message = Preflight.MSG_CDN_FAIL
  result.lastStatus = lastStatus
  log(result.message)
  return result
end

return Preflight
