-- ============================================================================
-- The Voider — core/runtime/registry.lua
-- Resource Registry — ตัวครอบเดียว สี่ชนิด (แผน freeze v2.1 §3.2 ข้อ 2, hardening #2)
--
--   Runtime.Spawn(name, fn)          task/loop          (เดิม Task Registry)
--   Runtime.Connect(signal, fn)      event connection   (เดิม Connection Registry)
--   Runtime.NewRender(kind, props)   Drawing/Instance   (ใหม่ v2.1)
--   Runtime.Temp(obj, disposer)      ทรัพยากรชั่วคราว   (ใหม่ v2.1)
--
-- กฎเหล็ก (§3.4): หลัง Module:Destroy() จบ ทรัพยากรทั้ง 4 ชนิดของโมดูลนั้น
-- ต้องเท่ากับ 0 รวมทุกชนิด — มี assertion ตรวจอัตโนมัติใน debug build
-- hot update (§3.6 ขั้น VERIFY) ตรวจทั้ง 4 ชนิดก่อนสลับรุ่น: orphan > 0 = ABORT
--
-- ความเป็นเจ้าของ (ownership): ทรัพยากรผูกกับ "owner" ที่กำหนดผ่าน Runtime.Scope
-- ทุกการจองต้องอยู่ใน Scope ของโมดูล — ของที่หลุดจากระบบ = นับเป็น orphan ของ "_unscoped"
--
-- สัญญาของ loop task: fn(ctx) ต้องเรียก ctx.ShouldRun() ทุกรอบ (คืน false = ถูกสั่งหยุด)
-- ผลพลอยได้: ทุกครั้งที่ ShouldRun() คืน true = heartbeat 1 ครั้งของโมดูลผู้เป็นเจ้า
-- (โมดูลที่ loop ยังเดินอยู่ = ยังหายใจ — watchdog ใช้ตรวจโมดูลตาย/ค้างโดยอัตโนมัติ)
-- ============================================================================

local Registry = {}
Registry.__index = Registry

local unpack = table.unpack or unpack

Registry.KIND_KEYS = { "tasks", "connections", "renders", "temps" }

function Registry.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    clock = ctx.clock or os.clock,
    task = ctx.task or rawget(_G, "task"),
    drawing = ctx.drawing or rawget(_G, "Drawing"),
    instance = ctx.instance or rawget(_G, "Instance"),
    debug = ctx.debug or false,
    boundary = nil,   -- ติดตั้งภายหลังโดย init.lua
    watchdog = nil,   -- ติดตั้งภายหลังโดย init.lua
    currentOwner = nil,
    items = {},       -- handle ทุกตัวที่ยังมีชีวิต (เรียงตามเวลาสร้าง)
    counts = { tasks = 0, connections = 0, renders = 0, temps = 0 },
  }, Registry)
  return self
end

function Registry:SetBoundary(b) self.boundary = b end
function Registry:SetWatchdog(w) self.watchdog = w end

--- กำหนด "ผู้เป็นเจ้า" ของทุกทรัพยากรที่จองภายใน fn (ซ้อนกันได้ คืนค่าเดิมหลังจบ)
function Registry:Scope(owner, fn)
  local prev = self.currentOwner
  self.currentOwner = owner
  local results = { pcall(fn) }
  self.currentOwner = prev
  if not results[1] then
    error(results[2], 0)
  end
  return unpack(results, 2)
end

function Registry:Owner()
  return self.currentOwner
end

function Registry:_owner()
  if self.currentOwner then return self.currentOwner end
  if self.debug then
    print("[The Voider][Registry] WARNING: จองทรัพยากรนอก Scope — นับเป็น '_unscoped' (ต้องแก้เป็น Runtime.Scope)")
  end
  return "_unscoped"
end

function Registry:_beat(owner)
  if self.watchdog then
    self.watchdog:Beat(owner)
  end
end

function Registry:_add(h)
  table.insert(self.items, h)
  self.counts[h.kindKey] = self.counts[h.kindKey] + 1
end

function Registry:_remove(h)
  for i, item in ipairs(self.items) do
    if item == h then
      table.remove(self.items, i)
      self.counts[h.kindKey] = math.max(0, self.counts[h.kindKey] - 1)
      return true
    end
  end
  return false
end

-- ---------------------------------------------------------------------------
-- 1) Tasks — Runtime.Spawn(name, fn)
-- ---------------------------------------------------------------------------

--- จอง task/loop — fn(ctx) โดย ctx = { Name, ShouldRun(), Beat(), Wait(t) }
-- thread จบเอง (one-shot หรือ loop ครบ) = deregister อัตโนมัติ (ไม่ใช่ orphan)
-- error ภายใน fn = Error Boundary จับ + thread จบ + deregister (watchdog เห็น stall ต่อไป)
function Registry:Spawn(name, fn)
  if type(fn) ~= "function" then
    error("Runtime.Spawn(name, fn): fn ต้องเป็น function", 2)
  end
  if not self.task then
    error("Runtime.Spawn: ไม่มี task library (ctx.task)", 2)
  end
  local owner = self:_owner()
  local reg = self

  local h = {
    __registry_handle = true,
    kindKey = "tasks",
    kind = "task",
    name = name or "unnamed",
    owner = owner,
    released = false,
    cancelled = false,
    createdAt = self.clock(),
    lastBeatAt = self.clock(),
  }

  local ctx = {
    Name = h.name,
    -- เรียกทุกตั้งรอบของ loop: คืน false = ถูกสั่งหยุด (ต้องออกจาก loop ทันที)
    ShouldRun = function()
      if h.cancelled then return false end
      h.lastBeatAt = reg.clock()
      reg:_beat(owner)
      return true
    end,
    -- รายงานหายใจด้วยตนเอง (โมดูลที่ไม่ใช่ loop เช่น event-driven เรียกเองใน handler ได้)
    Beat = function()
      if h.cancelled then return end
      h.lastBeatAt = reg.clock()
      reg:_beat(owner)
    end,
    Wait = function(t)
      return reg.task.wait(t)
    end,
  }
  h.ctx = ctx

  h.Release = function()
    reg:_releaseTask(h)
  end
  h.Cancel = h.Release

  -- ลงทะเบียนก่อน spawn: กัน race ที่ thread จบสนิทภายใน spawn() ก่อนที่ _add จะทำงาน
  self:_add(h)

  h.thread = self.task.spawn(function()
    local bnd = reg.boundary
    if bnd then
      bnd:Guard(owner, function()
        return fn(ctx)
      end)
    else
      pcall(fn, ctx)
    end
    -- จบแบบธรรมชาติ (return/error ที่โดนจับแล้ว) → deregister อัตโนมัติ
    h.released = true
    reg:_remove(h)
  end)

  return h
end

function Registry:_releaseTask(h)
  if h.released then return end
  h.cancelled = true
  h.released = true
  if self.task and self.task.cancel and h.thread then
    pcall(self.task.cancel, h.thread)
  end
  self:_remove(h)
end

-- ---------------------------------------------------------------------------
-- 2) Connections — Runtime.Connect(signal, fn)
-- ---------------------------------------------------------------------------

--- จอง event connection — handler รันภายใต้ Error Boundary ของ owner เสมอ
function Registry:Connect(signal, fn)
  if type(fn) ~= "function" then
    error("Runtime.Connect(signal, fn): fn ต้องเป็น function", 2)
  end
  if type(signal) ~= "table" and type(signal) ~= "userdata" then
    error("Runtime.Connect(signal, fn): signal ต้องมี :Connect", 2)
  end
  local owner = self:_owner()
  local reg = self

  local h = {
    __registry_handle = true,
    kindKey = "connections",
    kind = "connection",
    name = (type(signal) == "table" and signal.Name) or "signal",
    owner = owner,
    released = false,
  }

  -- entry point ของโมดูล = รันใต้ boundary (error ใน handler ต้องไม่ลามไป handler อื่น)
  local wrapped = function(...)
    local bnd = reg.boundary
    if bnd then
      return bnd:Guard(owner, fn, ...)
    end
    return fn(...)
  end

  local ok, conn = pcall(function()
    return signal:Connect(wrapped)
  end)
  if not ok then
    error("Runtime.Connect: signal:Connect ล้มเหลว: " .. tostring(conn), 2)
  end
  h.conn = conn

  h.Release = function()
    if h.released then return end
    h.released = true
    if conn and type(conn.Disconnect) == "function" then
      pcall(conn.Disconnect, conn)
    end
    reg:_remove(h)
  end
  h.Disconnect = h.Release

  self:_add(h)
  return h
end

-- ---------------------------------------------------------------------------
-- 3) Render Objects — Runtime.NewRender(kind, props)
-- ---------------------------------------------------------------------------

--- จอง Drawing/Instance สำหรับ ESP/FOV circle/overlay
--- kind รูปแบบที่ 1: ชื่อ Drawing class เช่น "Line" "Circle" "Text" "Square" "Image"
--           → Drawing.new(kind) แล้ว apply props ทุกตัว
-- kind รูปแบบที่ 2: "Instance"
--           → props.Class = ชื่อ class, props.Props = {…} ตั้งค่า, props ที่เหลือ (เช่น Parent) ตั้งตรง
-- ถ้าไม่มี library / สร้างไม่ได้: คืน nil + reason (graceful — ผู้เรียกต้องเช็ค capability ก่อนเปิดฟีเจอร์ §3.2)
function Registry:NewRender(kind, props)
  props = props or {}
  local owner = self:_owner()
  local obj, why

  if kind == "Instance" then
    local cls = props.Class
    if not self.instance then
      why = "ไม่มี Instance library"
    elseif type(cls) ~= "string" then
      why = "props.Class จำเป็นสำหรับ kind='Instance'"
    else
      local ok, res = pcall(self.instance.new, cls)
      if ok then
        obj = res
      else
        why = ("Instance.new(%s) ล้มเหลว: %s"):format(tostring(cls), tostring(res))
      end
    end
  else
    if not self.drawing then
      why = "ไม่มี Drawing library (DRAWING capability ปิด)"
    else
      local ok, res = pcall(self.drawing.new, kind)
      if ok then
        obj = res
      else
        why = ("Drawing.new(%s) ล้มเหลว: %s"):format(tostring(kind), tostring(res))
      end
    end
  end

  if not obj then
    if self.debug then
      print(("[The Voider][Registry] NewRender(%s) ใช้ไม่ได้: %s"):format(tostring(kind), tostring(why)))
    end
    return nil, why
  end

  local okApply, applyErr = pcall(function()
    if kind == "Instance" then
      for k, v in pairs(props.Props or {}) do
        obj[k] = v
      end
      for k, v in pairs(props) do
        if k ~= "Class" and k ~= "Props" then
          obj[k] = v
        end
      end
    else
      for k, v in pairs(props) do
        obj[k] = v
      end
    end
  end)
  if not okApply then
    pcall(function()
      if type(obj.Remove) == "function" then obj:Remove()
      elseif type(obj.Destroy) == "function" then obj:Destroy() end
    end)
    return nil, "ตั้งค่า props ไม่ได้: " .. tostring(applyErr)
  end

  local reg = self
  local h = {
    __registry_handle = true,
    kindKey = "renders",
    kind = "render",
    name = tostring(kind),
    owner = owner,
    obj = obj,
    released = false,
  }
  h.Release = function()
    if h.released then return end
    h.released = true
    pcall(function()
      if type(obj.Remove) == "function" then
        obj:Remove()
      elseif type(obj.Destroy) == "function" then
        obj:Destroy()
      end
    end)
    reg:_remove(h)
  end
  h.Remove = h.Release
  h.Destroy = h.Release

  self:_add(h)
  return h
end

-- ---------------------------------------------------------------------------
-- 4) Temporary Resources — Runtime.Temp(obj [, disposer])
-- ---------------------------------------------------------------------------

--- จองทรัพยากรชั่วคราว (tween/timer/อ็อบเจ็กต์ที่ต้องคืน)
-- วิธีคืน: disposer(obj) ถ้าให้มา | obj() ถ้า obj เป็น function
--          | obj:Disconnect() / obj:Destroy() / obj:Remove() ตามลำดับที่หาเจอ
function Registry:Temp(obj, disposer)
  local owner = self:_owner()
  local reg = self

  local h = {
    __registry_handle = true,
    kindKey = "temps",
    kind = "temp",
    name = (type(obj) == "table" and obj.Name) or "temp",
    owner = owner,
    obj = obj,
    released = false,
  }
  h.Release = function()
    if h.released then return end
    h.released = true
    pcall(function()
      if type(disposer) == "function" then
        disposer(obj)
      elseif type(obj) == "function" then
        obj()
      elseif type(obj) == "table" then
        if type(obj.Disconnect) == "function" then obj:Disconnect()
        elseif type(obj.Destroy) == "function" then obj:Destroy()
        elseif type(obj.Remove) == "function" then obj:Remove() end
      end
    end)
    reg:_remove(h)
  end

  self:_add(h)
  return h
end

-- ---------------------------------------------------------------------------
-- ตรวจนับ / คืนทรัพยากร / ตรวจ orphan
-- ---------------------------------------------------------------------------

--- สรุปจำนวนทรัพยากร (owner = nil → ทั้งหมด) — {tasks, connections, renders, temps, total}
function Registry:Snapshot(owner)
  local snap = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 }
  for _, h in ipairs(self.items) do
    if owner == nil or h.owner == owner then
      snap[h.kindKey] = snap[h.kindKey] + 1
      snap.total = snap.total + 1
    end
  end
  return snap
end

--- รายชื่อทรัพยากรที่ค้างอยู่ (ใช้ใน Diagnostics + รายงาน orphan)
function Registry:List(owner)
  local out = {}
  for _, h in ipairs(self.items) do
    if owner == nil or h.owner == owner then
      table.insert(out, ("%s:%s(%s)"):format(h.kind, h.name, h.owner))
    end
  end
  return out
end

--- คืนทรัพยากรของ owner (nil = ทั้งหมด) — คืนตารางจำนวนที่ปล่อยไป
function Registry:Release(owner)
  local released = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0 }
  for i = #self.items, 1, -1 do
    local h = self.items[i]
    if owner == nil or h.owner == owner then
      if h.Release then
        h.Release()
      end
      released[h.kindKey] = released[h.kindKey] + 1
      released.total = released.total + 1
    end
  end
  return released
end

--- ตรวจ orphan ของ owner (nil = ทั้งหมด) — คืน (ok, snapshot)
function Registry:VerifyZero(owner)
  local snap = self:Snapshot(owner)
  snap.ok = snap.total == 0
  return snap.ok, snap
end

--- ใช้ตอน hot update VERIFY (§3.6 ขั้น 8): นับเฉพาะของ "โมดูล"
-- (ของ Runtime เอง owner ขึ้นต้นด้วย "Runtime." ยกเว้น — TEARDOWN ทำลายโมดูลก่อน
--  ส่วน Runtime ถูกปิดท้ายตามลำดับ dependency graph §3.10)
function Registry:ModuleTotals()
  local snap = { tasks = 0, connections = 0, renders = 0, temps = 0, total = 0, owners = {} }
  for _, h in ipairs(self.items) do
    local isRuntime = type(h.owner) == "string" and h.owner:sub(1, 8) == "Runtime."
    if not isRuntime then
      snap[h.kindKey] = snap[h.kindKey] + 1
      snap.total = snap.total + 1
      snap.owners[h.owner] = (snap.owners[h.owner] or 0) + 1
    end
  end
  return snap
end

return Registry
