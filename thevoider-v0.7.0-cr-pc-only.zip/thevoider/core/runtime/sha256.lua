-- ============================================================================
-- The Voider — core/runtime/sha256.lua (loader-domain §7.2)
--
-- SHA-256 สามระดับตามแผน §7.2 (บอกตามจริง ไม่อวดอ้าง):
--   ระดับ 1 "crypto-api" : executor มี crypto API (crypto.hash / syn.crypt.hash)
--                           และผ่าน Known-Answer Test — ใช้ของมัน
--   ระดับ 2 "software"   : pure-Lua SHA-256 (ไฟล์นี้) — ใช้เมื่อไม่มี crypto API
--                           และ hash จบภายในงบเวลา (วัดจริงทุกครั้ง §9.1)
--   ระดับ 3 "level2"     : version + size + header marker (ช้าเกินงบ = ตกมาที่ระดับนี้
--                           และรายงาน "ตรวจระดับพื้นฐาน" ตามความจริง)
--
-- การเลือกชุด op ตาม environment: bit32 (Luau/Volt) → bit (LuaJIT) →
--   ตาราง byte 8-bit (256x256) สำหรับ AND/OR/XOR + เลขคณิตล้วนสำหรับ
--   ADD/SHR/ROTR/NOT — ไม่ใช้ bitwise operator ของ Lua 5.3 (Lua 5.1 parser
--   ไม่รองรับ → ไฟล์จะพังตอน parse ทั้งไฟล์ ถ้าอยู่บน executor 5.1)
--
-- Known-Answer Test ชุดเดียวกับ core/runtime/capability.lua:
--   sha256("TheVoider-KAT") = a0c4fa5d1b78...196b4ee (ตรวจกับ python hashlib แล้ว)
--
-- ไฟล์นี้ self-contained — build ฝังลง loader.lua ได้ทันที
-- ============================================================================

local Sha256 = {}

Sha256.VERSION = "0.3.0"

-- ---- ค่าคงที่ของ SHA-256 (FIPS 180-4) --------------------------------------
-- IMPORTANT: เขียนเป็นฐานสิบเท่านั้น — hex literal เกิน 0x7fffffff ในบาง runtime
-- (fengari) ถูก parse เป็นค่าติดลบ (BUG-016) — ฐานสิบปลอดภัยทุก runtime

local K = {
  1116352408, 1899447441, 3049323471, 3921009573,  961987163, 1508970993, 2453635748, 2870763221,
  3624381080,  310598401,  607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580,
  3835390401, 4022224774,  264347078,  604807628,  770255983, 1249150122, 1555081692, 1996064986,
  2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,  113926993,  338241895,
   666307205,  773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037,
  2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909,  275423344,
   430227734,  506948616,  659060556,  883997877,  958139571, 1322822218, 1537002063, 1747873779,
  1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298,
}

local H0 = {
  1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,  528734635, 1541459225,
}

local MOD = 4294967296.0 -- 2^32 (float เสมอ: fengari ทำ integer arithmetic แบบ wrap ที่ 2^31 — BUG-016b)
local floor = math.floor

-- ---- เลือกชุด op ตาม environment --------------------------------------------

local bor, band, bxor, bnot, rshift
local opsReady = false

local function initBit32()
  local b = rawget(_G, "bit32")
  if type(b) == "table" and type(b.bor) == "function"
    and type(b.band) == "function" and type(b.bxor) == "function" then
    bor, band, bxor = b.bor, b.band, b.bxor
    bnot = b.bnot
    rshift = function(x, n) return b.rshift(x, n) end
    return true
  end
  return false
end

local function initBitLib()
  local b = rawget(_G, "bit")
  if type(b) == "table" and type(b.bor) == "function"
    and type(b.band) == "function" and type(b.bxor) == "function" then
    bor, band, bxor = b.bor, b.band, b.bxor
    bnot = function(x) return b.bxor(x, 0xFFFFFFFF) end
    rshift = function(x, n) return b.rshift(x, n) end
    return true
  end
  return false
end

-- ตาราง byte 8-bit (256 x 256) สำหรับ AND/OR/XOR — สร้างครั้งเดียวเมื่อจำเป็น
local T_X, T_A, T_O

local function buildTables()
  T_X, T_A, T_O = {}, {}, {}
  for i = 0, 255 do
    local xi, ai, oi = {}, {}, {}
    for j = 0, 255 do
      local p, q, bitv, andv, xorv = i, j, 1, 0, 0
      while p > 0 or q > 0 do
        local pb, qb = p % 2, q % 2
        if pb == 1 and qb == 1 then andv = andv + bitv end
        if pb ~= qb then xorv = xorv + bitv end
        p = floor(p / 2)
        q = floor(q / 2)
        bitv = bitv * 2
      end
      xi[j + 1] = xorv
      ai[j + 1] = andv
      oi[j + 1] = i + j - andv -- OR = a + b - AND
    end
    T_X[i + 1] = xi
    T_A[i + 1] = ai
    T_O[i + 1] = oi
  end
end

local function initArith()
  if not T_X then buildTables() end
  bor = function(a, b)
    if a == 0 then return b end
    if b == 0 then return a end
    local a1, a2, a3 = a % 256, floor(a / 256) % 256, floor(a / 65536) % 256
    local b1, b2, b3 = b % 256, floor(b / 256) % 256, floor(b / 65536) % 256
    return T_O[a1 + 1][b1 + 1]
      + T_O[a2 + 1][b2 + 1] * 256.0
      + T_O[a3 + 1][b3 + 1] * 65536.0
      + T_O[floor(a / 16777216) + 1][floor(b / 16777216) + 1] * 16777216.0
  end
  band = function(a, b)
    if a == 0 or b == 0 then return 0 end
    local a1, a2, a3 = a % 256, floor(a / 256) % 256, floor(a / 65536) % 256
    local b1, b2, b3 = b % 256, floor(b / 256) % 256, floor(b / 65536) % 256
    return T_A[a1 + 1][b1 + 1]
      + T_A[a2 + 1][b2 + 1] * 256.0
      + T_A[a3 + 1][b3 + 1] * 65536.0
      + T_A[floor(a / 16777216) + 1][floor(b / 16777216) + 1] * 16777216.0
  end
  bxor = function(a, b)
    if a == 0 then return b end
    if b == 0 then return a end
    local a1, a2, a3 = a % 256, floor(a / 256) % 256, floor(a / 65536) % 256
    local b1, b2, b3 = b % 256, floor(b / 256) % 256, floor(b / 65536) % 256
    return T_X[a1 + 1][b1 + 1]
      + T_X[a2 + 1][b2 + 1] * 256.0
      + T_X[a3 + 1][b3 + 1] * 65536.0
      + T_X[floor(a / 16777216) + 1][floor(b / 16777216) + 1] * 16777216.0
  end
  bnot = function(x) return 4294967295.0 - x end
  rshift = function(x, n) return floor(x / (2 ^ n)) end
  return true
end

local function ensureOps()
  if opsReady then return end
  opsReady = true
  if not initBit32() and not initBitLib() then
    initArith()
  end
end

-- ROTR แบบเลขคณิตล้วน (ไม่พึ่งตาราง — ใช้ได้ทุกโหมด)
local function rotr(x, n)
  local dn = 2 ^ n
  local hi = floor(x / dn)
  local lo = x % dn
  return hi + lo * (2 ^ (32 - n))
end

-- ---- hex -------------------------------------------------------------------

local HEXCHARS = "0123456789abcdef"
local function toHex32(v)
  local out = {}
  for i = 8, 1, -1 do
    local nib = v % 16
    out[i] = HEXCHARS:sub(nib + 1, nib + 1)
    v = floor(v / 16)
  end
  return table.concat(out)
end

-- ---- แกนกลาง: hash ข้อความ (string) → 64 hex ตัวพิมพ์เล็ก -------------------

local W = {}

local function hashBlock(bytes, off, h1, h2, h3, h4, h5, h6, h7, h8)
  local i
  for i = 1, 16 do
    local j = off + (i - 1) * 4
    W[i] = bytes[j] * 16777216.0 + bytes[j + 1] * 65536.0 + bytes[j + 2] * 256.0 + bytes[j + 3]
  end
  for i = 17, 64 do
    local w15, w2 = W[i - 15], W[i - 2]
    local s0 = bxor(bxor(rotr(w15, 7), rotr(w15, 18)), rshift(w15, 3))
    local s1 = bxor(bxor(rotr(w2, 17), rotr(w2, 19)), rshift(w2, 10))
    W[i] = (W[i - 16] + s0 + W[i - 7] + s1) % MOD
  end
  local a, b, c, d, e, f, g, hh = h1, h2, h3, h4, h5, h6, h7, h8
  for i = 1, 64 do
    local S1 = bxor(bxor(rotr(e, 6), rotr(e, 11)), rotr(e, 25))
    local ch = bxor(band(e, f), band(bnot(e), g))
    local t1 = (hh + S1 + ch + K[i] + W[i]) % MOD
    local S0 = bxor(bxor(rotr(a, 2), rotr(a, 13)), rotr(a, 22))
    local maj = bxor(bxor(band(a, b), band(a, c)), band(b, c))
    local t2 = S0 + maj
    hh = g; g = f; f = e
    e = (d + t1) % MOD
    d = c; c = b; b = a
    a = (t1 + t2) % MOD
  end
  return
    (h1 + a) % MOD, (h2 + b) % MOD, (h3 + c) % MOD, (h4 + d) % MOD,
    (h5 + e) % MOD, (h6 + f) % MOD, (h7 + g) % MOD, (h8 + hh) % MOD
end

function Sha256.hex(msg)
  if type(msg) ~= "string" then
    error("Sha256.hex(msg): msg ต้องเป็น string (ได้ " .. type(msg) .. ")", 2)
  end
  ensureOps()

  local len = #msg
  local bitLen = len * 8
  local lenHi = floor(bitLen / MOD)
  local lenLo = bitLen % MOD

  -- สร้าง padded byte array: msg + 0x80 + ศูนย์ + 8 ไบต์ความยาว (BE)
  local bytes = {}
  local n = 0
  local idx
  for idx = 1, len do
    n = n + 1
    bytes[n] = string.byte(msg, idx)
  end
  n = n + 1
  bytes[n] = 0x80
  while n % 64 ~= 56 do
    n = n + 1
    bytes[n] = 0
  end
  -- ความยาว 64-bit BE: 4 ไบต์บน (lenHi) + 4 ไบต์ล่าง (lenLo)
  bytes[n + 1] = floor(lenHi / 16777216.0) % 256
  bytes[n + 2] = floor(lenHi / 65536.0) % 256
  bytes[n + 3] = floor(lenHi / 256.0) % 256
  bytes[n + 4] = lenHi % 256
  bytes[n + 5] = floor(lenLo / 16777216.0) % 256
  bytes[n + 6] = floor(lenLo / 65536.0) % 256
  bytes[n + 7] = floor(lenLo / 256.0) % 256
  bytes[n + 8] = lenLo % 256

  local h1, h2, h3, h4, h5, h6, h7, h8 =
    H0[1], H0[2], H0[3], H0[4], H0[5], H0[6], H0[7], H0[8]
  local off = 1
  while off <= n do
    h1, h2, h3, h4, h5, h6, h7, h8 =
      hashBlock(bytes, off, h1, h2, h3, h4, h5, h6, h7, h8)
    off = off + 64
  end

  return toHex32(h1) .. toHex32(h2) .. toHex32(h3) .. toHex32(h4)
    .. toHex32(h5) .. toHex32(h6) .. toHex32(h7) .. toHex32(h8)
end

-- ชื่อเดียวกัน (โหมดซอฟต์แวร์ §7.2) — ให้ caller อ่านออกง่าย
Sha256.software = Sha256.hex

-- ---- ระดับ 1: crypto API ของ executor (มีหรือไม่ + ใช้ได้จริงไหม) ----------

-- รูปแบบที่รองรับ (เรียงตามความนิยม) — KAT เดียวกับ capability.lua
Sha256.KAT_INPUT = "TheVoider-KAT"
Sha256.KAT_DIGEST = "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee"

local function cryptoForms(env)
  local forms = {}
  local crypto = rawget(env, "crypto")
  if type(crypto) == "table" and type(crypto.hash) == "function" then
    forms[#forms + 1] = { name = "crypto.hash(algo, s)", fn = function(s) return crypto.hash("sha256", s) end }
    forms[#forms + 1] = { name = "crypto.hash(s, algo)", fn = function(s) return crypto.hash(s, "sha256") end }
  end
  local syn = rawget(env, "syn")
  if type(syn) == "table" and type(syn.crypt) == "table" and type(syn.crypt.hash) == "function" then
    forms[#forms + 1] = { name = "syn.crypt.hash(algo, s)", fn = function(s) return syn.crypt.hash("sha256", s) end }
    forms[#forms + 1] = { name = "syn.crypt.hash(s, algo)", fn = function(s) return syn.crypt.hash(s, "sha256") end }
  end
  return forms
end

local function digestOk(v)
  return type(v) == "string" and #v == 64 and v:match("^[%x]+$") ~= nil
end

--- หา crypto API ที่ hash ได้ถูกต้องจริง (KAT) — คืน (apiName, hashFn) หรือ (nil, เหตุผล)
--- ผ่าน KAT เท่านั้น — API ที่ตอบค่าผิด/พัง = ไม่ใช้ (ป้องกัน "มีชื่อแต่ใช้ไม่ได้")
function Sha256.probe(env)
  env = env or _G
  local forms = cryptoForms(env)
  for _, f in ipairs(forms) do
    local ok, v = pcall(f.fn, Sha256.KAT_INPUT)
    if ok and digestOk(v) then
      local dv = v:lower()
      if dv == Sha256.KAT_DIGEST then
        return f.name, f.fn
      end
    end
  end
  if #forms == 0 then
    return nil, "ไม่มี crypto API ที่รู้จัก"
  end
  return nil, "มี crypto API แต่ไม่ผ่าน Known-Answer Test (ใช้ hash จริงไม่ได้)"
end

--- hash ผ่าน crypto API ที่ผ่าน KAT แล้ว — คืน (hex, apiName) หรือ (nil, เหตุผล)
function Sha256.cryptoHex(env, msg)
  env = env or _G
  local name, fn = Sha256.probe(env)
  if not name then
    return nil, name == nil and "no-crypto" or name
  end
  local ok, v = pcall(fn, msg)
  if not ok then
    return nil, ("crypto API พังกลางทาง: " .. tostring(v))
  end
  if not digestOk(v) then
    return nil, "crypto API ตอบค่าไม่ใช่ 64-hex"
  end
  return v:lower(), name
end

-- ---- self-test (ใช้ใน L1 + SELFCHECK ย่อยได้) --------------------------------

Sha256.KAT_VECTORS = {
  { input = "", digest = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855" },
  { input = "abc", digest = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad" },
  { input = "TheVoider-KAT", digest = "a0c4fa5d1b78ce13eb7d6bc3309f6b0009b06b3ce0412a8e9612aecdc196b4ee" },
}

--- รัน KAT 3 ตัวด้วยโหมดซอฟต์แวร์ — คืน (ok, detail)
function Sha256.selfTest()
  for _, v in ipairs(Sha256.KAT_VECTORS) do
    local got = Sha256.hex(v.input)
    if got ~= v.digest then
      return false, ("KAT ไม่ผ่าน: sha256(%q)\n  อยากได้ %s\n  ได้จริง    %s")
        :format(v.input, v.digest, got)
    end
  end
  return true, "KAT ผ่านครบ 3 ตัว (โหมดซอฟต์แวร์)"
end

return Sha256
