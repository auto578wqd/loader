-- ============================================================================
-- The Voider — core/adapter/combat.lua
-- Combat Adapter (แผน freeze v2.1 §3.3) — อาวุธ, สกิล, cooldown, remote, M1
--
-- ขอบเขตรอบ "โครงแรกระดับพื้นฐาน" (§5.3):
--   ✅ หาอาวุธที่ถือ (Tool ใน Character)
--   ✅ ส่งสกิลผ่าน remote ของเกม (FireSkill = ส่งต่อ RemoteEvent จริง)
--   ✅ สำรวจ remote ที่รู้จัก (GetRemotes — ใช้โดย Self-Probe)
--   ⏸ cooldown รายสกิล = PENDING (ต้องอ่านค่าจากโครงสร้างเกมจริง — จะทำพร้อม
--      Behavioral Matrix ของ VoidAim/CombatCore เฟส 2-3 ตามกติกา §4.5)
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local CombatAdapter = {}
CombatAdapter.__index = CombatAdapter

CombatAdapter.NODE = "CombatAdapter"
CombatAdapter.VERSION = "0.2.0"

CombatAdapter.METHODS = {
  "GetEquippedWeapon", "FireSkill", "GetRemotes",
}

function CombatAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env,
    playerAdapter = ctx.playerAdapter,
    characterAdapter = ctx.characterAdapter,
    health = nil,
  }, CombatAdapter)
end

-- ---- internal -----------------------------------------------------------------

--- โครงสร้าง remote ที่รู้จัก (เกมอัปเดตเปลี่ยนชื่อ = แก้จุดเดียวที่นี่ §3.3)
local KNOWN_REMOTE_PATHS = {
  { storage = "ReplicatedStorage", parent = "Remotes", name = "Skill" },
  { storage = "ReplicatedStorage", parent = "Remotes", name = "RemoteEvent" },
}

local function findRemotes(self)
  local ok, rs = Common.service(self.env, "ReplicatedStorage")
  if not ok then return nil, rs end
  local found = {}
  for _, spec in ipairs(KNOWN_REMOTE_PATHS) do
    local parent = rs
    if spec.parent and type(rs.FindFirstChild) == "function" then
      parent = rs:FindFirstChild(spec.parent)
    end
    if parent and type(parent.FindFirstChild) == "function" then
      local remote = parent:FindFirstChild(spec.name)
      if remote then
        found[#found + 1] = ("%s/%s/%s"):format(spec.storage, spec.parent or "-", spec.name)
      end
    end
  end
  return found
end

-- ---- API ------------------------------------------------------------------------

--- อาวุธที่ถืออยู่ — { name } หรือ nil ถ้ามือเปล่า (มือเปล่าไม่ใช่ error)
--- พังจริง (character/tool หายเพราะเกมอัปเดต) = (nil, err)
function CombatAdapter:GetEquippedWeapon(player)
  local char, charErr = self.characterAdapter:GetCharacter(player)
  if not char then
    return nil, charErr
  end
  -- Tool แรกที่เจอใน Character = อาวุธที่ถือ (ตามพฤติกรรม Roblox)
  if type(char.GetChildren) == "function" then
    local ok, children = Common.safe(char.GetChildren, char)
    if not ok then return nil, children end
    for _, child in ipairs(children or {}) do
      if child.ClassName == "Tool" then
        return { name = child.Name }
      end
    end
  end
  return nil -- มือเปล่า (ค่าปกติ ไม่ใช่ error)
end

--- หา RemoteEvent "Skill" — คืน (remote) หรือ (nil, err)
function CombatAdapter:_findSkillRemote()
  local ok, rs = Common.service(self.env, "ReplicatedStorage")
  if not ok then return nil, rs end
  local remotes = nil
  if type(rs.FindFirstChild) == "function" then
    remotes = rs:FindFirstChild("Remotes")
  end
  if not remotes then
    return nil, Common.err("GONE", "ReplicatedStorage.Remotes หาย (เกมอัปเดต?)")
  end
  local remote = nil
  if type(remotes.FindFirstChild) == "function" then
    remote = remotes:FindFirstChild("Skill")
  end
  if not remote or type(remote.FireServer) ~= "function" then
    return nil, Common.err("GONE", "Remote Skill หาย (เกมอัปเดต?)")
  end
  return remote
end

--- ส่งสกิลผ่าน remote ของเกม — abstraction ของการส่ง remote เท่านั้น
--- (ไม่มี logic เลือกเป้า/ช่วงเวลา (timing) — นั่นเป็นของโมดูลชั้นบนหลังผ่าน Matrix §4.5)
function CombatAdapter:FireSkill(skill)
  if type(skill) ~= "string" or #skill == 0 then
    return false, Common.err("ERROR", "FireSkill(skill): skill ต้องเป็น string ไม่ว่าง")
  end
  local remote, rErr = self:_findSkillRemote()
  if not remote then
    return false, rErr
  end
  local okFire, fired = Common.safe(remote.FireServer, remote, skill)
  if not okFire then
    return false, fired
  end
  return true
end

--- cooldown รายสกิล — ยังไม่มีแหล่งค่าจริงในเกมให้อ่าน (โครงแรก)
--- คืน (nil, { code = "PENDING", ... }) อย่างชัดเจน — ไม่แอบอ้างว่าใช้ได้ (§3.9 ข้อ 5)
function CombatAdapter:GetSkillCooldown(skill)
  return nil, Common.err("PENDING",
    ("cooldown ของสกิล %q ยังไม่มีแหล่งอ่านจริง — ทำพร้อม Behavioral Matrix เฟส 2-3")
      :format(tostring(skill)))
end

--- รายชื่อ remote ที่มองเห็น (Self-Probe + Diagnostics)
function CombatAdapter:GetRemotes()
  local found = findRemotes(self)
  if not found then
    return nil, Common.err("GONE", "ReplicatedStorage ใช้ไม่ได้")
  end
  return found
end

-- ---- self-probe -------------------------------------------------------------------

function CombatAdapter:Probe()
  local results = {}
  -- มือเปล่า = nil ไม่ใช่ error → probe ใช้ "เรียกแล้วไม่พัง + err ไม่ใช่ nil"
  local w, wErr = self:GetEquippedWeapon()
  results.GetEquippedWeapon = (w ~= nil or wErr == nil) and true or wErr
  -- ตรวจโครงสร้างของ remote โดยไม่ยิงจริง (ไม่สร้าง traffic ขยะในเกมจริง)
  local remote, rErr = self:_findSkillRemote()
  results.FireSkill = (remote ~= nil) and true or rErr
  local remotes, rrErr = self:GetRemotes()
  results.GetRemotes = (remotes ~= nil) and true or rrErr
  self.health = Common.healthFromResults(results, CombatAdapter.METHODS)
  return self.health
end

return CombatAdapter
