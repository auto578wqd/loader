-- ============================================================================
-- The Voider — core/adapter/camera.lua
-- Camera Adapter (แผน freeze v2.1 §3.3) — ตำแหน่ง/ทิศ/FOV กล้อง, ล็อกกล้อง
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local CameraAdapter = {}
CameraAdapter.__index = CameraAdapter

CameraAdapter.NODE = "CameraAdapter"
CameraAdapter.VERSION = "0.2.0"

CameraAdapter.METHODS = {
  "GetPosition", "GetLookVector", "GetFOV",
}

function CameraAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env,
    health = nil,
  }, CameraAdapter)
end

-- ---- internal -----------------------------------------------------------------

function CameraAdapter:_camera()
  local ok, ws = Common.service(self.env, "Workspace")
  if not ok then return nil, ws end
  local cam = ws.CurrentCamera
  if not cam then
    return nil, Common.err("GONE", "CurrentCamera หาย")
  end
  return cam
end

-- ---- API ------------------------------------------------------------------------

function CameraAdapter:GetPosition()
  local cam, err = self:_camera()
  if not cam then return nil, err end
  local cframe = cam.CFrame
  if not cframe or cframe.Position == nil then
    return nil, Common.err("GONE", "Camera.CFrame หาย")
  end
  return cframe.Position
end

function CameraAdapter:GetLookVector()
  local cam, err = self:_camera()
  if not cam then return nil, err end
  local cframe = cam.CFrame
  if not cframe or cframe.LookVector == nil then
    return nil, Common.err("GONE", "Camera.CFrame.LookVector หาย")
  end
  return cframe.LookVector
end

function CameraAdapter:GetFOV()
  local cam, err = self:_camera()
  if not cam then return nil, err end
  if cam.FieldOfView == nil then
    return nil, Common.err("GONE", "Camera.FieldOfView หาย")
  end
  return cam.FieldOfView
end

--- ล็อกกล้องไปที่เป้า — กลไกจริงมาเฟส 2 (VoidAim) ตามกติกา §4.5
--- รอบนี้คืน PENDING ชัดเจน ไม่แอบอ้างว่าทำงาน (§3.9 ข้อ 5)
function CameraAdapter:SetLock(target)
  return false, Common.err("PENDING", "SetLock จะมาพร้อม VoidAim เฟส 2 (Behavioral Matrix ผ่านรีวิวก่อน)")
end

--- แปลงพิกัดโลก → หน้าจอ — ใช้โดย ESP เฟส 2 (รอบนี้ PENDING เหมือนกัน)
function CameraAdapter:WorldToScreen(point)
  return nil, Common.err("PENDING", "WorldToScreen จะมาพร้อม Void ESP เฟส 2")
end

-- ---- self-probe -------------------------------------------------------------------

function CameraAdapter:Probe()
  local results = {}
  local p, e1 = self:GetPosition()
  results.GetPosition = (p ~= nil) and true or e1
  local l, e2 = self:GetLookVector()
  results.GetLookVector = (l ~= nil) and true or e2
  local f, e3 = self:GetFOV()
  results.GetFOV = (f ~= nil) and true or e3
  self.health = Common.healthFromResults(results, CameraAdapter.METHODS)
  return self.health
end

return CameraAdapter
