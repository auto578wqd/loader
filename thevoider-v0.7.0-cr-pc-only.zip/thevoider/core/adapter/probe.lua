-- ============================================================================
-- The Voider — core/adapter/probe.lua
-- Adapter Self-Probe (แผน freeze v2.1 §3.3 กฎ 2 + §3.10)
--
-- หน้าที่:
--   1) probe adapter ทั้ง 6 → Adapter Health report:
--      ครบ (ok) / เสื่อมบางส่วน (degraded — ระบุ method ที่ตาย) / ตาย (dead)
--   2) "สายตาย" — node ไหนตาย → กระทบ consumer ตัวไหนบ้าง (อ่านจาก
--      dependency graph SSOT — ไม่มี logic คู่ซ้ำ §3.10)
--   3) ประกาศผลผ่าน Event Bus ("adapter:health") + แจ้งผู้ใช้เมื่อเสื่อม
--      (No Silent Degradation §3.9 ข้อ 5 — ฟีเจอร์ที่พึ่ง API ตายต้องบอกผู้ใช้)
--   4) ส่งรายงานให้ DiagnosticsService (§8.4)
--
-- เรียกซ้ำได้ (idempotent): hot update ขั้น ADAPTER PROBE (§3.6 ขั้น 11)
-- เรียกตัวเดิมอีกครั้งเพื่อพิสูจน์ว่ารุ่นใหม่เห็นเกมครบก่อนเป็น active
-- ============================================================================

local Probe = {}
Probe.__index = Probe

Probe.NODE = "AdapterSelfProbe"
Probe.VERSION = "0.2.0"

function Probe.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    adapters = ctx.adapters or {}, -- { PlayerAdapter = adapter, ... } (6 ตัว)
    graph = ctx.graph,             -- graph.lua (deps ใช้คำนวณสายตาย)
    bus = ctx.bus,
    i18n = ctx.i18n,
    diagnostics = ctx.diagnostics,
    time = ctx.time or os.time,
    lastReport = nil,
  }, Probe)
end

-- ---- internal -----------------------------------------------------------------

--- consumer ทางตรงของ node (ใครประกาศ dep บน node นี้ใน graph)
local function directConsumers(graph, nodeName)
  local out = {}
  if not graph or not graph.deps then return out end
  for consumer, deps in pairs(graph.deps) do
    for _, d in ipairs(deps) do
      if d == nodeName then
        out[#out + 1] = consumer
        break
      end
    end
  end
  table.sort(out)
  return out
end

local function compactHealth(health)
  return {
    status = health.status,
    ok = health.ok,
    dead = health.dead,
    deadMethods = health.deadMethods,
  }
end

-- ---- probe หลัก -------------------------------------------------------------------

--- รัน probe ทั้ง 6 + สรุป + แจ้ง — เรียกซ้ำกี่ครั้งก็ได้ (รายงานล่าสุดทับเก่า)
function Probe:Probe()
  local report = {
    probedAt = self.time(),
    adapters = {},
    impacted = {},     -- [node ที่ตาย/เสื่อม] = { consumers = {...}, deadMethods }
    status = "ok",
    summary = "",
  }

  local anyDegraded, anyDead = false, false
  local degradedNames, deadNames = {}, {}

  for name, adapter in pairs(self.adapters) do
    local health = adapter:Probe()
    report.adapters[name] = compactHealth(health)
    if health.status == "ok" then
      -- สบายดี
    elseif health.status == "dead" then
      anyDead = true
      deadNames[#deadNames + 1] = name
      report.impacted[name] = {
        consumers = directConsumers(self.graph, name),
        deadMethods = health.deadMethods,
      }
    else
      anyDegraded = true
      degradedNames[#degradedNames + 1] = name
      report.impacted[name] = {
        consumers = directConsumers(self.graph, name),
        deadMethods = health.deadMethods,
      }
    end
  end

  -- สรุปสถานะรวม
  if anyDead then
    report.status = "dead"
  elseif anyDegraded then
    report.status = "degraded"
  end
  table.sort(degradedNames)
  table.sort(deadNames)
  if report.status == "ok" then
    report.summary = "Adapter ครบทั้ง 6 API"
  else
    local parts = {}
    for _, n in ipairs(deadNames) do
      parts[#parts + 1] = ("%s ตาย"):format(n)
    end
    for _, n in ipairs(degradedNames) do
      local dm = report.adapters[n].deadMethods
      parts[#parts + 1] = ("%s เสื่อม (%s)"):format(n, table.concat(dm, ","))
    end
    report.summary = "Adapter มีปัญหา: " .. table.concat(parts, "; ")
  end

  self.lastReport = report

  -- ส่ง Diagnostics (§8.4 — แผง "ระบบ: Adapter Health 6 API")
  if self.diagnostics then
    self.diagnostics:SetAdapterHealth(report)
  end

  -- ประกาศผล (adapter:health = replay — เป็นสถานะที่ยังมีผล §3.6)
  if self.bus then
    self.bus:Publish("adapter:health", {
      status = report.status,
      summary = report.summary,
      adapters = report.adapters,
      impacted = report.impacted,
    })
    -- แจ้งผู้ใช้เมื่อไม่ครบ (No Silent Degradation)
    for _, n in ipairs(deadNames) do
      self.bus:Publish("notify:user", {
        level = "warn",
        key = "notify.adapter.dead",
        params = { name = n, reason = table.concat(report.adapters[n].deadMethods, ", ") },
      })
    end
    for _, n in ipairs(degradedNames) do
      self.bus:Publish("notify:user", {
        level = "warn",
        key = "notify.adapter.degraded",
        params = { name = n },
      })
    end
  end

  return report
end

--- รายงานล่าสุด (ไม่ probe ใหม่ — ใช้ตอน Diagnostics/UI ดึงข้อมูล)
function Probe:LastReport()
  return self.lastReport
end

return Probe
