-- ============================================================================
-- The Voider — core/adapter/init.lua
-- Game Adapter Layer assembler (แผน freeze v2.1 §3.3 + §3.10)
--
-- ประกอบ L3 ทั้งหมดตามลำดับ dependency graph:
--   PlayerAdapter → CharacterAdapter → CombatAdapter → CameraAdapter
--   → InputAdapter → WorldAdapter → AdapterSelfProbe
--
-- "ประตูเดียวสู่เกม" (§3.3 กฎ 1): env (game/workspace) ถูกห่อไว้ที่นี่เท่านั้น
-- โมดูลชั้นบนเข้าถึงเกมผ่าน adapter interface เท่านั้น — บังคับด้วย
-- build/tools/lint_adapter.py ทุก build
--
-- ใช้งาน:
--   local A = AdapterLib.new({ runtime = R, foundation = F })
--   A:Bootstrap()   -- Self-Probe + ต่อ Keybind เข้า InputAdapter
--   A.Player / A.Character / A.Combat / A.Camera / A.Input / A.World
--   A.SelfProbe:Probe()  -- re-probe ได้ (hot update ขั้น ADAPTER PROBE §3.6)
-- ============================================================================

local P = __TV_PACKAGES
local Common = P.adapter_common
local PlayerAdapterLib = P.adapter_player
local CharacterAdapterLib = P.adapter_character
local CombatAdapterLib = P.adapter_combat
local CameraAdapterLib = P.adapter_camera
local InputAdapterLib = P.adapter_input
local WorldAdapterLib = P.adapter_world
local SelfProbeLib = P.adapter_probe

local AdapterLib = {}
AdapterLib.version = "0.2.0"

-- ชื่อ node ตาม dependency graph (SSOT §3.10)
AdapterLib.NODES = {
  "PlayerAdapter",
  "CharacterAdapter",
  "CombatAdapter",
  "CameraAdapter",
  "InputAdapter",
  "WorldAdapter",
  "AdapterSelfProbe",
}

function AdapterLib.new(ctx)
  ctx = ctx or {}
  local R = ctx.runtime
  local F = ctx.foundation
  if not R or not R.Registry or not R.Graph then
    error("AdapterLib.new({ runtime = R }): ต้องส่ง Runtime ครบ (Registry/Graph)", 2)
  end
  if not F or not F.Keybind or not F.Diag or not F.Bus then
    error("AdapterLib.new({ foundation = F }): ต้องส่ง Foundation ครบ (Keybind/Diag/Bus)", 2)
  end

  -- ---- SSOT check: node ของ adapter ต้องอยู่ใน graph ครบ --------------------
  local inGraph = {}
  for _, n in ipairs(R.Graph.initOrder) do
    inGraph[n] = true
  end
  for _, n in ipairs(AdapterLib.NODES) do
    if not inGraph[n] then
      error(("Adapter: node %q ไม่อยู่ใน dependency graph (dependencies.md) — "
        .. "โค้ดกับ SSOT คลาดเคลื่อน แก้ที่ dependencies.md ก่อน (§3.10)"):format(n), 2)
    end
  end

  -- env ของเกม — จุดเดียวที่แตะ global game/workspace (production);
  -- L1/L2 ส่ง ctx.env เป็น stub แทน
  local env = ctx.env or { game = game, workspace = workspace }

  local A = {}
  A.version = AdapterLib.version
  A.runtime = R
  A.foundation = F
  A.env = env

  -- ---- สร้างตามลำดับ (ตามตาราง graph §3) ------------------------------------
  A.Player = PlayerAdapterLib.new({ env = env })

  A.Character = CharacterAdapterLib.new({
    env = env,
    playerAdapter = A.Player,
  })

  A.Combat = CombatAdapterLib.new({
    env = env,
    playerAdapter = A.Player,
    characterAdapter = A.Character,
  })

  A.Camera = CameraAdapterLib.new({ env = env })

  A.Input = InputAdapterLib.new({
    env = env,
    runtime = R,
  })

  A.World = WorldAdapterLib.new({
    env = env,
    playerAdapter = A.Player,
  })

  A.SelfProbe = SelfProbeLib.new({
    adapters = {
      PlayerAdapter = A.Player,
      CharacterAdapter = A.Character,
      CombatAdapter = A.Combat,
      CameraAdapter = A.Camera,
      InputAdapter = A.Input,
      WorldAdapter = A.World,
    },
    graph = R.Graph,
    bus = F.Bus,
    i18n = F.I18n,
    diagnostics = F.Diag,
  })

  -- ---- Bootstrap ----------------------------------------------------------------

  function A:Bootstrap()
    -- 1) Self-Probe ครั้งแรก (§3.3 กฎ 2): ทดสอบ instance/property/remote ที่รู้จัก
    --    → Adapter Health → Diagnostics + แจ้งผู้ใช้เมื่อไม่ครบ
    A.SelfProbe:Probe()

    -- 2) ต่อ Keybind เข้า InputAdapter (KeybindService รอ attach ตั้งแต่ L2)
    F.Keybind:AttachInput(A.Input)

    return A
  end

  --- re-probe ทั้ง 6 (hot update ขั้น ADAPTER PROBE §3.6 ขั้น 11)
  --- คืน report — ใช้ตัดสินว่า release ใหม่ active ได้หรือยัง (atomic rule R3)
  function A:Reprobe()
    return A.SelfProbe:Probe()
  end

  return A
end

return AdapterLib
