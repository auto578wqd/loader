-- ============================================================================
-- The Voider — core/adapter/_common.lua
-- helper กลางของ Game Adapter ทั้ง 6 (แผน freeze v2.1 §3.3)
--
-- หลักการ "ประตูเดียวสู่เกม": ไฟล์ใน core/adapter/* เท่านั้นที่แตะ game
-- object ได้ — โมดูลชั้นบน (L4+) เรียก interface เหล่านี้เท่านั้น
-- (บังคับด้วย build/tools/lint_adapter.py ทุก build)
--
-- error code มาตรฐานที่ adapter คืน (ตาราง err = { code, message }):
--   GONE    โครงสร้างเกมหาย (เกมอัปเดต) → กระทบ health → ฟีเจอร์ที่พึ่งปิดตัวเอง
--   ERROR   ผิดพลาดอื่น (ค่าผิด ฯลฯ)
--   PENDING ยังไม่ทำจริงรอบนี้ (ระบุเฟสที่จะมาตามแผน — โปร่งใส ไม่แอบอ้าง §3.9)
-- ============================================================================

local Common = {}

Common.VERSION = "0.2.0"

--- คืน error object มาตรฐาน
function Common.err(code, message)
  return { code = code, message = tostring(message) }
end

--- เรียก fn แบบปลอดภัย — คืน (true, ...) หรือ (false, { code, message })
--- error ของการเข้าถึงเกม (เช่น GetService ตาย / property หาย) = ERROR
--- (การ "หาไม่เจอ" แบบธรรมดา ผู้เรียกต้องคืน GONE เองตามบริบท)
function Common.safe(fn, ...)
  local results = { pcall(fn, ...) }
  local ok = table.remove(results, 1)
  if ok then
    return true, table.unpack(results)
  end
  return false, Common.err("ERROR", results[1])
end

--- เข้าถึง service ของเกมผ่าน env — ตาย/ไม่มี = GONE (เกมอัปเดต)
--- คืน (true, service) หรือ (false, err)
function Common.service(env, name)
  if not env or not env.game then
    return false, Common.err("GONE", "ไม่มี game environment")
  end
  local ok, svc = Common.safe(function()
    return env.game:GetService(name)
  end)
  if not ok then
    return false, Common.err("GONE", ("service %s ใช้ไม่ได้: %s"):format(name, svc.message))
  end
  if svc == nil then
    return false, Common.err("GONE", ("service %s คืน nil"):format(name))
  end
  return true, svc
end

--- normalize ชื่อคีย์/enum → string ธรรมดา
--- รับ: "E" (stub/สตริงตรง) หรือ Enum.KeyCode.E (production — tostring = "Enum.KeyCode.E")
function Common.keyName(v)
  if v == nil then return nil end
  if type(v) == "string" then return v end
  local s = tostring(v)
  local last = s:match("([^%.]+)$")
  return last or s
end

--- สร้างรายงาน probe ของ adapter จากผลทดสอบรายเมธอด
--- results = { [methodName] = true | { code = ..., message = ... } }
--- คืน { status, ok, dead, deadMethods, detail }
function Common.healthFromResults(results, methodNames)
  local deadMethods = {}
  local okCount, deadCount = 0, 0
  for _, name in ipairs(methodNames) do
    local r = results[name]
    if r == true then
      okCount = okCount + 1
    else
      deadCount = deadCount + 1
      deadMethods[#deadMethods + 1] = name
    end
  end
  local status
  if deadCount == 0 then
    status = "ok"
  elseif okCount == 0 then
    status = "dead"
  else
    status = "degraded"
  end
  return {
    status = status,
    ok = okCount,
    dead = deadCount,
    deadMethods = deadMethods,
    detail = results,
  }
end

return Common
