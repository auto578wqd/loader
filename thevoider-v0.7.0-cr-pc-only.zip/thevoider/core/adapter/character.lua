-- ============================================================================
-- The Voider — core/adapter/character.lua
-- Character Adapter (แผน freeze v2.1 §3.3) — humanoid, อวัยวะ, state, VFX
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local CharacterAdapter = {}
CharacterAdapter.__index = CharacterAdapter

CharacterAdapter.NODE = "CharacterAdapter"
CharacterAdapter.VERSION = "0.2.0"

CharacterAdapter.METHODS = {
  "GetCharacter", "GetRoot", "IsAlive", "GetState", "GetMoveDirection",
}

function CharacterAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env,
    playerAdapter = ctx.playerAdapter, -- ใช้ GetLocalPlayer (ไม่แตะ Players เองซ้ำ)
    health = nil,
  }, CharacterAdapter)
end

-- ---- internal -----------------------------------------------------------------

local function findChild(model, name)
  if type(model) ~= "table" then return nil end
  if type(model.FindFirstChild) == "function" then
    return model:FindFirstChild(name)
  end
  return model[name]
end

local function humanoidOf(self, player)
  player = player or self.playerAdapter:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  local char = player.Character
  if not char then
    return nil, Common.err("GONE", "Character ยังไม่โหลด/หาย")
  end
  local hum = findChild(char, "Humanoid")
  if not hum then
    return nil, Common.err("GONE", "Humanoid หาย (เกมอัปเดต?)")
  end
  return hum, char, player
end

-- ---- API ------------------------------------------------------------------------

function CharacterAdapter:GetCharacter(player)
  player = player or self.playerAdapter:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  local char = player.Character
  if not char then
    return nil, Common.err("GONE", "Character ยังไม่โหลด/หาย")
  end
  return char
end

function CharacterAdapter:GetRoot(player)
  local char = self:GetCharacter(player)
  if not char then return nil, Common.err("GONE", "Character ยังไม่โหลด/หาย") end
  local root = findChild(char, "HumanoidRootPart")
  if not root then
    return nil, Common.err("GONE", "HumanoidRootPart หาย")
  end
  return root
end

function CharacterAdapter:IsAlive(player)
  local hum, humErr = humanoidOf(self, player)
  if not hum then return nil, humErr end
  return (hum.Health or 0) > 0
end

--- สถานะรวม: { alive, health, maxHealth, state }
--- state = ชื่อสถานะ humanoid normalize เป็น string ("Running"/"Freefall"/...)
function CharacterAdapter:GetState(player)
  local hum, humErr = humanoidOf(self, player)
  if not hum then return nil, humErr end
  local state = "Unknown"
  if type(hum.GetState) == "function" then
    local ok, s = Common.safe(hum.GetState, hum)
    if ok and s ~= nil then
      state = Common.keyName(s)
    end
  end
  return {
    alive = (hum.Health or 0) > 0,
    health = hum.Health or 0,
    maxHealth = hum.MaxHealth or 100,
    state = state,
  }
end

--- ทิศทางการเคลื่อนที่ (Vector3) — ใช้โดย PredictionService ภายหลัง (เฟส 2)
function CharacterAdapter:GetMoveDirection(player)
  local hum, humErr = humanoidOf(self, player)
  if not hum then return nil, humErr end
  local md = hum.MoveDirection
  if md == nil then
    return nil, Common.err("GONE", "Humanoid.MoveDirection หาย")
  end
  return md
end

-- ---- self-probe -------------------------------------------------------------------

function CharacterAdapter:Probe()
  local results = {}
  local c, e1 = self:GetCharacter()
  results.GetCharacter = (c ~= nil) and true or e1
  local r, e2 = self:GetRoot()
  results.GetRoot = (r ~= nil) and true or e2
  local a, e3 = self:IsAlive()
  results.IsAlive = (a ~= nil) and true or e3
  local s, e4 = self:GetState()
  results.GetState = (s ~= nil) and true or e4
  local m, e5 = self:GetMoveDirection()
  results.GetMoveDirection = (m ~= nil) and true or e5
  self.health = Common.healthFromResults(results, CharacterAdapter.METHODS)
  return self.health
end

return CharacterAdapter
