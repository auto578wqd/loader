-- ============================================================================
-- The Voider — core/adapter/world.lua
-- World Adapter (แผน freeze v2.1 §3.3) — entities ในฉาก, ระยะทาง,
-- raycast/line-of-sight, server info
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local WorldAdapter = {}
WorldAdapter.__index = WorldAdapter

WorldAdapter.NODE = "WorldAdapter"
WorldAdapter.VERSION = "0.2.0"

WorldAdapter.METHODS = {
  "GetPlayers", "GetOthers", "GetServerInfo", "RaycastClear", "GetDistance",
}

function WorldAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env,
    playerAdapter = ctx.playerAdapter,
    health = nil,
  }, WorldAdapter)
end

-- ---- API ------------------------------------------------------------------------

--- ผู้เล่นทั้งหมดในเซิร์ฟเวอร์ (รวม local)
function WorldAdapter:GetPlayers()
  local ok, players = Common.service(self.env, "Players")
  if not ok then return nil, players end
  if type(players.GetPlayers) ~= "function" then
    return nil, Common.err("GONE", "Players.GetPlayers หาย")
  end
  local okList, list = Common.safe(players.GetPlayers, players)
  if not okList then return nil, list end
  return list or {}
end

--- ผู้เล่นอื่น (ไม่รวม local) — ใช้บ่อยโดย TargetService (เฟส 2)
function WorldAdapter:GetOthers()
  local list, err = self:GetPlayers()
  if list == nil then return nil, err end
  local lp = self.playerAdapter:GetLocalPlayer()
  local out = {}
  for _, p in ipairs(list) do
    if p ~= lp then
      out[#out + 1] = p
    end
  end
  return out
end

--- ข้อมูลเซิร์ฟเวอร์ — { jobId, playerCount }
function WorldAdapter:GetServerInfo()
  local list, err = self:GetPlayers()
  if list == nil then return nil, err end
  local jobId = ""
  if self.env and self.env.game and self.env.game.JobId then
    jobId = tostring(self.env.game.JobId)
  end
  return {
    jobId = jobId,
    playerCount = #list,
  }
end

--- raycast จาก from → to — คืน true = ทางโล่ง (ไม่มีอะไรบัง)
function WorldAdapter:RaycastClear(from, to)
  if type(from) ~= "table" or type(to) ~= "table" then
    return nil, Common.err("ERROR", "RaycastClear(from, to): ต้องเป็น Vector3 ทั้งคู่")
  end
  local ok, ws = Common.service(self.env, "Workspace")
  if not ok then return nil, ws end
  if type(ws.Raycast) ~= "function" then
    return nil, Common.err("GONE", "Workspace.Raycast หาย")
  end
  local direction = to - from
  local okCast, hit = Common.safe(ws.Raycast, ws, from, direction)
  if not okCast then return nil, hit end
  return hit == nil
end

--- ระยะทางระหว่างจุดสองจุด (helper คำนวณ — ไม่แตะเกม)
function WorldAdapter:GetDistance(a, b)
  if type(a) ~= "table" or type(b) ~= "table" then
    return nil, Common.err("ERROR", "GetDistance(a, b): ต้องเป็น Vector3 ทั้งคู่")
  end
  if a.Position ~= nil then a = a.Position end
  if b.Position ~= nil then b = b.Position end
  local d = a - b
  if d.Magnitude == nil then
    return nil, Common.err("ERROR", "คำนวณระยะไม่ได้ (Vector3 ผิดรูป)")
  end
  return d.Magnitude
end

-- ---- self-probe -------------------------------------------------------------------

function WorldAdapter:Probe()
  local results = {}
  local list, e1 = self:GetPlayers()
  results.GetPlayers = (list ~= nil) and true or e1
  local others, e2 = self:GetOthers()
  results.GetOthers = (others ~= nil) and true or e2
  local info, e3 = self:GetServerInfo()
  results.GetServerInfo = (info ~= nil) and true or e3
  -- raycast ตรวจด้วยจุดจำลองใกล้ตัว (ไม่ยิงไกล — ไม่กระทบเกมจริง)
  local v = Vector3 and Vector3.new(0, 0, 0)
  if v then
    local clear, e4 = self:RaycastClear(v, v)
    results.RaycastClear = (clear ~= nil) and true or e4
  else
    results.RaycastClear = Common.err("ERROR", "ไม่มี Vector3 (stub เท่านั้น)")
  end
  local dOk, dErr
  if v then
    local dd, de = self:GetDistance(v, v)
    dOk, dErr = dd, de
  end
  results.GetDistance = (dOk ~= nil) and true or dErr
  self.health = Common.healthFromResults(results, WorldAdapter.METHODS)
  return self.health
end

return WorldAdapter
