-- ============================================================================
-- The Voider — core/adapter/player.lua
-- Player Adapter (แผน freeze v2.1 §3.3) — local player, สถิติ, team, bounty, crew
--
-- หนึ่งใน 6 ประตูเดียวสู่เกม — โมดูลชั้นบนห้ามแตะ Players service โดยตรง
-- ทุกเมธอดคืน (ผลลัพธ์) เมื่อสำเร็จ หรือ (nil, err = { code, message }) เมื่อพัง
-- เกมอัปเดตทำให้โครงสร้างหาย = code "GONE" → Self-Probe เห็น → ฟีเจอร์ที่
-- พึ่ง API นั้นปิดตัวเอง + แจ้งผู้ใช้ (§3.3 กฎ 3)
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local PlayerAdapter = {}
PlayerAdapter.__index = PlayerAdapter

PlayerAdapter.NODE = "PlayerAdapter"
PlayerAdapter.VERSION = "0.2.0"

-- รายชื่อเมธอดสาธารณะ (probe ใช้ตรวจครบ)
PlayerAdapter.METHODS = {
  "GetLocalPlayer", "GetBounty", "GetLevel", "GetTeam", "GetStats",
}

function PlayerAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env, -- { game = game } — ประตูเดียว (production: real, L1/L2: stub)
    health = nil,
  }, PlayerAdapter)
end

-- ---- internal -----------------------------------------------------------------

--- หา leaderstats ของ player (เกมจริงเป็น child, stub รองรับทั้ง field)
local function findStats(player)
  if type(player) ~= "table" then return nil end
  if player.leaderstats ~= nil then return player.leaderstats end
  if type(player.FindFirstChild) == "function" then
    return player:FindFirstChild("leaderstats")
  end
  return nil
end

--- อ่าน IntValue ใน leaderstats
local function readStat(player, statName)
  local stats = findStats(player)
  if not stats then
    return nil, Common.err("GONE", "leaderstats หาย (เกมอัปเดต?)")
  end
  local node = stats
  if type(stats.FindFirstChild) == "function" then
    node = stats:FindFirstChild(statName)
  end
  if not node or node.Value == nil then
    return nil, Common.err("GONE", ("leaderstats.%s หาย"):format(statName))
  end
  return node.Value
end

-- ---- API ------------------------------------------------------------------------

function PlayerAdapter:GetLocalPlayer()
  local ok, players = Common.service(self.env, "Players")
  if not ok then return nil, players end
  local lp = players.LocalPlayer
  if lp == nil then
    return nil, Common.err("GONE", "LocalPlayer ยังไม่โหลด/หาย")
  end
  return lp
end

function PlayerAdapter:GetBounty(player)
  player = player or self:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  return readStat(player, "Bounty")
end

function PlayerAdapter:GetLevel(player)
  player = player or self:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  return readStat(player, "Level")
end

function PlayerAdapter:GetTeam(player)
  player = player or self:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  if player.Team == nil then
    return nil, Common.err("GONE", "Team หาย")
  end
  return player.Team
end

--- ข้อมูลรวมของ player — { name, userId, team, bounty, level }
function PlayerAdapter:GetStats(player)
  player = player or self:GetLocalPlayer()
  if player == nil then return nil, Common.err("GONE", "ไม่มี player") end
  local bounty, bErr = readStat(player, "Bounty")
  local level, lErr = readStat(player, "Level")
  if bounty == nil then return nil, bErr end
  if level == nil then return nil, lErr end
  return {
    name = player.Name,
    userId = player.UserId,
    team = player.Team,
    bounty = bounty,
    level = level,
  }
end

-- ---- self-probe (§3.3 กฎ 2) ------------------------------------------------------

function PlayerAdapter:Probe()
  local results = {}
  -- แต่ละเมธอด: เรียกจริงครั้งเดียว — ok = ได้ค่ากลับ (ไม่ error และไม่ GONE)
  local lp, lpErr = self:GetLocalPlayer()
  results.GetLocalPlayer = (lp ~= nil) and true or lpErr
  if lp then
    local v1, e1 = self:GetBounty(lp)
    results.GetBounty = (v1 ~= nil) and true or e1
    local v2, e2 = self:GetLevel(lp)
    results.GetLevel = (v2 ~= nil) and true or e2
    local v3, e3 = self:GetTeam(lp)
    results.GetTeam = (v3 ~= nil) and true or e3
    local v4, e4 = self:GetStats(lp)
    results.GetStats = (v4 ~= nil) and true or e4
  else
    local skip = Common.err("GONE", "ข้าม — ไม่มี LocalPlayer")
    results.GetBounty = skip
    results.GetLevel = skip
    results.GetTeam = skip
    results.GetStats = skip
  end
  self.health = Common.healthFromResults(results, PlayerAdapter.METHODS)
  return self.health
end

return PlayerAdapter
