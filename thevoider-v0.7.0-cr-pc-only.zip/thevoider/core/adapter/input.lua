-- ============================================================================
-- The Voider — core/adapter/input.lua
-- Input Adapter (แผน freeze v2.1 §3.3) — คีย์บอร์ด/เมาส์/ทัชมือถือ
--
-- OnInput(callback) = จุดต่อเดียวของ input ทั้งระบบ:
--   callback({ key = "LeftControl", state = "down"|"up", inputType = "Keyboard"|"Mouse"|"Touch" })
--   subscription เป็น connection ใน Resource Registry ของผู้สมัคร
--   (เรียกใน Scope ของโมดูล — Destroy แล้วคืนอัตโนมัติ orphan=0 §3.4)
-- ============================================================================

local Common = __TV_PACKAGES.adapter_common

local InputAdapter = {}
InputAdapter.__index = InputAdapter

InputAdapter.NODE = "InputAdapter"
InputAdapter.VERSION = "0.2.0"

InputAdapter.METHODS = {
  "IsKeyDown", "OnInput", "KeyboardEnabled", "TouchEnabled",
}

function InputAdapter.new(ctx)
  ctx = ctx or {}
  return setmetatable({
    env = ctx.env,
    runtime = ctx.runtime, -- R (OnInput ใช้ R.Connect — registry นับ connection)
    health = nil,
  }, InputAdapter)
end

-- ---- internal -----------------------------------------------------------------

local INPUT_TYPE_NAMES = {
  Keyboard = "Keyboard",
  MouseButton1 = "Mouse", MouseButton2 = "Mouse", MouseButton3 = "Mouse",
  Touch = "Touch",
}

local function normalizeInput(inputObj, state)
  if type(inputObj) ~= "table" then return nil end
  local rawType = inputObj.UserInputType
  local inputType = "Unknown"
  if type(rawType) == "string" then
    inputType = INPUT_TYPE_NAMES[rawType] or rawType
  elseif rawType ~= nil then
    inputType = INPUT_TYPE_NAMES[tostring(rawType)] or Common.keyName(rawType)
  end
  return {
    key = Common.keyName(inputObj.KeyCode),
    state = state,
    inputType = inputType,
    processed = inputObj.UserInputState == "Processed" or false,
  }
end

-- ---- API ------------------------------------------------------------------------

function InputAdapter:IsKeyDown(key)
  if type(key) ~= "string" then
    return false, Common.err("ERROR", "IsKeyDown(key): key ต้องเป็น string")
  end
  local ok, uis = Common.service(self.env, "UserInputService")
  if not ok then return false, uis end
  if type(uis.IsKeyDown) ~= "function" then
    return false, Common.err("GONE", "UserInputService.IsKeyDown หาย")
  end
  local okDown, down = Common.safe(uis.IsKeyDown, uis, key)
  if not okDown then return false, down end
  return down == true
end

function InputAdapter:KeyboardEnabled()
  local ok, uis = Common.service(self.env, "UserInputService")
  if not ok then return nil, uis end
  return uis.KeyboardEnabled == true
end

function InputAdapter:TouchEnabled()
  local ok, uis = Common.service(self.env, "UserInputService")
  if not ok then return nil, uis end
  return uis.TouchEnabled == true
end

--- สมัครรับ input ทั้งหมด (down + up) — คืน connection handle (Registry)
function InputAdapter:OnInput(callback)
  if type(callback) ~= "function" then
    error("InputAdapter:OnInput(callback): callback ต้องเป็น function", 2)
  end
  local ok, uis = Common.service(self.env, "UserInputService")
  if not ok then
    return nil, ok and nil or uis
  end
  local began, ended = uis.InputBegan, uis.InputEnded
  if not began or not ended then
    return nil, Common.err("GONE", "UserInputService.InputBegan/InputEnded หาย")
  end
  local R = self.runtime
  if not R or not R.Connect then
    error("InputAdapter:OnInput: ต้องมี runtime (R.Connect) — สร้าง adapter ผ่าน adapter init", 2)
  end
  -- connection เป็นของผู้สมัคร (Scope ปัจจุบัน) — Module:Destroy → คืนอัตโนมัติ
  local h1 = R.Connect(began, function(inputObj)
    callback(normalizeInput(inputObj, "down"))
  end)
  local h2 = R.Connect(ended, function(inputObj)
    callback(normalizeInput(inputObj, "up"))
  end)
  -- รวมเป็น handle เดียว: Release = ปลดทั้งคู่
  return {
    Release = function()
      h1.Release()
      h2.Release()
    end,
    Disconnect = function()
      h1.Release()
      h2.Release()
    end,
  }
end

-- ---- self-probe -------------------------------------------------------------------

function InputAdapter:Probe()
  local results = {}
  local d, e1 = self:IsKeyDown("UnknownKey")
  results.IsKeyDown = (d == false and e1 == nil) and true or e1
  -- OnInput ตรวจโครงสร้างโดยไม่สมัครจริง (กัน connection ขยะจาก probe)
  local ok, uis = Common.service(self.env, "UserInputService")
  if ok and uis.InputBegan and uis.InputEnded then
    results.OnInput = true
  else
    results.OnInput = ok or uis
  end
  local kb, e2 = self:KeyboardEnabled()
  results.KeyboardEnabled = (kb ~= nil) and true or e2
  local tc, e3 = self:TouchEnabled()
  results.TouchEnabled = (tc ~= nil) and true or e3
  self.health = Common.healthFromResults(results, InputAdapter.METHODS)
  return self.health
end

return InputAdapter
