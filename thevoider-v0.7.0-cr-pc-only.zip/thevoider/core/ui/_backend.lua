-- ============================================================================
-- The Voider — core/ui/_backend.lua
-- GUI Backend (เฟส 1 UI Framework — แผน freeze v2.1 §3.8 + §8.2 + §3.9 #4)
--
-- util ภายในของชั้น UI (ไม่แยก node ตามกติกา dependencies.md —
-- เทียบเท่า adapter/_common.lua / foundation/services.lua)
--
-- หลักการ 3 ข้อ (บังคับโดย lint_adapter.py + Resource Registry):
--   1) ทุก Instance สร้างผ่าน Runtime.NewRender("Instance", ...) เท่านั้น
--      (§3.9 #4 Everything Registered) — ตกเป็น resource ของ "owner"
--      ตาม Registry:Scope ของโหนดผู้เรียกขณะสร้าง
--   2) ทุก callback (คลิก/แตะ/ลาก) ต่อผ่าน Runtime.Connect — connection
--      นับเป็น resource ของโหนดผู้เรียกเช่นกัน
--   3) root ของ UI ทั้งหมด = ctx.guiRoot ที่ผู้สร้างส่งมา หรือ gethui()
--      ของ executor (global ของ executor ไม่ใช่ game service — นอกประตู
--      §3.3 ซึ่งว่าด้วย game object) ถ้าไม่มี = UI ปิดตัวเองแบบ graceful
--      + แจ้ง plain text ครั้งเดียว (No Silent Degradation §3.9 #5)
--      — ระบบที่เหลือเดินต่อ ไม่สัญญา UI ในสถานการณ์ที่เปิดไม่ได้ (ตามแบบ
--      Bootstrap Preflight §3.2 ข้อ 0)
--
-- ไม่ใช้ TweenService/GuiService/CoreGui โดยตรง (ชื่อเหล่านี้ผ่าน lint ไม่ได้)
-- — animation ทำด้วย task สั้น ๆ ของ registry เอง (§8.2 "0.15 วินาที")
-- ============================================================================

local Backend = {}
Backend.__index = Backend

Backend.VERSION = "0.1.0"

-- input ของ GUI signal: รับทั้ง stub (string) และ production (Enum.*.Name)
local DRAG_INPUTS = { MouseButton1 = true, Touch = true }

local function inputTypeName(u)
  if u == nil then return nil end
  if type(u) == "table" then return u.Name end
  if type(u) == "string" then return u end
  return tostring(u)
end

local function isDragInput(u)
  return DRAG_INPUTS[inputTypeName(u)] == true
end

function Backend.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    runtime = ctx.runtime,
    logger = ctx.logger,
    clock = ctx.clock or os.clock,
    root = nil,
    available = false,
    reason = nil,
    _fadeTokens = setmetatable({}, { __mode = "k" }),
  }, Backend)

  -- root resolution: ผู้เรียกส่งมา → gethui() ของ executor → ไม่มี = degraded
  local root = ctx.guiRoot
  if root == nil then
    local g = rawget(_G, "gethui")
    if type(g) == "function" then
      local ok, r = pcall(g)
      if ok and r ~= nil then
        root = r
      end
    end
  end

  if root ~= nil and self.runtime and self.runtime.NewRender then
    self.root = root
    self.available = true
  else
    self.reason = root == nil
      and "ไม่พบขอบเขต GUI (gethui) ของ executor"
      or "ไม่มี Runtime.NewRender"
    if self.logger then
      self.logger("warn", ("UI ปิดตัวเองชั่วคราว: %s — ระบบอื่นเดินต่อตามปกติ")
        :format(self.reason))
    end
  end
  return self
end

--- สร้าง instance ใต้ parent (default = root) — ต้องเรียกภายใน
--- Registry:Scope("<NodeName>", ...) ของโหนดผู้เป็นเจ้าเสมอ
--- คืน handle ของ registry (มี .obj / .Release) หรือ nil + reason (degraded)
function Backend:Create(class, props, parent)
  if not self.available then
    return nil, self.reason or "UI unavailable"
  end
  props = props or {}
  parent = parent or self.root
  local handle = self.runtime.NewRender("Instance", {
    Class = class,
    Props = props,
    Parent = parent,
  })
  if not handle then
    return nil, "NewRender ล้มเหลว (Instance/props ผิดรูปแบบ?)"
  end
  return handle
end

--- ตั้งค่า property ภายหลัง (ไม่ใช่การจอง resource — เช่นอัปเดต Text/สี)
function Backend:Apply(handle, props)
  local obj = handle and handle.obj or handle
  if not obj or type(props) ~= "table" then return false end
  for k, v in pairs(props) do
    obj[k] = v
  end
  return true
end

--- ต่อ callback เข้า signal ของ instance (MouseButton1Click / InputBegan /
--- MouseEnter / ...) — ผ่าน Runtime.Connect ทั้งหมด
function Backend:OnSignal(handle, signalName, fn)
  local obj = handle and handle.obj or handle
  if not self.runtime or not self.runtime.Connect then
    error("Backend:OnSignal: ต้องมี runtime (R.Connect)", 2)
  end
  local sig = obj and obj[signalName]
  if not sig then
    return nil, ("signal %s ไม่มีบน instance นี้"):format(tostring(signalName))
  end
  return self.runtime.Connect(sig, fn)
end

--- ปุ่ม/แถวที่แตะได้ (คลิกเมาส์ + ทัชรวมอยู่ใน MouseButton1Click)
function Backend:OnClick(handle, fn)
  return self:OnSignal(handle, "MouseButton1Click", fn)
end

--- animation นุ่ม 0.15 วินาที (§8.2): แทรก property จาก from → to
--- ใช้ task ชั่วคราวของ registry — จบเองตามเวลา = deregister อัตโนมัติ
--- (ไม่มี orphan) — fade ใหม่บน obj เดิมยกเลิก fade เก่า
function Backend:Fade(handle, prop, from, to, dur, onDone)
  if not self.available then return nil, self.reason end
  local obj = handle and handle.obj or handle
  if not obj then return nil, "ไม่มี instance" end
  dur = dur or 0.15
  local token = {}
  self._fadeTokens[obj] = token
  local backend = self
  backend.runtime.Spawn(("fade:%s"):format(tostring(prop)), function(ctx)
    local t0 = backend.clock()
    while true do
      if not ctx.ShouldRun() then return end
      if backend._fadeTokens[obj] ~= token then return end -- โดน fade ใหม่แทน
      local elapsed = backend.clock() - t0
      local a = math.min(1, elapsed / dur)
      obj[prop] = from + (to - from) * a
      if a >= 1 then
        obj[prop] = to
        if type(onDone) == "function" then onDone(obj) end
        return
      end
      ctx.Wait(0.016)
    end
  end)
  return true
end

--- ลากย้าย: จับที่ grip (เช่นแถบหัว) แล้วเลื่อน rootFrame ตาม pointer
--- — ใช้ signal ของ instance เอง (InputBegan/InputChanged/InputEnded)
--- กรองเฉพาะ MouseButton1/Touch (§8.3 ลากย้ายได้ ทั้งเมาส์และนิ้ว)
--- opts.onDragEnd() เรียกเมื่อปล่อย (ใช้บันทึกตำแหน่งลง config)
--- คืน { conns = { handle, ... } }
function Backend:MakeDraggable(rootHandle, gripHandle, opts)
  opts = opts or {}
  local root = rootHandle and rootHandle.obj or rootHandle
  local grip = gripHandle and gripHandle.obj or gripHandle
  local conns = {}
  local dragging = false

  conns[#conns + 1] = self:OnSignal(grip, "InputBegan", function(input)
    if not isDragInput(input and input.UserInputType) then return end
    dragging = true
  end)
  conns[#conns + 1] = self:OnSignal(root, "InputChanged", function(input)
    if not dragging then return end
    if not isDragInput(input and input.UserInputType) then return end
    local d = input and input.Input and input.Input.Delta
    if not d then return end
    local pos = root.Position
    if not pos or not pos.X then return end
    root.Position = UDim2.new(
      pos.X.Scale, pos.X.Offset + (d.X or 0),
      pos.Y.Scale, pos.Y.Offset + (d.Y or 0))
  end)
  local function stop()
    if dragging and type(opts.onDragEnd) == "function" then
      opts.onDragEnd()
    end
    dragging = false
  end
  conns[#conns + 1] = self:OnSignal(grip, "InputEnded", stop)
  conns[#conns + 1] = self:OnSignal(root, "InputEnded", stop)

  return { conns = conns, dragging = function() return dragging end }
end

return Backend
