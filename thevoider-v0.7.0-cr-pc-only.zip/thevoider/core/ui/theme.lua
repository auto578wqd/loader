-- ============================================================================
-- The Voider — core/ui/theme.lua
-- ThemeEngine (เฟส 1 UI Framework — แผน freeze v2.1 §8.1 + §8.2 + §5.4)
--
-- node L6 ตาม dependency graph: ThemeEngine | palette Void Neon | deps: —
-- (ไม่มี dependency ใด ๆ ตาม SSOT — เป็น pure token source:
-- ไม่ใช้ bus/config/registry จึงไม่มี edge เพิ่ม)
--
-- สิ่งที่ให้:
--   palette ตาม §8.1 เป๊ะ (ดำหลุมดำ/ดำน้ำเงินเข้ม/ม่วงนีออน/ไล่สี/ฟ้านีออน/
--   ขาวนวล/เทาหม่น/เขียวมรกต/แดงหลังคา) + เหลืองอำพัน (ระดับ warn ของ toast)
--   accent 4 ตัวตาม §8.2 "Dark-only + ปรับ accent ได้ (ม่วง/ฟ้า/ชมพู/เขียว)"
--   layout constants: TOUCH_MIN = 44 (ความสูงปุ่มมาตรฐานของ UI ทั้งหมด —
--   [CR-PC-ONLY] เดิมเป็น gate ทัช ≥ 44px ของ DoD §5.4 ฉบับเก่า ตอนนี้คงไว้
--   เป็นมาตรฐานปุ่ม PC) + ตัวเลข typography/spacing/radius
--   animation 0.15 วินาที (§8.2) + glass โปร่งแสง 12% (§8.2)
--
-- การเปลี่ยน accent = SetAccent(name) + Subscribe(fn) แจ้งผู้สนใจ
-- (node อื่น render ใหม่เอง — ThemeEngine ไม่รู้จักใคร)
-- ความคงทนของค่า accent เป็นหน้าที่ของ Hub ผ่าน ConfigService (ตาม graph
-- Hub→ConfigService) ไม่ใช่ของ ThemeEngine
-- ============================================================================

local ThemeEngine = {}
ThemeEngine.__index = ThemeEngine

ThemeEngine.NODE = "ThemeEngine"
ThemeEngine.VERSION = "0.1.0"

-- ---- palette §8.1 (คงเดิมจาก v1.0 — ห้ามเลื่อน เปลี่ยนแปลงผ่านเจ้าของ) ------
local BASE = {
  bg        = { 0x0A, 0x0A, 0x14 }, -- ดำหลุมดำ     #0A0A14 พื้นหลัง hub/HUD
  card      = { 0x12, 0x12, 0x1F }, -- ดำน้ำเงินเข้ม #12121F การ์ด/แท็บ
  border    = { 0x7C, 0x3A, 0xED }, -- ม่วงนีออน     #7C3AED เส้นขอบ 1px
  accentA   = { 0xA8, 0x55, 0xF7 }, -- ม่วงไล่แสง    #A855F7
  accentB   = { 0x63, 0x66, 0xF1 }, -- → #6366F1     ปุ่มหลัก/toggle เปิด/หัวข้อ
  hilite    = { 0x22, 0xD3, 0xEE }, -- ฟ้านีออน      #22D3EE ไฮไลต์/ลิงก์/สถิติ
  text      = { 0xE5, 0xE7, 0xEB }, -- ขาวนวล       #E5E7EB ข้อความหลัก
  textDim   = { 0x9C, 0xA3, 0xAF }, -- เทาหม่น      #9CA3AF คำอธิบาย/ค่าปิด
  on        = { 0x34, 0xD3, 0x99 }, -- เขียวมรกต    #34D399 สถานะเปิด/สำเร็จ
  danger    = { 0xF8, 0x71, 0x71 }, -- แดงหลังคา    #F87171 ปิด/อันตราย
  warn      = { 0xFB, 0xBF, 0x24 }, -- เหลืองอำพัน  #FBBF24 ระดับ warn ของ toast
}

-- ---- accent 4 ตัว (§8.2) — เปลี่ยนเฉพาะชุด border/accentA/accentB ---------
ThemeEngine.ACCENTS = {
  purple = { border = { 0x7C, 0x3A, 0xED }, accentA = { 0xA8, 0x55, 0xF7 }, accentB = { 0x63, 0x66, 0xF1 } },
  cyan   = { border = { 0x22, 0xD3, 0xEE }, accentA = { 0x22, 0xD3, 0xEE }, accentB = { 0x08, 0x91, 0xB2 } },
  pink   = { border = { 0xF4, 0x72, 0xB6 }, accentA = { 0xF4, 0x72, 0xB6 }, accentB = { 0xEC, 0x48, 0x99 } },
  green  = { border = { 0x34, 0xD3, 0x99 }, accentA = { 0x34, 0xD3, 0x99 }, accentB = { 0x05, 0x96, 0x69 } },
}
ThemeEngine.DEFAULT_ACCENT = "purple"

-- ---- layout constants (DoD เฟส 1 + §8.2/§8.3) --------------------------------
ThemeEngine.LAYOUT = {
  TOUCH_MIN = 44,     -- ความสูงปุ่มมาตรฐานของ UI ทั้งหมด (เดิม: gate ทัช §5.4 — คงค่าไว้ตาม CR-PC-ONLY)
  TAB_W = 116,       -- แท็บซ้ายเดสก์ท็อป
  TAB_H = 44,        -- สูงแท็บ (= TOUCH_MIN — มาตรฐานปุ่ม)
  HUB_W = 560,       -- ความกว้าง hub ตอนเปิดเต็ม
  HUB_H = 420,
  HEADER_H = 44,     -- แถบหัว (ลากย้ายได้ §8.3)
  PAD = 12,
  GAP = 8,
  RADIUS = 10,
  STROKE = 1,        -- เส้นขอบเรือง 1px §8.2
  FONT_SIZE = 14,
  FONT_TITLE = 18,
  FONT_MONO = 13,    -- ตัวเลขสถิติ mono §8.2
  LINE_H = 20,
}

ThemeEngine.ANIM = {
  FAST = 0.15,       -- §8.2 "นุ่มแต่ไม่เยอะ — 0.15 วินาที"
}

ThemeEngine.GLASS = {
  CARD_ALPHA = 0.12, -- การ์ดโปร่งแสง ~12% §8.2
}

-- ---- toast levels (Notification) --------------------------------------------
ThemeEngine.TOAST_LEVELS = { info = "hilite", success = "on", warn = "warn", error = "danger" }

local function rgb(t)
  return Color3.fromRGB(t[1], t[2], t[3])
end

function ThemeEngine.new()
  local self = setmetatable({
    accent = ThemeEngine.DEFAULT_ACCENT,
    subs = {},       -- รายการผู้สนใจการเปลี่ยน accent
    tokens = nil,    -- สร้างครั้งแรกตอน Get()
  }, ThemeEngine)
  return self
end

--- ชื่อ accent ปัจจุบัน
function ThemeEngine:Accent()
  return self.accent
end

--- รายชื่อ accent ที่เลือกได้ (เรียงตามตัวอักษร — ให้ UI วาดปุ่ม)
function ThemeEngine:ListAccents()
  local out = {}
  for k in pairs(ThemeEngine.ACCENTS) do out[#out + 1] = k end
  table.sort(out)
  return out
end

--- ตาราง token รวม (palette §8.1 + accent ที่เลือก + layout/anim/glass)
--- คืนตารางเดิมตัวเดียว (ไม่ clone ทุกเรียก — เป็น hot path) —
--- ผู้ใช้อย่าเขียนตรง ๆ ให้ถือเป็น read-only
function ThemeEngine:Get()
  if not self.tokens then
    self:_build()
  end
  return self.tokens
end

function ThemeEngine:_build()
  local acc = ThemeEngine.ACCENTS[self.accent] or ThemeEngine.ACCENTS[ThemeEngine.DEFAULT_ACCENT]
  local t = {
    -- สี §8.1 (accent ชุดที่เลือกแทนที่ 3 ช่อง)
    bg = rgb(BASE.bg),
    card = rgb(BASE.card),
    border = rgb(acc.border),
    accentA = rgb(acc.accentA),
    accentB = rgb(acc.accentB),
    hilite = rgb(BASE.hilite),
    text = rgb(BASE.text),
    textDim = rgb(BASE.textDim),
    on = rgb(BASE.on),
    danger = rgb(BASE.danger),
    warn = rgb(BASE.warn),
    -- สีตามชื่อบทบาท (สะดวก)
    bgRGB = BASE.bg,
    cardRGB = BASE.card,
    -- สีที่ใช้บ่อยของ toast ตาม level
    toastColor = {},
    -- layout/anim/glass
    layout = ThemeEngine.LAYOUT,
    anim = ThemeEngine.ANIM,
    glass = ThemeEngine.GLASS,
  }
  for level, role in pairs(ThemeEngine.TOAST_LEVELS) do
    t.toastColor[level] = t[role]
  end
  self.tokens = t
  return t
end

--- เปลี่ยน accent (invalid = ปฏิเสธ ไม่เดาเงียบ ๆ) + แจ้งผู้สมัครทุกตัว
function ThemeEngine:SetAccent(name)
  if ThemeEngine.ACCENTS[name] == nil then
    return false, { code = "UNSUPPORTED", message = ("accent %q ไม่มี (มี: %s)")
      :format(tostring(name), table.concat(self:ListAccents(), ", ")) }
  end
  if self.accent == name then
    return true -- ไม่มีอะไรเปลี่ยน — ไม่ปลุกผู้ใช้
  end
  self.accent = name
  self:_build()
  for _, cb in ipairs(self.subs) do
    cb(name)
  end
  return true
end

--- สมัครรับการเปลี่ยน accent — คืน function ถอนการสมัคร
function ThemeEngine:Subscribe(fn)
  if type(fn) ~= "function" then
    error("ThemeEngine:Subscribe(fn): fn ต้องเป็น function", 2)
  end
  self.subs[#self.subs + 1] = fn
  local subs = self.subs
  return function()
    for i, f in ipairs(subs) do
      if f == fn then
        table.remove(subs, i)
        return true
      end
    end
    return false
  end
end

-- [CR-PC-ONLY 1 ต.ค. 2026] ThemeEngine:TouchSize() ถูกตัดออก — เป็น helper
-- ของ gate ทัช ≥ 44px ฉบับเดิม (DoD §5.4 เดิม) ซึ่งเปลี่ยนเป็น PC-only แล้ว
-- และไม่มีผู้เรียกเหลืออยู่ — ปุ่มทั้ง UI ใช้ค่า LAYOUT.TOUCH_MIN ตรง ๆ

return ThemeEngine
