-- ============================================================================
-- The Voider — core/ui/hud.lua
-- HUD (เฟส 1 UI Framework — แผน freeze v2.1 §5.4 + §8.3 + §9.1)
--
-- node L6 ตาม dependency graph: HUD | FPS/uptime/สถานะ + Diagnostics ย่อ
-- | deps: DiagnosticsService, EventBus
--
--   แถบลอยลากย้ายได้ (§5.4 "HUD เต็มรูปแบบ (ลากย้าย + FPS + uptime)")
--   + จุดสถานะสด (§8.3: Adapter Health + คิว Event Bus)
--   + ไดอักนอสติกย่อ: แตะแถบ → ขยายดูตัวเลข Registry/Event Bus สด
--     (ดูแบบเต็มที่แท็บ Setup → Diagnostics ของ Hub)
--
--   FPS: วัดจาก frame task ของ node นี้ (task.wait ≈ 1 เฟรมทั้งใน
--   production และ virtual-time ของเทส) → EMA → ต่อเข้า Diagnostics
--   ผ่าน SetFpsProvider (§8.4 "FPS จริง")
--   ต้นทุน UI render ต่อเฟรม วัดด้วย timer ชื่อ "ui" ของ Diagnostics
--   (DoD §5.4: ≤ 0.5 ms/frame ใน test env — ตัวเลขออกที่ Export/แผงเต็ม)
--
--   อัปเดตหนัก (Snapshot) เกิดเฉพาะเมื่อแผงย่อเปิดอยู่จริง (§9 งบ)
--   ป้าย FPS/uptime อัปเดต 4 ครั้ง/วิ — ไม่ใช่ทุกเฟรม
-- ============================================================================

local HUD = {}
HUD.__index = HUD

HUD.NODE = "HUD"
HUD.VERSION = "0.1.0"

HUD.I18N = {
  th = {
    ["ui.hud.fps"] = "FPS {v}",
    ["ui.hud.online.sec"] = "ออนไลน์ {v} วิ",
    ["ui.hud.online.min"] = "ออนไลน์ {v} นาที",
    ["ui.hud.online.hr"] = "ออนไลน์ {v} ชม.",
    ["ui.hud.dot.adapter"] = "Adapter",
    ["ui.hud.mini.registry"] = "Registry: task {t} · conn {c} · render {r} · temp {tp}",
    ["ui.hud.mini.bus"] = "Event Bus: {eps}/วิ · คิวค้าง {q}",
    ["ui.hud.mini.adapter"] = "Adapter: {status}",
    ["ui.hud.mini.fullhint"] = "ดูแบบเต็ม: แท็บ Setup → Diagnostics",
  },
  en = {
    ["ui.hud.fps"] = "FPS {v}",
    ["ui.hud.online.sec"] = "Online {v}s",
    ["ui.hud.online.min"] = "Online {v}m",
    ["ui.hud.online.hr"] = "Online {v}h",
    ["ui.hud.dot.adapter"] = "Adapter",
    ["ui.hud.mini.registry"] = "Registry: task {t} · conn {c} · render {r} · temp {tp}",
    ["ui.hud.mini.bus"] = "Event Bus: {eps}/sec · queued {q}",
    ["ui.hud.mini.adapter"] = "Adapter: {status}",
    ["ui.hud.mini.fullhint"] = "Full view: Setup tab → Diagnostics",
  },
}

function HUD.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    runtime = ctx.runtime,
    backend = ctx.backend,
    bus = ctx.bus,          -- EventBus (declared dep)
    diag = ctx.diag,        -- DiagnosticsService (declared dep)
    i18n = ctx.i18n,        -- แปลป้าย (ตามแบบ probe.lua ที่ถือ F.I18n ตรง ๆ)
    tokens = ctx.tokens,
    clock = ctx.clock or os.clock,
    built = false,
    fpsEMA = nil,
    uptime = 0,
    updateAcc = 0,
    lastAdapter = nil,      -- สรุปล่าสุดจาก adapter:health
    labels = {},            -- [name] = handle ของป้าย (รีเรนเดอร์ภาษา/theme)
    dots = {},
    miniVisible = false,
  }, HUD)
  if self.i18n then
    self.i18n:AddTable("th", HUD.I18N.th)
    self.i18n:AddTable("en", HUD.I18N.en)
  end
  return self
end

-- ---- ตัวช่วยภายใน ---------------------------------------------------------------

local STATUS_COLOR = { ok = "on", degraded = "warn", dead = "danger" }

function HUD:_statusColor(status)
  local role = STATUS_COLOR[status or "ok"] or "on"
  return self.tokens and self.tokens[role] or nil
end

--- ข้อความ uptime ตามช่วงเวลา (วิ/นาที/ชม.)
function HUD:_uptimeText()
  local s = math.floor(self.uptime + 0.5)
  if self.i18n == nil then return tostring(s) end
  if s < 60 then
    return self.i18n:T("ui.hud.online.sec", { v = s })
  elseif s < 3600 then
    return self.i18n:T("ui.hud.online.min", { v = math.floor(s / 60) })
  end
  return self.i18n:T("ui.hud.online.hr", { v = math.floor(s / 3600) })
end

-- ---- สร้าง UI + frame task ครั้งเดียว ------------------------------------------

function HUD:Render()
  if self.built then return true end
  if not self.backend.available then
    return false, self.backend.reason
  end
  local R = self.runtime
  R.Scope(HUD.NODE, function()
    local tk = self.tokens or {}
    local L = tk.layout or {}
    local glass = tk.glass and (1 - tk.glass.CARD_ALPHA) or 0.88

    self.gui = self.backend:Create("ScreenGui", {
      Name = "TVHud", DisplayOrder = 50, ResetOnSpawn = false,
    })
    self.bar = self.backend:Create("Frame", {
      Name = "Bar",
      AnchorPoint = UDim2.new(0.5, 0, 1, 0),
      Position = UDim2.new(0.5, 0, 1, -76),
      Size = UDim2.new(0, 360, 0, L.TOUCH_MIN or 44), -- แถบแตะได้ ≥ 44 (DoD §5.4)
      BackgroundColor3 = tk.card,
      BackgroundTransparency = glass,
    }, self.gui.obj)
    self.backend:Create("UICorner", { CornerRadius = UDim.new(0, L.RADIUS or 10) }, self.bar.obj)
    self.backend:Create("UIStroke", {
      Color = tk.border, Thickness = L.STROKE or 1, Transparency = 0.35,
    }, self.bar.obj)
    self.backend:Create("UIListLayout", {
      Name = "Row",
      FillDirection = Enum.FillDirection.Horizontal,
      HorizontalAlignment = Enum.HorizontalAlignment.Center,
      VerticalAlignment = Enum.VerticalAlignment.Center,
      Padding = UDim.new(0, L.GAP or 8),
      SortOrder = Enum.SortOrder.LayoutOrder,
    }, self.bar.obj)

    -- จุดสถานะ adapter (สดจาก adapter:health — replay policy §3.6)
    self.dots.adapter = self.backend:Create("Frame", {
      Name = "DotAdapter",
      LayoutOrder = 1,
      Size = UDim2.new(0, 10, 0, 10),
      BackgroundColor3 = self:_statusColor("ok"),
      BorderSizePixel = 0,
    }, self.bar.obj)
    self.labels.fps = self.backend:Create("TextLabel", {
      Name = "Fps", LayoutOrder = 2,
      BackgroundTransparency = 1,
      Size = UDim2.new(0, 90, 1, 0),
      Font = Enum.Font.GothamMedium,
      Text = self.i18n and self.i18n:T("ui.hud.fps", { v = 0 }) or "FPS 0",
      TextSize = L.FONT_MONO or 13,
      TextColor3 = tk.text,
    }, self.bar.obj)
    self.labels.uptime = self.backend:Create("TextLabel", {
      Name = "Uptime", LayoutOrder = 3,
      BackgroundTransparency = 1,
      Size = UDim2.new(0, 110, 1, 0),
      Font = Enum.Font.GothamMedium,
      Text = self:_uptimeText(),
      TextSize = L.FONT_MONO or 13,
      TextColor3 = tk.textDim,
    }, self.bar.obj)
    self.labels.adapter = self.backend:Create("TextLabel", {
      Name = "Adapter", LayoutOrder = 4,
      BackgroundTransparency = 1,
      Size = UDim2.new(0, 130, 1, 0),
      Font = Enum.Font.GothamMedium,
      Text = "Adapter: ok",
      TextSize = L.FONT_MONO or 13,
      TextColor3 = tk.textDim,
    }, self.bar.obj)

    -- แผงย่อ (ไดอักนอสติกย่อ §8.3 — ซ่อนไว้ กดแถบเพื่อเปิด)
    self.mini = self.backend:Create("Frame", {
      Name = "Mini",
      AnchorPoint = UDim2.new(0.5, 0, 1, 0),
      Position = UDim2.new(0.5, 0, 0, 52),
      Size = UDim2.new(1, 0, 0, 118),
      BackgroundColor3 = tk.card,
      BackgroundTransparency = glass,
      Visible = false,
    }, self.bar.obj)
    self.backend:Create("UICorner", { CornerRadius = UDim.new(0, L.RADIUS or 10) }, self.mini.obj)
    self.labels.miniRegistry = self.backend:Create("TextLabel", {
      Name = "MiniRegistry", LayoutOrder = 1,
      BackgroundTransparency = 1,
      Position = UDim2.new(0, 12, 0, 10),
      Size = UDim2.new(1, -24, 0, L.LINE_H or 20),
      Font = Enum.Font.Gotham,
      Text = "-", TextSize = L.FONT_MONO or 13, TextColor3 = tk.text,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.mini.obj)
    self.labels.miniBus = self.backend:Create("TextLabel", {
      Name = "MiniBus", LayoutOrder = 2,
      BackgroundTransparency = 1,
      Position = UDim2.new(0, 12, 0, 34),
      Size = UDim2.new(1, -24, 0, L.LINE_H or 20),
      Font = Enum.Font.Gotham,
      Text = "-", TextSize = L.FONT_MONO or 13, TextColor3 = tk.text,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.mini.obj)
    self.labels.miniAdapter = self.backend:Create("TextLabel", {
      Name = "MiniAdapter", LayoutOrder = 3,
      BackgroundTransparency = 1,
      Position = UDim2.new(0, 12, 0, 58),
      Size = UDim2.new(1, -24, 0, L.LINE_H or 20),
      Font = Enum.Font.Gotham,
      Text = "-", TextSize = L.FONT_MONO or 13, TextColor3 = tk.text,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.mini.obj)
    self.labels.miniHint = self.backend:Create("TextLabel", {
      Name = "MiniHint", LayoutOrder = 4,
      BackgroundTransparency = 1,
      Position = UDim2.new(0, 12, 0, 88),
      Size = UDim2.new(1, -24, 0, L.LINE_H or 20),
      Font = Enum.Font.Gotham,
      Text = self.i18n and self.i18n:T("ui.hud.mini.fullhint") or "-",
      TextSize = L.FONT_SIZE or 14, TextColor3 = tk.hilite,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.mini.obj)

    -- แตะแถบ = สลับแผงย่อ / ลากที่แถบ = ย้ายตำแหน่ง (§5.4 ลากย้ายได้)
    self.backend:OnClick(self.bar, function()
      self.miniVisible = not self.miniVisible
      if self.mini and self.mini.obj then
        self.mini.obj.Visible = self.miniVisible
      end
      if self.miniVisible then
        self:RefreshMini() -- เปิด moment นี้เลย ไม่รอรอบ 0.25 วิ
      end
    end)
    self.drag = self.backend:MakeDraggable(self.bar, self.bar)

    -- สมัครรับ event (declared dep: EventBus)
    self.bus:On("adapter:health", function(p)
      self.lastAdapter = p
      self:RefreshAdapterDot()
    end)
    self.bus:On("i18n:changed", function()
      self:RerenderTexts()
    end)

    -- frame task ของ node นี้ (owner = "HUD") — วัด FPS + uptime + อัปเดตป้าย 4 ครั้ง/วิ
    self.runtime.Spawn("hud:frame", function(ctx)
      local clock = self.clock
      while true do
        if not ctx.ShouldRun() then return end
        local t0 = clock()
        ctx.Wait() -- ≈ 1 เฟรม (VT: 0.03 วิ / production: ~1/60 วิ)
        local dt = clock() - t0
        if dt > 0 then
          local instFps = 1 / dt
          if self.fpsEMA == nil then
            self.fpsEMA = instFps
          else
            self.fpsEMA = self.fpsEMA * 0.85 + instFps * 0.15
          end
          self.uptime = self.uptime + dt
        end
        self.updateAcc = self.updateAcc + dt
        if self.updateAcc >= 0.25 then
          self.updateAcc = 0
          -- ต้นทุน UI render ต่อเฟรม → timer "ui" ของ Diagnostics (DoD §5.4)
          if self.diag then self.diag:Begin("ui") end
          self:Update()
          if self.diag then self.diag:End("ui") end
        end
      end
    end)

    -- ต่อ FPS เข้า Diagnostics (§8.4 "FPS จริง" — แสดงใน Snapshot/Export)
    if self.diag then
      self.diag:SetFpsProvider(function()
        if self.fpsEMA == nil then return nil end
        return math.floor(self.fpsEMA + 0.5)
      end)
    end
  end)
  self.built = true
  return true
end

-- ---- อัปเดตป้าย (เบา — เรียก 4 ครั้ง/วิ จาก frame task) ----------------------

function HUD:Update()
  if not self.built then return end
  local fps = self.fpsEMA and math.floor(self.fpsEMA + 0.5) or 0
  if self.labels.fps and self.labels.fps.obj then
    self.labels.fps.obj.Text = self.i18n
      and self.i18n:T("ui.hud.fps", { v = fps }) or ("FPS " .. fps)
  end
  if self.labels.uptime and self.labels.uptime.obj then
    self.labels.uptime.obj.Text = self:_uptimeText()
  end
  if self.miniVisible then
    self:RefreshMini()
  end
end

--- จุด adapter ตามสถานะล่าสุด (ok=เขียว/degraded=เหลือง/dead=แดง §8.1)
function HUD:RefreshAdapterDot()
  local status = self.lastAdapter and self.lastAdapter.status or "ok"
  if self.dots.adapter and self.dots.adapter.obj then
    self.dots.adapter.obj.BackgroundColor3 = self:_statusColor(status)
  end
  if self.labels.adapter and self.labels.adapter.obj and self.i18n then
    local name = self.i18n:T("ui.hud.dot.adapter")
    self.labels.adapter.obj.Text = ("%s: %s"):format(name, status)
  end
end

--- แผงย่อ: ตัวเลขสดจาก Diagnostics + Event Bus (หนัก — เรียกเฉพาะตอนเปิด)
function HUD:RefreshMini()
  if not self.built or not self.miniVisible then return end
  local snap = self.diag and self.diag:Snapshot() or nil
  local busStats = self.bus and self.bus:Stats() or { perSec = 0, queued = 0 }
  if self.labels.miniRegistry and self.labels.miniRegistry.obj and snap then
    local r = snap.registry or { tasks = 0, connections = 0, renders = 0, temps = 0 }
    self.labels.miniRegistry.obj.Text = self.i18n and self.i18n:T("ui.hud.mini.registry", {
      t = r.tasks, c = r.connections, r = r.renders, tp = r.temps,
    }) or "-"
  end
  if self.labels.miniBus and self.labels.miniBus.obj then
    self.labels.miniBus.obj.Text = self.i18n and self.i18n:T("ui.hud.mini.bus", {
      eps = busStats.perSec or 0, q = busStats.queued or 0,
    }) or "-"
  end
  if self.labels.miniAdapter and self.labels.miniAdapter.obj then
    local status = self.lastAdapter and self.lastAdapter.status or "ok"
    self.labels.miniAdapter.obj.Text = self.i18n
      and self.i18n:T("ui.hud.mini.adapter", { status = status }) or "-"
  end
end

--- แปลป้ายทั้งหมดใหม่ (เปลี่ยนภาษา — DoD ห้ามข้อความค้างภาษาเดิม)
function HUD:RerenderTexts()
  if not self.built then return end
  self:Update()
  self:RefreshAdapterDot()
  if self.labels.miniHint and self.labels.miniHint.obj and self.i18n then
    self.labels.miniHint.obj.Text = self.i18n:T("ui.hud.mini.fullhint")
  end
  if self.miniVisible then
    self:RefreshMini()
  end
end

-- ---- theme -----------------------------------------------------------------

function HUD:ApplyTheme(tokens)
  self.tokens = tokens
  if not self.built then return self end
  local L = tokens.layout or {}
  if self.bar and self.bar.obj then
    self.bar.obj.BackgroundColor3 = tokens.card
  end
  if self.mini and self.mini.obj then
    self.mini.obj.BackgroundColor3 = tokens.card
  end
  for _, key in ipairs({ "fps" }) do
    if self.labels[key] and self.labels[key].obj then
      self.labels[key].obj.TextColor3 = tokens.text
    end
  end
  if self.labels.uptime and self.labels.uptime.obj then
    self.labels.uptime.obj.TextColor3 = tokens.textDim
  end
  self:RefreshAdapterDot()
  return self
end

-- ---- สถานะ / ปิด ------------------------------------------------------------

function HUD:Stats()
  return {
    built = self.built,
    fps = self.fpsEMA and math.floor(self.fpsEMA + 0.5) or nil,
    uptimeSec = self.uptime,
    miniVisible = self.miniVisible,
  }
end

function HUD:Shutdown()
  -- ถอน fps provider ก่อน (Diagnostics จะได้ไม่ชี้มาที่เราหลังปิด)
  if self.diag then
    self.diag:SetFpsProvider(nil)
  end
  if self.runtime and self.runtime.Release then
    self.runtime.Release(HUD.NODE)
  end
  self.built = false
  self.labels = {}
  self.dots = {}
  return true
end

return HUD
