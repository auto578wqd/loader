-- ============================================================================
-- The Voider — core/ui/hub.lua
-- Main Hub (เฟส 1 UI Framework — แผน freeze v2.1 §5.4 + §8.3 + §8.4)
--
-- node L6 ตาม dependency graph: Hub | แท็บ 8 โมดูล + ค้นหา(P1) |
-- deps: ConfigService, I18nService (โมดูล L5 ยังไม่มีในเฟสนี้ — แท็บของ
-- โมดูลแสดงสถานะ "จะพร้อมในเฟส N" ตาม roadmap แบบโปร่งใส §3.9 PENDING
-- ไม่ใช่ซ่อนเงียบ ๆ)
--
-- โครงตาม §8.3: แถบหัว (ลากย้ายได้ + สถานะระบบสด) / แถบค้นหา (พื้นที่
-- สงวน P1 — แสดง placeholder แต่ยังไม่มีพฤติกรรม) / แท็บซ้าย 8 โมดูล +
-- Setup / เนื้อหาขวา
--
-- Setup tab: ภาษา (th/en — เขียน config i18n.lang) + สีเน้น 4 ตัว (§8.2 —
-- ผ่าน callback ของ assembler → ThemeEngine + config + fanout ทุก node)
-- + เครื่องมือนักพัฒนา
--
-- Developer Diagnostics เต็มรูปแบบ (§8.4) — แผงลับเปิดได้ 2 ทาง:
-- แตะโลโก้ 5 ครั้ง (ช่วงห่าง ≤ 2 วิ) หรือปุ่มจากแท็บ Setup
-- ข้อมูลจาก Direct Service "Diagnostics" (ambient §3.5 — ตามแบบ
-- bundle selftest ที่ใช้ Services:MustGet) : Snapshot/MemorySeries/
-- ExportToClipboard + กราฟ memory วาดจริง (แท่งตามอนุกรม sample)
-- ESP objects / Macro = "—" (ยังไม่มีโมดูล — PENDING โปร่งใส)
--
-- ความคงทน (§3.7 config เป็นของผู้ใช้): ui.hub.open / ui.hub.pos /
-- ui.accent / i18n.lang — ผ่าน ConfigService (declared dep ของ node นี้)
-- ============================================================================

local Hub = {}
Hub.__index = Hub

Hub.NODE = "Hub"
Hub.VERSION = "0.1.0"

--- แท็บทั้งหมด — 8 โมดูลตาม graph L5 + Setup (§8.3)
--- phase = เฟสที่โมดูลนั้นจะมีของจริงตาม roadmap §5.2 (0 = มีเนื้อหาเดี๋ยวนี้)
Hub.TABS = {
  { key = "aim",    name = "Aim",    icon = "⭐", phase = 2, order = 1 },
  { key = "esp",    name = "ESP",    icon = "👁", phase = 2, order = 2 },
  { key = "macro",  name = "Macro",  icon = "🎹", phase = 3, order = 3 },
  { key = "combat", name = "Combat", icon = "⚔",  phase = 3, order = 4 },
  { key = "race",   name = "Race",   icon = "🧬", phase = 4, order = 5 },
  { key = "fruit",  name = "Fruit",  icon = "🍎", phase = 4, order = 6 },
  { key = "move",   name = "Move",   icon = "🏃", phase = 4, order = 7 },
  { key = "hop",    name = "Hop",    icon = "🛰",  phase = 4, order = 8 },
  { key = "setup",  name = "Setup",  icon = "⚙",  phase = 0, order = 9 },
}

Hub.LOGO_TAPS = 5       -- §8.4: แตะโลโก้ 5 ครั้ง = เปิดแผง Diagnostics
Hub.TAP_WINDOW = 2.0    -- ช่วงห่างระหว่างแตะ (วิ) — เกิน = เริ่มนับใหม่

Hub.I18N = {
  th = {
    ["ui.hub.title"] = "THE VOIDER",
    ["ui.hub.search"] = "🔍 ค้นหาฟีเจอร์…",
    ["ui.hub.version"] = "v{v}",
    ["ui.hub.status.ready"] = "ระบบพร้อม",
    ["ui.hub.status.degraded"] = "Adapter เสื่อม — รออัปเดต The Voider",
    ["ui.hub.tab.aim"] = "⭐ Aim",
    ["ui.hub.tab.esp"] = "👁 ESP",
    ["ui.hub.tab.macro"] = "🎹 Macro",
    ["ui.hub.tab.combat"] = "⚔ Combat",
    ["ui.hub.tab.race"] = "🧬 Race",
    ["ui.hub.tab.fruit"] = "🍎 Fruit",
    ["ui.hub.tab.move"] = "🏃 Move",
    ["ui.hub.tab.hop"] = "🛰 Hop",
    ["ui.hub.tab.setup"] = "⚙ Setup",
    ["ui.hub.coming"] = "โมดูล {name} จะพร้อมใช้ในเฟส {phase} ตาม roadmap",
    ["ui.hub.coming.sub"] = "ยังไม่มีการตั้งค่าให้แสดงในเฟสนี้ (§แผน 5.2)",
    ["ui.setup.lang"] = "ภาษา / Language",
    ["ui.setup.lang.th"] = "ไทย",
    ["ui.setup.lang.en"] = "English",
    ["ui.setup.accent"] = "สีเน้น (accent)",
    ["ui.setup.accent.err"] = "ไม่รองรับสีนี้",
    ["ui.accent.purple"] = "ม่วง",
    ["ui.accent.cyan"] = "ฟ้า",
    ["ui.accent.pink"] = "ชมพู",
    ["ui.accent.green"] = "เขียว",
    ["ui.setup.tools"] = "เครื่องมือนักพัฒนา",
    ["ui.setup.diag.open"] = "เปิดแผง Diagnostics",
    ["ui.setup.diag.export"] = "Export Diagnostics",
    ["ui.diag.exported"] = "คัดลอกรายงานแล้ว ({n} ตัวอักษร)",
    ["ui.diag.export.console"] = "ไม่มี clipboard — พิมพ์รายงานออกคอนโซลแล้ว",
    ["ui.diag.close"] = "✕ ปิด",
    ["ui.diag.frame"] = "เฟรม",
    ["ui.diag.memory"] = "หน่วยความจำ (กราฟ 15 นาทีล่าสุด)",
    ["ui.diag.registry"] = "Registry (4 ชนิด — ต้องกลับเป็น 0 หลังปิดโมดูล)",
    ["ui.diag.bus"] = "Event Bus",
    ["ui.diag.objects"] = "วัตถุ ESP",
    ["ui.diag.macro"] = "Macro",
    ["ui.diag.system"] = "ระบบ",
    ["ui.diag.pending"] = "— (ยังไม่มีโมดูลในเฟสนี้)",
  },
  en = {
    ["ui.hub.title"] = "THE VOIDER",
    ["ui.hub.search"] = "🔍 Search features…",
    ["ui.hub.version"] = "v{v}",
    ["ui.hub.status.ready"] = "System ready",
    ["ui.hub.status.degraded"] = "Adapter degraded — waiting for The Voider update",
    ["ui.hub.tab.aim"] = "⭐ Aim",
    ["ui.hub.tab.esp"] = "👁 ESP",
    ["ui.hub.tab.macro"] = "🎹 Macro",
    ["ui.hub.tab.combat"] = "⚔ Combat",
    ["ui.hub.tab.race"] = "🧬 Race",
    ["ui.hub.tab.fruit"] = "🍎 Fruit",
    ["ui.hub.tab.move"] = "🏃 Move",
    ["ui.hub.tab.hop"] = "🛰 Hop",
    ["ui.hub.tab.setup"] = "⚙ Setup",
    ["ui.hub.coming"] = "The {name} module arrives in phase {phase} per the roadmap",
    ["ui.hub.coming.sub"] = "No settings to show in this phase yet (plan §5.2)",
    ["ui.setup.lang"] = "ภาษา / Language",
    ["ui.setup.lang.th"] = "ไทย",
    ["ui.setup.lang.en"] = "English",
    ["ui.setup.accent"] = "Accent color",
    ["ui.setup.accent.err"] = "Unsupported accent",
    ["ui.accent.purple"] = "Purple",
    ["ui.accent.cyan"] = "Cyan",
    ["ui.accent.pink"] = "Pink",
    ["ui.accent.green"] = "Green",
    ["ui.setup.tools"] = "Developer tools",
    ["ui.setup.diag.open"] = "Open Diagnostics panel",
    ["ui.setup.diag.export"] = "Export Diagnostics",
    ["ui.diag.exported"] = "Report copied ({n} chars)",
    ["ui.diag.export.console"] = "No clipboard — report printed to console",
    ["ui.diag.close"] = "✕ Close",
    ["ui.diag.frame"] = "Frame",
    ["ui.diag.memory"] = "Memory (graph: last 15 min)",
    ["ui.diag.registry"] = "Registry (4 kinds — must return to 0 after module close)",
    ["ui.diag.bus"] = "Event Bus",
    ["ui.diag.objects"] = "ESP objects",
    ["ui.diag.macro"] = "Macro",
    ["ui.diag.system"] = "System",
    ["ui.diag.pending"] = "— (no module in this phase yet)",
  },
}

function Hub.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    runtime = ctx.runtime,
    backend = ctx.backend,
    config = ctx.config,     -- ConfigService (declared dep)
    i18n = ctx.i18n,         -- I18nService (declared dep)
    services = ctx.services, -- Service Registry (ambient §3.5 — อ่าน Diagnostics)
    tokens = ctx.tokens,
    clock = ctx.clock or os.clock,
    version = ctx.version or "0.0.0",
    accents = ctx.accents or { "purple" },
    accent = ctx.accent or "purple",
    setAccent = ctx.setAccent, -- callback ของ assembler (ThemeEngine+config+fanout)
    built = false,
    visible = true,
    currentTab = "setup",
    tabBtns = {},            -- [key] = { h, order }
    contents = {},            -- [key] = handle (เนื้อหาของแต่ละแท็บ)
    langBtns = {},            -- [lang] = { h }
    accentBtns = {},          -- [name] = { h }
    elems = {},               -- [name] = handle
    graphBars = {},
    logoTaps = 0,
    lastTapAt = 0,
    panelOpen = false,
    feedback = { h = nil, text = "" },
    styling = { cards = {}, strokes = {}, textMain = {}, textDim = {}, hilite = {} },
  }, Hub)
  if self.i18n then
    self.i18n:AddTable("th", Hub.I18N.th)
    self.i18n:AddTable("en", Hub.I18N.en)
  end
  return self
end

-- ---- helpers -----------------------------------------------------------------

local function fmtMs(v)
  if v == nil then return "-" end
  return ("%.2f"):format(v)
end

function Hub:_T(key, params)
  if self.i18n then return self.i18n:T(key, params) end
  return key
end

function Hub:_svc()
  -- Direct Service "Diagnostics" (ambient §3.5) — ไม่มี = คืน nil (ไม่เดา)
  if self.services and self.services.Get then
    return self.services:Get("Diagnostics")
  end
  return nil
end

--- บันทึกตำแหน่ง hub ปัจจุบันลง config (§3.7 — ของผู้ใช้ ห้ามทิ้ง)
function Hub:_savePos()
  if not (self.config and self.mainH and self.mainH.obj) then return end
  local pos = self.mainH.obj.Position
  if not pos or not pos.X then return end
  self.config:Set("ui.hub.pos", {
    x = pos.X.Offset,
    y = pos.Y.Offset,
  }, { save = true })
end

function Hub:_saveOpen(v)
  if self.config then
    self.config:Set("ui.hub.open", v, { save = true })
  end
end

-- ---- สร้าง UI ครั้งเดียว -------------------------------------------------------

function Hub:Render()
  if self.built then return true end
  if not self.backend.available then
    return false, self.backend.reason
  end
  local R = self.runtime
  R.Scope(Hub.NODE, function()
    local tk = self.tokens or {}
    local L = tk.layout or {}
    local glass = tk.glass and (1 - tk.glass.CARD_ALPHA) or 0.88
    local S = self.styling
    local BE = self.backend

    -- ตำแหน่ง/สถานะเปิดจาก config (§3.7 — ผู้ใช้เป็นเจ้าของ)
    local pos = self.config and self.config:Get("ui.hub.pos") or nil
    local posX = (type(pos) == "table" and type(pos.x) == "number") and pos.x or 0
    local posY = (type(pos) == "table" and type(pos.y) == "number") and pos.y or -40
    local open = self.config and self.config:Get("ui.hub.open")
    if open == nil then open = true end
    if open == false then self.visible = false end

    self.gui = BE:Create("ScreenGui", { Name = "TVHub", DisplayOrder = 70, ResetOnSpawn = false })

    -- ปุ่มลอยเปิด hub (โผล่เฉพาะเมื่อ hub ถูกย่อ) — 44px (DoD §5.4)
    self.elems.pill = BE:Create("TextButton", {
      Name = "OpenPill",
      AnchorPoint = UDim2.new(0, 0, 0, 0),
      Position = UDim2.new(0, 16, 0, 16),
      Size = UDim2.new(0, L.TOUCH_MIN or 44, 0, L.TOUCH_MIN or 44),
      BackgroundColor3 = tk.card, BackgroundTransparency = glass,
      Text = "🕳", TextSize = 22, Font = Enum.Font.GothamBold,
      TextColor3 = tk.text, AutoButtonColor = false,
      Visible = not self.visible,
    }, self.gui.obj)
    S.cards[#S.cards + 1] = self.elems.pill
    BE:OnClick(self.elems.pill, function() self:SetVisible(true) end)

    -- หน้าต่างหลัก
    self.mainH = BE:Create("Frame", {
      Name = "Hub",
      AnchorPoint = UDim2.new(0.5, 0, 0.5, 0),
      Position = UDim2.new(0.5, posX, 0.5, posY),
      Size = UDim2.new(0, L.HUB_W or 560, 0, L.HUB_H or 420),
      BackgroundColor3 = tk.bg,
      BackgroundTransparency = 0.02,
      Visible = self.visible,
    }, self.gui.obj)
    S.cards[#S.cards + 1] = self.mainH
    BE:Create("UICorner", { CornerRadius = UDim.new(0, L.RADIUS or 10) }, self.mainH.obj)
    local mainStroke = BE:Create("UIStroke", {
      Color = tk.border, Thickness = L.STROKE or 1, Transparency = 0.25,
    }, self.mainH.obj)
    S.strokes[#S.strokes + 1] = mainStroke

    -- แถบหัว: โลโก้ (แตะ 5 ครั้ง = แผง Diagnostics §8.4) + เวอร์ชัน + สถานะ + ย่อ
    self.elems.header = BE:Create("Frame", {
      Name = "Header",
      Position = UDim2.new(0, 0, 0, 0),
      Size = UDim2.new(1, 0, 0, L.HEADER_H or 44),
      BackgroundColor3 = tk.card, BackgroundTransparency = glass,
    }, self.mainH.obj)
    S.cards[#S.cards + 1] = self.elems.header
    self.elems.logo = BE:Create("TextButton", {
      Name = "Logo",
      Position = UDim2.new(0, 12, 0, 0),
      Size = UDim2.new(0, 190, 1, 0),
      BackgroundTransparency = 1,
      Text = "🕳 " .. self:_T("ui.hub.title"),
      Font = Enum.Font.GothamBold, TextSize = L.FONT_TITLE or 18,
      TextColor3 = tk.text, TextXAlignment = Enum.TextXAlignment.Left,
      AutoButtonColor = false,
    }, self.elems.header.obj)
    S.textMain[#S.textMain + 1] = self.elems.logo
    self.elems.version = BE:Create("TextLabel", {
      Name = "Version",
      Position = UDim2.new(0, 206, 0, 0),
      Size = UDim2.new(0, 70, 1, 0),
      BackgroundTransparency = 1,
      Text = self:_T("ui.hub.version", { v = self.version }),
      Font = Enum.Font.Gotham, TextSize = L.FONT_SIZE or 14,
      TextColor3 = tk.textDim, TextXAlignment = Enum.TextXAlignment.Left,
    }, self.elems.header.obj)
    S.textDim[#S.textDim + 1] = self.elems.version
    self.elems.statusDot = BE:Create("Frame", {
      Name = "StatusDot",
      AnchorPoint = UDim2.new(1, 0, 0.5, 0),
      Position = UDim2.new(1, -110, 0.5, 0),
      Size = UDim2.new(0, 10, 0, 10),
      BackgroundColor3 = tk.on, BorderSizePixel = 0,
    }, self.elems.header.obj)
    self.elems.statusText = BE:Create("TextLabel", {
      Name = "StatusText",
      AnchorPoint = UDim2.new(1, 0, 0.5, 0),
      Position = UDim2.new(1, -60, 0.5, 0),
      Size = UDim2.new(0, 48, 0, L.LINE_H or 20),
      BackgroundTransparency = 1,
      Text = self:_T("ui.hub.status.ready"),
      Font = Enum.Font.Gotham, TextSize = 12,
      TextColor3 = tk.textDim, TextXAlignment = Enum.TextXAlignment.Right,
    }, self.elems.header.obj)
    S.textDim[#S.textDim + 1] = self.elems.statusText
    self.elems.minBtn = BE:Create("TextButton", {
      Name = "Minimize",
      AnchorPoint = UDim2.new(1, 0, 0, 0),
      Position = UDim2.new(1, -8, 0, 0),
      Size = UDim2.new(0, L.TOUCH_MIN or 44, 0, L.HEADER_H or 44),
      BackgroundTransparency = 1,
      Text = "—", Font = Enum.Font.GothamBold, TextSize = 20,
      TextColor3 = tk.textDim, AutoButtonColor = false,
    }, self.elems.header.obj)
    BE:OnClick(self.elems.minBtn, function() self:SetVisible(false) end)

    -- แถบค้นหา — พื้นที่สงวน P1 (§5.4 "พื้นที่สำหรับค้นหา P1")
    -- แสดง placeholder แต่ไม่มีพฤติกรรมในเฟสนี้ (ห้ามเพิ่ม feature เงียบ ๆ §4.5)
    self.elems.search = BE:Create("TextBox", {
      Name = "Search",
      Position = UDim2.new(0, 12, 0, (L.HEADER_H or 44) + 8),
      Size = UDim2.new(1, -24, 0, L.TOUCH_MIN or 44),
      BackgroundColor3 = tk.card, BackgroundTransparency = glass,
      Text = self:_T("ui.hub.search"),
      TextEditable = false, ClearTextOnFocus = false,
      Font = Enum.Font.Gotham, TextSize = L.FONT_SIZE or 14,
      TextColor3 = tk.textDim,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.mainH.obj)
    S.cards[#S.cards + 1] = self.elems.search
    S.textDim[#S.textDim + 1] = self.elems.search

    -- แท็บซ้าย (8 โมดูล + Setup ตาม §8.3)
    local railTop = (L.HEADER_H or 44) + 8 + (L.TOUCH_MIN or 44) + 10
    self.elems.rail = BE:Create("Frame", {
      Name = "Tabs",
      Position = UDim2.new(0, 12, 0, railTop),
      Size = UDim2.new(0, L.TAB_W or 116, 1, -(railTop + 12)),
      BackgroundTransparency = 1,
    }, self.mainH.obj)
    self.elems.railList = BE:Create("UIListLayout", {
      Name = "List", Padding = UDim.new(0, L.GAP or 8),
      SortOrder = Enum.SortOrder.LayoutOrder,
    }, self.elems.rail.obj)
    for _, tab in ipairs(Hub.TABS) do
      local h = BE:Create("TextButton", {
        Name = "Tab_" .. tab.key,
        Size = UDim2.new(1, 0, 0, L.TAB_H or 44),
        LayoutOrder = tab.order,
        BackgroundTransparency = 1,
        Text = self:_T("ui.hub.tab." .. tab.key),
        Font = Enum.Font.GothamMedium, TextSize = L.FONT_SIZE or 14,
        TextColor3 = tk.textDim, AutoButtonColor = false,
        TextXAlignment = Enum.TextXAlignment.Left,
      }, self.elems.rail.obj)
      self.tabBtns[tab.key] = { h = h, order = tab.order }
      BE:OnClick(h, function() self:SwitchTab(tab.key) end)
    end

    -- เนื้อหาขวา
    self.elems.content = BE:Create("Frame", {
      Name = "Content",
      AnchorPoint = UDim2.new(1, 0, 0, 0),
      Position = UDim2.new(1, -12, 0, railTop),
      Size = UDim2.new(1, -((L.TAB_W or 116) + 36), 1, -(railTop + 12)),
      BackgroundTransparency = 1,
    }, self.mainH.obj)

    -- เนื้อหาแท็บโมดูล: empty-state โปร่งใส (§3.9 PENDING)
    for _, tab in ipairs(Hub.TABS) do
      if tab.phase > 0 then
        local c = BE:Create("Frame", {
          Name = "Content_" .. tab.key,
          Size = UDim2.new(1, 0, 1, 0),
          BackgroundTransparency = 1, Visible = false,
        }, self.elems.content.obj)
        local big = BE:Create("TextLabel", {
          Name = "Icon",
          AnchorPoint = UDim2.new(0.5, 0, 0, 0),
          Position = UDim2.new(0.5, 0, 0, 24),
          Size = UDim2.new(0, 64, 0, 64),
          BackgroundTransparency = 1, Text = tab.icon,
          Font = Enum.Font.GothamBold, TextSize = 44, TextColor3 = tk.textDim,
        }, c.obj)
        S.textDim[#S.textDim + 1] = big
        local t1 = BE:Create("TextLabel", {
          Name = "Coming",
          AnchorPoint = UDim2.new(0.5, 0, 0, 0),
          Position = UDim2.new(0.5, 0, 0, 108),
          Size = UDim2.new(1, -32, 0, L.LINE_H or 20),
          BackgroundTransparency = 1,
          Text = self:_T("ui.hub.coming", { name = tab.name, phase = tab.phase }),
          Font = Enum.Font.Gotham, TextSize = L.FONT_SIZE or 14, TextColor3 = tk.text,
        }, c.obj)
        S.textMain[#S.textMain + 1] = t1
        local t2 = BE:Create("TextLabel", {
          Name = "ComingSub",
          AnchorPoint = UDim2.new(0.5, 0, 0, 0),
          Position = UDim2.new(0.5, 0, 0, 132),
          Size = UDim2.new(1, -32, 0, L.LINE_H or 20),
          BackgroundTransparency = 1,
          Text = self:_T("ui.hub.coming.sub"),
          Font = Enum.Font.Gotham, TextSize = 12, TextColor3 = tk.textDim,
        }, c.obj)
        S.textDim[#S.textDim + 1] = t2
        self.contents[tab.key] = c
      end
    end

    -- เนื้อหาแท็บ Setup
    self:_buildSetup(tk, L, glass)

    -- ลากย้ายที่แถบหัว + บันทึกตำแหน่งเมื่อปล่อย (§3.7)
    BE:MakeDraggable(self.mainH, self.elems.header, {
      onDragEnd = function() self:_savePos() end,
    })

    -- แผง Diagnostics เต็มรูปแบบ (§8.4) — สร้างไว้ซ่อน
    self:_buildDiagPanel(tk, L, glass)

    -- โลโก้ 5 แตะ → เปิดแผง
    BE:OnClick(self.elems.logo, function() self:_logoTap() end)

    -- โพลล์ 1 วิ: สถานะหัว (สด) + รีเฟรชแผงถ้าเปิดอยู่ (§8.4 "แสดงสด ๆ")
    self.runtime.Spawn("hub:poll", function(ctx)
      while true do
        if not ctx.ShouldRun() then return end
        ctx.Wait(1)
        if not ctx.ShouldRun() then return end
        if self.built then
          if self.visible then self:RefreshStatus() end
          if self.panelOpen then self:RefreshPanel() end
        end
      end
    end)
  end)
  self.built = true
  self:SwitchTab(self.currentTab)
  return true
end

-- ---- แท็บ Setup -----------------------------------------------------------------

function Hub:_buildSetup(tk, L, glass)
  local BE = self.backend
  local S = self.styling
  local c = BE:Create("Frame", {
    Name = "Content_setup",
    Size = UDim2.new(1, 0, 1, 0),
    BackgroundTransparency = 1, Visible = false,
  }, self.elems.content.obj)
  self.contents.setup = c

  local function sectionLabel(name, textKey, y)
    local h = BE:Create("TextLabel", {
      Name = name,
      Position = UDim2.new(0, 4, 0, y),
      Size = UDim2.new(1, -8, 0, L.LINE_H or 20),
      BackgroundTransparency = 1,
      Text = self:_T(textKey),
      Font = Enum.Font.GothamBold, TextSize = L.FONT_SIZE or 14,
      TextColor3 = tk.hilite, TextXAlignment = Enum.TextXAlignment.Left,
    }, c.obj)
    S.hilite[#S.hilite + 1] = h
    return h
  end
  local function actionBtn(name, textKey, x, y, w)
    local h = BE:Create("TextButton", {
      Name = name,
      Position = UDim2.new(0, x, 0, y),
      Size = UDim2.new(0, w, 0, L.TOUCH_MIN or 44),
      BackgroundColor3 = tk.card, BackgroundTransparency = glass,
      Text = self:_T(textKey),
      Font = Enum.Font.GothamMedium, TextSize = L.FONT_SIZE or 14,
      TextColor3 = tk.text, AutoButtonColor = false,
    }, c.obj)
    S.cards[#S.cards + 1] = h
    S.textMain[#S.textMain + 1] = h
    BE:Create("UICorner", { CornerRadius = UDim.new(0, L.RADIUS or 10) }, h.obj)
    return h
  end

  -- ภาษา
  sectionLabel("LangTitle", "ui.setup.lang", 12)
  self.langBtns.th = actionBtn("LangTh", "ui.setup.lang.th", 4, 40, 96)
  self.langBtns.en = actionBtn("LangEn", "ui.setup.lang.en", 108, 40, 110)
  BE:OnClick(self.langBtns.th, function()
    if self.config then self.config:Set("i18n.lang", "th", { save = true }) end
    if self.i18n then
      self.i18n:Set("th")
      self:RerenderTexts() -- Hub ไม่มี bus เป็น dep — เรียกเองหลังเปลี่ยน (§3.10)
    end
    self:_restyleLangBtns()
  end)
  BE:OnClick(self.langBtns.en, function()
    if self.config then self.config:Set("i18n.lang", "en", { save = true }) end
    if self.i18n then
      self.i18n:Set("en")
      self:RerenderTexts()
    end
    self:_restyleLangBtns()
  end)

  -- สีเน้น (§8.2) — ผ่าน callback ของ assembler (ThemeEngine + config + fanout)
  sectionLabel("AccentTitle", "ui.setup.accent", 104)
  local ax = 4
  for _, name in ipairs(self.accents) do
    local h = actionBtn("Accent_" .. name, "ui.accent." .. name, ax, 132, 96)
    self.accentBtns[name] = h
    ax = ax + 104
    BE:OnClick(h, function() self:TrySetAccent(name) end)
  end

  -- เครื่องมือนักพัฒนา (§8.4)
  sectionLabel("ToolsTitle", "ui.setup.tools", 196)
  local openBtn = actionBtn("DiagOpen", "ui.setup.diag.open", 4, 224, 220)
  local exportBtn = actionBtn("DiagExport", "ui.setup.diag.export", 232, 224, 200)
  BE:OnClick(openBtn, function() self:OpenPanel() end)
  BE:OnClick(exportBtn, function() self:DoExport() end)

  -- ป้ายผลลัพธ์ (export/accent error)
  local fb = BE:Create("TextLabel", {
    Name = "Feedback",
    Position = UDim2.new(0, 4, 0, 280),
    Size = UDim2.new(1, -8, 0, L.LINE_H or 20),
    BackgroundTransparency = 1,
    Text = "", Font = Enum.Font.Gotham, TextSize = 12,
    TextColor3 = tk.textDim, TextXAlignment = Enum.TextXAlignment.Left,
  }, c.obj)
  self.feedback.h = fb
  S.textDim[#S.textDim + 1] = fb
end

--- เปลี่ยน accent ผ่าน assembler — ไม่สำเร็จ = แจ้งในป้าย (ไม่เดาเงียบ ๆ)
function Hub:TrySetAccent(name)
  if type(self.setAccent) ~= "function" then
    self:_feedback(self:_T("ui.setup.accent.err"))
    return false
  end
  local ok, err = self.setAccent(name)
  if ok then
    self.accent = name
    self:_restyleAccentBtns()
    self:_feedback("")
    return true
  end
  self:_feedback(self:_T("ui.setup.accent.err") .. " (" .. tostring(name) .. ")")
  return false, err
end

function Hub:_feedback(text)
  self.feedback.text = text
  if self.feedback.h and self.feedback.h.obj then
    self.feedback.h.obj.Text = text
  end
end

-- ---- แผง Diagnostics เต็มรูปแบบ (§8.4) -----------------------------------------

function Hub:_buildDiagPanel(tk, L, glass)
  local BE = self.backend
  local S = self.styling

  self.elems.panel = BE:Create("Frame", {
    Name = "DiagPanel",
    Position = UDim2.new(0, 0, 0, 0),
    Size = UDim2.new(1, 0, 1, 0),
    BackgroundColor3 = tk.bg,
    BackgroundTransparency = 0.02,
    Visible = false, ZIndex = 50,
  }, self.mainH.obj)
  S.cards[#S.cards + 1] = self.elems.panel

  local close = BE:Create("TextButton", {
    Name = "Close",
    AnchorPoint = UDim2.new(1, 0, 0, 0),
    Position = UDim2.new(1, -8, 0, 6),
    Size = UDim2.new(0, L.TOUCH_MIN or 44, 0, L.TOUCH_MIN or 44),
    BackgroundTransparency = 1, ZIndex = 51,
    Text = self:_T("ui.diag.close"),
    Font = Enum.Font.GothamBold, TextSize = 13, TextColor3 = tk.textDim,
    AutoButtonColor = false,
  }, self.elems.panel.obj)
  BE:OnClick(close, function() self:ClosePanel() end)

  local function row(name, titleKey, y, h)
    local t = BE:Create("TextLabel", {
      Name = name .. "Title",
      Position = UDim2.new(0, 16, 0, y),
      Size = UDim2.new(1, -32, 0, L.LINE_H or 20),
      BackgroundTransparency = 1, ZIndex = 51,
      Text = self:_T(titleKey),
      Font = Enum.Font.GothamBold, TextSize = 13, TextColor3 = tk.hilite,
      TextXAlignment = Enum.TextXAlignment.Left,
    }, self.elems.panel.obj)
    S.hilite[#S.hilite + 1] = t
    local v = BE:Create("TextLabel", {
      Name = name .. "Value",
      Position = UDim2.new(0, 16, 0, y + (L.LINE_H or 20)),
      Size = UDim2.new(1, -32, 0, h or (L.LINE_H or 20)),
      BackgroundTransparency = 1, ZIndex = 51,
      Text = "-", Font = Enum.Font.Gotham, TextSize = L.FONT_MONO or 13,
      TextColor3 = tk.text, TextXAlignment = Enum.TextXAlignment.Left,
    }, self.elems.panel.obj)
    S.textMain[#S.textMain + 1] = v
    return v
  end

  self.pRows = {
    frame = row("Frame", "ui.diag.frame", 12, 40),
    memory = row("Memory", "ui.diag.memory", 76, 18),
    registry = row("Registry", "ui.diag.registry", 114, 18),
    bus = row("Bus", "ui.diag.bus", 152, 18),
    objects = row("Objects", "ui.diag.objects", 190, 18),
    macro = row("Macro", "ui.diag.macro", 228, 18),
    system = row("System", "ui.diag.system", 266, 74),
  }

  -- กราฟ memory วาดจริง (§8.4 "กราฟย้อนหลัง 15 นาที ตรวจด้วยตาได้เลย")
  self.elems.graph = BE:Create("Frame", {
    Name = "MemGraph",
    Position = UDim2.new(0, 16, 0, 118),
    Size = UDim2.new(1, -32, 0, 58),
    BackgroundColor3 = tk.card, BackgroundTransparency = 0.6, ZIndex = 51,
  }, self.elems.panel.obj)
  S.cards[#S.cards + 1] = self.elems.graph
  BE:Create("UIListLayout", {
    Name = "Bars",
    FillDirection = Enum.FillDirection.Horizontal,
    VerticalAlignment = Enum.VerticalAlignment.Bottom,
    Padding = UDim.new(0, 1), SortOrder = Enum.SortOrder.LayoutOrder,
  }, self.elems.graph.obj)

  -- ปุ่ม Export ในแผง (เครื่องมือ §8.4)
  local ex = BE:Create("TextButton", {
    Name = "Export",
    Position = UDim2.new(0, 16, 1, -56),
    Size = UDim2.new(0, 210, 0, L.TOUCH_MIN or 44),
    BackgroundColor3 = tk.card, BackgroundTransparency = glass, ZIndex = 51,
    Text = self:_T("ui.setup.diag.export"),
    Font = Enum.Font.GothamMedium, TextSize = L.FONT_SIZE or 14,
    TextColor3 = tk.text, AutoButtonColor = false,
  }, self.elems.panel.obj)
  S.cards[#S.cards + 1] = ex
  S.textMain[#S.textMain + 1] = ex
  BE:OnClick(ex, function() self:DoExport() end)
  local fb = BE:Create("TextLabel", {
    Name = "PanelFeedback",
    Position = UDim2.new(0, 236, 1, -56),
    Size = UDim2.new(1, -252, 0, L.TOUCH_MIN or 44),
    BackgroundTransparency = 1, ZIndex = 51,
    Text = "", Font = Enum.Font.Gotham, TextSize = 12,
    TextColor3 = tk.textDim, TextXAlignment = Enum.TextXAlignment.Left,
  }, self.elems.panel.obj)
  self.panelFeedback = { h = fb }
  S.textDim[#S.textDim + 1] = fb
end

function Hub:_logoTap()
  local now = self.clock()
  if now - self.lastTapAt > Hub.TAP_WINDOW then
    self.logoTaps = 1
  else
    self.logoTaps = self.logoTaps + 1
  end
  self.lastTapAt = now
  if self.logoTaps >= Hub.LOGO_TAPS then
    self.logoTaps = 0
    self:OpenPanel()
  end
end

function Hub:OpenPanel()
  if not (self.built and self.elems.panel and self.elems.panel.obj) then
    return false, "hub ยังไม่ถูกสร้าง"
  end
  self.panelOpen = true
  self.elems.panel.obj.Visible = true
  self:RefreshPanel()
  return true
end

function Hub:ClosePanel()
  self.panelOpen = false
  if self.elems.panel and self.elems.panel.obj then
    self.elems.panel.obj.Visible = false
  end
  -- คืนแท่งกราฟ (handle ทุกตัว — กัน orphan สะสมข้ามการเปิด)
  for _, h in ipairs(self.graphBars) do
    if h.Release then h.Release() end
  end
  self.graphBars = {}
  return true
end

--- อัปเดตแผงจาก Direct Service "Diagnostics" (สด ๆ §8.4)
function Hub:RefreshPanel()
  if not self.panelOpen then return end
  local svc = self:_svc()
  if not svc then return end
  local snap = svc.Snapshot()
  if not snap then return end

  -- เฟรม: FPS + ต้นทุนต่อโมดูล (min/avg/max)
  local fpsTxt = snap.fps and ("%d"):format(snap.fps) or "-"
  local lines = { ("FPS %s"):format(fpsTxt) }
  local names = {}
  for n in pairs(snap.timers or {}) do names[#names + 1] = n end
  table.sort(names)
  for _, n in ipairs(names) do
    local t = snap.timers[n]
    if t and t.count and t.count > 0 then
      lines[#lines + 1] = ("  [%s] n=%d avg=%sms max=%sms"):format(
        n, t.count, fmtMs(t.total / t.count), fmtMs(t.max))
    end
  end
  self.pRows.frame.obj.Text = table.concat(lines, "\n")

  -- หน่วยความจำ
  self.pRows.memory.obj.Text = snap.memoryKb
    and ("ใช้ปัจจุบัน %.0f KB (แท่ง = sample ย้อนหลัง)"):format(snap.memoryKb)
    or "ใช้ปัจจุบัน - (สภาพแวดล้อมนี้ไม่รายงาน)"

  -- Registry 4 ชนิด (สด ๆ — ต้องกลับเป็น 0 หลังปิดโมดูล)
  local r = snap.registry or { tasks = 0, connections = 0, renders = 0, temps = 0 }
  self.pRows.registry.obj.Text = ("task %d · connection %d · render %d · temp %d (total %d)")
    :format(r.tasks, r.connections, r.renders, r.temps, r.total or 0)

  -- Event Bus
  local b = snap.bus or { perSec = 0, queued = 0 }
  self.pRows.bus.obj.Text = ("events/sec %d · คิวค้าง %d · subscribers %d")
    :format(b.perSec or 0, b.queued or 0, b.subscribers or 0)

  -- ESP objects / Macro: ยังไม่มีโมดูล (PENDING โปร่งใส §3.9)
  self.pRows.objects.obj.Text = self:_T("ui.diag.pending")
  self.pRows.macro.obj.Text = self:_T("ui.diag.pending")

  -- ระบบ: capability + adapter + เวลา
  local sys = {}
  if snap.capability then
    local parts = {}
    local caps = {}
    for n in pairs(snap.capability) do caps[#caps + 1] = n end
    table.sort(caps)
    for _, n in ipairs(caps) do
      parts[#parts + 1] = ("%s=%s"):format(n, snap.capability[n].supported and "Y" or "N")
    end
    sys[#sys + 1] = "capability: " .. table.concat(parts, " ")
  end
  if snap.adapterHealth then
    local nApi = (snap.adapterHealth.adapters and #snap.adapterHealth.adapters) or 0
    sys[#sys + 1] = ("adapter: %s%s"):format(
      snap.adapterHealth.summary or "-",
      nApi > 0 and string.format(" (%d API)", nApi) or "")
  else
    sys[#sys + 1] = "adapter: (ยังไม่ probe)"
  end
  local m = snap.marks or {}
  sys[#sys + 1] = ("startup %sms · config load %sms · hot update %sms"):format(
    fmtMs(m.startupMs), fmtMs(m.configLoadMs), fmtMs(m.hotUpdateMs))
  sys[#sys + 1] = ("uptime %ds"):format(snap.uptimeSec or 0)
  self.pRows.system.obj.Text = table.concat(sys, "\n")

  -- กราฟ memory วาดจริง — สร้าง/คืนแท่งใน Scope ของ node นี้เสมอ
  self:_renderMemGraph(svc)
end

function Hub:_renderMemGraph(svc)
  local series = svc.MemorySeries and svc.MemorySeries() or {}
  -- คืนของเก่าก่อน (handle ทุกตัวของกราฟเดิม)
  for _, h in ipairs(self.graphBars) do
    if h.Release then h.Release() end
  end
  self.graphBars = {}
  if #series == 0 then return end

  self.runtime.Scope(Hub.NODE, function()
    local tk = self.tokens or {}
    local maxMem = 1
    local startAt = math.max(1, #series - 59) -- แท่งสูงสุด 60 อัน (15 นาที @ 5 วิ/sample ย่อ)
    for i = startAt, #series do
      local s = series[i]
      if s.memoryKb and s.memoryKb > maxMem then maxMem = s.memoryKb end
    end
    for i = startAt, #series do
      local s = series[i]
      local mem = s.memoryKb or 0
      local h = math.max(2, math.floor((mem / maxMem) * 54 + 0.5))
      local bar = self.backend:Create("Frame", {
        Name = "Bar",
        Size = UDim2.new(0, 3, 0, h),
        BackgroundColor3 = tk.accentA or nil,
        BorderSizePixel = 0, ZIndex = 52,
        LayoutOrder = #self.graphBars + 1,
      }, self.elems.graph.obj)
      self.graphBars[#self.graphBars + 1] = bar
    end
  end)
end

--- Export Diagnostics (§8.4 เครื่องมือ) — คัดลอก หรือพิมพ์คอนโซลเมื่อไม่มี clipboard
function Hub:DoExport()
  local svc = self:_svc()
  if not svc then
    self:_feedback("Diagnostics service ไม่พร้อม")
    return false
  end
  local text, ok
  if svc.ExportToClipboard then
    text, ok = svc.ExportToClipboard()
  else
    text = svc.Export()
    ok = false
  end
  text = text or ""
  if ok then
    self:_feedback(self:_T("ui.diag.exported", { n = #text }))
  else
    -- No Silent Degradation: ไม่มี clipboard = พิมพ์ออกคอนโซลให้คัดลอกเอง
    print(text)
    self:_feedback(self:_T("ui.diag.export.console"))
  end
  return true
end

--- สถานะหัว: จุด + ข้อความ (สดจาก Diagnostics — โพลล์ 1 วิ)
function Hub:RefreshStatus()
  if not self.built then return end
  local svc = self:_svc()
  local status = "ok"
  if svc then
    local snap = svc.Snapshot()
    if snap and snap.adapterHealth and snap.adapterHealth.status then
      status = snap.adapterHealth.status
    end
  end
  local dotColor = (status == "ok" and self.tokens and self.tokens.on)
    or (status == "degraded" and self.tokens and self.tokens.warn)
    or (self.tokens and self.tokens.danger)
  if self.elems.statusDot and self.elems.statusDot.obj then
    self.elems.statusDot.obj.BackgroundColor3 = dotColor
  end
  if self.elems.statusText and self.elems.statusText.obj then
    self.elems.statusText.obj.Text = self:_T(status == "ok"
      and "ui.hub.status.ready" or "ui.hub.status.degraded")
  end
end

-- ---- แท็บ ---------------------------------------------------------------------

function Hub:SwitchTab(key)
  if not self.built then return false end
  if not self.contents[key] then return false end
  self.currentTab = key
  for k, c in pairs(self.contents) do
    if c and c.obj then
      c.obj.Visible = (k == key)
    end
  end
  self:_restyleTabs()
  return true
end

function Hub:_restyleTabs()
  local tk = self.tokens or {}
  for k, btn in pairs(self.tabBtns) do
    if btn.h and btn.h.obj then
      if k == self.currentTab then
        btn.h.obj.BackgroundTransparency = 0.72
        btn.h.obj.BackgroundColor3 = tk.accentB or nil
        btn.h.obj.TextColor3 = tk.text or nil
      else
        btn.h.obj.BackgroundTransparency = 1
        btn.h.obj.TextColor3 = tk.textDim or nil
      end
    end
  end
end

function Hub:_restyleAccentBtns()
  local tk = self.tokens or {}
  for name, h in pairs(self.accentBtns) do
    if h and h.obj then
      if name == self.accent then
        h.obj.BackgroundTransparency = 0.72
        h.obj.BackgroundColor3 = tk.accentB or nil
        h.obj.TextColor3 = tk.text or nil
      else
        h.obj.BackgroundTransparency = 0.88
        h.obj.BackgroundColor3 = tk.card or nil
        h.obj.TextColor3 = tk.textDim or nil
      end
    end
  end
end

function Hub:_restyleLangBtns()
  local tk = self.tokens or {}
  local cur = self.i18n and self.i18n:Lang() or "th"
  for lang, h in pairs(self.langBtns) do
    if h and h.obj then
      if lang == cur then
        h.obj.BackgroundTransparency = 0.72
        h.obj.BackgroundColor3 = tk.accentB or nil
        h.obj.TextColor3 = tk.text or nil
      else
        h.obj.BackgroundTransparency = 0.88
        h.obj.BackgroundColor3 = tk.card or nil
        h.obj.TextColor3 = tk.textDim or nil
      end
    end
  end
end

-- ---- มองเห็น/ไม่มองเห็น (DoD: เปิด-ปิด-เปิด 20 รอบ orphan 0) ------------------

function Hub:SetVisible(v)
  if not self.built then return false end
  self.visible = v == true
  if self.mainH and self.mainH.obj then
    self.mainH.obj.Visible = self.visible
  end
  if self.elems.pill and self.elems.pill.obj then
    -- [CR-PC-ONLY] เดิมซ่อน pill ในโหมดมือถือ (MobileLayout มีปุ่มลัดลอยของตัวเอง)
    -- ตัด MobileLayout แล้ว pill จึงแสดงทุกครั้งที่ hub ถูกย่อ
    self.elems.pill.obj.Visible = not self.visible
  end
  if not self.visible and self.panelOpen then
    self:ClosePanel()
  end
  self:_saveOpen(self.visible)
  return true
end

function Hub:Toggle()
  return self:SetVisible(not self.visible)
end

-- [CR-PC-ONLY 1 ต.ค. 2026] Hub:SetLayoutMode / Hub:LayoutMode ถูกตัดออก
-- (เดิมถูกเรียกโดย MobileLayout ตาม edge ใน graph — node นั้นถูกตัดจาก scope
-- ตาม dependencies.md v1.6) UI เหลือเลย์เอาต์ desktop เดียวตาม layout
-- constants ของ ThemeEngine — อุปกรณ์ทัชอย่างเดียวก็ได้เลย์เอาต์นี้เหมือนกัน
-- ---- แปลทั้งหมดใหม่ (เปลี่ยนภาษา — DoD ห้ามข้อความค้างภาษาเดิม) ---------------

function Hub:RerenderTexts()
  if not self.built then return end
  local L = (self.tokens and self.tokens.layout) or {}
  if self.elems.logo and self.elems.logo.obj then
    self.elems.logo.obj.Text = "🕳 " .. self:_T("ui.hub.title")
  end
  if self.elems.version and self.elems.version.obj then
    self.elems.version.obj.Text = self:_T("ui.hub.version", { v = self.version })
  end
  if self.elems.search and self.elems.search.obj then
    self.elems.search.obj.Text = self:_T("ui.hub.search")
  end
  for _, tab in ipairs(Hub.TABS) do
    local btn = self.tabBtns[tab.key]
    if btn and btn.h and btn.h.obj then
      btn.h.obj.Text = self:_T("ui.hub.tab." .. tab.key)
    end
    if tab.phase > 0 and self.contents[tab.key] then
      local c = self.contents[tab.key]
      local coming = c.obj and c.obj:FindFirstChild("Coming")
      local sub = c.obj and c.obj:FindFirstChild("ComingSub")
      if coming then
        coming.Text = self:_T("ui.hub.coming", { name = tab.name, phase = tab.phase })
      end
      if sub then
        sub.Text = self:_T("ui.hub.coming.sub")
      end
    end
  end
  if self.feedback.h and self.feedback.h.obj then
    -- ป้ายผลลัพธ์ไม่ต้องแปลซ้ำ (เป็นผลลัพธ์ล่าสุด — ว่างได้)
    self.feedback.h.obj.Text = self.feedback.text
  end
  self:RefreshStatus()
  if self.panelOpen then self:RefreshPanel() end
end

-- ---- theme -----------------------------------------------------------------

function Hub:ApplyTheme(tokens)
  self.tokens = tokens
  if not self.built then return self end
  local S = self.styling
  for _, h in ipairs(S.cards) do
    if h and h.obj then h.obj.BackgroundColor3 = tokens.card end
  end
  for _, h in ipairs(S.strokes) do
    if h and h.obj then h.obj.Color = tokens.border end
  end
  for _, h in ipairs(S.textMain) do
    if h and h.obj then h.obj.TextColor3 = tokens.text end
  end
  for _, h in ipairs(S.textDim) do
    if h and h.obj then h.obj.TextColor3 = tokens.textDim end
  end
  for _, h in ipairs(S.hilite) do
    if h and h.obj then h.obj.TextColor3 = tokens.hilite end
  end
  self:_restyleTabs()
  self:_restyleAccentBtns()
  self:_restyleLangBtns()
  self:RefreshStatus()
  return self
end

-- ---- สถานะ / ปิด ------------------------------------------------------------

function Hub:Stats()
  return {
    built = self.built,
    visible = self.visible,
    tab = self.currentTab,
    panelOpen = self.panelOpen,
    accent = self.accent,
  }
end

function Hub:Shutdown()
  if self.runtime and self.runtime.Release then
    self.runtime.Release(Hub.NODE)
  end
  self.graphBars = {}
  self.built = false
  self.panelOpen = false
  return true
end

return Hub
