-- ============================================================================
-- The Voider — core/ui/init.lua
-- UI Layer assembler (เฟส 1 — แผน freeze v2.1 §3.8 + §3.10)
--
-- ประกอบ L6 ทั้งหมดตามลำดับ dependency graph:
--   ThemeEngine → Hub → HUD → Notification
--
-- [CR-PC-ONLY 1 ต.ค. 2026] node MobileLayout ถูกตัดออกจาก graph
--   (dependencies.md v1.6: 39→38 node) — PC/Desktop only บน Volt —
--   อุปกรณ์ทัชอย่างเดียวก็ได้เลย์เอาต์ desktop เดิม (PC-only guard
--   ใน qa/l1_unit/test_ui.lua กันถอยหลัง)
--
-- SSOT enforcement (§3.10): ตรวจว่าชื่อ node ที่ layer นี้ดูแลอยู่ใน
-- Graph.initOrder ครบทุกตัว — ไม่ตรง = error ทันที (แบบเดียวกับ
-- foundation/adapter)
--
-- จุดต่อของชั้นนี้ (composition root — วิธีเดียวกับ foundation/init.lua
-- ที่ถือ service ทั้งชุดแล้วส่งต่อ):
--   Backend    root จาก ctx.guiRoot หรือ gethui() — ไม่มี = graceful
--              disable + แจ้ง plain text (§3.2 ข้อ 0 pattern)
--   ThemeEngine ถูกอ่าน/สั่งเฉพาะที่นี่ — node อื่นรับ "token" และ
--              callback จาก assembler (ไม่ต้องเพิ่ม edge ใน graph)
--              เปลี่ยน accent = SetAccent + เขียน config + fanout
--              ApplyTheme ให้ทุก node ตามลำดับ graph
--   i18n       Hub/Notification = declared dep ตรง; HUD รับ F.I18n ตามแบบ
--              probe.lua (แปลป้าย); ข้อมูลแผง Diagnostics ผ่าน Direct
--              Service "Diagnostics" (ambient §3.5 — ตามแบบ bundle selftest)
--
-- ใช้งาน:
--   local U = UiLib.new({ runtime = R, foundation = F, version = "0.7.0" })
--   U:Bootstrap()   -- Render ทุก node (resource ลง Scope ของ node ตัวเอง)
--   U.Theme / U.Backend / U.Hub / U.HUD / U.Notify
--   -- ปิดทั้งชุดผ่าน R.ShutdownAll() (hook ลงทะเบียนครบตามชื่อ node)
-- ============================================================================

local P = __TV_PACKAGES
local BackendLib = P.ui_backend
local ThemeLib = P.ui_theme
local HubLib = P.ui_hub
local HudLib = P.ui_hud
local NotifyLib = P.ui_notify

local UiLib = {}
UiLib.version = "0.1.0"

-- ชื่อ node ตาม dependency graph (SSOT §3.10) — MobileLayout ตัดออกตาม CR-PC-ONLY
UiLib.NODES = {
  "ThemeEngine",
  "Hub",
  "HUD",
  "Notification",
}

function UiLib.new(ctx)
  ctx = ctx or {}
  local R = ctx.runtime
  local F = ctx.foundation
  if not R or not R.Registry or not R.Graph or not R.Shutdown then
    error("UiLib.new({ runtime = R }): ต้องส่ง Runtime ครบ (Registry/Graph/Shutdown)", 2)
  end
  if not F or not F.Config or not F.I18n or not F.Bus
    or not F.Keybind or not F.Diag or not F.Services then
    error("UiLib.new({ foundation = F }): ต้องส่ง Foundation ครบ "
      .. "(Config/I18n/Bus/Keybind/Diag/Services)", 2)
  end

  -- ---- SSOT check: node ของ UI ต้องอยู่ใน graph ครบ ------------------------
  local inGraph = {}
  for _, n in ipairs(R.Graph.initOrder) do
    inGraph[n] = true
  end
  for _, n in ipairs(UiLib.NODES) do
    if not inGraph[n] then
      error(("UI: node %q ไม่อยู่ใน dependency graph (dependencies.md) — "
        .. "โค้ดกับ SSOT คลาดเคลื่อน แก้ที่ dependencies.md ก่อน (§3.10)"):format(n), 2)
    end
  end

  local U = {}
  U.version = UiLib.version
  U.runtime = R
  U.foundation = F

  local logger = ctx.logger or function(level, msg)
    local w = (level == "warn" or level == "error")
      and (type(warn) == "function" and warn or print)
      or print
    w(("[The Voider][UI][%s] %s"):format(level, msg))
  end

  -- 1) Backend — root resolution (gethui ของ executor / ctx.guiRoot ของเทส)
  U.Backend = BackendLib.new({
    runtime = R,
    guiRoot = ctx.guiRoot,
    logger = logger,
    clock = ctx.clock,
  })

  -- 2) ThemeEngine + accent จาก config (§3.7 ของผู้ใช้ — ห้ามทิ้ง)
  U.Theme = ThemeLib.new()
  do
    local saved = F.Config:Get("ui.accent")
    if type(saved) == "string" and #saved > 0 then
      local ok = U.Theme:SetAccent(saved)
      if not ok then
        -- ค่าเก่าไม่รองรับ (เช่น config จากอนาคต) — กลับ default + แจ้ง + เขียนกลับ
        logger("warn", ("accent %q ใน config ไม่รองรับ — ใช้ %s แทน")
          :format(saved, U.Theme:Accent()))
        F.Config:Set("ui.accent", U.Theme:Accent(), { save = true })
      end
    end
  end

  -- รายการ node ที่ได้รับ ApplyTheme (fanout ตามลำดับ graph)
  local themeConsumers = {}

  -- เปลี่ยน accent ผ่านจุดเดียว: theme + config + fanout ทุก node
  local function setAccent(name)
    local ok, err = U.Theme:SetAccent(name)
    if not ok then
      return false, err
    end
    F.Config:Set("ui.accent", name, { save = true })
    local tokens = U.Theme:Get()
    for _, node in ipairs(themeConsumers) do
      if node and node.ApplyTheme then
        node:ApplyTheme(tokens)
      end
    end
    return true
  end

  -- 3) สร้าง node ตามลำดับ graph (ThemeEngine แล้ว → Hub ต้องการ token)
  local tokens = U.Theme:Get()

  U.Hub = HubLib.new({
    runtime = R,
    backend = U.Backend,
    config = F.Config,
    i18n = F.I18n,
    services = F.Services,
    tokens = tokens,
    clock = ctx.clock,
    version = ctx.version,
    accents = U.Theme:ListAccents(),
    accent = U.Theme:Accent(),
    setAccent = setAccent,
  })

  U.HUD = HudLib.new({
    runtime = R,
    backend = U.Backend,
    bus = F.Bus,
    diag = F.Diag,
    i18n = F.I18n,
    tokens = tokens,
    clock = ctx.clock,
  })

  U.Notify = NotifyLib.new({
    runtime = R,
    backend = U.Backend,
    bus = F.Bus,
    i18n = F.I18n,
    tokens = tokens,
  })

  themeConsumers = { U.Hub, U.HUD, U.Notify }

  -- 4) (ถอดออกภายหลังการตรวจสอบ) เดิมวาง subscriber i18n:changed ระดับชั้น
  --    ไว้ใต้ Scope("EventBus") — ผิดหลัก orphan ราย node (§3.10): ทรัพยากร
  --    จะตกเป็นของ "EventBus" แล้ว row นั้นเห็น orphan > 0 ตอน TEARDOWN
  --    ทางที่ถูกตาม graph: Notification/HUD ฟัง i18n:changed เองใน Scope ของ
  --    ตัวเอง (ทั้งคู่มี EventBus เป็น declared dep) ส่วน Hub ไม่มี bus เป็น
  --    dep — Hub เป็นผู้กดปุ่มเปลี่ยนภาษาเอง จึงเรียก RerenderTexts เองหลัง Set

  -- 5) Shutdown hooks ตามชื่อ node (TEARDOWN = Init กลับด้าน §3.10)
  -- ThemeEngine: pure (ไม่ถือ resource) — ไม่มี hook (Shutdown ข้ามให้เอง)
  R.Shutdown:Register("Hub", {
    Destroy = function() U.Hub:Shutdown() end,
  })
  R.Shutdown:Register("HUD", {
    Destroy = function() U.HUD:Shutdown() end,
  })
  R.Shutdown:Register("Notification", {
    Destroy = function() U.Notify:Shutdown() end,
  })

  -- 6) Bootstrap — Notification subscribe เสมอ (แม้ degraded — ห้ามเงียบ
  --    §3.9 #5) ส่วน node ที่ต้องมี GUI เรนเดอร์เฉพาะเมื่อ backend พร้อม
  --    (คืน false+reason — ผู้ใช้ถูกแจ้งจาก Backend แล้ว)
  function U:Bootstrap()
    U.Notify:Render()
    if not U.Backend.available then
      return U
    end
    U.Hub:Render()
    U.HUD:Render()
    -- สำหรับเฟส 2+: โมดูลต่าง ๆ จะ Render เนื้อหาในแท็บของตัวเองผ่าน
    -- U.Hub ตอนนี้ (ยังไม่มี L5 ในเฟส 1)
    return U
  end

  return U
end

return UiLib
