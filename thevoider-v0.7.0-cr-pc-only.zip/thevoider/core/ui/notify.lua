-- ============================================================================
-- The Voider — core/ui/notify.lua
-- Notification (เฟส 1 UI Framework — แผน freeze v2.1 §8.2 + §3.5 + §5.4)
--
-- node L6 ตาม dependency graph: Notification | แจ้งเตือนภาษาไทย
-- (No Silent Degradation) | deps: EventBus, I18nService
--
--   ฟัง "notify:user" จาก Event Bus (payload { level, key, params } หรือ
--   { level, text }) → toast 4 อันล่าสุด + TTL 5 วิ + แตะปิดได้
--   สีตาม level: info/hilite · success/on · warn/warn · error/danger (§8.1)
--   เปลี่ยนภาษา → แปล toast ที่ยังเปิดอยู่ใหม่ทั้งหมด (DoD: ห้ามข้อความ
--   ค้างภาษาเดิม)
--
--   UI ไม่ available (ไม่มี gui root): ยังรับ event และพิมพ์ plain text
--   ตามแบบ §3.2 ข้อ 0 — ไม่เงียบ (§3.9 #5)
--
-- กฎ resource: ทุก instance/connection/task สร้างภายใต้ Scope("Notification")
-- เสมอ — รวมที่ตอน bus dispatch (Push ต้องเปิด Scope เอง) และการปิด
-- toast รายตัวปล่อย handle ทุกตัวของ toast นั้น (พ่อถูกทำลาย cascade
-- ลูกในเกมจริง แต่ handle ของลูกต้องคืนระบบเอง — ไม่งั้นนับเป็น orphan)
-- ============================================================================

local Notification = {}
Notification.__index = Notification

Notification.NODE = "Notification"
Notification.VERSION = "0.1.0"

Notification.MAX_TOASTS = 4   -- เกิน = ปิดอันเก่าสุดทันที (บันทึกใน stats)
Notification.TTL = 5          -- วินาที แล้วหายเอง
Notification.WIDTH = 280
Notification.HEIGHT = 48      -- ≥ 44 (ความสูงปุ่มมาตรฐาน — คลิกปิดได้)

Notification.LEVELS = { info = true, success = true, warn = true, error = true }

-- i18n keys ของ node นี้ (เจ้าของ key เอง — ตามแบบ i18n.lua)
Notification.I18N = {
  th = {
    ["ui.notify.plain.prefix"] = "แจ้งเตือน",
  },
  en = {
    ["ui.notify.plain.prefix"] = "Notice",
  },
}

function Notification.new(ctx)
  ctx = ctx or {}
  local self = setmetatable({
    runtime = ctx.runtime,
    backend = ctx.backend,
    bus = ctx.bus,        -- EventBus (declared dep)
    i18n = ctx.i18n,      -- I18nService (declared dep)
    tokens = ctx.tokens,
    toasts = {},          -- ลำดับจากเก่า → ใหม่
    gui = nil,
    holder = nil,
    built = false,
    stats = { total = 0, droppedOldest = 0, plainText = 0 },
  }, Notification)
  if self.i18n then
    self.i18n:AddTable("th", Notification.I18N.th)
    self.i18n:AddTable("en", Notification.I18N.en)
  end
  return self
end

-- ---- helpers -------------------------------------------------------------------

--- ข้อความของ payload (key → แปลผ่าน i18n / text → ตรง ๆ / ไม่มี = หลุดโปร่งใส)
function Notification:TextOf(p)
  if p == nil then return "(no payload)" end
  if type(p.text) == "string" then return p.text end
  if type(p.key) == "string" and self.i18n then
    return self.i18n:T(p.key, p.params)
  end
  return "(no text)"
end

--- สีของ level จาก token ปัจจุบัน
function Notification:LevelColor(level)
  local t = self.tokens
  if t and t.toastColor and t.toastColor[level] then
    return t.toastColor[level]
  end
  return nil, "ยังไม่มี theme token"
end

-- ---- สร้าง UI ครั้งเดียว -------------------------------------------------------

function Notification:Render()
  -- 1) subscribe ก่อนเสมอ — แม้ไม่มี GUI (degraded) เพราะการแจ้งเตือน
  --    ห้ามหายเงียบ ๆ (§3.9 #5): event ที่มาถึงตอนไม่มี UI จะถูกพิมพ์เป็น
  --    plain text ตามแบบ §3.2 ข้อ 0
  if not self.subscribed then
    local R = self.runtime
    R.Scope(Notification.NODE, function()
      self.bus:On("notify:user", function(p)
        self:Push(p)
      end)
      self.bus:On("i18n:changed", function()
        self:Retranslate()
      end)
    end)
    self.subscribed = true
  end

  if not self.backend.available then
    return false, self.backend.reason
  end
  if self.built then return true end
  local R = self.runtime
  R.Scope(Notification.NODE, function()
    local tk = self.tokens
    self.gui = self.backend:Create("ScreenGui", {
      Name = "TVNotify",
      DisplayOrder = 90,
      ResetOnSpawn = false,
    })
    self.holder = self.backend:Create("Frame", {
      Name = "Holder",
      AnchorPoint = UDim2.new(1, 0, 0, 0),
      Position = UDim2.new(1, -16, 0, 20),
      Size = UDim2.new(0, Notification.WIDTH, 1, -40),
      BackgroundTransparency = 1,
    }, self.gui.obj)
    self.backend:Create("UIListLayout", {
      Name = "List",
      Padding = UDim.new(0, 8),
      SortOrder = Enum.SortOrder.LayoutOrder,
      HorizontalAlignment = Enum.HorizontalAlignment.Right,
    }, self.holder.obj)
  end)
  self.built = true
  return true
end

-- ---- รับการแจ้งเตือน -----------------------------------------------------------

--- push ตรง (ใช้ในเทส/อนาคต) — รูปเดียวกับ event บน bus
function Notification:Push(p)
  p = p or {}
  local level = Notification.LEVELS[p.level] and p.level or "info"
  self.stats.total = self.stats.total + 1

  if not self.built then
    -- UI ไม่มี — plain text ตามแบบ §3.2 ข้อ 0 (ไม่เงียบ §3.9 #5)
    self.stats.plainText = self.stats.plainText + 1
    local prefix = self.i18n and self.i18n:T("ui.notify.plain.prefix") or "Notice"
    print(("[The Voider][%s] %s"):format(prefix, self:TextOf(p)))
    return false, "UI unavailable"
  end

  -- เกินโควต้า → ปิดอันเก่าสุดทันที
  while #self.toasts >= Notification.MAX_TOASTS do
    self:Dismiss(self.toasts[1])
    self.stats.droppedOldest = self.stats.droppedOldest + 1
  end

  local R = self.runtime
  R.Scope(Notification.NODE, function()
    local tk = self.tokens
    local tkLayout = tk and tk.layout or { PAD = 12, RADIUS = 10, STROKE = 1 }
    local glass = tk and (1 - tk.glass.CARD_ALPHA) or 0.88

    local entry = {
      level = level,
      key = type(p.key) == "string" and p.key or nil,
      params = type(p.params) == "table" and p.params or nil,
      text = type(p.text) == "string" and p.text or nil,
      handles = {},
      alive = { true },
    }
    local text = self:TextOf(p)

    -- ปุ่มทั้ง toast (คลิก = ปิด) — สูง 48 ≥ 44 (ปุ่มมาตรฐาน — CR-PC-ONLY: เดิมอ้าง gate ทัช §5.4)
    local btn = self.backend:Create("TextButton", {
      Name = "Toast",
      Size = UDim2.new(1, 0, 0, Notification.HEIGHT),
      BackgroundColor3 = tk and tk.card or nil,
      BackgroundTransparency = glass,
      Text = "",
      AutoButtonColor = false,
      LayoutOrder = #self.toasts + 1,
    }, self.holder.obj)
    entry.handles[#entry.handles + 1] = btn

    local bar = self.backend:Create("Frame", {
      Name = "LevelBar",
      BackgroundColor3 = self:LevelColor(level),
      BorderSizePixel = 0,
      Position = UDim2.new(0, 0, 0, 0),
      Size = UDim2.new(0, 4, 1, 0),
    }, btn.obj)
    entry.handles[#entry.handles + 1] = bar

    local label = self.backend:Create("TextLabel", {
      Name = "Text",
      BackgroundTransparency = 1,
      Position = UDim2.new(0, 14, 0, 0),
      Size = UDim2.new(1, -22, 1, 0),
      Font = Enum.Font.Gotham,
      Text = text,
      TextSize = tkLayout.FONT_SIZE or 14,
      TextColor3 = tk and tk.text or nil,
      TextWrapped = true,
      TextXAlignment = Enum.TextXAlignment.Left,
      TextYAlignment = Enum.TextYAlignment.Center,
    }, btn.obj)
    entry.handles[#entry.handles + 1] = label
    entry.label = label -- หยิบป้ายแบบเจาะจง (handles ยาวไม่คงที่)

    -- ตกแต่ง + connection เก็บ handle ด้วย: การปิด toast รายตัวต้องคืน
    -- "ทุก" resource ของ toast นั้น — ลูกถูกทำลาย cascade ไปกับพ่อในเกม
    -- จริง แต่ handle ใน Registry ต้องคืนเอง ไม่งั้นนับเป็น orphan สะสม
    entry.handles[#entry.handles + 1] = self.backend:Create("UICorner",
      { CornerRadius = UDim.new(0, tkLayout.RADIUS or 10) }, btn.obj)
    entry.handles[#entry.handles + 1] = self.backend:Create("UIStroke", {
      Color = tk and tk.border or nil,
      Thickness = tkLayout.STROKE or 1,
      Transparency = 0.35,
    }, btn.obj)

    local clickConn = self.backend:OnClick(btn, function()
      self:Dismiss(entry)
    end)
    if clickConn then
      entry.handles[#entry.handles + 1] = clickConn
    end

    -- โผล่เข้ามาแบบนุ่ม 0.15 วิ (§8.2) — task จบเอง = deregister เอง
    self.backend:Fade(btn, "BackgroundTransparency", glass, math.min(1, glass + 0.35), tk and tk.anim.FAST or 0.15)

    -- TTL: หายเองเมื่อครบเวลา (task ชั่วคราว — ยกเลิกได้ทั้งจากการปิดเอง
    -- และจาก Registry:Release ตอน TEARDOWN)
    local alive = entry.alive
    self.runtime.Spawn("toast:ttl", function(ctx)
      ctx.Wait(Notification.TTL)
      if not ctx.ShouldRun() then return end
      if not alive[1] then return end
      self:Dismiss(entry)
    end)

    table.insert(self.toasts, entry)
  end)
  return true
end

--- ปิด toast รายตัว — ปล่อย handle ทุกตัวของ entry (กัน orphan จาก cascade)
function Notification:Dismiss(entry)
  if not entry or not entry.alive then return false end
  entry.alive[1] = false
  for i = #self.toasts, 1, -1 do
    if self.toasts[i] == entry then
      table.remove(self.toasts, i)
    end
  end
  for _, h in ipairs(entry.handles) do
    if h and h.Release then h.Release() end
  end
  entry.handles = {}
  return true
end

--- แปล toast ที่ยังเปิดอยู่ใหม่ทั้งหมด (เปลี่ยนภาษา — DoD ห้ามค้างภาษาเดิม)
function Notification:Retranslate()
  for _, entry in ipairs(self.toasts) do
    local label = entry.label
    if label and label.obj and entry.key then
      label.obj.Text = self:TextOf({ key = entry.key, params = entry.params })
    end
  end
end

-- ---- theme -----------------------------------------------------------------

function Notification:ApplyTheme(tokens)
  self.tokens = tokens
  if not self.built then return self end
  for _, entry in ipairs(self.toasts) do
    local btn = entry.handles[1]
    local bar = entry.handles[2]
    local label = entry.label
    if btn and btn.obj then
      btn.obj.BackgroundColor3 = tokens.card
    end
    if bar and bar.obj then
      bar.obj.BackgroundColor3 = self:LevelColor(entry.level)
    end
    if label and label.obj then
      label.obj.TextColor3 = tokens.text
    end
  end
  return self
end

-- ---- สถานะ / ปิด ------------------------------------------------------------

function Notification:Stats()
  return {
    active = #self.toasts,
    total = self.stats.total,
    droppedOldest = self.stats.droppedOldest,
    plainText = self.stats.plainText,
    built = self.built,
  }
end

--- ปิด node (TEARDOWN) — Registry คืน resource ทั้งหมดของ owner นี้
--- (render/connection/temp รวม ttl task) แล้วล้างสถานะ
function Notification:Shutdown()
  if self.runtime and self.runtime.Release then
    self.runtime.Release(Notification.NODE)
  end
  for _, e in ipairs(self.toasts) do
    if e.alive then e.alive[1] = false end
  end
  self.toasts = {}
  self.built = false
  return true
end

return Notification
